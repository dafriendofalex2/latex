"""Burst-conditional probability model for the five severity cases.

The model estimates P(S=s | B=1), not P(B=1). A qualifying burst is defined
by a drawdown D >= 40% following a qualifying run-up. The five deterministic
stress scenarios are representative points in a continuous loss-severity
space. Probability mass is assigned using Voronoi cells in positive log-loss
coordinates L=-log(1-D).

Because the primary historical sample contains only 21 exact event-level burst
severities, the baseline estimator model-averages four parsimonious continuous
families using AICc weights and quantifies uncertainty with episode-level
bootstrap refits. A Jeffreys-prior Dirichlet calculation provides a low-
assumption cross-check. A GPD fit is retained only as a tail-instability
diagnostic rather than the production estimator.
"""
from __future__ import annotations

import warnings
from dataclasses import dataclass
from typing import Dict, Iterable, Tuple

import numpy as np
import pandas as pd
from scipy import optimize, stats

BURST_THRESHOLD = 0.40
SCENARIO_ORDER = ["mild", "base", "severe", "extreme", "worst"]
DEFAULT_ANCHORS = np.array([0.319, 0.537, 0.639, 0.753, 0.831], dtype=float)
EPS = 1e-12


@dataclass
class CandidateFit:
    model: str
    params: tuple
    log_likelihood: float
    n_parameters: int
    aicc: float


def positive_log_loss(drawdown):
    d = np.asarray(drawdown, dtype=float)
    if np.any((d < 0) | (d >= 1)):
        raise ValueError("drawdown must lie in [0,1)")
    return -np.log1p(-d)


def drawdown_from_log_loss(log_loss):
    return 1.0 - np.exp(-np.asarray(log_loss, dtype=float))


def scenario_cells(
    anchors: Iterable[float] = DEFAULT_ANCHORS,
    burst_threshold: float = BURST_THRESHOLD,
) -> pd.DataFrame:
    """Create nearest-representative Voronoi cells in positive log-loss space."""
    d = np.asarray(list(anchors), dtype=float)
    if len(d) != 5 or not np.all(np.diff(d) > 0):
        raise ValueError("five strictly increasing anchors are required")
    L = positive_log_loss(d)
    boundaries_L = 0.5 * (L[:-1] + L[1:])
    boundaries_D = drawdown_from_log_loss(boundaries_L)
    lower = np.r_[burst_threshold, boundaries_D[:-0] if False else boundaries_D]
    # Explicit construction avoids a hard-to-read slicing trick.
    cell_lower = np.array([burst_threshold, *boundaries_D], dtype=float)
    cell_upper = np.array([*boundaries_D, 1.0], dtype=float)
    return pd.DataFrame({
        "scenario": SCENARIO_ORDER,
        "representative_drawdown": d,
        "representative_log_loss": L,
        "cell_lower": cell_lower,
        "cell_upper": cell_upper,
    })


def _aicc(log_likelihood: float, k: int, n: int) -> float:
    aic = -2.0 * log_likelihood + 2.0 * k
    if n <= k + 1:
        return np.inf
    return aic + 2.0 * k * (k + 1.0) / (n - k - 1.0)


def _beta_nll(log_params, drawdowns, threshold):
    a, b = np.exp(log_params)
    y = (drawdowns - threshold) / (1.0 - threshold)
    if np.any((y <= 0) | (y >= 1)):
        # Observed points in the data are interior; this branch mainly protects
        # generalized use with boundary observations.
        y = np.clip(y, EPS, 1.0 - EPS)
    logpdf = stats.beta.logpdf(y, a, b) - np.log(1.0 - threshold)
    return -float(np.sum(logpdf))


def _positive_excess_log_loss(drawdowns, threshold):
    u = float(positive_log_loss([threshold])[0])
    x = positive_log_loss(drawdowns) - u
    return np.maximum(x, EPS)


def _transformed_nll(log_params, drawdowns, threshold, family):
    p1, p2 = np.exp(log_params)
    x = _positive_excess_log_loss(drawdowns, threshold)
    if family == "gamma":
        logpdf_x = stats.gamma.logpdf(x, a=p1, scale=p2)
    elif family == "weibull":
        logpdf_x = stats.weibull_min.logpdf(x, c=p1, scale=p2)
    elif family == "lognormal":
        # Parameterization: sigma=p1, scale=exp(mu)=p2.
        logpdf_x = stats.lognorm.logpdf(x, s=p1, scale=p2)
    else:
        raise ValueError(f"unknown family {family}")
    # x = -log(1-D) - constant; dx/dD = 1/(1-D).
    jacobian = -np.log1p(-drawdowns)
    return -float(np.sum(logpdf_x + jacobian))


def fit_candidate_models(
    drawdowns: Iterable[float],
    burst_threshold: float = BURST_THRESHOLD,
) -> Dict[str, CandidateFit]:
    """Fit Beta, Gamma, Weibull and Lognormal conditional severity families."""
    d = np.asarray(list(drawdowns), dtype=float)
    if np.any(d < burst_threshold) or np.any(d >= 1.0):
        raise ValueError("all observations must satisfy threshold <= D < 1")
    n = len(d)
    fits = {}

    specs = {
        "beta": lambda lp: _beta_nll(lp, d, burst_threshold),
        "gamma": lambda lp: _transformed_nll(lp, d, burst_threshold, "gamma"),
        "weibull": lambda lp: _transformed_nll(lp, d, burst_threshold, "weibull"),
        "lognormal": lambda lp: _transformed_nll(lp, d, burst_threshold, "lognormal"),
    }
    starts = {
        "beta": np.log([2.0, 2.0]),
        "gamma": np.log([2.0, 0.25]),
        "weibull": np.log([1.5, 0.35]),
        "lognormal": np.log([0.7, 0.25]),
    }

    for name, objective in specs.items():
        res = optimize.minimize(
            objective, starts[name], method="Nelder-Mead",
            options={"maxiter": 5000, "xatol": 1e-10, "fatol": 1e-10},
        )
        if not res.success:
            # Retry with BFGS; bootstrap resamples can be numerically awkward.
            res = optimize.minimize(objective, res.x, method="BFGS")
        params = tuple(np.exp(res.x))
        ll = -float(objective(res.x))
        fits[name] = CandidateFit(name, params, ll, 2, _aicc(ll, 2, n))
    return fits


def aicc_weights(fits: Dict[str, CandidateFit]) -> Dict[str, float]:
    vals = np.array([fit.aicc for fit in fits.values()], dtype=float)
    delta = vals - np.nanmin(vals)
    raw = np.exp(-0.5 * delta)
    raw = raw / raw.sum()
    return {name: float(w) for name, w in zip(fits.keys(), raw)}


def _conditional_cdf(d, fit: CandidateFit, threshold=BURST_THRESHOLD):
    d = np.asarray(d, dtype=float)
    out = np.zeros_like(d, dtype=float)
    out[d >= 1.0] = 1.0
    mask = (d > threshold) & (d < 1.0)
    if not np.any(mask):
        return out
    if fit.model == "beta":
        a, b = fit.params
        y = (d[mask] - threshold) / (1.0 - threshold)
        out[mask] = stats.beta.cdf(np.clip(y, 0.0, 1.0), a, b)
    else:
        p1, p2 = fit.params
        x = _positive_excess_log_loss(d[mask], threshold)
        if fit.model == "gamma":
            out[mask] = stats.gamma.cdf(x, a=p1, scale=p2)
        elif fit.model == "weibull":
            out[mask] = stats.weibull_min.cdf(x, c=p1, scale=p2)
        elif fit.model == "lognormal":
            out[mask] = stats.lognorm.cdf(x, s=p1, scale=p2)
        else:
            raise ValueError(fit.model)
    return out


def cell_probabilities_for_fit(
    fit: CandidateFit,
    cells: pd.DataFrame,
    threshold: float = BURST_THRESHOLD,
) -> np.ndarray:
    lo = cells["cell_lower"].to_numpy(float)
    hi = cells["cell_upper"].to_numpy(float)
    cdf_lo = _conditional_cdf(lo, fit, threshold)
    cdf_hi = _conditional_cdf(hi, fit, threshold)
    # The conditioning distribution begins at threshold, so CDF(threshold)=0.
    p = np.maximum(cdf_hi - cdf_lo, 0.0)
    p[-1] += max(0.0, 1.0 - p.sum())
    return p / p.sum()


def estimate_probabilities(
    drawdowns: Iterable[float],
    anchors: Iterable[float] = DEFAULT_ANCHORS,
    threshold: float = BURST_THRESHOLD,
):
    cells = scenario_cells(anchors, threshold)
    fits = fit_candidate_models(drawdowns, threshold)
    weights = aicc_weights(fits)
    per_model = {}
    averaged = np.zeros(5)
    for name, fit in fits.items():
        p = cell_probabilities_for_fit(fit, cells, threshold)
        per_model[name] = p
        averaged += weights[name] * p
    result = cells.copy()
    result["probability"] = averaged
    return result, fits, weights, per_model


def bootstrap_probabilities(
    drawdowns: Iterable[float],
    n_boot: int = 5000,
    seed: int = 20260810,
    anchors: Iterable[float] = DEFAULT_ANCHORS,
    threshold: float = BURST_THRESHOLD,
) -> pd.DataFrame:
    """Episode-level nonparametric bootstrap with full ensemble refit."""
    d = np.asarray(list(drawdowns), dtype=float)
    rng = np.random.default_rng(seed)
    rows = []
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        for b in range(int(n_boot)):
            sample = rng.choice(d, size=len(d), replace=True)
            try:
                result, _, _, _ = estimate_probabilities(sample, anchors, threshold)
                p = result["probability"].to_numpy(float)
            except Exception:
                # Rare optimization failure: skip rather than silently substitute.
                continue
            rows.append([b, *p])
    return pd.DataFrame(rows, columns=["bootstrap_id", *SCENARIO_ORDER])


def probability_intervals(bootstrap: pd.DataFrame, alpha: float = 0.10) -> pd.DataFrame:
    rows = []
    for scenario in SCENARIO_ORDER:
        rows.append({
            "scenario": scenario,
            "lower": float(bootstrap[scenario].quantile(alpha / 2.0)),
            "median": float(bootstrap[scenario].quantile(0.50)),
            "upper": float(bootstrap[scenario].quantile(1.0 - alpha / 2.0)),
        })
    return pd.DataFrame(rows)


def dirichlet_crosscheck(
    drawdowns: Iterable[float],
    cells: pd.DataFrame,
    jeffreys_alpha: float = 0.5,
):
    """Jeffreys-prior Dirichlet posterior mean over observed cell counts."""
    d = np.asarray(list(drawdowns), dtype=float)
    counts = []
    for i, row in cells.iterrows():
        if i < len(cells) - 1:
            n = np.sum((d >= row["cell_lower"]) & (d < row["cell_upper"]))
        else:
            n = np.sum((d >= row["cell_lower"]) & (d <= row["cell_upper"]))
        counts.append(int(n))
    counts = np.asarray(counts, dtype=float)
    posterior = counts + jeffreys_alpha
    mean = posterior / posterior.sum()
    return counts.astype(int), mean


def gpd_tail_diagnostic(
    drawdowns: Iterable[float],
    threshold: float = BURST_THRESHOLD,
) -> dict:
    """Small-sample EVT diagnostic; not used to set production probabilities."""
    d = np.asarray(list(drawdowns), dtype=float)
    u = float(positive_log_loss([threshold])[0])
    excess = positive_log_loss(d) - u
    shape, loc, scale = stats.genpareto.fit(excess, floc=0)
    endpoint_log = np.inf if shape >= 0 else u - scale / shape
    endpoint_drawdown = 1.0 if not np.isfinite(endpoint_log) else 1.0 - np.exp(-endpoint_log)
    return {
        "shape": float(shape),
        "scale": float(scale),
        "finite_endpoint_drawdown": float(endpoint_drawdown),
    }


def conditional_weighted_metric(case_values, probabilities):
    """E[Y | B=1] for any five-case metric already produced by the stress engine."""
    y = np.asarray(case_values, dtype=float)
    p = np.asarray(probabilities, dtype=float)
    if len(y) != 5 or len(p) != 5:
        raise ValueError("five case values and five probabilities are required")
    return float(np.dot(y, p / p.sum()))
