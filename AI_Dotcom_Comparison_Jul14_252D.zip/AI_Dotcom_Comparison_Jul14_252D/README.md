AI Dot-Com Comparison - Jul. 14 cutoff, 252 trading day window

This bundle uses a fixed Jul. 14, 2026 cutoff and a 252-trading-day window, as requested.

Key outputs
- Window length: 252 trading days
- Current window: 2025-07-14 to 2026-07-14
- Dot-com peak: 2000-03-27
- Best-fit lead: 54 trading days
- Final-window path correlation: 0.8390
- Final-window RMSE: 0.2136
- Best-fit RMSE: 0.0916
- Best-fit correlation: 0.9007
- Remaining historical move from matched point: 33.2936%

Note
With a Jul. 14, 2026 cutoff and a 252-day window, the best-fit lead sits near the boundary. This bundle keeps the requested specification but should be interpreted as a narrative similarity deck rather than a strict timing exercise.
