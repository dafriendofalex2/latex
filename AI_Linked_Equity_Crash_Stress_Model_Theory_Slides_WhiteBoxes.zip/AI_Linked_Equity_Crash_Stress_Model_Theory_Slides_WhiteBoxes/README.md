This bundle replicates the revised theory and probability slide decks with white/transparent-style backgrounds for blocks, tables, and labels instead of colored fills.
