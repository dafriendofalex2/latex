#!/usr/bin/env bash
set -e
pdflatex main.tex
pdflatex main.tex
