# AI bubble impact research v6 final

Corrected comparative analysis package.

Main corrections from prior drafts:
- Projection lines are connected to the final actual observation.
- AI-vs-dot-com comparison charts show both current AI and dot-com/TMT lines.
- The signal chart separates current AI peak risk from current latest signal; the latest signal being low is explicitly treated as a data result, not hidden.
- Platform names such as GOOGL are not assigned zero AI exposure. A hybrid regression plus economic exposure multiplier is used.
- The report explains mathematical definitions, figure interpretation, known problems, and next steps.

Files:
- `main.pdf`: compiled report.
- `main.tex`: LaTeX source. It uses only default LaTeX plus `graphicx`.
- `figures/`: exported PNG charts.
- `data/`: CSV outputs and vectors.
- `data_dictionary.md`: description of data files.

This is a research prototype, not a production risk engine. The report explicitly lists what remains to make it deliverable.
