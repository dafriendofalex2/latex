# AI-Linked Equity Crash Stress Model - Revised Theory Slides

This bundle contains two separate LaTeX Beamer slideshows:

1. `Model_Framework_Slides.pdf` - 8 slides covering the deterministic stress model.
2. `Probability_Model_Slides.pdf` - 3 slides covering the separate conditional probability model.

Both decks include formulas, variable labels, data inputs, and outputs. Speaker scripts are provided as separate PDFs and `.tex` files.
