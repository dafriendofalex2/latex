"""Cross-sectional AI-excess exposure construction.

The model uses empirical information as the primary signal and structural
information as a stabilizer:
    I_pre = 0.60 * I_stat + 0.40 * I_econ.

Country-industry cells inherit a country baseline and an industry tilt. A
narrow coherence projection prevents explicitly AI-linked industries from
being assigned less AI-excess vulnerability than their broad country index.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

STATISTICAL_WEIGHT = 0.60
ECONOMIC_WEIGHT = 0.40
COUNTRY_ECONOMIC_WEIGHT = 0.35
INDUSTRY_ECONOMIC_WEIGHT = 0.65
INDUSTRY_TILT_LAMBDA = 0.50
INTENSITY_CAP = 1.50
COHERENCE_MARGIN = 0.05
HIGH_AI_INDUSTRY_THRESHOLD = 0.50
EPS = 1e-8


def statistical_ai_excess_intensity(
    theta_ai_abs,
    beta_world,
    theta_world_ai,
    lower: float = 0.0,
    upper: float = INTENSITY_CAP,
):
    """Beta-adjusted AI-excess intensity.

    Starting from the decomposition
      theta_abs ~= beta_world*theta_world + I_excess*(1-theta_world),
    solve for I_excess and then apply production bounds.
    """
    theta = np.asarray(theta_ai_abs, dtype=float)
    beta = np.asarray(beta_world, dtype=float)
    denom = max(1.0 - float(theta_world_ai), EPS)
    raw = (theta - beta * float(theta_world_ai)) / denom
    clipped = np.clip(raw, lower, upper)
    return raw, clipped


def blend_ai_intensity(
    statistical_score,
    economic_score,
    statistical_weight: float = STATISTICAL_WEIGHT,
    economic_weight: float = ECONOMIC_WEIGHT,
    lower: float = 0.0,
    upper: float = INTENSITY_CAP,
):
    """Canonical empirical-structural 60/40 blend."""
    if abs(statistical_weight + economic_weight - 1.0) > 1e-12:
        raise ValueError("statistical and economic weights must sum to one")
    s = np.asarray(statistical_score, dtype=float)
    e = np.asarray(economic_score, dtype=float)
    return np.clip(statistical_weight * s + economic_weight * e, lower, upper)


def cell_economic_score(country_score, industry_score):
    """Structural country-industry transmission score."""
    return (
        COUNTRY_ECONOMIC_WEIGHT * np.asarray(country_score, dtype=float)
        + INDUSTRY_ECONOMIC_WEIGHT * np.asarray(industry_score, dtype=float)
    )


def country_industry_tilt(
    beta_country,
    theta_country,
    beta_industry,
    theta_industry,
    theta_world_ai,
    lambda_tilt: float = INDUSTRY_TILT_LAMBDA,
):
    """Apply a square-root industry tilt to a country baseline.

    The industry proxy informs local cross-sectional shape without replacing a
    country/regional baseline with a global industry ETF one-for-one.
    """
    beta_cell = float(beta_country) * max(float(beta_industry), EPS) ** lambda_tilt
    theta_ratio = max(float(theta_industry), EPS) / max(float(theta_world_ai), EPS)
    theta_cell = float(theta_country) * theta_ratio ** lambda_tilt
    return beta_cell, theta_cell


def coherence_project(
    pre_intensity,
    country_index_intensity,
    industry_economic_score,
    threshold: float = HIGH_AI_INDUSTRY_THRESHOLD,
    margin: float = COHERENCE_MARGIN,
    upper: float = INTENSITY_CAP,
):
    """Narrow monotonicity rule for explicitly AI-linked industries."""
    pre = np.asarray(pre_intensity, dtype=float)
    country = np.asarray(country_index_intensity, dtype=float)
    econ = np.asarray(industry_economic_score, dtype=float)
    floor = np.minimum(upper, country + margin)
    use = econ >= threshold
    final = np.where(use, np.maximum(pre, floor), pre)
    final = np.clip(final, 0.0, upper)
    applied = use & (final > pre + 1e-14)
    return final, applied, np.where(use, floor, np.nan)


def reliability_flag(country_flag: str, industry_flag: str) -> str:
    """Conservative composite quality flag: worst constituent wins."""
    order = ["A", "B", "C", "D", "X"]
    rank = {v: i for i, v in enumerate(order)}
    a = str(country_flag).upper()
    b = str(industry_flag).upper()
    return max((a, b), key=lambda x: rank.get(x, rank["X"]))


def build_country_industry_grid(
    country_estimates: pd.DataFrame,
    industry_estimates: pd.DataFrame,
    industry_mapping: pd.DataFrame,
    theta_world_ai: float,
) -> pd.DataFrame:
    """Build the auditable country x client-industry exposure grid.

    Required country columns:
      country_bucket, ticker, region_group, beta_world_final,
      theta_ai_abs_final, country_economic_ai_intensity, reliability_country.
    Required industry columns:
      industry_bucket, ticker, sector_group, beta_world_final,
      theta_ai_abs_final, reliability_industry.
    Required mapping columns:
      client_industry_label, client_industry_normalized, industry_bucket,
      client_industry_economic_ai_intensity.
    """
    ind_lookup = industry_estimates.set_index("industry_bucket").to_dict("index")
    rows = []

    for _, c in country_estimates.iterrows():
        beta_c = float(c["beta_world_final"])
        theta_c = float(c["theta_ai_abs_final"])
        econ_c = float(c["country_economic_ai_intensity"])
        country_raw, country_stat = statistical_ai_excess_intensity(
            theta_c, beta_c, theta_world_ai
        )
        country_index = float(blend_ai_intensity(country_stat, econ_c))

        for _, m in industry_mapping.iterrows():
            ib = m["industry_bucket"]
            if ib == "Out of Scope Fixed Income":
                rows.append({
                    "country_bucket": c["country_bucket"],
                    "country_proxy_ticker": c["ticker"],
                    "country_region_group": c["region_group"],
                    "client_industry_label": m["client_industry_label"],
                    "client_industry_normalized": m["client_industry_normalized"],
                    "industry_bucket": ib,
                    "model_scope": "outside_equity_ai_model",
                    "reliability_flag": "X",
                    "beta_world_cell": np.nan,
                    "final_ai_excess_intensity": np.nan,
                })
                continue
            if ib not in ind_lookup:
                continue

            i = ind_lookup[ib]
            beta_i = float(i["beta_world_final"])
            theta_i = float(i["theta_ai_abs_final"])
            econ_i = float(m["client_industry_economic_ai_intensity"])

            if ib == "Index or ETF":
                beta_cell = beta_c
                theta_cell = theta_c
                stat_raw = float(country_raw)
                stat = float(country_stat)
                econ_cell = econ_c
                pre = country_index
                final = country_index
                applied = False
                floor = np.nan
            else:
                beta_cell, theta_cell = country_industry_tilt(
                    beta_c, theta_c, beta_i, theta_i, theta_world_ai
                )
                stat_raw, stat = statistical_ai_excess_intensity(
                    theta_cell, beta_cell, theta_world_ai
                )
                stat_raw = float(stat_raw)
                stat = float(stat)
                econ_cell = float(cell_economic_score(econ_c, econ_i))
                pre = float(blend_ai_intensity(stat, econ_cell))
                final_a, applied_a, floor_a = coherence_project(
                    np.array([pre]), np.array([country_index]), np.array([econ_i])
                )
                final = float(final_a[0])
                applied = bool(applied_a[0])
                floor = float(floor_a[0]) if np.isfinite(floor_a[0]) else np.nan

            rows.append({
                "country_bucket": c["country_bucket"],
                "country_proxy_ticker": c["ticker"],
                "country_region_group": c["region_group"],
                "client_industry_label": m["client_industry_label"],
                "client_industry_normalized": m["client_industry_normalized"],
                "industry_bucket": ib,
                "industry_proxy_ticker": i["ticker"],
                "industry_sector_group": i["sector_group"],
                "model_scope": "equity_factor_stress",
                "reliability_flag": reliability_flag(
                    c["reliability_country"], i["reliability_industry"]
                ),
                "beta_world_country": beta_c,
                "beta_world_industry": beta_i,
                "beta_world_cell": beta_cell,
                "theta_ai_abs_country": theta_c,
                "theta_ai_abs_industry": theta_i,
                "theta_ai_abs_cell": theta_cell,
                "theta_ai_abs_world_reference": float(theta_world_ai),
                "country_stat_ai_excess_intensity_raw": float(country_raw),
                "country_stat_ai_excess_intensity": float(country_stat),
                "country_index_final_ai_excess_intensity": country_index,
                "cell_stat_ai_excess_intensity_raw": stat_raw,
                "cell_stat_ai_excess_intensity": stat,
                "country_economic_ai_intensity": econ_c,
                "client_industry_economic_ai_intensity": econ_i,
                "cell_economic_ai_intensity": econ_cell,
                "statistical_weight": STATISTICAL_WEIGHT,
                "economic_weight": ECONOMIC_WEIGHT,
                "final_ai_excess_intensity_pre_coherence": pre,
                "monotonic_constraint_applied": applied,
                "monotonic_floor_if_applicable": floor,
                "final_ai_excess_intensity": final,
            })
    return pd.DataFrame(rows)
