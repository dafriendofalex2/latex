Boyu Capital and Prosperis - Markets Client Profile and Relationship Review
Information cut-off: 11 August 2026

VANILLA LATEX BUILD
-------------------
No external LaTeX packages are used.
No geometry, hyperref, booktabs, BibTeX/Biber, latexmk, Perl or shell escape is required.

Compile from this folder with:

    pdflatex main.tex
    pdflatex main.tex

Files
-----
main.tex              Main report source
references.tex        Manually maintained bibliography
source_links.txt       Full public-domain source URLs
source_register.csv    Source register for audit / refresh
Boyu_Capital_Prosperis_Markets_Client_Profile_2026-08-11.pdf  Compiled report

Important entity note
---------------------
The exact name "Prosperis Holding Limited" matches a BVI company (no. 2189125), while the established Nigerian group is Prosperis Holdings Company Limited (RC-1486935). The report deliberately keeps these entities separate and does not infer a Boyu relationship without legal-entity evidence.
