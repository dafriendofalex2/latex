# Data Required

## Already available in current workspace

1. `w21944.pdf`
   - Barberis, Greenwood, Jin, Shleifer, *Extrapolation and Bubbles*.
   - Use: central model for growth signal, value signal, extrapolative demand, and bubble collapse.

2. `2026.04.17 - AI Boom or Bubble Lessons from the Dot-Com Perio....pdf`
   - Amundi Investment Institute, *AI Boom or Bubble? Lessons from the Dot-Com Period*.
   - Use: AI/ex-AI and TMT/ex-TMT portfolio comparison framework.

3. `holdings-daily-us-en-spy.xlsx`
   - SPY current holdings.
   - Use: current S&P 500 constituent weights for direct AI concentration impact.

4. `pdhist-us-en-spy.xlsx`
   - SPY price history.
   - Use: market benchmark returns.

5. `49_Industry_Portfolios.csv`
   - Fama-French 49 industry returns.
   - Use: dot-com TMT construction and broader historical industry calibration.

6. AI stock price files already available:
   - `nvda.us.txt`
   - `amd.us.txt`
   - `avgo.us.txt`
   - `msft.us.txt`
   - `googl.us.txt`
   - `amzn.us.txt`
   - `meta.us.txt`
   - `smci.us.txt`
   - `pltr.us.txt`

7. `NASDAQCOM.xlsx`
   - Nasdaq Composite historical data.
   - Use: dot-com and current-market benchmark.

## Still needed later

1. ORCL price history
   - Only needed if Oracle remains in the AI basket.
   - Suggested source: Stooq daily data.

2. Fama-French 3 Factors
   - Needed for monthly market return `Mkt-RF + RF`.
   - Source: Kenneth French Data Library.

3. Sector ETF prices
   - Suggested tickers: XLK, XLC, XLY, XLI, XLF, XLV, XLP, XLU, XLE, XLB, XLRE.
   - Use: daily sector-level spillover regression.

4. QQQ holdings
   - Needed if reporting Nasdaq-100 direct concentration impact.

5. AI basket market caps
   - Needed for value-weighted AI factor. Equal-weighted factor is acceptable for first pass.

## Historical data usage

Past data is included in two ways:

1. Dot-com TMT template:
   - Use Fama-French 49 industries from 1995-2004.
   - Build TMT factor from software, hardware, chips, telecom, business services, and related industries.
   - Compute post-peak drawdowns over 6, 12, and 24 months.

2. Broader historical industry calibration:
   - Use all Fama-French 49 industries over the available historical sample.
   - Compute extrapolation signal, stretch signal, and future drawdown for each industry-month.
   - Estimate a reduced relationship between past extrapolation/stretch and future relative drawdowns.
