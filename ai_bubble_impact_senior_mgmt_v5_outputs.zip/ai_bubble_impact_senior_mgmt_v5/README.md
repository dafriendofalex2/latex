# AI Bubble Impact Senior Management v5

This package rebuilds the analysis with corrected connected projections and richer visualization.

Key outputs:
- Base AI relative shock from dot-com TMT replay: -46.7%
- Base market shock over same replay window: -23.0%
- Base projected AI basket return: -63.5%
- Base projected SPY weighted impact: -35.6%
- Covered AI weight in SPY: 28.0%

Main files:
- main.pdf: compiled report
- main.tex: vanilla LaTeX source using only graphicx
- figures/: all visualizations
- data/: output vectors and diagnostics
- code/build_v5.py: script used to build the package

Important limitations are stated in the report. This is a stress prototype, not a forecast model.
