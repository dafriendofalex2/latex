"""Map model stresses to client positions and compute portfolio losses.

The function below assumes the model has already produced a long-form
country-industry stress table and an approved long-form single-stock override
table. A ticker override replaces the generic factor row. A market-cap overlay
is then added in log-return space, after which the result is converted once to
simple return and applied to signed market value.
"""
from __future__ import annotations

import re
import numpy as np
import pandas as pd


def normalize_label(x) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(x).lower()).strip()


def apply_stress_to_positions(
    positions: pd.DataFrame,
    country_mapping: pd.DataFrame,
    country_industry_stress: pd.DataFrame,
    stock_stress: pd.DataFrame | None = None,
    size_overlay: pd.DataFrame | None = None,
    horizon: str = "2m",
    scenario: str = "base",
) -> pd.DataFrame:
    """Apply one horizon/scenario state to a position table.

    Required position columns: country, industry, signed_market_value_usd.
    Optional: ticker, market_cap_bucket, client_level_margin_usd.
    """
    out = positions.copy()
    required = ["country", "industry", "signed_market_value_usd"]
    missing = [c for c in required if c not in out.columns]
    if missing:
        raise ValueError(f"missing required position columns: {missing}")

    out["country_normalized"] = out["country"].map(normalize_label)
    out["industry_normalized"] = out["industry"].map(normalize_label)
    out["ticker_upper"] = (
        out.get("ticker", pd.Series("", index=out.index))
        .fillna("").astype(str).str.upper().str.replace(r"[^A-Z0-9.]+", "", regex=True)
    )

    cmap = country_mapping.copy()
    if "client_country_normalized" not in cmap.columns:
        cmap["client_country_normalized"] = cmap["client_country_label"].map(normalize_label)
    out = out.merge(
        cmap[["client_country_normalized", "country_bucket"]],
        left_on="country_normalized",
        right_on="client_country_normalized",
        how="left",
    )
    out["country_bucket"] = out["country_bucket"].fillna("World Fallback")

    ci = country_industry_stress.copy()
    ci = ci[(ci["horizon"] == horizon) & (ci["scenario"] == scenario)]
    keep = [
        "country_bucket", "client_industry_normalized", "stress_log",
        "world_component_log", "ai_excess_component_log",
        "beta_world_cell", "final_ai_excess_intensity", "reliability_flag",
    ]
    out = out.merge(
        ci[keep],
        left_on=["country_bucket", "industry_normalized"],
        right_on=["country_bucket", "client_industry_normalized"],
        how="left",
    )
    out["model_scope"] = "country_industry"

    # Specific ticker row replaces generic return if an approved override exists.
    if stock_stress is not None:
        ss = stock_stress.copy()
        ss = ss[(ss["horizon"] == horizon) & (ss["scenario"] == scenario)]
        ss["ticker_upper"] = ss["ticker"].astype(str).str.upper()
        ss = ss[[
            "ticker_upper", "stress_log", "world_component_log",
            "ai_excess_component_log", "beta_world_stock",
            "final_ai_excess_intensity"
        ]].rename(columns={
            "stress_log": "stock_stress_log",
            "world_component_log": "stock_world_component_log",
            "ai_excess_component_log": "stock_ai_excess_component_log",
            "final_ai_excess_intensity": "stock_ai_intensity",
        })
        out = out.merge(ss, on="ticker_upper", how="left")
        use = out["stock_stress_log"].notna()
        out.loc[use, "stress_log"] = out.loc[use, "stock_stress_log"]
        out.loc[use, "world_component_log"] = out.loc[use, "stock_world_component_log"]
        out.loc[use, "ai_excess_component_log"] = out.loc[use, "stock_ai_excess_component_log"]
        out.loc[use, "final_ai_excess_intensity"] = out.loc[use, "stock_ai_intensity"]
        out.loc[use, "model_scope"] = "single_stock_override"

    # Size overlay is a separate additive log-return channel.
    out["size_overlay_log"] = 0.0
    if size_overlay is not None and "market_cap_bucket" in out.columns:
        ov = size_overlay.copy()
        ov = ov[(ov["horizon"] == horizon) & (ov["scenario"] == scenario)]
        out = out.merge(
            ov[["cap_bucket", "size_overlay_log"]].rename(
                columns={"cap_bucket": "market_cap_bucket", "size_overlay_log": "overlay_join"}
            ),
            on="market_cap_bucket",
            how="left",
        )
        out["size_overlay_log"] = out["overlay_join"].fillna(0.0)

    out["final_stress_log"] = out["stress_log"] + out["size_overlay_log"]
    out["stress_simple"] = np.exp(out["final_stress_log"]) - 1.0
    out["stress_pct"] = 100.0 * out["stress_simple"]
    out["stress_pnl_usd"] = -out["signed_market_value_usd"].astype(float) * out["stress_simple"]
    out["adverse_stress_loss_usd"] = out["stress_pnl_usd"].clip(lower=0.0)
    if "client_level_margin_usd" in out.columns:
        denom = out["client_level_margin_usd"].replace({0.0: np.nan}).astype(float)
        out["stress_loss_to_margin"] = out["adverse_stress_loss_usd"] / denom
    return out


def aggregate_client_loss(position_results: pd.DataFrame, client_col: str = "client_id") -> pd.DataFrame:
    if client_col not in position_results.columns:
        raise KeyError(client_col)
    agg = position_results.groupby(client_col, as_index=False).agg(
        signed_stress_pnl_usd=("stress_pnl_usd", "sum"),
        adverse_stress_loss_usd=("adverse_stress_loss_usd", "sum"),
        gross_market_value_usd=("signed_market_value_usd", lambda x: np.abs(x).sum()),
    )
    return agg
