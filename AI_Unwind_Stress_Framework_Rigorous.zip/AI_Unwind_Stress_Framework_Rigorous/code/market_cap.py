"""Empirical market-cap fragility overlay calibrated from size portfolios."""
from __future__ import annotations
import numpy as np
import pandas as pd

SCENARIO_QUANTILES = {
    "mild": 0.50,
    "base": 0.25,
    "severe": 0.10,
    "extreme": 0.05,
}
HORIZONS = (5, 10, 21, 42)


def rolling_log_return(simple_return, window):
    """Cumulative log return over a fixed window from simple daily returns."""
    return np.log1p(pd.Series(simple_return, dtype=float)).rolling(window).sum()


def calibrate_size_fragility(
    size_returns: pd.DataFrame,
    broad_return: pd.Series,
    horizons=HORIZONS,
    stress_decile: float = 0.10,
    reference_col: str = "Q5",
):
    """Estimate relative small-cap fragility in broad-market stress windows.

    For each horizon, select bottom-decile broad-market rolling windows.  For
    every size bucket m, compute R_m - R_Q5 in those windows.  Mild/Base/Severe/
    Extreme use the 50/25/10/5 percentiles; Worst uses the historical minimum.
    Positive relative outcomes are clipped to zero because the overlay is an
    adverse fragility channel, not a source of stress relief.
    """
    size = pd.DataFrame(size_returns).copy()
    broad = pd.Series(broad_return, copy=True).astype(float)
    if reference_col not in size.columns:
        raise ValueError(f"missing reference size portfolio {reference_col}")
    rows = []
    for h in horizons:
        broad_roll = rolling_log_return(broad, h)
        cutoff = float(broad_roll.quantile(stress_decile))
        stressed = broad_roll <= cutoff
        size_roll = pd.DataFrame({c: rolling_log_return(size[c], h) for c in size.columns})
        rel = size_roll.sub(size_roll[reference_col], axis=0)
        for bucket in size.columns:
            sample = rel.loc[stressed, bucket].dropna().to_numpy(float)
            if len(sample) == 0:
                raise ValueError(f"no stressed observations for horizon={h}, bucket={bucket}")
            for scenario, q in SCENARIO_QUANTILES.items():
                overlay = min(float(np.quantile(sample, q)), 0.0)
                rows.append({"sessions": h, "cap_bucket": bucket, "scenario": scenario,
                             "size_overlay_log": 0.0 if bucket == reference_col else overlay,
                             "calibration_statistic": f"quantile_{q:.2f}"})
            worst = min(float(np.min(sample)), 0.0)
            rows.append({"sessions": h, "cap_bucket": bucket, "scenario": "worst",
                         "size_overlay_log": 0.0 if bucket == reference_col else worst,
                         "calibration_statistic": "historical_minimum"})
    return pd.DataFrame(rows)


def add_size_overlay(base_stress_log, size_overlay_log):
    return np.asarray(base_stress_log, dtype=float) + np.asarray(size_overlay_log, dtype=float)


def assign_market_cap_bucket(market_cap_usd, breakpoints: pd.DataFrame):
    """Map current USD market capitalization to refreshable empirical ranges."""
    value = float(market_cap_usd)
    bp = breakpoints.sort_values("range_lower_usd").reset_index(drop=True)
    for _, row in bp.iterrows():
        lo = float(row["range_lower_usd"])
        hi = row.get("range_upper_usd", np.nan)
        if pd.isna(hi):
            if value >= lo:
                return row["cap_bucket"]
        elif lo <= value < float(hi):
            return row["cap_bucket"]
    raise ValueError("market cap outside supplied bucket ranges")
