Alvin Jiang / Boyu Capital - concise senior-person profile

Vanilla LaTeX build. No external packages are used.

Compile:
  pdflatex main.tex
  pdflatex main.tex
