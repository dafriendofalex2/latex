import os, shutil, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE=Path('/mnt/data')
OUT=BASE/'ai_unwind_sample_shocks_actual_etfs_bundle'
OUT.mkdir(exist_ok=True)
plt.rcParams['figure.dpi']=180
plt.rcParams['font.size']=10

# ---------------- inputs ----------------
cal=pd.read_csv(BASE/'ai_unwind_dotcom_calibration_theory_rebuilt_table.csv')
v=pd.read_csv(BASE/'country_industry_stress_vector_v5(1).csv')

# Country ETF parameters are read directly from production country-index rows.
def country_params(country):
    row=v[(v['country_bucket']==country)&(v['client_industry_label']=='index & ETF')].iloc[0]
    return float(row['beta_world_cell']), float(row['final_ai_excess_intensity'])

country_specs=[]
for ticker,country,label,composition,source in [
    ('SPY','United States','SPY - US large caps','S&P 500: 504 large-cap US stocks across all 11 GICS sectors.','State Street SPY product page; data as of 14 Jul 2026.'),
    ('EWT','Taiwan','EWT - Taiwan','79 Taiwan equities; 73% information technology and 14% financials.','iShares EWT product page; sector data as of 14 Jul 2026.'),
    ('EWY','Korea','EWY - South Korea','78 South Korea equities; 51% information technology and 19% industrials.','iShares EWY product page; sector data as of 14 Jul 2026.'),
    ('EWJ','Japan','EWJ - Japan','168 Japan equities; 23% industrials, 20% information technology, 19% financials.','iShares EWJ product page; sector data as of 14 Jul 2026.'),
]:
    b,i=country_params(country)
    country_specs.append(dict(ticker=ticker,label=label,beta=b,I_AI=i,parameter_source='Production country-index row',composition=composition,source_note=source))

# Thematic ETF parameters: monthly orthogonal regression, Jun-2018 to Jun-2026.
price_files={
    'SPY':BASE/'spy_us_d (1).csv',
    'IXN':BASE/'ixn_us_d(2).csv',
    'SMH':BASE/'smh_us_d(3).csv',
    'SOXX':BASE/'soxx_us_d(2).csv',
    'IGV':BASE/'igv_us_d(1).csv',
    'SKYY':BASE/'skyy_us_d(1).csv',
    'AIQ':BASE/'aiq_us_d(1).csv',
}
rets={}
for t,p in price_files.items():
    d=pd.read_csv(p)
    d['Date']=pd.to_datetime(d['Date'])
    s=d.set_index('Date').sort_index()['Close'].resample('ME').last()
    rets[t]=np.log(s).diff()
monthly=pd.concat(rets,axis=1).dropna()

def orth_reg(target):
    ai_members=['IXN','SMH','SOXX','IGV','SKYY','AIQ']
    peers=[x for x in ai_members if x!=target]
    d=monthly[['SPY',target]+peers].dropna()
    ai=d[peers].mean(axis=1)
    X=np.column_stack([np.ones(len(d)),d['SPY'].values])
    first=np.linalg.lstsq(X,ai.values,rcond=None)[0]
    x=ai.values-X@first
    Z=np.column_stack([np.ones(len(d)),d['SPY'].values,x])
    coef=np.linalg.lstsq(Z,d[target].values,rcond=None)[0]
    pred=Z@coef
    r2=1-((d[target].values-pred)**2).sum()/((d[target].values-d[target].mean())**2).sum()
    return float(coef[1]),float(coef[2]),float(r2),len(d),d.index.min(),d.index.max()

theme_defs=[
    ('IXN','IXN - Global tech','128 global tech stocks: 52% semiconductors/equipment, 29% hardware, 19% software.','iShares IXN product page; sector data as of 14 Jul 2026.'),
    ('SMH','SMH - Semiconductors','26 semiconductor producers and equipment firms; includes chip designers, foundries, memory and equipment.','VanEck SMH product page; holdings as of 14 Jul 2026.'),
    ('SKYY','SKYY - Cloud computing','63 cloud companies across IaaS, PaaS and SaaS; 47% software and 25% IT services.','First Trust SKYY product page; sector data as of 14 Jul 2026.'),
    ('AIQ','AIQ - AI & big data','Companies benefiting from AI adoption plus hardware used for AI and big-data analysis.','Global X AIQ product page.'),
]
theme_specs=[]
reg_rows=[]
for t,label,composition,source in theme_defs:
    b,i,r2,n,d0,d1=orth_reg(t)
    theme_specs.append(dict(ticker=t,label=label,beta=b,I_AI=i,parameter_source='Monthly orthogonal ETF regression',composition=composition,source_note=source))
    reg_rows.append(dict(ticker=t,beta_world=b,ai_excess_loading=i,r_squared=r2,n_months=n,start_date=d0.date(),end_date=d1.date()))

specs=pd.DataFrame(country_specs+theme_specs)
# order
order=['SPY','EWT','EWY','EWJ','IXN','SMH','SKYY','AIQ']
specs['ord']=specs['ticker'].map({t:i for i,t in enumerate(order)})
specs=specs.sort_values('ord').drop(columns='ord').reset_index(drop=True)

# ---------------- sample shocks ----------------
rows=[]
for _,s in specs.iterrows():
    for _,r in cal.iterrows():
        log_world=s['beta']*float(r['S_WORLD_log'])
        log_ai=s['I_AI']*float(r['S_AI_EXCESS_log'])
        total_log=log_world+log_ai
        total_simple=np.exp(total_log)-1
        rows.append({
            **s.to_dict(),
            'horizon':r['horizon'],'scenario':r['scenario'],
            'kappa':r['ai_excess_severity_scalar'],
            'world_component_log_pct':100*log_world,
            'ai_component_log_pct':100*log_ai,
            'total_log_pct':100*total_log,
            'total_shock_pct':100*total_simple,
        })
res=pd.DataFrame(rows)
scenario_order=['mild','base','severe','extreme','worst']
horizon_order=['1w','2w','1m','2m']

# outputs
specs_csv=BASE/'ai_unwind_sample_shocks_actual_etfs_definitions.csv'
reg_csv=BASE/'ai_unwind_sample_shocks_actual_etfs_regression_diagnostics.csv'
long_csv=BASE/'ai_unwind_sample_shocks_actual_etfs_long.csv'
wide_csv=BASE/'ai_unwind_sample_shocks_actual_etfs_wide.csv'
specs.to_csv(specs_csv,index=False)
pd.DataFrame(reg_rows).to_csv(reg_csv,index=False)
res.to_csv(long_csv,index=False)
wide=res.pivot_table(index=['ticker','label','beta','I_AI'],columns=['horizon','scenario'],values='total_shock_pct')
wide.columns=[f'{h}_{sc}' for h,sc in wide.columns]
wide.reset_index().to_csv(wide_csv,index=False)

# ---------------- figures ----------------
figs=[]
def save(name):
    p=OUT/name
    plt.tight_layout()
    plt.savefig(p,bbox_inches='tight')
    plt.close()
    figs.append(p)

chart_labels=specs.set_index('ticker')['label'].to_dict()

# 1 beta/I map
fig,ax=plt.subplots(figsize=(8.2,5.0))
ax.scatter(specs['beta'],specs['I_AI'],s=65)
for _,r in specs.iterrows():
    ax.annotate(r['ticker'],(r['beta'],r['I_AI']),xytext=(5,4),textcoords='offset points',fontsize=9,fontweight='bold')
ax.set_xlabel('Broad-market beta')
ax.set_ylabel('AI-excess loading $I^{AI}$')
ax.set_title('Actual ETF inputs used in the sample shocks')
ax.set_xlim(0.65,1.55); ax.set_ylim(0.15,1.12)
save('fig_etf_parameter_map.png')

# 2 2m scenario heatmap
sub=res[res['horizon']=='2m'].pivot(index='ticker',columns='scenario',values='total_shock_pct').loc[order,scenario_order]
fig,ax=plt.subplots(figsize=(7.4,5.0))
im=ax.imshow(sub.values,aspect='auto')
ax.set_xticks(range(len(scenario_order)));ax.set_xticklabels(['Mild','Base','Severe','Extreme','Worst'])
ax.set_yticks(range(len(order)));ax.set_yticklabels([chart_labels[t] for t in order],fontsize=8)
for i in range(sub.shape[0]):
    for j in range(sub.shape[1]):
        ax.text(j,i,f'{sub.iloc[i,j]:.1f}%',ha='center',va='center',fontsize=7)
ax.set_title('2-month sample shocks by ETF and scenario')
plt.colorbar(im,ax=ax,fraction=0.046,pad=0.04,label='Simple return shock (%)')
save('fig_2m_etf_heatmap.png')

# 3 base term structure
fig,ax=plt.subplots(figsize=(8.4,5.0))
for t in order:
    y=res[(res['ticker']==t)&(res['scenario']=='base')].set_index('horizon').loc[horizon_order,'total_shock_pct']
    ax.plot(['1w','2w','1m','2m'],y.values,marker='o',label=t)
ax.set_xlabel('Horizon');ax.set_ylabel('Shock (%)');ax.set_title('Base-case shock term structure')
ax.legend(ncol=4,fontsize=8,loc='upper left')
save('fig_base_term_structure_actual_etfs.png')

# 4 base 2m ranked bars
sub=res[(res['horizon']=='2m')&(res['scenario']=='base')].set_index('ticker').loc[order]
fig,ax=plt.subplots(figsize=(8.6,4.8))
ax.barh([chart_labels[t] for t in order],sub['total_shock_pct'])
for i,val in enumerate(sub['total_shock_pct']): ax.text(val+0.7,i,f'{val:.1f}%',va='center',ha='left',fontsize=8,color='white',fontweight='bold')
ax.set_xlabel('2-month base shock (%)');ax.set_title('Base scenario: actual ETF examples')
save('fig_2m_base_ranked.png')

# 5 base decomposition log contributions
sub=res[(res['horizon']=='2m')&(res['scenario']=='base')].set_index('ticker').loc[order]
fig,ax=plt.subplots(figsize=(9.0,5.0))
y=np.arange(len(order))
ax.barh(y,sub['world_component_log_pct'],label='Broad-market beta contribution')
ax.barh(y,sub['ai_component_log_pct'],left=sub['world_component_log_pct'],label='AI-excess contribution')
ax.set_yticks(y);ax.set_yticklabels([chart_labels[t] for t in order],fontsize=8)
ax.set_xlabel('Log-return contribution (%)');ax.set_title('2-month base decomposition')
ax.legend(fontsize=8)
save('fig_2m_base_decomposition_actual_etfs.png')

# 6 worst decomposition
sub=res[(res['horizon']=='2m')&(res['scenario']=='worst')].set_index('ticker').loc[order]
fig,ax=plt.subplots(figsize=(9.0,5.0))
y=np.arange(len(order))
ax.barh(y,sub['world_component_log_pct'],label='Broad-market beta contribution')
ax.barh(y,sub['ai_component_log_pct'],left=sub['world_component_log_pct'],label='AI-excess contribution')
ax.set_yticks(y);ax.set_yticklabels([chart_labels[t] for t in order],fontsize=8)
ax.set_xlabel('Log-return contribution (%)');ax.set_title('2-month worst decomposition')
ax.legend(fontsize=8)
save('fig_2m_worst_decomposition_actual_etfs.png')

# 7 scenario ladder selected actual ETFs
fig,ax=plt.subplots(figsize=(8.4,4.9))
for t in ['SPY','EWT','EWY','EWJ','SMH','AIQ']:
    y=res[(res['ticker']==t)&(res['horizon']=='2m')].set_index('scenario').loc[scenario_order,'total_shock_pct']
    ax.plot(['Mild','Base','Severe','Extreme','Worst'],y.values,marker='o',label=t)
ax.set_ylabel('2-month shock (%)');ax.set_title('Scenario ladder for selected ETFs')
ax.legend(ncol=3,fontsize=8,loc='upper left')
save('fig_2m_scenario_ladder_actual_etfs.png')

# 8 parameter source comparison
fig,ax=plt.subplots(figsize=(8.4,4.5))
colors=[]
for x in specs['parameter_source']:
    colors.append(0 if x.startswith('Production') else 1)
ax.bar(np.arange(len(specs)),specs['I_AI'])
ax.set_xticks(np.arange(len(specs)));ax.set_xticklabels(specs['ticker'])
ax.set_ylabel('$I^{AI}$ used in visualization');ax.set_title('AI-excess loading used for each ETF')
for i,r in specs.iterrows():
    ax.text(i,r['I_AI']+0.02,'Model' if r['parameter_source'].startswith('Production') else 'Regression',ha='center',fontsize=7)
save('fig_ai_loading_by_etf.png')

# ---------------- LaTeX ----------------
pdf=BASE/'ai_unwind_sample_shocks_actual_etfs.pdf'
tex=BASE/'ai_unwind_sample_shocks_actual_etfs.tex'

# create composition rows
rows_tex=[]
for _,r in specs.iterrows():
    comp=str(r['composition']).replace('&','\\&').replace('%','\\%')
    src='Model' if r['parameter_source'].startswith('Production') else 'Regression'
    rows_tex.append(f"{r['ticker']} & {comp} & {r['beta']:.2f} & {r['I_AI']:.2f} & {src} \\\\")
rows_text='\n'.join(rows_tex)

latex=r'''
\documentclass[10.5pt]{article}
\usepackage{graphicx}
\usepackage[margin=0.75in]{geometry}
\usepackage{array}
\usepackage{float}
\setlength{\parindent}{0pt}
\setlength{\parskip}{0.45em}
\begin{document}
\title{Sample Shocks Using Actual ETFs}
\author{Visualization appendix}
\date{July 2026}
\maketitle

\section*{What changed}
Every sample is now an actual ETF used either in the production country mapping or in the ETF regression set. Chart labels use the ticker plus a short, literal description. No invented categories are used.

\section{ETF definitions and model inputs}
\small
\begin{tabular}{p{0.08\textwidth} p{0.50\textwidth} r r p{0.12\textwidth}}
\textbf{ETF} & \textbf{What it contains} & $\boldsymbol{\beta^W}$ & $\boldsymbol{I^{AI}}$ & \textbf{Input source}\\
\hline
'''+rows_text+r'''
\end{tabular}
\normalsize

Country ETF parameters come directly from the production \texttt{index \& ETF} rows. Thematic ETF parameters are estimated from monthly returns from June 2018 to June 2026. For each thematic ETF, the peer AI basket is first orthogonalized against SPY; the ETF is then regressed on SPY and the residual AI factor. The coefficient on the residual factor is the displayed $I^{AI}$.

\begin{figure}[H]
\centering
\includegraphics[width=0.78\textwidth]{fig_etf_parameter_map.png}
\caption{The actual ETF inputs. Labels show tickers only; the table above defines each fund.}
\end{figure}

\section{Shock calculation}
For ETF $i$, scenario $s$, and horizon $h$:
\[
R_{i,\log}^{s,h}=\beta_i^W S_W^{s,h}+I_i^{AI}S_X^{s,h},
\qquad
R_{i,\mathrm{simple}}^{s,h}=e^{R_{i,\log}^{s,h}}-1.
\]
The decomposition charts are shown in log-return space because the two components add exactly there. Heatmaps and ranked charts show the final simple-return shock.

\begin{figure}[H]
\centering
\includegraphics[width=0.78\textwidth]{fig_2m_etf_heatmap.png}
\caption{Two-month shocks across all scenarios.}
\end{figure}

\begin{figure}[H]
\centering
\includegraphics[width=0.82\textwidth]{fig_base_term_structure_actual_etfs.png}
\caption{Base-case term structure using the same actual ETF definitions.}
\end{figure}

\begin{figure}[H]
\centering
\includegraphics[width=0.84\textwidth]{fig_2m_base_ranked.png}
\caption{Two-month base shock ranked by ETF.}
\end{figure}

\section{Why the ETFs differ}
\begin{figure}[H]
\centering
\includegraphics[width=0.88\textwidth]{fig_2m_base_decomposition_actual_etfs.png}
\caption{Base scenario. Each bar is broad-market beta plus AI-excess loading.}
\end{figure}

\begin{figure}[H]
\centering
\includegraphics[width=0.88\textwidth]{fig_2m_worst_decomposition_actual_etfs.png}
\caption{Worst scenario. The broad-market leg is unchanged from base; the AI-excess leg is scaled by the larger scenario $\kappa$.}
\end{figure}

\begin{figure}[H]
\centering
\includegraphics[width=0.82\textwidth]{fig_2m_scenario_ladder_actual_etfs.png}
\caption{Scenario ladder for selected ETFs.}
\end{figure}

\begin{figure}[H]
\centering
\includegraphics[width=0.76\textwidth]{fig_ai_loading_by_etf.png}
\caption{The $I^{AI}$ input used for each ETF and whether it comes from a production model row or an ETF-level regression.}
\end{figure}

\section*{Source notes for fund descriptions}
SPY: State Street SPDR S\&P 500 ETF Trust product page. EWT, EWY, EWJ and IXN: iShares product pages. SMH: VanEck product page. SKYY: First Trust product page. AIQ: Global X product page. Sector weights and holding counts are stated using issuer data available on 14-15 July 2026 and are subject to change.

\end{document}
'''
tex.write_text(latex)
shutil.copy2(tex,OUT/tex.name)
# copy CSVs and build script
for p in [specs_csv,reg_csv,long_csv,wide_csv,BASE/'build_sample_shocks_actual_etfs.py']:
    shutil.copy2(p,OUT/p.name)
os.chdir(OUT)
os.system('pdflatex -interaction=nonstopmode ai_unwind_sample_shocks_actual_etfs.tex > /tmp/actual_etfs.log 2>&1')
os.system('pdflatex -interaction=nonstopmode ai_unwind_sample_shocks_actual_etfs.tex >> /tmp/actual_etfs.log 2>&1')
if (OUT/pdf.name).exists(): shutil.copy2(OUT/pdf.name,pdf)
# zip
zip_path=BASE/'ai_unwind_sample_shocks_actual_etfs_bundle.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for fp in OUT.iterdir(): z.write(fp,arcname=fp.name)
print('built',pdf.exists(),zip_path.stat().st_size)
