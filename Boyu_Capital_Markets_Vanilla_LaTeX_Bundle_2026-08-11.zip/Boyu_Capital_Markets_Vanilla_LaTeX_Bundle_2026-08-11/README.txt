Boyu Capital - Markets Client Profile
Information cut-off: 11 August 2026

VANILLA LATEX BUILD
-------------------
No external packages are used.
No geometry, hyperref, xcolor, booktabs, tabularx, longtable, BibTeX,
Biber, latexmk, Perl, shell escape, or additional LaTeX packages are required.

Compile from this folder with:

  pdflatex main.tex
  pdflatex main.tex

Files:
- main.tex             Main document
- references.tex       Embedded bibliography
- source_links.txt     Source URLs / source register
- README.txt           Build instructions
