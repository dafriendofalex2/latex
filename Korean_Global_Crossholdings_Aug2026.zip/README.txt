Korean Global Strategic Cross-Holdings package
Cut-off: 12 August 2026

Files:
- korean_global_crossholdings_master.xlsx: complete workbook with summary, listed/private holdings, watchlist, exits/pending, true crossholdings, sector map, methodology, sources.
- listed_foreign_holdings.xlsx: listed-target dataset + sources.
- private_foreign_holdings.xlsx: private/unlisted-target dataset + sources.
- watchlist_exits_pending.xlsx: qualified/watchlist and historical/pending relationships.
- main_report.tex: main LaTeX report.
- public_holdings_table.tex: modular listed-holdings table.
- private_holdings_table.tex: modular private-holdings table.
- supplementary_tables.tex: watchlist, historical/pending, ranking, narrow crossholding list, sector map.
- sources.tex: source registry.
- korean_global_crossholdings_report.pdf: compiled PDF.

Important: listed-target values are cutoff-date market-value estimates where possible. Private-target values are transaction / investment proxies and are not directly comparable with listed market values.
