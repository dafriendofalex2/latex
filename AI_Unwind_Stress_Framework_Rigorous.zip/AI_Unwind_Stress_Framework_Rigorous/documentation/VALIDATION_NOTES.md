# Validation Notes

Validation was performed after the final 60/40 rewrite and after the final PDF build.

## Python source validation

All Python modules in `code/` pass `python -m py_compile`.

A synthetic orthogonalization test generated an AI series as a market component plus an independent residual. The recovered market loading was approximately 0.704 and the centered world/residual inner product was `1.01e-16`, passing the `1e-10` tolerance.

The exact terminal scenario engine reproduced the following AI-epicenter representative drawdowns:

| Scenario | kappa | Drawdown |
|---|---:|---:|
| Mild | 0.3353695 | 31.9353% |
| Base | 0.6707391 | 53.6720% |
| Severe | 1.0000000 | 63.9000% |
| Extreme | 1.5000000 | 75.2833% |
| Worst | 2.0000000 | 83.0771% |

The log-to-simple return identity is exact to machine precision for these rows.

## Probability model validation

Using the exact 21-event historical severity sample:

- sample mean drawdown: 60.2857%;
- scenario-weighted representative drawdown: 60.5541%;
- model-averaged probability vector sums to 1.0 within floating-point tolerance;
- observed scenario-cell counts are `(0, 9, 9, 3, 0)`;
- the Jeffreys-prior posterior mean is approximately `(2.13%, 40.43%, 40.43%, 14.89%, 2.13%)`;
- the unconstrained GPD diagnostic produces a finite endpoint of approximately 75%, illustrating the small-sample tail instability discussed in the paper.

Central AICc-model-averaged conditional probabilities are:

| Scenario | Probability |
|---|---:|
| Mild | 1.3076% |
| Base | 46.4564% |
| Severe | 37.6326% |
| Extreme | 12.5335% |
| Worst | 2.0699% |

The included `data/probability_bootstrap_5000.csv` contains exactly 5,000 valid full-ensemble episode-level bootstrap refits. The 5th/95th percentile intervals are approximately:

- Mild: 0.14% / 3.65%;
- Base: 31.78% / 59.92%;
- Severe: 28.75% / 48.55%;
- Extreme: 5.52% / 19.34%;
- Worst: 0.39% / 4.26%.

## PDF validation

The LaTeX source was compiled repeatedly with `pdflatex -interaction=nonstopmode -halt-on-error`. The final compilation contains no overfull-box warnings, unresolved references, or undefined citations.

The final PDF has 40 pages. All 40 pages were rendered to PNG at 150 DPI using the PDF validation renderer. The title page, code-heavy pages, figures, probability-model pages, tables, and final references were visually inspected. No clipped text, overlap, black boxes, or broken glyphs were observed.
