"""Country-industry latent exposure construction and coherence projection."""
from __future__ import annotations
import numpy as np
import pandas as pd

from ai_exposure import (
    statistical_ai_excess_intensity, economic_ai_cell, blend_ai_intensity,
    INTENSITY_CAP,
)

INDUSTRY_TILT = 0.50
AI_LINKED_ECON_THRESHOLD = 0.50
COHERENCE_MARGIN = 0.05


def latent_cell_exposure(
    beta_country, beta_industry, theta_country, theta_industry,
    theta_world_ai, industry_tilt: float = INDUSTRY_TILT,
):
    """Country baseline multiplied by a tempered global-industry tilt."""
    beta_cell = float(beta_country) * max(float(beta_industry), 1e-12) ** industry_tilt
    theta_ratio = max(float(theta_industry), 1e-12) / max(float(theta_world_ai), 1e-12)
    theta_cell = float(theta_country) * theta_ratio ** industry_tilt
    return float(beta_cell), float(theta_cell)


def coherence_project(
    pre_intensity, country_index_intensity, industry_economic_score,
    threshold: float = AI_LINKED_ECON_THRESHOLD,
    margin: float = COHERENCE_MARGIN,
    upper: float = INTENSITY_CAP,
):
    """AI-linked industries may not lie below broad-country intensity + margin."""
    pre = np.asarray(pre_intensity, dtype=float)
    idx = np.asarray(country_index_intensity, dtype=float)
    econ = np.asarray(industry_economic_score, dtype=float)
    floor = np.minimum(upper, idx + margin)
    use_floor = econ >= threshold
    projected = np.where(use_floor, np.maximum(pre, floor), pre)
    applied = use_floor & (pre < floor)
    return np.clip(projected, 0.0, upper), applied, floor


def build_country_industry_grid(country_estimates, industry_estimates, industry_mapping, theta_world_ai):
    """Build all country x client-industry exposure rows.

    Expected country columns: country_bucket, beta_world_final,
    theta_ai_abs_final, country_economic_ai_intensity.
    Expected industry columns: industry_bucket, beta_world_final,
    theta_ai_abs_final.
    Expected mapping columns: client_industry_label, industry_bucket,
    client_industry_economic_ai_intensity.
    """
    countries = pd.DataFrame(country_estimates).copy()
    industries = pd.DataFrame(industry_estimates).set_index("industry_bucket")
    mapping = pd.DataFrame(industry_mapping).copy()
    rows = []

    for _, c in countries.iterrows():
        beta_b = float(c["beta_world_final"])
        theta_b = float(c["theta_ai_abs_final"])
        econ_b = float(c["country_economic_ai_intensity"])
        _, stat_b = statistical_ai_excess_intensity(theta_b, beta_b, theta_world_ai)
        index_intensity = blend_ai_intensity(stat_b, econ_b)

        for _, m in mapping.iterrows():
            ib = m["industry_bucket"]
            if ib not in industries.index:
                continue
            g = industries.loc[ib]
            econ_g = float(m["client_industry_economic_ai_intensity"])

            if str(ib).lower() in {"index or etf", "index & etf", "index etf"}:
                beta_cell, theta_cell = beta_b, theta_b
                _, stat_cell = statistical_ai_excess_intensity(theta_cell, beta_cell, theta_world_ai)
                econ_cell = econ_b
                pre = index_intensity
                final = index_intensity
                applied = False
                floor = np.nan
            else:
                beta_cell, theta_cell = latent_cell_exposure(
                    beta_b, float(g["beta_world_final"]),
                    theta_b, float(g["theta_ai_abs_final"]), theta_world_ai,
                )
                raw_stat, stat_cell = statistical_ai_excess_intensity(
                    theta_cell, beta_cell, theta_world_ai
                )
                econ_cell = economic_ai_cell(econ_b, econ_g)
                pre = blend_ai_intensity(stat_cell, econ_cell)
                final_a, applied_a, floor_a = coherence_project(
                    np.array([pre]), np.array([index_intensity]), np.array([econ_g])
                )
                final, applied, floor = float(final_a[0]), bool(applied_a[0]), float(floor_a[0])

            rows.append({
                "country_bucket": c["country_bucket"],
                "client_industry_label": m["client_industry_label"],
                "industry_bucket": ib,
                "beta_world_cell": beta_cell,
                "theta_ai_abs_cell": theta_cell,
                "theta_ai_abs_world_reference": float(theta_world_ai),
                "cell_stat_ai_excess_intensity": stat_cell,
                "country_economic_ai_intensity": econ_b,
                "client_industry_economic_ai_intensity": econ_g,
                "cell_economic_ai_intensity": econ_cell,
                "country_index_final_ai_excess_intensity": index_intensity,
                "final_ai_excess_intensity_pre_coherence": pre,
                "monotonic_constraint_applied": applied,
                "monotonic_floor_if_applicable": floor if econ_g >= AI_LINKED_ECON_THRESHOLD else np.nan,
                "final_ai_excess_intensity": final,
            })
    return pd.DataFrame(rows)
