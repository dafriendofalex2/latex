"""Return-estimation utilities for the AI-led equity unwind framework.

The module is intentionally small and transparent. It provides:
  * month-end log-return construction;
  * ordinary least squares with a Newey-West/HAC covariance estimate;
  * market-orthogonalization of the raw AI thematic return;
  * proxy-level exposure estimation; and
  * optional reliability-weighted shrinkage toward explicit priors.

The production stress engine consumes the resulting coefficients. It does not
re-estimate coefficients when a client portfolio is stressed.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Optional

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class HACRegressionResult:
    alpha: float
    beta: float
    se_alpha: float
    se_beta: float
    t_alpha: float
    t_beta: float
    n_obs: int
    nw_lags: int
    r_squared: float

    def to_dict(self):
        return asdict(self)


def month_end_log_returns(price: pd.Series) -> pd.Series:
    """Convert a positive daily price series to month-end log returns."""
    p = pd.Series(price, copy=True).dropna().astype(float)
    if not isinstance(p.index, pd.DatetimeIndex):
        raise TypeError("price must have a DatetimeIndex")
    if (p <= 0).any():
        raise ValueError("prices must be strictly positive")
    month_end = p.sort_index().resample("ME").last().dropna()
    out = np.log(month_end).diff().dropna()
    out.name = getattr(price, "name", None)
    return out


def default_newey_west_lags(n_obs: int) -> int:
    """Common automatic lag rule: floor(4 (n/100)^(2/9))."""
    if n_obs <= 1:
        return 0
    return int(np.floor(4.0 * (n_obs / 100.0) ** (2.0 / 9.0)))


def _aligned_xy(y: pd.Series, x: pd.Series) -> pd.DataFrame:
    z = pd.concat([pd.Series(y, name="y"), pd.Series(x, name="x")], axis=1).dropna()
    if len(z) < 4:
        raise ValueError("at least four aligned observations are required")
    return z.astype(float)


def ols_hac(y: pd.Series, x: pd.Series, nw_lags: Optional[int] = None) -> HACRegressionResult:
    """OLS y = alpha + beta*x with Bartlett-kernel Newey-West covariance.

    This implementation is deliberately explicit so a model validator can
    reproduce each matrix operation without depending on a black-box package.
    """
    z = _aligned_xy(y, x)
    yy = z["y"].to_numpy(dtype=float)
    xx = z["x"].to_numpy(dtype=float)
    n = len(z)
    X = np.column_stack([np.ones(n), xx])
    xtx_inv = np.linalg.pinv(X.T @ X)
    bhat = xtx_inv @ (X.T @ yy)
    resid = yy - X @ bhat

    if nw_lags is None:
        nw_lags = default_newey_west_lags(n)
    nw_lags = int(max(0, min(nw_lags, n - 1)))

    # Newey-West long-run covariance of score vectors x_t u_t.
    xu = X * resid[:, None]
    meat = xu.T @ xu
    for lag in range(1, nw_lags + 1):
        weight = 1.0 - lag / (nw_lags + 1.0)
        gamma = xu[lag:].T @ xu[:-lag]
        meat += weight * (gamma + gamma.T)
    cov = xtx_inv @ meat @ xtx_inv
    se = np.sqrt(np.maximum(np.diag(cov), 0.0))

    fitted = X @ bhat
    ss_res = float(np.sum((yy - fitted) ** 2))
    ss_tot = float(np.sum((yy - yy.mean()) ** 2))
    r2 = np.nan if ss_tot <= 0 else 1.0 - ss_res / ss_tot

    return HACRegressionResult(
        alpha=float(bhat[0]),
        beta=float(bhat[1]),
        se_alpha=float(se[0]),
        se_beta=float(se[1]),
        t_alpha=float(bhat[0] / se[0]) if se[0] > 0 else np.nan,
        t_beta=float(bhat[1] / se[1]) if se[1] > 0 else np.nan,
        n_obs=n,
        nw_lags=nw_lags,
        r_squared=float(r2),
    )


def orthogonalize_ai(ai_return: pd.Series, world_return: pd.Series):
    """Project the raw AI thematic return on the broad market.

    r_A,t = alpha_A + theta_W^AI r_W,t + x_t.

    The returned residual x_t is, up to numerical precision, orthogonal to the
    centered broad-market return in the estimation sample.
    """
    z = pd.concat(
        [pd.Series(ai_return, name="ai"), pd.Series(world_return, name="world")],
        axis=1,
    ).dropna().astype(float)
    fit = ols_hac(z["ai"], z["world"])
    residual = z["ai"] - fit.alpha - fit.beta * z["world"]
    residual.name = "ai_residual"
    centered_cov = float(
        np.mean((z["world"] - z["world"].mean()) * (residual - residual.mean()))
    )
    return {
        "theta_world_ai": fit.beta,
        "alpha_ai": fit.alpha,
        "ai_residual": residual,
        "world_ai_regression": fit,
        "orthogonality_sample_covariance": centered_cov,
    }


def estimate_proxy_exposure(
    proxy_return: pd.Series,
    world_return: pd.Series,
    ai_return: pd.Series,
) -> dict:
    """Estimate market beta, raw AI co-movement and residual-AI diagnostic.

    beta_world is the market loading used by the stress engine.
    theta_ai_abs is the raw co-movement with the AI basket used to construct the
    beta-adjusted statistical AI-excess intensity.
    residual_ai_beta is retained only as a diagnostic because a negative
    residual loading is relative performance, not a direct absolute-gain
    assumption in a broad equity sell-off.
    """
    z = pd.concat(
        [
            pd.Series(proxy_return, name="proxy"),
            pd.Series(world_return, name="world"),
            pd.Series(ai_return, name="ai"),
        ],
        axis=1,
    ).dropna().astype(float)
    ortho = orthogonalize_ai(z["ai"], z["world"])
    beta_world = ols_hac(z["proxy"], z["world"])
    theta_ai_abs = ols_hac(z["proxy"], z["ai"])
    resid_beta = ols_hac(z.loc[ortho["ai_residual"].index, "proxy"], ortho["ai_residual"])
    return {
        "beta_world_raw": beta_world.beta,
        "beta_world_se": beta_world.se_beta,
        "beta_world_t": beta_world.t_beta,
        "theta_ai_abs_raw": theta_ai_abs.beta,
        "theta_ai_abs_se": theta_ai_abs.se_beta,
        "theta_ai_abs_t": theta_ai_abs.t_beta,
        "theta_ai_abs_world_reference": ortho["theta_world_ai"],
        "residual_ai_beta_diagnostic": resid_beta.beta,
        "residual_ai_beta_se": resid_beta.se_beta,
        "n_months": len(z),
        "orthogonality_sample_covariance": ortho["orthogonality_sample_covariance"],
    }


def shrink_to_prior(raw_value: float, prior_value: float, reliability_weight: float) -> float:
    """Reliability-weighted shrinkage with weight in [0,1]."""
    w = float(np.clip(reliability_weight, 0.0, 1.0))
    return w * float(raw_value) + (1.0 - w) * float(prior_value)


def finalize_proxy_coefficients(
    exposure: dict,
    reliability_weight: float,
    beta_prior: float = 1.0,
    theta_prior: Optional[float] = None,
) -> dict:
    """Store raw and shrunken coefficients separately for auditability."""
    if theta_prior is None:
        theta_prior = float(exposure["theta_ai_abs_world_reference"])
    out = dict(exposure)
    out["reliability_weight"] = float(np.clip(reliability_weight, 0.0, 1.0))
    out["beta_world_final"] = shrink_to_prior(
        exposure["beta_world_raw"], beta_prior, reliability_weight
    )
    out["theta_ai_abs_final"] = shrink_to_prior(
        exposure["theta_ai_abs_raw"], theta_prior, reliability_weight
    )
    return out


def audit_orthogonality(ai_return: pd.Series, world_return: pd.Series, tolerance: float = 1e-10) -> dict:
    result = orthogonalize_ai(ai_return, world_return)
    cov = abs(result["orthogonality_sample_covariance"])
    return {"absolute_sample_covariance": cov, "pass": bool(cov <= tolerance)}
