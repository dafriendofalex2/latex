# Data dictionary

## country_industry_stress_vector_v5.csv
- `country_bucket`: model country or regional bucket.
- `client_industry_label`: client industry label used for merging.
- `client_industry_normalized`: normalized merge key for industry.
- `industry_bucket`: model industry proxy bucket.
- `beta_world_cell`: cell market beta used in stress formula.
- `final_ai_excess_intensity`: AI-excess intensity after statistical/economic blend and coherence projection.
- `base_stress_simple`: base simple return shock.
- `base_stress_pct`: base return shock in percent.
- `mild_stress_pct`, `severe_stress_pct`: mild and severe scenario shocks.
- `country_index_final_ai_excess_intensity`: AI-excess intensity of the broad country index.
- `cell_stat_ai_excess_intensity_raw`: raw beta-adjusted statistical intensity before clipping.
- `cell_stat_ai_excess_intensity`: clipped statistical intensity.
- `cell_economic_ai_intensity`: economic AI relevance score used in blend.
- `monotonic_constraint_applied`: whether the coherence floor was applied to explicitly AI-linked industries.
- `reliability_flag`: A/B/C/D/X proxy quality flag.

## single_stock_override_vector_v5.csv
- `ticker`: override ticker.
- `beta_world_stock`: stock market beta.
- `theta_ai_abs_stock`: absolute beta to AI raw basket.
- `stat_ai_excess_intensity`: beta-adjusted statistical AI-excess intensity.
- `economic_ai_intensity`: economic AI score.
- `final_ai_excess_intensity`: final override intensity.
- `mild_stress_pct`, `base_stress_pct`, `severe_stress_pct`: scenario shocks.

## Formula
`stress_log_return = beta_world_cell*S_WORLD_log + final_ai_excess_intensity*S_AI_EXCESS_log`

`stress_simple_return = exp(stress_log_return)-1`

`stress_pnl_usd = -signed_market_value_usd * stress_simple_return`
