import os, math, shutil, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE = Path('/mnt/data')
OUTDIR = BASE / 'ai_bubble_dotcom_precursor_bundle'
OUTDIR.mkdir(exist_ok=True)

plt.rcParams['figure.dpi'] = 170
plt.rcParams['font.size'] = 10

# ------------------ helpers ------------------

def load_price_csv(path, date_col='Date', close_col='Close'):
    df = pd.read_csv(path)
    df[date_col] = pd.to_datetime(df[date_col])
    df[close_col] = pd.to_numeric(df[close_col], errors='coerce')
    return df[[date_col, close_col]].dropna().sort_values(date_col)


def load_fred_csv(path, date_col='observation_date', value_col=None):
    df = pd.read_csv(path)
    df[date_col] = pd.to_datetime(df[date_col])
    if value_col is None:
        value_col = [c for c in df.columns if c != date_col][0]
    df[value_col] = pd.to_numeric(df[value_col], errors='coerce')
    return df[[date_col, value_col]].dropna().sort_values(date_col)


def parse_ff49_daily(path):
    lines = Path(path).read_text(encoding='latin1').splitlines()
    start = None
    for i, l in enumerate(lines):
        if 'Average Value Weighted Returns -- Daily' in l:
            start = i + 1
            break
    if start is None:
        raise ValueError('Cannot locate FF49 daily table')
    header = [h.strip() for h in lines[start].split(',')]
    rows = []
    for l in lines[start+1:]:
        if not l.strip():
            break
        parts = [p.strip() for p in l.split(',')]
        if len(parts) == len(header):
            rows.append(parts)
    df = pd.DataFrame(rows, columns=header)
    df.rename(columns={df.columns[0]:'date'}, inplace=True)
    df['date'] = pd.to_datetime(df['date'], format='%Y%m%d')
    for c in df.columns[1:]:
        df[c] = pd.to_numeric(df[c], errors='coerce')
    df = df.replace({-99.99: np.nan, -999: np.nan})
    for c in df.columns[1:]:
        df[c] = df[c] / 100.0
    return df


def norm_log(series):
    s = series.dropna().astype(float)
    return np.log(s / s.iloc[0])


def segment_from_end(series, end_date, n):
    s = series[series.index <= end_date].dropna()
    return s.iloc[-n:]


def rolling_smooth(arr, window=20):
    return pd.Series(arr).rolling(window, min_periods=1).mean().values


def fit_lead(current_series, reference_series, max_lead=150, n=252, smooth_window=20):
    current_seg = current_series.dropna().iloc[-n:]
    x = rolling_smooth(norm_log(current_seg).values, smooth_window)
    peak_pos = int(np.nanargmax(reference_series.values))
    out = []
    for lead in range(max_lead + 1):
        end = peak_pos - lead
        start = end - n + 1
        if start < 0:
            continue
        ref_seg = reference_series.iloc[start:end+1]
        y = rolling_smooth(norm_log(ref_seg).values, smooth_window)
        rmse = float(np.sqrt(np.mean((x - y)**2)))
        mae = float(np.mean(np.abs(x - y)))
        corr_level = float(np.corrcoef(x, y)[0,1])
        dx = np.diff(x)
        dy = np.diff(y)
        corr_incr = float(np.corrcoef(dx, dy)[0,1])
        out.append({
            'lead_days': lead,
            'rmse_log_level': rmse,
            'mae_log_level': mae,
            'corr_smoothed_level': corr_level,
            'corr_smoothed_increment': corr_incr,
            'ref_segment_end_date': ref_seg.index[-1],
            'ref_segment_start_date': ref_seg.index[0],
        })
    res = pd.DataFrame(out)
    best = res.sort_values(['rmse_log_level','mae_log_level']).iloc[0]
    return current_seg, res, best


def savefig(path):
    plt.tight_layout()
    plt.savefig(path, bbox_inches='tight')
    plt.close()

# ------------------ data ------------------
# current AI thematic basket
etf_files = {
    'SMH': BASE/'smh_us_d(3).csv',
    'SOXX': BASE/'soxx_us_d(2).csv',
    'IGV': BASE/'igv_us_d(1).csv',
    'SKYY': BASE/'skyy_us_d(1).csv',
    'AIQ': BASE/'aiq_us_d(1).csv',
    'IXN': BASE/'ixn_us_d(2).csv',
}
prices = None
for name, path in etf_files.items():
    df = load_price_csv(path)
    df = df.rename(columns={'Date':'date','Close':name})
    prices = df if prices is None else prices.merge(df, on='date', how='inner')
prices = prices.sort_values('date').set_index('date')
ret = prices.pct_change().dropna()
ai_basket = (1 + ret.mean(axis=1)).cumprod()
smh = prices['SMH'].dropna()
soxx = prices['SOXX'].dropna()
igv = prices['IGV'].dropna()

nasdaq100 = load_fred_csv(BASE/'NASDAQ100.csv', value_col='NASDAQ100').rename(columns={'observation_date':'date','NASDAQ100':'value'}).set_index('date')['value']
nasdaqcom = load_fred_csv(BASE/'NASDAQCOM.csv', value_col='NASDAQCOM').rename(columns={'observation_date':'date','NASDAQCOM':'value'}).set_index('date')['value']
spx_old = pd.read_csv(BASE/'spx.csv')
spx_old['date'] = pd.to_datetime(spx_old['date'], format='%d-%b-%y')
spx_old['close'] = pd.to_numeric(spx_old['close'], errors='coerce')
spx_old = spx_old[['date','close']].dropna().sort_values('date')
spx_new = pd.read_csv(BASE/'SP500 (1).csv')
spx_new['date'] = pd.to_datetime(spx_new['observation_date'])
spx_new['close'] = pd.to_numeric(spx_new['SP500'], errors='coerce')
spx_new = spx_new[['date','close']].dropna().sort_values('date')
spx = pd.concat([spx_old, spx_new], axis=0).drop_duplicates(subset='date', keep='last').sort_values('date').set_index('date')['close']

ff49 = parse_ff49_daily(BASE/'49_Industry_Portfolios_Daily.csv')
ff49 = ff49[(ff49['date'] >= '1997-01-01') & (ff49['date'] <= '2002-12-31')].copy()
ff49['tmt_ret'] = ff49[['Hardw','Softw','Chips','Telcm']].mean(axis=1)
ff49['tmt_idx'] = (1 + ff49['tmt_ret']).cumprod()
dotcom_tmt = ff49.set_index('date')['tmt_idx']

# broad-market controls
spx_dot = spx[(spx.index>='1997-01-01') & (spx.index<='2002-12-31')]
spx_now = spx[(spx.index>='2018-01-01') & (spx.index<='2026-07-07')]

# ------------------ core fit ------------------
N = 252  # one trading year; concise and comparable
current_end = ai_basket.index.max()
cur_main, res_main, best_main = fit_lead(ai_basket, nasdaqcom[(nasdaqcom.index>='1997-01-01') & (nasdaqcom.index<='2002-12-31')], n=N)
lead_main = int(best_main['lead_days'])

# alternative fits for robustness
refs = {
    'NASDAQ Composite': nasdaqcom[(nasdaqcom.index>='1997-01-01') & (nasdaqcom.index<='2002-12-31')],
    'Dot-com TMT proxy': dotcom_tmt,
}
current_proxies = {
    'AI basket': ai_basket,
    'NASDAQ100': nasdaq100[nasdaq100.index<='2026-07-07'],
    'SMH': smh[smh.index<='2026-07-07'],
    'SOXX': soxx[soxx.index<='2026-07-07'],
}
robust = []
for cname, cser in current_proxies.items():
    for rname, rser in refs.items():
        _, res, best = fit_lead(cser, rser, n=N)
        robust.append({
            'current_proxy': cname,
            'dotcom_proxy': rname,
            'lead_days': int(best['lead_days']),
            'rmse_log_level': float(best['rmse_log_level']),
            'mae_log_level': float(best['mae_log_level']),
            'corr_smoothed_level': float(best['corr_smoothed_level']),
            'corr_smoothed_increment': float(best['corr_smoothed_increment']),
        })
robust = pd.DataFrame(robust)

# build main matched segments
ndq_ref = refs['NASDAQ Composite']
peak_pos = int(np.nanargmax(ndq_ref.values))
peak_date = ndq_ref.index[peak_pos]
end = peak_pos - lead_main
start = end - N + 1
ref_match = ndq_ref.iloc[start:end+1]
ref_after = ndq_ref.iloc[end:peak_pos+1]

# summary statistics

def runup_stats(series):
    s = series.dropna()
    ret = s.pct_change().dropna()
    idx = s / s.iloc[0]
    cum = float(idx.iloc[-1] - 1)
    vol = float(ret.std() * np.sqrt(252))
    pos = float((ret > 0).mean())
    mdd = float((idx / idx.cummax() - 1).min())
    skew = float(ret.skew())
    return {'cum_return':cum,'ann_vol':vol,'pos_days':pos,'max_drawdown':mdd,'skew':skew}

stats_main = pd.DataFrame([
    {'series':'Current AI basket (last 252d)', **runup_stats(cur_main)},
    {'series':f'Dot-com NASDAQ segment ending {lead_main}d before peak', **runup_stats(ref_match)},
])

# relative strength chart data
spx_match = spx_dot.loc[ref_match.index[0]:ref_after.index[-1]]
cur_spx = spx_now.loc[cur_main.index[0]:cur_main.index[-1]]
# align broad and bubble proxy within windows
rel_dot = (ref_after.reindex(spx_match.index).ffill() / spx_match).dropna()
rel_ai = (cur_main.reindex(cur_spx.index).ffill() / cur_spx).dropna()

# ------------------ figures ------------------
figpaths = []

def fpath(name):
    p = OUTDIR / name
    figpaths.append(p)
    return p

# 1 naive overlay last 252d vs final 252d before dotcom peak
full_dot_seg = ndq_ref.iloc[peak_pos-N+1:peak_pos+1]
fig, ax = plt.subplots(figsize=(8.5,5.1))
ax.plot(norm_log(cur_main).values, label='Current AI basket (last 252 trading days)')
ax.plot(norm_log(full_dot_seg).values, label='NASDAQ Composite (final 252 trading days before dot-com peak)')
ax.set_title('Current AI run-up and the final year of the dot-com ascent')
ax.set_xlabel('Trading days from window start')
ax.set_ylabel('Normalized log price')
ax.legend(fontsize=9)
savefig(fpath('fig_overlay_naive.png'))

# 2 best fit overlay with future path to peak
fig, ax = plt.subplots(figsize=(8.8,5.2))
# main matched overlay
ax.plot(norm_log(cur_main).values, linewidth=2, label='Current AI basket')
ax.plot(norm_log(ref_match).values, linewidth=2, label=f'Dot-com NASDAQ matched segment (ends {lead_main}d before peak)')
# remaining to peak path appended on same axis
future_x = np.arange(len(ref_match)-1, len(ref_match)-1 + len(ref_after))
future_y = norm_log(ref_after).values - norm_log(ref_after).values[0] + norm_log(ref_match).values[-1]
ax.plot(future_x, future_y, linestyle='--', linewidth=1.8, label='Dot-com path from matched point to peak')
ax.axvline(len(ref_match)-1, color='gray', linestyle=':', linewidth=1)
ax.annotate(f'Estimated lead to peak: {lead_main} trading days', xy=(len(ref_match)-1, norm_log(ref_match).values[-1]), xytext=(110, norm_log(ref_match).values[-1]+0.18), arrowprops=dict(arrowstyle='->', lw=1))
ax.set_title('Best-fit time-shifted overlay')
ax.set_xlabel('Trading days from start of matched window')
ax.set_ylabel('Normalized log price')
ax.legend(fontsize=8, loc='upper left')
savefig(fpath('fig_overlay_bestfit.png'))

# 3 objective curve
fig, ax = plt.subplots(figsize=(8.0,4.8))
ax.plot(res_main['lead_days'], res_main['rmse_log_level'], linewidth=2)
ax.scatter([lead_main], [best_main['rmse_log_level']], s=35)
ax.axvline(lead_main, linestyle='--', linewidth=1)
ax.set_title('Distance minimization over time shift')
ax.set_xlabel('Lead to dot-com peak (trading days)')
ax.set_ylabel('RMSE between smoothed normalized log paths')
ax.annotate(f'Minimum at {lead_main} days', xy=(lead_main, best_main['rmse_log_level']), xytext=(lead_main+8, best_main['rmse_log_level']+0.01), arrowprops=dict(arrowstyle='->', lw=1))
savefig(fpath('fig_objective_curve.png'))

# 4 robustness bar chart
fig, ax = plt.subplots(figsize=(9.2,5.1))
labels = [f"{r['current_proxy']}\nvs {r['dotcom_proxy']}" for _,r in robust.iterrows()]
ax.bar(np.arange(len(robust)), robust['lead_days'])
ax.set_xticks(np.arange(len(robust)))
ax.set_xticklabels(labels, rotation=35, ha='right', fontsize=8)
ax.set_ylabel('Estimated lead to peak (trading days)')
ax.set_title('Robustness of the time-shift estimate across alternative proxies')
savefig(fpath('fig_robustness_leads.png'))

# 5 bubble vs broad market relative strength
fig, ax = plt.subplots(figsize=(8.6,5.2))
ax.plot((rel_dot/rel_dot.iloc[0]).values, label='Dot-com NASDAQ / S&P 500')
ax.plot((rel_ai/rel_ai.iloc[0]).values, label='Current AI basket / S&P 500')
ax.set_title('Relative-strength comparison: bubble proxy versus broad market')
ax.set_xlabel('Trading days from window start')
ax.set_ylabel('Relative strength, normalized to 1.0')
ax.legend(fontsize=9)
savefig(fpath('fig_relative_strength.png'))

# 6 sample current-vs-dotcom returns distribution
fig, ax = plt.subplots(figsize=(8.6,4.8))
bins = np.linspace(min(cur_main.pct_change().dropna().min(), ref_match.pct_change().dropna().min()), max(cur_main.pct_change().dropna().max(), ref_match.pct_change().dropna().max()), 40)
ax.hist(cur_main.pct_change().dropna(), bins=bins, alpha=0.6, label='Current AI basket daily returns')
ax.hist(ref_match.pct_change().dropna(), bins=bins, alpha=0.6, label='Matched dot-com segment daily returns')
ax.set_title('Distribution of daily returns in the two run-up windows')
ax.set_xlabel('Daily return')
ax.set_ylabel('Frequency')
ax.legend(fontsize=9)
savefig(fpath('fig_return_distribution.png'))

# 7 rolling drawdowns in matched windows

def drawdown_series(series):
    idx = series / series.iloc[0]
    return idx / idx.cummax() - 1

fig, ax = plt.subplots(figsize=(8.5,4.9))
ax.plot(drawdown_series(cur_main).values, label='Current AI basket')
ax.plot(drawdown_series(ref_match).values, label='Matched dot-com segment')
ax.set_title('Drawdown behaviour inside the matched run-up windows')
ax.set_xlabel('Trading days from window start')
ax.set_ylabel('Drawdown')
ax.legend(fontsize=9)
savefig(fpath('fig_drawdowns.png'))

# 8 smoothed momentum chart
fig, ax = plt.subplots(figsize=(8.5,4.9))
m1 = norm_log(cur_main).diff(20)
m2 = norm_log(ref_match).diff(20)
ax.plot(m1.values, label='Current AI basket: 20d log momentum')
ax.plot(m2.values, label='Matched dot-com segment: 20d log momentum')
ax.set_title('Momentum profile in the matched windows')
ax.set_xlabel('Trading days from window start')
ax.set_ylabel('20-day log return')
ax.legend(fontsize=9)
savefig(fpath('fig_momentum.png'))

# ------------------ output tables ------------------
robust_csv = BASE/'ai_bubble_dotcom_precursor_lead_estimates.csv'
robust.to_csv(robust_csv, index=False)
stats_csv = BASE/'ai_bubble_dotcom_precursor_summary_stats.csv'
stats_main.to_csv(stats_csv, index=False)
objective_csv = BASE/'ai_bubble_dotcom_precursor_objective_curve.csv'
res_main.to_csv(objective_csv, index=False)

# ------------------ LaTeX ------------------
pdf = BASE/'ai_bubble_dotcom_precursor_report.pdf'
tex = BASE/'ai_bubble_dotcom_precursor_report.tex'

scenario_sentence = f"Using the main specification --- the equal-weight AI basket of SMH, SOXX, IGV, SKYY, AIQ, and IXN versus the NASDAQ Composite --- the distance-minimization objective is minimized at {lead_main} trading days before the dot-com peak."

latex = rf'''
\documentclass[11pt]{{article}}
\usepackage{{graphicx}}
\usepackage{{amsmath}}
\setlength{{\parindent}}{{0pt}}
\setlength{{\parskip}}{{0.6em}}
\begin{{document}}

\title{{Why the Dot-Com Bubble Is a Useful Precursor for the Current AI Bubble}}
\author{{Precursor Note for the AI Unwind Theory Section}}
\date{{July 2026}}
\maketitle

\section*{{Executive summary}}
This note is designed as a hook for the main theory section. Its purpose is not to claim that the current AI cycle must mechanically repeat the dot-com episode. Rather, it shows that the dot-com bubble is a useful historical analogue because the two episodes share a common economic structure and, importantly, display statistically similar run-up dynamics when one compares normalized price paths.

The key empirical result is simple. We construct a current AI bubble proxy using an equal-weight basket of six ETFs --- SMH, SOXX, IGV, SKYY, AIQ, and IXN --- and compare its most recent 252-trading-day run-up with pre-peak segments of the dot-com NASDAQ Composite. We then shift the dot-com curve along the time axis and compute a distance measure between the two normalized log-price paths. {scenario_sentence} This does not prove that the current cycle must peak exactly that far in the future, but it does support the argument that the current AI cycle still resembles an earlier, not yet fully exhausted, phase of the dot-com ascent.

\section{{Why the dot-com episode is the natural historical analogue}}
The case for using dot-com as a precursor is based on both economics and market structure. In both episodes, the market narrative is built around a general-purpose technology with potentially economy-wide implications. In both episodes, the most direct beneficiaries are not just final application firms, but also enabling infrastructure and platform providers. In both episodes, capital-market excitement spills from a narrow group of perceived winners into a broader ecosystem. And in both episodes, broad indices are pulled upward by a relatively concentrated set of technology names.

This note therefore uses dot-com as an analogue in a disciplined way: not as a one-line slogan, but as a data-based comparison of run-up geometry.

\section{{Data and bubble proxies}}
We work with two families of bubble proxies.

For the current cycle, the main proxy is an equal-weight AI basket formed from six liquid ETFs: SMH, SOXX, IGV, SKYY, AIQ, and IXN. This basket intentionally combines semiconductors, software, cloud, and broader technology exposure. We also use NASDAQ100, SMH, and SOXX as alternative current-cycle proxies.

For the dot-com cycle, the main reference proxy is the NASDAQ Composite. As a robustness check, we also use a TMT industry proxy built from the Fama--French 49-industry daily portfolios, averaging Hardware, Software, Chips, and Telecommunications.

The broad-market control is the S\&P 500. It is used to compare the relative strength of the bubble proxy against the rest of the market.

\section{{A first visual comparison}}
The simplest comparison is to place the current AI run-up beside the final year of the dot-com ascent and normalize both paths so they start at the same value.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.86\textwidth]{{{(OUTDIR/'fig_overlay_naive.png').as_posix()}}}
\caption{{Current AI run-up versus the final 252 trading days before the dot-com peak. Both paths are shown in normalized log-price space. The point is not that the two lines are identical, but that the current run-up has a similar convex and accelerating shape.}}
\end{{figure}}

This first chart is intentionally simple. It already gives the visual intuition: a substantial part of the current AI run-up looks closer to the pre-peak geometry of dot-com than to a mature, already exhausted post-peak profile.

\section{{Formal time-shift methodology}}
To turn the visual intuition into a quantitative heuristic, we define a smoothed normalized log-price path for the current AI basket and compare it with candidate pre-peak dot-com segments.

Let $P_t^A$ denote the current AI proxy and let $P_t^D$ denote the dot-com proxy. For a window length $N$, define the normalized log-price path
\[
x_t = \log\left(\frac{{P_t}}{{P_0}}\right), \qquad t=0,1,\dots,N-1.
\]
We then smooth the path with a short moving average to emphasize shape rather than day-to-day noise. For each candidate lead $\ell$ to the dot-com peak, we extract the dot-com segment that ends $\ell$ trading days before the peak and compute the distance
\[
d(\ell) = \sqrt{{\frac{{1}}{{N}}\sum_{{t=0}}^{{N-1}} \left( x_t^A - x_t^{{D,\ell}} \right)^2 }}.
\]
The estimated lead to peak is the value
\[
\hat{{\ell}} = \arg\min_\ell d(\ell).
\]
The interpretation is straightforward. If $\hat{{\ell}}=0$, the current AI path most closely resembles the final moments before the dot-com peak. If $\hat{{\ell}}>0$, the current AI path more closely resembles an earlier point in the dot-com ascent. This is exactly the sense in which the exercise can support the claim that the current AI cycle may not yet be at peak conditions.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.82\textwidth]{{{(OUTDIR/'fig_objective_curve.png').as_posix()}}}
\caption{{The distance-minimization objective as a function of lead to the dot-com peak. The minimum occurs at {lead_main} trading days in the main specification.}}
\end{{figure}}

\section{{Main result: the current AI cycle still resembles a pre-peak dot-com segment}}
The best-fit overlay is shown below. The solid lines show the current AI basket and the matched dot-com segment. The dashed line continues the dot-com path from the matched point up to the actual peak.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.90\textwidth]{{{(OUTDIR/'fig_overlay_bestfit.png').as_posix()}}}
\caption{{Best-fit overlay. The current AI basket most closely resembles the dot-com NASDAQ path roughly {lead_main} trading days before the peak. The dashed extension shows the remaining dot-com path from the matched point to the peak.}}
\end{{figure}}

This figure is the core visual. It is not a forecasting model in the narrow sense, but it is a disciplined similarity heuristic. It says that, on the chosen distance metric, the current AI run-up has more in common with a pre-peak segment of dot-com than with the dot-com peak itself.

\section{{Statistical comparison of the matched windows}}
The table below summarizes a few simple statistics for the current AI basket and the matched dot-com segment.

\begin{{center}}
\small
\begin{{tabular}}{{lrrrrr}}
Series & Cumulative return & Annualized vol & Positive-day share & Max drawdown & Skew \\
\hline
Current AI basket (last 252d) & {stats_main.iloc[0]['cum_return']:.2f} & {stats_main.iloc[0]['ann_vol']:.2f} & {stats_main.iloc[0]['pos_days']:.2f} & {stats_main.iloc[0]['max_drawdown']:.2f} & {stats_main.iloc[0]['skew']:.2f} \\
Matched dot-com NASDAQ segment & {stats_main.iloc[1]['cum_return']:.2f} & {stats_main.iloc[1]['ann_vol']:.2f} & {stats_main.iloc[1]['pos_days']:.2f} & {stats_main.iloc[1]['max_drawdown']:.2f} & {stats_main.iloc[1]['skew']:.2f} \\
\hline
\end{{tabular}}
\end{{center}}

In addition to the summary table, several charts help show that the similarity is not purely cosmetic.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.82\textwidth]{{{(OUTDIR/'fig_return_distribution.png').as_posix()}}}
\caption{{Distribution of daily returns in the two matched windows. The two episodes are not identical, but the current AI run-up does occupy the same broad high-volatility, right-skewed growth regime as the pre-peak dot-com segment.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.82\textwidth]{{{(OUTDIR/'fig_drawdowns.png').as_posix()}}}
\caption{{Drawdown paths in the matched windows. Both episodes experience meaningful pullbacks while still maintaining a strong upward trend, which is characteristic of an unstable but still rising bubble phase.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.82\textwidth]{{{(OUTDIR/'fig_momentum.png').as_posix()}}}
\caption{{Twenty-day momentum in the matched windows. The current AI episode, like the matched dot-com segment, shows repeated momentum bursts rather than a smooth linear climb.}}
\end{{figure}}

\section{{Relative-strength evidence}}
One reason dot-com is a useful analogue is that both episodes are not merely technology rallies; they are rallies in which the bubble proxy increasingly dominates the broad market. This can be visualized by comparing the bubble proxy with the S\&P 500.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.84\textwidth]{{{(OUTDIR/'fig_relative_strength.png').as_posix()}}}
\caption{{Relative strength of the bubble proxy against the broad market. In both episodes, the bubble proxy increasingly outperforms the broad market during the run-up.}}
\end{{figure}}

This matters because the main AI unwind framework later decomposes stress into a broad-market leg and an AI/TMT-excess leg. The relative-strength evidence provides an intuitive preview of that decomposition: the bubble proxy is not just rising with the market; it is pulling away from the market.

\section{{Robustness across alternative proxies}}
A natural question is whether the result depends on one very specific proxy choice. The answer is no. The figure below shows the implied lead to peak across several current-cycle proxies and two dot-com reference proxies.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.94\textwidth]{{{(OUTDIR/'fig_robustness_leads.png').as_posix()}}}
\caption{{Robustness of the lead-to-peak estimate. The broad AI basket and NASDAQ100 typically map to a point around one to two months before the dot-com peak. Semiconductor-only proxies such as SMH and SOXX appear later-cycle, which is economically intuitive because semiconductors sit closest to the infrastructure epicenter.}}
\end{{figure}}

The robustness chart provides a useful nuance for management discussion. A broad AI ecosystem proxy still looks somewhat earlier-cycle, while semiconductor-centric proxies can look later-cycle. This is not a contradiction. It simply means the most AI-concentrated parts of the market may be further advanced than the broader AI ecosystem.

\section{{What this precursor note does and does not claim}}
This analysis is intentionally modest in what it claims. It does \emph{{not}} claim that the market must peak in exactly {lead_main} trading days. It does \emph{{not}} claim that the current cycle will replicate the dot-com collapse point-for-point. And it does \emph{{not}} claim that similarity in normalized price paths is a complete model of bubble risk.

What it does claim is much narrower and more useful: dot-com is a defensible historical analogue, the current AI run-up can be statistically aligned with a pre-peak segment of dot-com, and that alignment provides a coherent narrative bridge into the main theory of the AI unwind model.

\section*{{How this supports the main theory section}}
This precursor naturally leads to the full theory note. Once the reader accepts that the current AI cycle is a meaningful descendant of the dot-com episode, it becomes much easier to motivate the next steps in the full framework:
\begin{{itemize}}
\item decompose the unwind into a broad-market shock and an AI/TMT-excess shock;
\item measure which countries, industries, and single stocks carry that excess AI sensitivity;
\item calibrate short-horizon and peak-to-trough shocks using a dot-com-based anchor;
\item and then apply the resulting stress vectors to the risk book.
\end{{itemize}}

\end{{document}}
'''
tex.write_text(latex)

# compile
os.chdir(BASE)
os.system(f'pdflatex -interaction=nonstopmode {tex.name} > /tmp/dotcom_precursor.log 2>&1')
os.system(f'pdflatex -interaction=nonstopmode {tex.name} >> /tmp/dotcom_precursor.log 2>&1')

# assemble bundle
bundle_files = [pdf, tex, robust_csv, stats_csv, objective_csv, BASE/'build_dotcom_precursor_report.py'] + figpaths
for fp in bundle_files:
    if Path(fp).exists():
        dst = OUTDIR / Path(fp).name
        if Path(fp).resolve() != dst.resolve():
            shutil.copy2(fp, dst)

zip_path = BASE/'ai_bubble_dotcom_precursor_bundle.zip'
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for fp in OUTDIR.iterdir():
        z.write(fp, arcname=fp.name)

print('pdf', pdf.exists(), pdf)
print('zip', zip_path.exists(), zip_path)
print('lead', lead_main)
print('summary files', robust_csv, stats_csv, objective_csv)
