Vanilla LaTeX build: pdflatex ai_unwind_model_construction_methodology_v5_expanded.tex
No latexmk/perl required. Uses only graphicx.
