"""Canonical stress operator and return/P&L conversions."""
from __future__ import annotations
import numpy as np


def stress_log_return(beta_world, world_shock_log, ai_intensity,
                      ai_excess_shock_log, size_overlay_log=0.0):
    """R = beta*S_W + I_AI*S_X + A_size, all in log-return space."""
    return (
        np.asarray(beta_world, dtype=float) * float(world_shock_log)
        + np.asarray(ai_intensity, dtype=float) * float(ai_excess_shock_log)
        + np.asarray(size_overlay_log, dtype=float)
    )


def simple_return(log_return):
    """Exact conversion from log return to simple return."""
    return np.exp(np.asarray(log_return, dtype=float)) - 1.0


def position_stress_pnl(signed_market_value_usd, stressed_simple_return):
    """Positive number is loss; shorts may produce gains before adverse-only policy."""
    return -np.asarray(signed_market_value_usd, dtype=float) * np.asarray(
        stressed_simple_return, dtype=float
    )


def adverse_only_loss(stress_pnl_usd):
    """Reporting transform applied after signed economic P&L."""
    return np.maximum(np.asarray(stress_pnl_usd, dtype=float), 0.0)
