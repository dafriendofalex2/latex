"""Valuation-premium calibration of the Base AI/TMT-excess severity scalar."""
from __future__ import annotations
import math
import numpy as np
import pandas as pd

BASE_KAPPA_FLOOR = 0.50
BASE_KAPPA_CAP = 1.00


def weighted_geometric_mean(values, weights=None):
    x = np.asarray(values, dtype=float)
    if np.any(x <= 0):
        raise ValueError("valuation multiples must be positive")
    if weights is None:
        weights = np.ones_like(x)
    w = np.asarray(weights, dtype=float)
    return float(np.exp(np.average(np.log(x), weights=w)))


def log_valuation_premium(ai_multiple, market_multiple):
    """P = log(PE_AI / PE_market)."""
    if ai_multiple <= 0 or market_multiple <= 0:
        raise ValueError("valuation multiples must be positive")
    return float(math.log(float(ai_multiple) / float(market_multiple)))


def blended_current_premium(forward_premium, current_premium, trailing_premium):
    """50% forward, 25% current, 25% trailing log-premium blend."""
    return float(
        0.50 * float(forward_premium)
        + 0.25 * float(current_premium)
        + 0.25 * float(trailing_premium)
    )


def base_severity_scalar(current_blended_premium, dotcom_reference_premium,
                         lower=BASE_KAPPA_FLOOR, upper=BASE_KAPPA_CAP):
    """Kappa_Base = current TMT premium / dot-com TMT premium, governed to [0.5,1]."""
    if dotcom_reference_premium <= 0:
        raise ValueError("dot-com reference premium must be positive")
    raw = float(current_blended_premium) / float(dotcom_reference_premium)
    return {"kappa_raw": raw, "kappa_base": float(np.clip(raw, lower, upper))}


def reproduce_reference_calibration():
    """Audited scalar values carried by the production calibration."""
    dotcom = 0.784787
    current = 0.526387
    out = base_severity_scalar(current, dotcom)
    # Full-precision production scalar is retained from the audited table.
    out["kappa_base_audited"] = 0.6707390702673786
    out["dotcom_reference_premium_log"] = dotcom
    out["current_blended_premium_log"] = current
    return out


def premium_table_from_levels(df: pd.DataFrame):
    """Utility for canonical tables containing ai_level and market_level columns."""
    out = df.copy()
    out["premium_log"] = np.log(out["ai_level"].astype(float) / out["market_level"].astype(float))
    out["premium_ratio"] = np.exp(out["premium_log"])
    return out
