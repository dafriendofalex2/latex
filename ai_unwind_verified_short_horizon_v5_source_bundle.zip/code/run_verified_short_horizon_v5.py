import os, re, math, json, shutil, subprocess, zipfile, textwrap
from pathlib import Path
from datetime import datetime

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path('/mnt/data')
OUT = ROOT / 'ai_unwind_short_horizon_verified_v5'
DATA = OUT / 'data'
FIG = OUT / 'figures'
CODE = OUT / 'code'
for d in [OUT, DATA, FIG, CODE]:
    d.mkdir(parents=True, exist_ok=True)

PATHS = {
    'ci': ROOT / 'country_industry_stress_vector_v5(1).csv',
    'ss': ROOT / 'single_stock_override_vector_v5(1).csv',
    'scenario': ROOT / 'scenario_parameters_v5.csv',
    'spx': ROOT / 'spx(1).csv',
    'ff49_daily': ROOT / '49_Industry_Portfolios_Daily(1).csv',
    'ff_factors_daily': ROOT / 'F-F_Research_Data_Factors_daily(1).csv',
}
for k,p in PATHS.items():
    if not p.exists():
        raise FileNotFoundError(f'Missing required file {k}: {p}')

# ----------------------------
# Parsers
# ----------------------------
def parse_french_49_daily(path: Path) -> pd.DataFrame:
    with open(path, 'r', errors='replace') as f:
        lines = f.readlines()
    header_idx = None
    for i, line in enumerate(lines):
        if line.strip().startswith(',Agric'):
            header_idx = i
            break
    if header_idx is None:
        raise ValueError('Could not locate FF49 daily header starting with ,Agric')
    header = [x.strip() for x in lines[header_idx].strip().split(',')]
    cols = ['date'] + header[1:]
    rows = []
    for line in lines[header_idx + 1:]:
        first = line.split(',', 1)[0].strip()
        if not re.match(r'^\d{8}$', first):
            break
        parts = [x.strip() for x in line.rstrip('\n').split(',')]
        if len(parts) >= len(cols):
            rows.append(parts[:len(cols)])
    df = pd.DataFrame(rows, columns=cols)
    df['date'] = pd.to_datetime(df['date'], format='%Y%m%d')
    for c in cols[1:]:
        df[c] = pd.to_numeric(df[c], errors='coerce') / 100.0
        df.loc[df[c] <= -0.99, c] = np.nan
    return df.set_index('date').sort_index()


def parse_french_factors_daily(path: Path) -> pd.DataFrame:
    with open(path, 'r', errors='replace') as f:
        lines = f.readlines()
    header_idx = None
    for i, line in enumerate(lines):
        if line.strip().startswith(',Mkt-RF'):
            header_idx = i
            break
    if header_idx is None:
        raise ValueError('Could not locate FF factor daily header')
    header = [x.strip() for x in lines[header_idx].strip().split(',')]
    cols = ['date'] + header[1:]
    rows = []
    for line in lines[header_idx + 1:]:
        first = line.split(',', 1)[0].strip()
        if not re.match(r'^\d{8}$', first):
            break
        parts = [x.strip() for x in line.rstrip('\n').split(',')]
        if len(parts) >= len(cols):
            rows.append(parts[:len(cols)])
    df = pd.DataFrame(rows, columns=cols)
    df['date'] = pd.to_datetime(df['date'], format='%Y%m%d')
    for c in cols[1:]:
        df[c] = pd.to_numeric(df[c], errors='coerce') / 100.0
    return df.set_index('date').sort_index()


def parse_spx(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = [c.strip().lower() for c in df.columns]
    if 'date' not in df.columns or 'close' not in df.columns:
        raise ValueError(f'SPX file must have date and close columns. Got {df.columns.tolist()}')
    df['date'] = pd.to_datetime(df['date'], format='%d-%b-%y', errors='coerce')
    if df['date'].isna().any():
        df['date'] = pd.to_datetime(df['date'], errors='coerce')
    df['close'] = pd.to_numeric(df['close'], errors='coerce')
    df = df.dropna(subset=['date', 'close']).drop_duplicates('date').sort_values('date')
    df = df.set_index('date')
    df['spx_log_ret'] = np.log(df['close']).diff()
    df['spx_simple_ret'] = df['close'].pct_change()
    return df

# ----------------------------
# Load data
# ----------------------------
ci = pd.read_csv(PATHS['ci'])
ss = pd.read_csv(PATHS['ss'])
scenario_terminal = pd.read_csv(PATHS['scenario'])
ff49 = parse_french_49_daily(PATHS['ff49_daily'])
ff = parse_french_factors_daily(PATHS['ff_factors_daily'])
spx = parse_spx(PATHS['spx'])

# Data validation
for col in ['beta_world_cell','final_ai_excess_intensity']:
    if col not in ci.columns:
        raise ValueError(f'country-industry vector missing {col}')
for col in ['beta_world_stock','final_ai_excess_intensity']:
    if col not in ss.columns:
        raise ValueError(f'single-stock override vector missing {col}')
for col in ['scenario','world_scale','valuation_severity_scalar']:
    if col not in scenario_terminal.columns:
        raise ValueError(f'scenario file missing {col}')

TMT_COLS = ['Hardw','Softw','Chips','Telcm']
missing_tmt = [c for c in TMT_COLS if c not in ff49.columns]
if missing_tmt:
    raise ValueError(f'FF49 daily file missing TMT columns: {missing_tmt}')

# TMT basket: daily-rebalanced equal-weight basket of the four dot-com TMT industries.
original_ff49_cols = [c for c in ff49.columns]
ff49['TMT4_simple'] = ff49[TMT_COLS].mean(axis=1, skipna=False)
ff49['TMT4_log'] = np.log1p(ff49['TMT4_simple'])
ff49['TMT3_simple'] = ff49[['Hardw','Softw','Chips']].mean(axis=1, skipna=False)
ff49['TMT3_log'] = np.log1p(ff49['TMT3_simple'])
ff49['TMT5_simple'] = ff49[['Hardw','Softw','Chips','Telcm','BusSv']].mean(axis=1, skipna=False)
ff49['TMT5_log'] = np.log1p(ff49['TMT5_simple'])
ff49['All49_simple'] = ff49[original_ff49_cols].mean(axis=1, skipna=True)
ff49['All49_log'] = np.log1p(ff49['All49_simple'])

ff['ff_market_simple'] = ff['Mkt-RF'] + ff['RF']
ff['ff_market_log'] = np.log1p(ff['ff_market_simple'])

common = ff49[['TMT4_simple','TMT4_log','TMT3_simple','TMT3_log','TMT5_simple','TMT5_log','All49_simple','All49_log']].join(spx[['close','spx_log_ret','spx_simple_ret']], how='inner')
common = common.join(ff[['ff_market_simple','ff_market_log']], how='left')
common = common.dropna(subset=['TMT4_log','spx_log_ret'])

# Main calibration window. Start early enough to identify the dot-com run-up and stop after post-bust trough.
cal = common.loc['1995-01-01':'2002-12-31'].copy()
if cal.empty:
    raise ValueError('No aligned daily data in calibration window 1995-2002')
cal['TMT4_wealth'] = np.exp(cal['TMT4_log'].cumsum())
cal['TMT3_wealth'] = np.exp(cal['TMT3_log'].cumsum())
cal['TMT5_wealth'] = np.exp(cal['TMT5_log'].cumsum())
cal['SPX_wealth'] = cal['close'] / cal['close'].iloc[0]
cal['All49_wealth'] = np.exp(cal['All49_log'].cumsum())

peak_date = cal.loc[:'2000-03-31', 'TMT4_wealth'].idxmax()
trough_date = cal.loc[peak_date:, 'TMT4_wealth'].idxmin()
common_dates = list(common.index)
peak_pos = common_dates.index(peak_date)

# Primary margin interpretation: max drawdown reached at any date by the horizon deadline.
# Also compute exact endpoint close-to-close return as an audit.
def horizon_anchor(h_days: int, label: str) -> dict:
    if peak_pos + h_days >= len(common_dates):
        raise ValueError(f'Horizon {h_days} exceeds available data after peak')
    exact_end_date = common_dates[peak_pos + h_days]
    fwd = common.iloc[peak_pos+1:peak_pos+h_days+1].copy()
    for col in ['TMT4_log','TMT3_log','TMT5_log','spx_log_ret','All49_log','ff_market_log']:
        fwd[f'cum_{col}'] = fwd[col].cumsum()
    anchor_date = fwd['cum_TMT4_log'].idxmin()
    trading_days_to_anchor = int(common_dates.index(anchor_date) - peak_pos)
    fwd_to_anchor = common.iloc[peak_pos+1:peak_pos+trading_days_to_anchor+1]
    fwd_exact = common.iloc[peak_pos+1:peak_pos+h_days+1]
    def sum_col(df, col): return float(df[col].sum())
    out = {
        'horizon': label,
        'horizon_trading_days': h_days,
        'peak_date': peak_date.strftime('%Y-%m-%d'),
        'anchor_date': anchor_date.strftime('%Y-%m-%d'),
        'calendar_days_to_anchor': int((anchor_date - peak_date).days),
        'trading_days_to_anchor': trading_days_to_anchor,
        'exact_end_date': exact_end_date.strftime('%Y-%m-%d'),
        'calendar_days_to_exact_end': int((exact_end_date - peak_date).days),
        # Primary short-horizon drawdown by deadline.
        'S_TMT_log': sum_col(fwd_to_anchor, 'TMT4_log'),
        'S_WORLD_log': sum_col(fwd_to_anchor, 'spx_log_ret'),
        'S_TMT3_log_audit': sum_col(fwd_to_anchor, 'TMT3_log'),
        'S_TMT5_log_audit': sum_col(fwd_to_anchor, 'TMT5_log'),
        'S_ALL49_log_audit': sum_col(fwd_to_anchor, 'All49_log'),
        'S_FF_MARKET_log_audit': sum_col(fwd_to_anchor, 'ff_market_log'),
        # Exact close-to-close endpoint audit.
        'endpoint_S_TMT_log': sum_col(fwd_exact, 'TMT4_log'),
        'endpoint_S_WORLD_log': sum_col(fwd_exact, 'spx_log_ret'),
        'endpoint_S_TMT3_log_audit': sum_col(fwd_exact, 'TMT3_log'),
        'endpoint_S_TMT5_log_audit': sum_col(fwd_exact, 'TMT5_log'),
        'endpoint_S_ALL49_log_audit': sum_col(fwd_exact, 'All49_log'),
        'endpoint_S_FF_MARKET_log_audit': sum_col(fwd_exact, 'ff_market_log'),
    }
    out['S_AI_EXCESS_log'] = out['S_TMT_log'] - out['S_WORLD_log']
    out['S_AI_EXCESS_vs_ALL49_log_audit'] = out['S_TMT_log'] - out['S_ALL49_log_audit']
    out['S_AI_EXCESS_vs_FF_MARKET_log_audit'] = out['S_TMT_log'] - out['S_FF_MARKET_log_audit']
    out['endpoint_S_AI_EXCESS_log'] = out['endpoint_S_TMT_log'] - out['endpoint_S_WORLD_log']
    out['endpoint_S_AI_EXCESS_vs_ALL49_log_audit'] = out['endpoint_S_TMT_log'] - out['endpoint_S_ALL49_log_audit']
    out['endpoint_S_AI_EXCESS_vs_FF_MARKET_log_audit'] = out['endpoint_S_TMT_log'] - out['endpoint_S_FF_MARKET_log_audit']
    return out

anchors = [horizon_anchor(5, '1w'), horizon_anchor(10, '2w'), horizon_anchor(21, '1m')]
anchor_df = pd.DataFrame(anchors)
log_cols = [c for c in anchor_df.columns if c.endswith('_log') or '_log_' in c]
for col in log_cols:
    simple_col = col.replace('_log', '_simple')
    pct_col = col.replace('_log', '_pct')
    anchor_df[simple_col] = np.exp(anchor_df[col]) - 1.0
    anchor_df[pct_col] = 100.0 * (np.exp(anchor_df[col]) - 1.0)
anchor_df.to_csv(DATA / 'verified_short_horizon_anchor_diagnostics.csv', index=False)
anchor_df.to_csv(ROOT / 'ai_unwind_v5_verified_short_horizon_anchor_diagnostics.csv', index=False)

# Raw daily path audit around peak.
daily_audit_cols = ['TMT4_simple','Hardw','Softw','Chips','Telcm','spx_simple_ret','close']
daily_audit = common.loc['2000-03-20':'2000-04-28', [c for c in daily_audit_cols if c in common.columns]].copy()
# Add cumulative from peak for display.
def cumulative_from_peak(ret_col, d):
    if d == peak_date:
        return 0.0
    elif d > peak_date:
        return float(np.exp(common.loc[peak_date:d, ret_col].iloc[1:].sum()) - 1.0)
    else:
        return np.nan
daily_audit['cum_TMT_from_peak'] = [cumulative_from_peak('TMT4_log', d) for d in daily_audit.index]
daily_audit['cum_SPX_from_peak'] = [cumulative_from_peak('spx_log_ret', d) for d in daily_audit.index]
daily_audit.to_csv(DATA / 'raw_daily_returns_around_dotcom_tmt_peak.csv')

# Terminal audit from the same daily data, for sanity; not used as short-horizon shock.
term_tmt_log = float(common.loc[peak_date:trough_date, 'TMT4_log'].iloc[1:].sum())
term_spx_log = float(common.loc[peak_date:trough_date, 'spx_log_ret'].iloc[1:].sum())
terminal_daily_audit = pd.DataFrame([{
    'peak_date': peak_date.strftime('%Y-%m-%d'),
    'trough_date': trough_date.strftime('%Y-%m-%d'),
    'trading_days_to_trough': int(common_dates.index(trough_date) - peak_pos),
    'TMT_peak_to_trough_log': term_tmt_log,
    'TMT_peak_to_trough_pct': 100*(math.exp(term_tmt_log)-1),
    'SPX_same_window_log': term_spx_log,
    'SPX_same_window_pct': 100*(math.exp(term_spx_log)-1),
    'TMT_excess_vs_SPX_log': term_tmt_log - term_spx_log,
    'TMT_excess_vs_SPX_pct_equiv': 100*(math.exp(term_tmt_log - term_spx_log)-1),
}])
terminal_daily_audit.to_csv(DATA / 'terminal_daily_audit_not_used_as_short_horizon_anchor.csv', index=False)

# ----------------------------
# Scenario construction using original v5 scaling logic.
# ----------------------------
scaling = scenario_terminal[['scenario','world_scale','valuation_severity_scalar','description']].copy()
scaling['scenario'] = scaling['scenario'].str.lower()
scenario_order = ['mild','base','severe']
scaling = scaling.set_index('scenario').loc[scenario_order].reset_index()

scenario_rows = []
for _, a in anchor_df.iterrows():
    raw_sw = float(a['S_WORLD_log'])
    raw_sx = float(a['S_AI_EXCESS_log'])
    for _, s in scaling.iterrows():
        scen = s['scenario']
        world_scale = float(s['world_scale'])
        ai_scalar = float(s['valuation_severity_scalar'])
        sw = world_scale * raw_sw
        sx = ai_scalar * raw_sx
        se = sw + sx
        scenario_rows.append({
            'horizon': a['horizon'],
            'horizon_trading_days': int(a['horizon_trading_days']),
            'scenario': scen,
            'world_scale': world_scale,
            'valuation_severity_scalar': ai_scalar,
            'peak_date': a['peak_date'],
            'anchor_date': a['anchor_date'],
            'trading_days_to_anchor': int(a['trading_days_to_anchor']),
            'exact_end_date': a['exact_end_date'],
            'S_TMT_raw_dotcom_log': float(a['S_TMT_log']),
            'S_WORLD_raw_dotcom_log': raw_sw,
            'S_AI_EXCESS_raw_dotcom_log': raw_sx,
            'S_WORLD_log': sw,
            'S_AI_EXCESS_log': sx,
            'S_AI_EPICENTER_log': se,
            'S_WORLD_simple': math.exp(sw)-1,
            'S_WORLD_pct': 100*(math.exp(sw)-1),
            'S_AI_EXCESS_simple': math.exp(sx)-1,
            'S_AI_EXCESS_pct': 100*(math.exp(sx)-1),
            'S_AI_EPICENTER_simple': math.exp(se)-1,
            'S_AI_EPICENTER_pct': 100*(math.exp(se)-1),
            'anchor_method': 'peak_anchored_max_tmt_drawdown_by_horizon_deadline',
            'broad_market_proxy': 'S&P 500 daily close from uploaded spx file',
            'tmt_proxy': 'FF49 daily value-weight returns, equal-weight basket of Hardw, Softw, Chips, Telcm',
            'description': s['description'],
        })
scen_df = pd.DataFrame(scenario_rows)
scen_path = ROOT / 'ai_unwind_v5_verified_short_horizon_scenario_parameters.csv'
scen_df.to_csv(scen_path, index=False)
scen_df.to_csv(DATA / scen_path.name, index=False)

# Endpoint audit scenario parameters (not applied to stress vector by default).
endpoint_rows=[]
for _, a in anchor_df.iterrows():
    raw_sw = float(a['endpoint_S_WORLD_log'])
    raw_sx = float(a['endpoint_S_AI_EXCESS_log'])
    for _, s in scaling.iterrows():
        sw=float(s['world_scale'])*raw_sw
        sx=float(s['valuation_severity_scalar'])*raw_sx
        se=sw+sx
        endpoint_rows.append({
            'horizon':a['horizon'], 'scenario':s['scenario'], 'exact_end_date':a['exact_end_date'],
            'S_TMT_endpoint_log':float(a['endpoint_S_TMT_log']),
            'S_WORLD_endpoint_raw_log':raw_sw, 'S_AI_EXCESS_endpoint_raw_log':raw_sx,
            'S_WORLD_log':sw, 'S_AI_EXCESS_log':sx, 'S_AI_EPICENTER_log':se,
            'S_WORLD_pct':100*(math.exp(sw)-1), 'S_AI_EXCESS_pct':100*(math.exp(sx)-1), 'S_AI_EPICENTER_pct':100*(math.exp(se)-1),
            'note':'endpoint close-to-close audit only; primary files use maximum drawdown by horizon deadline'
        })
endpoint_scen_df=pd.DataFrame(endpoint_rows)
endpoint_scen_path=ROOT/'ai_unwind_v5_verified_short_horizon_endpoint_audit_scenario_parameters.csv'
endpoint_scen_df.to_csv(endpoint_scen_path,index=False)
endpoint_scen_df.to_csv(DATA/endpoint_scen_path.name,index=False)

# ----------------------------
# Apply scenarios to v5 exposure matrices.
# ----------------------------
SCEN_OUTPUT_COLS = [
    'mild_stress_log','mild_stress_simple','mild_stress_pct','mild_world_component_log','mild_ai_excess_component_log','mild_valuation_severity_scalar',
    'base_stress_log','base_stress_simple','base_stress_pct','base_world_component_log','base_ai_excess_component_log','base_valuation_severity_scalar',
    'severe_stress_log','severe_stress_simple','severe_stress_pct','severe_world_component_log','severe_ai_excess_component_log','severe_valuation_severity_scalar'
]

def apply_scenarios(df: pd.DataFrame, beta_col: str, intensity_col: str, horizon: str) -> pd.DataFrame:
    out = df.copy()
    drop_cols = [c for c in SCEN_OUTPUT_COLS if c in out.columns]
    if drop_cols:
        out = out.drop(columns=drop_cols)
    out.insert(0, 'short_horizon_anchor_method', 'peak_anchored_max_tmt_drawdown_by_horizon_deadline')
    out.insert(1, 'short_horizon', horizon)
    ssub = scen_df[scen_df['horizon'] == horizon].copy()
    for _, s in ssub.iterrows():
        sc = s['scenario']
        world_comp = out[beta_col].astype(float) * float(s['S_WORLD_log'])
        ai_comp = out[intensity_col].astype(float) * float(s['S_AI_EXCESS_log'])
        stress_log = world_comp + ai_comp
        out[f'{sc}_stress_log'] = stress_log
        out[f'{sc}_stress_simple'] = np.exp(stress_log) - 1.0
        out[f'{sc}_stress_pct'] = 100.0 * (np.exp(stress_log) - 1.0)
        out[f'{sc}_world_component_log'] = world_comp
        out[f'{sc}_ai_excess_component_log'] = ai_comp
        out[f'{sc}_valuation_severity_scalar'] = float(s['valuation_severity_scalar'])
    return out

outputs = {}
for h in ['1w','2w','1m']:
    ci_h = apply_scenarios(ci, 'beta_world_cell', 'final_ai_excess_intensity', h)
    ss_h = apply_scenarios(ss, 'beta_world_stock', 'final_ai_excess_intensity', h)
    ci_path = ROOT / f'ai_unwind_v5_{h}_verified_stress_vector.csv'
    ss_path = ROOT / f'ai_unwind_v5_{h}_verified_single_stock_override.csv'
    ci_h.to_csv(ci_path, index=False)
    ss_h.to_csv(ss_path, index=False)
    ci_h.to_csv(DATA / ci_path.name, index=False)
    ss_h.to_csv(DATA / ss_path.name, index=False)
    outputs[(h,'ci')] = ci_h
    outputs[(h,'ss')] = ss_h

# Summaries and representative rows.
summary_rows=[]
for h in ['1w','2w','1m']:
    for dataset, df in [('country_industry', outputs[(h,'ci')]), ('single_stock_override', outputs[(h,'ss')])]:
        for sc in scenario_order:
            vals = df[f'{sc}_stress_pct']
            summary_rows.append({
                'horizon':h,
                'dataset':dataset,
                'scenario':sc,
                'rows':len(df),
                'min_stress_pct':float(vals.min()),
                'p01_stress_pct':float(vals.quantile(0.01)),
                'p05_stress_pct':float(vals.quantile(0.05)),
                'median_stress_pct':float(vals.median()),
                'p95_stress_pct':float(vals.quantile(0.95)),
                'max_stress_pct':float(vals.max()),
            })
summary_df = pd.DataFrame(summary_rows)
summary_df.to_csv(DATA / 'verified_short_horizon_vector_distribution_summary.csv', index=False)
summary_df.to_csv(ROOT / 'ai_unwind_v5_verified_short_horizon_distribution_summary.csv', index=False)

# Representative rows extraction.
def get_ci_row(df, country, industry_regex):
    m = df['country_bucket'].astype(str).str.contains(country, case=False, na=False)
    m &= df['client_industry_label'].astype(str).str.contains(industry_regex, case=False, na=False, regex=True)
    if not m.any():
        return None
    return df[m].iloc[0]

def get_ss_row(df, ticker):
    m = df['ticker'].astype(str).str.upper().eq(ticker.upper())
    return df[m].iloc[0] if m.any() else None

rep_specs = [
    ('Korea index / ETF', 'Korea', r'^index & ETF$'),
    ('Korea technology hardware', 'Korea', r'technology hardware'),
    ('Taiwan technology hardware', 'Taiwan', r'technology hardware'),
    ('United States technology hardware', 'United States', r'technology hardware'),
    ('United States index / ETF', 'United States', r'^index & ETF$'),
]
rep_rows=[]
for label, country, ind in rep_specs:
    base = get_ci_row(outputs[('1w','ci')], country, ind)
    if base is None:
        continue
    row = {'row':label, 'source':'country_industry', 'beta':float(base['beta_world_cell']), 'final_ai_excess_intensity':float(base['final_ai_excess_intensity'])}
    for h in ['1w','2w','1m']:
        r = get_ci_row(outputs[(h,'ci')], country, ind)
        if r is not None:
            for sc in ['base','severe']:
                row[f'{h}_{sc}_stress_pct']=float(r[f'{sc}_stress_pct'])
    rep_rows.append(row)
for ticker in ['NVDA','AMD','AVGO','MSFT','GOOGL','META','AMZN','PLTR','SMCI']:
    base = get_ss_row(outputs[('1w','ss')], ticker)
    if base is None:
        continue
    row = {'row':f'{ticker} override', 'source':'single_stock_override', 'beta':float(base['beta_world_stock']), 'final_ai_excess_intensity':float(base['final_ai_excess_intensity'])}
    for h in ['1w','2w','1m']:
        r = get_ss_row(outputs[(h,'ss')], ticker)
        if r is not None:
            for sc in ['base','severe']:
                row[f'{h}_{sc}_stress_pct']=float(r[f'{sc}_stress_pct'])
    rep_rows.append(row)
rep_df=pd.DataFrame(rep_rows)
rep_df.to_csv(DATA/'verified_representative_short_horizon_results.csv',index=False)
rep_df.to_csv(ROOT/'ai_unwind_v5_verified_representative_short_horizon_results.csv',index=False)

# Data audit and validation checks.
validation_checks=[]
validation_checks.append({'check':'FF49 TMT columns present', 'result':'PASS', 'detail':', '.join(TMT_COLS)})
validation_checks.append({'check':'SPX covers dot-com peak date', 'result':'PASS' if spx.index.min() <= peak_date <= spx.index.max() else 'FAIL', 'detail':f'{spx.index.min().date()} to {spx.index.max().date()}'})
validation_checks.append({'check':'FF49 daily covers dot-com peak date', 'result':'PASS' if ff49.index.min() <= peak_date <= ff49.index.max() else 'FAIL', 'detail':f'{ff49.index.min().date()} to {ff49.index.max().date()}'})
validation_checks.append({'check':'v5 exposure vector rows', 'result':'PASS' if len(ci)==1917 else 'WARN', 'detail':str(len(ci))})
validation_checks.append({'check':'v5 single-stock override rows', 'result':'PASS' if len(ss)>0 else 'FAIL', 'detail':str(len(ss))})
# Verify arithmetic: epicenter equals world+excess in logs for severe.
max_error = 0.0
for _, r in scen_df.iterrows():
    max_error=max(max_error, abs(float(r['S_AI_EPICENTER_log']) - (float(r['S_WORLD_log'])+float(r['S_AI_EXCESS_log']))))
validation_checks.append({'check':'Scenario log arithmetic identity', 'result':'PASS' if max_error < 1e-12 else 'FAIL', 'detail':f'max error {max_error:.3e}'})
validation_df=pd.DataFrame(validation_checks)
validation_df.to_csv(DATA/'validation_checks.csv',index=False)
validation_df.to_csv(ROOT/'ai_unwind_v5_verified_short_horizon_validation_checks.csv',index=False)

file_audit = pd.DataFrame([
    {'file':'FF49 daily industry portfolios','path':str(PATHS['ff49_daily']), 'rows':len(ff49), 'date_min':ff49.index.min().strftime('%Y-%m-%d'), 'date_max':ff49.index.max().strftime('%Y-%m-%d'), 'role':'TMT epicenter daily returns'},
    {'file':'S&P 500 daily close','path':str(PATHS['spx']), 'rows':len(spx), 'date_min':spx.index.min().strftime('%Y-%m-%d'), 'date_max':spx.index.max().strftime('%Y-%m-%d'), 'role':'primary broad-market short-horizon shock'},
    {'file':'Fama-French daily factors','path':str(PATHS['ff_factors_daily']), 'rows':len(ff), 'date_min':ff.index.min().strftime('%Y-%m-%d'), 'date_max':ff.index.max().strftime('%Y-%m-%d'), 'role':'broad-market audit, Mkt-RF plus RF'},
    {'file':'country_industry_stress_vector_v5','path':str(PATHS['ci']), 'rows':len(ci), 'date_min':'n/a', 'date_max':'n/a', 'role':'v5 exposure matrix'},
    {'file':'single_stock_override_vector_v5','path':str(PATHS['ss']), 'rows':len(ss), 'date_min':'n/a', 'date_max':'n/a', 'role':'v5 single-stock override exposure matrix'},
    {'file':'scenario_parameters_v5','path':str(PATHS['scenario']), 'rows':len(scenario_terminal), 'date_min':'n/a', 'date_max':'n/a', 'role':'v5 mild/base/severe scaling logic'},
])
file_audit.to_csv(DATA/'data_audit.csv', index=False)
file_audit.to_csv(ROOT/'ai_unwind_v5_verified_short_horizon_data_audit.csv', index=False)

# ----------------------------
# Figures
# ----------------------------
# 1. Raw path from peak to one-month endpoint.
path = common.loc['2000-03-20':'2000-04-28'].copy()
rel = pd.DataFrame(index=path.index)
for ret_col, out_col in [('TMT4_log','TMT4'), ('spx_log_ret','SPX'), ('All49_log','All49')]:
    vals=[]
    for d in path.index:
        if d == peak_date:
            vals.append(100.0)
        elif d > peak_date:
            vals.append(100.0 * math.exp(common.loc[peak_date:d, ret_col].iloc[1:].sum()))
        else:
            vals.append(np.nan)
    rel[out_col] = vals
fig, ax = plt.subplots(figsize=(9.0,4.8))
ax.plot(rel.index, rel['TMT4'], label='FF49 TMT basket')
ax.plot(rel.index, rel['SPX'], label='S&P 500')
ax.plot(rel.index, rel['All49'], label='FF49 all-industry average', linestyle='--')
ax.axvline(peak_date, linestyle='--', linewidth=1)
for _, r in anchor_df.iterrows():
    ax.axvline(pd.Timestamp(r['anchor_date']), linestyle=':', linewidth=1)
ax.set_title('Dot-com TMT path after identified TMT peak')
ax.set_ylabel('Index level, TMT peak = 100')
ax.grid(True, alpha=0.3)
ax.legend(loc='best')
fig.autofmt_xdate()
fig.tight_layout()
fig.savefig(FIG/'fig_01_dotcom_tmt_peak_path_verified.png', dpi=200)
plt.close(fig)

# 2. Raw dot-com anchor comparison: primary drawdown by deadline vs exact endpoint.
fig, ax = plt.subplots(figsize=(8.6,4.8))
x=np.arange(len(anchor_df))
width=0.35
ax.bar(x-width/2, anchor_df['S_TMT_pct'], width, label='Max TMT drawdown by deadline')
ax.bar(x+width/2, anchor_df['endpoint_S_TMT_pct'], width, label='Exact endpoint TMT return')
ax.set_xticks(x)
ax.set_xticklabels(anchor_df['horizon'])
ax.set_title('Short-horizon dot-com TMT anchor: drawdown by deadline vs endpoint')
ax.set_ylabel('TMT return (%)')
ax.axhline(0, linewidth=0.8)
ax.legend(loc='best')
ax.grid(True, axis='y', alpha=0.3)
fig.tight_layout()
fig.savefig(FIG/'fig_02_anchor_vs_endpoint_verified.png', dpi=200)
plt.close(fig)

# 3. Scenario epicenter ladder.
plot_scen=scen_df.copy(); plot_scen['label']=plot_scen['horizon']+' '+plot_scen['scenario']
fig, ax = plt.subplots(figsize=(9.2,4.8))
ax.bar(plot_scen['label'], plot_scen['S_AI_EPICENTER_pct'])
ax.set_title('Scenario ladder: implied AI epicenter shock by horizon')
ax.set_ylabel('Simple return stress (%)')
ax.axhline(0, linewidth=0.8)
ax.grid(True, axis='y', alpha=0.3)
plt.xticks(rotation=30, ha='right')
fig.tight_layout()
fig.savefig(FIG/'fig_03_scenario_epicenter_ladder_verified.png', dpi=200)
plt.close(fig)

# 4. Base decomposition in log component simple-equivalent terms.
base=scen_df[scen_df['scenario']=='base'].copy()
fig, ax = plt.subplots(figsize=(8.0,4.8))
x=np.arange(len(base))
world=base['S_WORLD_pct'].values
excess=base['S_AI_EXCESS_pct'].values
ax.bar(x, world, label='World shock component')
ax.bar(x, excess, bottom=world, label='Valuation-scaled AI/TMT excess component')
ax.set_xticks(x); ax.set_xticklabels(base['horizon'])
ax.set_title('Base-case shock decomposition')
ax.set_ylabel('Simple-return equivalent of log shock (%)')
ax.axhline(0, linewidth=0.8)
ax.grid(True, axis='y', alpha=0.3)
ax.legend(loc='best')
fig.tight_layout()
fig.savefig(FIG/'fig_04_base_decomposition_verified.png', dpi=200)
plt.close(fig)

# 5. Distribution of base country-industry row stresses.
fig, ax = plt.subplots(figsize=(9.0,4.8))
for h in ['1w','2w','1m']:
    ax.hist(outputs[(h,'ci')]['base_stress_pct'], bins=45, alpha=0.45, label=f'{h} base')
ax.set_title('Distribution of v5 country-industry base stress by horizon')
ax.set_xlabel('Stress (%)')
ax.set_ylabel('Number of country-industry rows')
ax.grid(True, axis='y', alpha=0.3)
ax.legend(loc='best')
fig.tight_layout()
fig.savefig(FIG/'fig_05_distribution_base_verified.png', dpi=200)
plt.close(fig)

# 6. Daily returns around peak for audit.
fig, ax = plt.subplots(figsize=(9.0,4.8))
small = daily_audit.loc['2000-03-27':'2000-04-14'].copy()
ax.bar(small.index, 100*small['TMT4_simple'], label='Daily TMT basket return')
ax.plot(small.index, 100*small['spx_simple_ret'], marker='o', label='Daily S&P 500 return')
ax.set_title('Raw daily returns around the dot-com TMT peak')
ax.set_ylabel('Daily simple return (%)')
ax.axhline(0, linewidth=0.8)
ax.grid(True, axis='y', alpha=0.3)
ax.legend(loc='best')
fig.autofmt_xdate()
fig.tight_layout()
fig.savefig(FIG/'fig_06_daily_return_audit_verified.png', dpi=200)
plt.close(fig)

# ----------------------------
# LaTeX report.
# ----------------------------
def pct(x, d=2):
    return f'{float(x):.{d}f}\%'

def num(x, d=3):
    return f'{float(x):.{d}f}'

def esc(s):
    s=str(s)
    return (s.replace('\\','\\textbackslash{}').replace('&','\\&').replace('%','\\%').replace('$','\\$')
            .replace('#','\\#').replace('_','\\_').replace('{','\\{').replace('}','\\}')
            .replace('~','\\textasciitilde{}').replace('^','\\textasciicircum{}'))

def table(headers, rows, align=None):
    if align is None: align='l'*len(headers)
    lines=['\\begin{center}', '\\begin{tabular}{'+align+'}', '\\hline', ' & '.join(headers)+' \\\\', '\\hline']
    for row in rows:
        lines.append(' & '.join(map(str,row))+' \\\\')
    lines += ['\\hline','\\end{tabular}','\\end{center}']
    return '\n'.join(lines)

anchor_rows=[]
for _, r in anchor_df.iterrows():
    anchor_rows.append([esc(r['horizon']), int(r['horizon_trading_days']), esc(r['anchor_date']), int(r['trading_days_to_anchor']), pct(r['S_TMT_pct']), pct(r['S_WORLD_pct']), pct(r['S_AI_EXCESS_pct']), esc(r['exact_end_date']), pct(r['endpoint_S_TMT_pct'])])
anchor_table = table(['Horizon','Deadline','Anchor','Days','TMT drawdown','S\&P','Excess','Endpoint','Endpoint TMT'], anchor_rows, 'lrrrrrrrr')

scenario_rows=[]
for _, r in scen_df.iterrows():
    scenario_rows.append([esc(r['horizon']), esc(r['scenario']), pct(r['S_WORLD_pct']), pct(r['S_AI_EXCESS_pct']), pct(r['S_AI_EPICENTER_pct']), num(r['valuation_severity_scalar'],3)])
scenario_table = table(['Horizon','Scenario','World','AI excess','Epicenter','Scalar'], scenario_rows, 'llrrrr')

summary_rows_tex=[]
for _, r in summary_df[(summary_df.dataset=='country_industry') & (summary_df.scenario=='base')].iterrows():
    summary_rows_tex.append([esc(r['horizon']), int(r['rows']), pct(r['min_stress_pct']), pct(r['p05_stress_pct']), pct(r['median_stress_pct']), pct(r['max_stress_pct'])])
summary_table = table(['Horizon','Rows','Min','P5','Median','Max'], summary_rows_tex, 'lrrrrr')

rep_rows_tex=[]
for _, r in rep_df.head(14).iterrows():
    rep_rows_tex.append([esc(r['row']), pct(r['1w_base_stress_pct']), pct(r['2w_base_stress_pct']), pct(r['1m_base_stress_pct']), pct(r['1w_severe_stress_pct']), pct(r['2w_severe_stress_pct']), pct(r['1m_severe_stress_pct'])])
rep_table = table(['Row','1w base','2w base','1m base','1w sev.','2w sev.','1m sev.'], rep_rows_tex, 'lrrrrrr')

audit_rows=[]
for _, r in file_audit.iterrows():
    audit_rows.append([esc(r['file']), esc(r['date_min']), esc(r['date_max']), int(r['rows']) if isinstance(r['rows'], (int, np.integer)) else esc(r['rows'])])
audit_table = table(['File','Start','End','Rows'], audit_rows, 'lrrr')

valid_rows=[]
for _, r in validation_df.iterrows():
    valid_rows.append([esc(r['check']), esc(r['result']), esc(r['detail'])])
valid_table = table(['Check','Result','Detail'], valid_rows, 'lll')

# Key strings.
peak_str = peak_date.strftime('%Y-%m-%d')
trough_str = trough_date.strftime('%Y-%m-%d')
term_tmt = pct(terminal_daily_audit.iloc[0]['TMT_peak_to_trough_pct'])
term_spx = pct(terminal_daily_audit.iloc[0]['SPX_same_window_pct'])

tex = r'''
\documentclass[10pt]{article}
\usepackage{graphicx}
\setlength{\parindent}{0pt}
\setlength{\parskip}{6pt}
\setlength{\textwidth}{6.7in}
\setlength{\oddsidemargin}{-0.05in}
\setlength{\evensidemargin}{-0.05in}
\setlength{\textheight}{9.15in}
\setlength{\topmargin}{-0.60in}
\begin{document}

\begin{center}
{\Large \bf AI Unwind Stress Framework}\\
{\large Verified One-Week, Two-Week, and One-Month Dot-Com Anchored Drawdown Extension}\\
{\normalsize Alex Zhang \quad July 2026}
\end{center}

\section*{Executive summary}

This note re-estimates the short-horizon version of the AI unwind stress vector using the same structural form as the peak-to-trough framework, but with short-horizon dot-com drawdown anchors. The exposure matrix is unchanged. The only object being replaced is the shock vector.

The corrected calibration uses daily Fama-French 49-industry returns for the technology, media and telecom epicenter basket and the uploaded S\&P 500 daily price file for the broad market leg. The identified dot-com TMT peak in the daily TMT basket is ''' + peak_str + r'''. The main margin interpretation is the maximum TMT drawdown reached by each deadline, because a margin call can occur before the close-to-close endpoint of the horizon. The report also shows the exact endpoint return as an audit.

The largest source of confusion is that the first week after the identified TMT peak was already very violent. In the raw data, the FF49 TMT basket lost more than ten percent by the fifth trading day after the peak. Therefore one-week and two-week short-horizon shocks are close. This is not a scaling assumption or a guessed result; it is visible directly in the daily Fama-French sector returns.

\section*{1. What is being replicated}

The peak-to-trough v5 model applies the log-return stress equation

\[
\widehat R_i^{s,h}=\beta_i^W S_W^{s,h}+I_i^{AI}S_X^{s,h}.
\]

Every symbol is defined as follows. The subscript $i$ is one country-industry row or one single-stock override row. The superscript $s$ is the scenario, either mild, base, or severe. The superscript $h$ is the horizon, here one week, two weeks, or one month. $\widehat R_i^{s,h}$ is the stressed log return for row $i$. $\beta_i^W$ is the row's broad-market beta from the uploaded v5 vector. $I_i^{AI}$ is the row's final AI-excess intensity from the uploaded v5 vector. $S_W^{s,h}$ is the broad-market shock for scenario $s$ and horizon $h$. $S_X^{s,h}$ is the AI/TMT excess shock for scenario $s$ and horizon $h$.

The important point is that this extension does not rebuild the exposure model. It keeps $\beta_i^W$ and $I_i^{AI}$ fixed. It only recalibrates $S_W^{s,h}$ and $S_X^{s,h}$ using daily dot-com short-horizon drawdowns.

\section*{2. Daily dot-com shock construction}

For each trading day $t$, define $r_{E,t}$ as the daily log return of the dot-com TMT epicenter basket. The epicenter basket is the equal-weight daily-rebalanced average of the Fama-French value-weighted industries Hardw, Softw, Chips, and Telcm. Define $r_{W,t}$ as the daily log return of the S\&P 500 price index.

For a horizon $h$, define the cumulative epicenter return from the peak date $t_0$ to a later date $u$ as

\[
R_{E}(t_0,u)=\sum_{t=t_0+1}^{u} r_{E,t}.
\]

Define the broad-market return over the same window as

\[
R_{W}(t_0,u)=\sum_{t=t_0+1}^{u} r_{W,t}.
\]

The short-horizon drawdown anchor is the worst TMT cumulative return reached by the horizon deadline:

\[
u_h=\arg\min_{u\in\{t_0+1,\ldots,t_0+h\}} R_E(t_0,u).
\]

Then the raw short-horizon shocks are

\[
S_E^h=R_E(t_0,u_h), \quad S_W^h=R_W(t_0,u_h), \quad S_X^h=S_E^h-S_W^h.
\]

Here $S_E^h$ is the raw TMT epicenter shock, $S_W^h$ is the broad-market shock, and $S_X^h$ is the TMT excess shock after removing the broad-market leg.

\section*{3. Data audit}

''' + audit_table + r'''

''' + valid_table + r'''

\section*{4. Raw dot-com anchors}

''' + anchor_table + r'''

The table separates the primary margin drawdown anchor from the exact endpoint audit. The primary stress vectors use the drawdown-by-deadline columns, not the endpoint audit columns.

\begin{center}
\includegraphics[width=0.95\textwidth]{figures/fig_01_dotcom_tmt_peak_path_verified.png}
\end{center}

\begin{center}
\includegraphics[width=0.95\textwidth]{figures/fig_02_anchor_vs_endpoint_verified.png}
\end{center}

\begin{center}
\includegraphics[width=0.95\textwidth]{figures/fig_06_daily_return_audit_verified.png}
\end{center}

\section*{5. Scenario ladder}

After the raw short-horizon shocks are estimated, the same v5 scenario ladder is applied. Mild uses half the broad-market shock and half of the valuation-adjusted excess shock. Base uses the full broad-market shock and the valuation-adjusted excess shock. Severe uses the full broad-market shock and the full dot-com TMT excess shock.

''' + scenario_table + r'''

\begin{center}
\includegraphics[width=0.95\textwidth]{figures/fig_03_scenario_epicenter_ladder_verified.png}
\end{center}

\begin{center}
\includegraphics[width=0.88\textwidth]{figures/fig_04_base_decomposition_verified.png}
\end{center}

\section*{6. Application to the v5 country-industry vector}

For each row $i$, the model calculates

\[
\widehat R_i^{s,h}=\beta_i^W S_W^{s,h}+I_i^{AI}S_X^{s,h}.
\]

The simple-return stress is then

\[
\widehat r_i^{s,h}=\exp(\widehat R_i^{s,h})-1.
\]

If the client position has signed market value $x_i$, the stress P\&L convention is

\[
\widehat L_i^{s,h}=-x_i\widehat r_i^{s,h}.
\]

A long position has $x_i>0$. If the stressed return is negative, the loss is positive. A short position has $x_i<0$. If the stressed return is negative, the position gains unless an adverse-only convention is separately imposed.

\section*{7. Vector distribution}

''' + summary_table + r'''

\begin{center}
\includegraphics[width=0.95\textwidth]{figures/fig_05_distribution_base_verified.png}
\end{center}

\section*{8. Representative outputs}

''' + rep_table + r'''

\section*{9. Interpretation and caveats}

The corrected output is internally consistent but the first-week shock is still large. This is because the actual dot-com TMT basket in the daily Fama-French data sold off sharply immediately after the identified TMT peak. The one-week severe epicenter shock is therefore close to the two-week severe epicenter shock. The one-month shock is materially worse because the April 14, 2000 selloff occurred within the one-month deadline.

The main production interpretation is that these files answer a different risk question from the peak-to-trough paper. The peak-to-trough vector asks how much capital may be lost if the full bubble unwind plays out. The short-horizon vectors ask how much of the same dot-com-style unwind can arrive before a margin call or risk reduction window.

The main methodological caveat is that the broad-market leg is the S\&P 500, while the v5 global framework uses world-beta exposures. That is a reasonable U.S. dot-com short-horizon proxy because the required daily world index series was not part of the uploaded model inputs. The report therefore keeps the v5 exposures fixed but uses S\&P 500 daily returns to identify the historical short-horizon broad-market shock.

For sanity, the same daily data produce a ''' + term_tmt + r''' TMT peak-to-trough loss from ''' + peak_str + r''' to ''' + trough_str + r''', while the S\&P 500 lost ''' + term_spx + r''' over the same dates. This terminal daily audit is not used directly in the short-horizon files, but it confirms that the daily TMT data contain the full dot-com bust period.

\section*{10. Output files}

The deliverable includes one-week, two-week, and one-month country-industry stress vectors; matching single-stock override files; scenario parameter files; diagnostics; figures; and the full Python generation script.

\end{document}
'''

tex_path = OUT / 'ai_unwind_verified_short_horizon_v5_report.tex'
tex_path.write_text(tex)
shutil.copy(tex_path, ROOT / 'ai_unwind_verified_short_horizon_v5_report.tex')

# Copy code to bundle.
script_src = Path(__file__) if '__file__' in globals() else ROOT / 'run_verified_short_horizon_v5.py'
try:
    shutil.copy(script_src, CODE / 'run_verified_short_horizon_v5.py')
except Exception:
    pass

# Compile LaTeX with pdflatex.
subprocess.run(['pdflatex','-interaction=nonstopmode','ai_unwind_verified_short_horizon_v5_report.tex'], cwd=OUT, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
subprocess.run(['pdflatex','-interaction=nonstopmode','ai_unwind_verified_short_horizon_v5_report.tex'], cwd=OUT, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
pdf_path = OUT / 'ai_unwind_verified_short_horizon_v5_report.pdf'
shutil.copy(pdf_path, ROOT / 'ai_unwind_verified_short_horizon_v5_report.pdf')

# Run summary.
run_summary = {
    'created_at': datetime.utcnow().isoformat()+'Z',
    'peak_date': peak_str,
    'tmt_cols': TMT_COLS,
    'primary_method': 'peak anchored maximum TMT drawdown by horizon deadline',
    'horizons': anchor_df[['horizon','horizon_trading_days','anchor_date','trading_days_to_anchor','S_TMT_pct','S_WORLD_pct','S_AI_EXCESS_pct','endpoint_S_TMT_pct']].to_dict(orient='records'),
    'scenario_parameters_file': str(scen_path),
    'pdf': str(ROOT / 'ai_unwind_verified_short_horizon_v5_report.pdf'),
}
(OUT/'run_summary.json').write_text(json.dumps(run_summary, indent=2))

# Source bundle.
bundle_path = ROOT / 'ai_unwind_verified_short_horizon_v5_source_bundle.zip'
with zipfile.ZipFile(bundle_path, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for path in OUT.rglob('*'):
        if path.is_file():
            z.write(path, arcname=str(path.relative_to(OUT)))
    # duplicate key files at root of zip for ease
    for p in [ROOT/'ai_unwind_verified_short_horizon_v5_report.pdf', ROOT/'ai_unwind_verified_short_horizon_v5_report.tex', scen_path, endpoint_scen_path, ROOT/'ai_unwind_v5_verified_short_horizon_anchor_diagnostics.csv']:
        if p.exists(): z.write(p, arcname=p.name)
    for h in ['1w','2w','1m']:
        for suffix in ['verified_stress_vector','verified_single_stock_override']:
            p = ROOT / f'ai_unwind_v5_{h}_{suffix}.csv'
            if p.exists(): z.write(p, arcname=p.name)

print(json.dumps(run_summary, indent=2))
