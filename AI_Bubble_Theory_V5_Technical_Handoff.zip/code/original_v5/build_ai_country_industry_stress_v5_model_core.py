"""
Original V5 model core recovered from the project File Library.

This file isolates the model-generating logic from the original
build_ai_country_industry_stress_v5.py. The authoritative original builder also
contained report/table/figure generation and packaging glue. Those presentation
blocks are intentionally omitted here because they do not change model outputs.

The parameter values, transformations, row construction, scenario mechanics,
single-stock calculations, and output fields below follow the original V5 source.
"""
from pathlib import Path
import math
import re
import numpy as np
import pandas as pd

# -----------------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------------
def norm_label(s):
    return re.sub(r'[^a-z0-9]+', ' ', str(s).lower()).strip()


def stat_excess_intensity(theta_abs, beta_world, theta_world,
                          max_intensity=1.50):
    """V5 beta-adjusted statistical AI-excess intensity."""
    raw = ((float(theta_abs) - float(beta_world) * float(theta_world)) /
           max(1.0 - float(theta_world), 1e-8))
    clipped = min(max_intensity, max(0.0, raw))
    return raw, clipped


def reliability_flag(country_rel, industry_rel):
    flags = [str(country_rel), str(industry_rel)]
    if 'X' in flags: return 'X'
    if 'D' in flags: return 'D'
    if 'C' in flags: return 'C'
    if 'B' in flags: return 'B'
    return 'A'


# -----------------------------------------------------------------------------
# Explicit V5 governance parameters
# -----------------------------------------------------------------------------
LAMBDA_INDUSTRY_TILT = 0.50
WEIGHT_STAT = 0.45
WEIGHT_ECON = 0.55
COUNTRY_WEIGHT_ECON = 0.35
INDUSTRY_WEIGHT_ECON = 0.65
MAX_INTENSITY = 1.50
MONOTONIC_MARGIN = 0.05
HIGH_AI_INDUSTRY_THRESHOLD = 0.50


def build_scenario_parameters(scenario_v4, valuation_summary):
    """Rebuild V5 Mild/Base/Severe terminal scenario table."""
    kappa_base = float(
        valuation_summary.loc[
            valuation_summary['parameter'].eq(
                'base_valuation_severity_scalar_kappa'), 'value'
        ].iloc[0]
    )
    kappa_severe = 1.0
    kappa_mild = 0.5 * kappa_base

    base_row = scenario_v4[scenario_v4['scenario'].eq('base')].iloc[0]
    s_world_base = float(base_row['S_WORLD_log'])
    s_ai_excess_dotcom = float(
        scenario_v4[scenario_v4['scenario'].eq('severe')]
        ['S_AI_EXCESS_log'].iloc[0]
    )

    scenario_params = pd.DataFrame([
        {
            'scenario': 'mild',
            'world_scale': 0.50,
            'valuation_severity_scalar': kappa_mild,
            'S_WORLD_log': 0.50 * s_world_base,
            'S_AI_EXCESS_log': kappa_mild * s_ai_excess_dotcom,
            'description': 'Half market shock plus half of valuation-adjusted AI-excess shock.'
        },
        {
            'scenario': 'base',
            'world_scale': 1.00,
            'valuation_severity_scalar': kappa_base,
            'S_WORLD_log': s_world_base,
            'S_AI_EXCESS_log': kappa_base * s_ai_excess_dotcom,
            'description': 'Full market de-risking plus valuation-adjusted AI-excess shock.'
        },
        {
            'scenario': 'severe',
            'world_scale': 1.00,
            'valuation_severity_scalar': kappa_severe,
            'S_WORLD_log': s_world_base,
            'S_AI_EXCESS_log': kappa_severe * s_ai_excess_dotcom,
            'description': 'Full dot-com analogue for the AI-excess component plus full market shock.'
        },
    ])
    scenario_params['S_AI_EPICENTER_log'] = (
        scenario_params['S_WORLD_log'] + scenario_params['S_AI_EXCESS_log']
    )
    for c in ['S_WORLD_log', 'S_AI_EXCESS_log', 'S_AI_EPICENTER_log']:
        scenario_params[c.replace('_log', '_simple')] = np.exp(scenario_params[c]) - 1
        scenario_params[c.replace('_log', '_pct')] = (
            100 * scenario_params[c.replace('_log', '_simple')]
        )
    return scenario_params


def build_country_industry_vector(ci_old, country_est, industry_est,
                                  industry_map, scenario_params):
    """Construct the 27 x 71 V5 country-industry grid."""
    theta_world = float(ci_old['theta_ai_abs_world_reference'].dropna().iloc[0])
    industry_lookup = industry_est.set_index('industry_bucket').to_dict('index')
    rows = []

    for _, crow in country_est.iterrows():
        cb = crow['country_bucket']
        beta_b = float(crow['beta_world_final'])
        theta_b = float(crow['theta_ai_abs_final'])
        econ_b = float(crow['country_economic_ai_intensity'])
        country_raw, country_stat = stat_excess_intensity(
            theta_b, beta_b, theta_world, MAX_INTENSITY)
        country_index_intensity = min(
            MAX_INTENSITY,
            max(0.0, WEIGHT_STAT * country_stat + WEIGHT_ECON * econ_b)
        )

        for _, m in industry_map.iterrows():
            ib = m['industry_bucket']

            if ib == 'Out of Scope Fixed Income':
                rec = {
                    'country_bucket': cb,
                    'country_proxy_ticker': crow['ticker'],
                    'country_region_group': crow['region_group'],
                    'client_industry_label': m['client_industry_label'],
                    'client_industry_normalized': m['client_industry_normalized'],
                    'industry_bucket': ib,
                    'industry_proxy_ticker': m.get('ticker', ''),
                    'industry_sector_group': 'Out of Scope',
                    'model_scope': 'outside_equity_ai_model',
                    'reliability_flag': 'X',
                    'beta_world_cell': np.nan,
                    'final_ai_excess_intensity': np.nan,
                    'formula_log_return': 'not_applicable_fixed_income_or_muni',
                    'formula_simple_return': 'not_applicable',
                    'recommended_client_pnl_formula': 'not_applicable_in_equity_ai_model',
                    'market_cap_overlay_formula': 'not_applicable'
                }
                for _, sc in scenario_params.iterrows():
                    s = sc['scenario']
                    for suffix in [
                        'stress_log', 'stress_simple', 'stress_pct',
                        'world_component_log', 'ai_excess_component_log',
                        'valuation_severity_scalar'
                    ]:
                        rec[f'{s}_{suffix}'] = np.nan
                rows.append(rec)
                continue

            if ib not in industry_lookup:
                continue

            irow = industry_lookup[ib]
            beta_g = float(irow['beta_world_final'])
            theta_g = float(irow['theta_ai_abs_final'])
            econ_g = float(m['client_industry_economic_ai_intensity'])

            if ib == 'Index or ETF':
                beta_cell = beta_b
                theta_cell = theta_b
                cell_raw_stat, cell_stat = country_raw, country_stat
                econ_cell = econ_b
                final_intensity_pre = country_index_intensity
                final_intensity = country_index_intensity
                monotonic_constraint_applied = False
                monotonic_floor = np.nan
            else:
                # Country baseline + square-root global-industry tilt.
                beta_cell = beta_b * (
                    max(beta_g, 1e-6) ** LAMBDA_INDUSTRY_TILT
                )
                theta_cell = theta_b * (
                    (max(theta_g, 1e-6) / max(theta_world, 1e-6))
                    ** LAMBDA_INDUSTRY_TILT
                )
                cell_raw_stat, cell_stat = stat_excess_intensity(
                    theta_cell, beta_cell, theta_world, MAX_INTENSITY)
                econ_cell = (
                    COUNTRY_WEIGHT_ECON * econ_b +
                    INDUSTRY_WEIGHT_ECON * econ_g
                )
                final_intensity_pre = (
                    WEIGHT_STAT * cell_stat + WEIGHT_ECON * econ_cell
                )
                final_intensity = final_intensity_pre
                monotonic_floor = np.nan
                monotonic_constraint_applied = False

                # Coherence projection for explicitly AI-linked industries.
                if econ_g >= HIGH_AI_INDUSTRY_THRESHOLD:
                    monotonic_floor = country_index_intensity + MONOTONIC_MARGIN
                    if final_intensity < monotonic_floor:
                        final_intensity = monotonic_floor
                        monotonic_constraint_applied = True

                final_intensity = min(
                    MAX_INTENSITY, max(0.0, final_intensity))

            rf = reliability_flag(
                crow['reliability_country'], irow['reliability_industry'])
            rec = {
                'country_bucket': cb,
                'country_proxy_ticker': crow['ticker'],
                'country_region_group': crow['region_group'],
                'client_industry_label': m['client_industry_label'],
                'client_industry_normalized': m['client_industry_normalized'],
                'industry_bucket': ib,
                'industry_proxy_ticker': irow['ticker'],
                'industry_sector_group': irow['sector_group'],
                'model_scope': 'equity_factor_stress',
                'reliability_flag': rf,
                'beta_world_country': beta_b,
                'beta_world_industry': beta_g,
                'beta_world_cell': beta_cell,
                'theta_ai_abs_country': theta_b,
                'theta_ai_abs_industry': theta_g,
                'theta_ai_abs_cell': theta_cell,
                'theta_ai_abs_world_reference': theta_world,
                'country_stat_ai_excess_intensity_raw': country_raw,
                'country_stat_ai_excess_intensity': country_stat,
                'country_index_final_ai_excess_intensity': country_index_intensity,
                'cell_stat_ai_excess_intensity_raw': cell_raw_stat,
                'cell_stat_ai_excess_intensity': cell_stat,
                'country_economic_ai_intensity': econ_b,
                'client_industry_economic_ai_intensity': econ_g,
                'cell_economic_ai_intensity': econ_cell,
                'statistical_weight': WEIGHT_STAT,
                'economic_weight': WEIGHT_ECON,
                'final_ai_excess_intensity_pre_coherence': final_intensity_pre,
                'monotonic_constraint_applied': monotonic_constraint_applied,
                'monotonic_floor_if_applicable': monotonic_floor,
                'final_ai_excess_intensity': final_intensity,
                'country_residual_ai_beta_diagnostic': crow['gamma_ai_resid_raw'],
                'industry_residual_ai_beta_diagnostic': irow['gamma_ai_resid_raw'],
                'country_abs_beta_tstat': crow['t_theta_ai_abs'],
                'industry_abs_beta_tstat': irow['t_theta_ai_abs'],
                'country_n_months': crow['n_abs_months'],
                'industry_n_months': irow['n_abs_months'],
                'formula_log_return': 'beta_world_cell*S_WORLD_log + final_ai_excess_intensity*S_AI_EXCESS_log',
                'formula_simple_return': 'EXP(stress_log_return)-1',
                'recommended_client_pnl_formula': 'stress_pnl_usd = - signed_market_value_usd * stress_simple_return',
                'margin_usage_formula': 'stress_loss_to_margin = max(stress_pnl_usd,0)/client_level_margin_usd',
                'market_cap_overlay_formula': 'optional only: loss_usd_adjusted = max(stress_pnl_usd,0)*size_loss_multiplier(holding_market_cap_usd)'
            }

            for _, sc in scenario_params.iterrows():
                s = sc['scenario']
                sw = float(sc['S_WORLD_log'])
                sx = float(sc['S_AI_EXCESS_log'])
                logret = beta_cell * sw + final_intensity * sx
                rec[f'{s}_stress_log'] = logret
                rec[f'{s}_stress_simple'] = math.exp(logret) - 1
                rec[f'{s}_stress_pct'] = 100 * (math.exp(logret) - 1)
                rec[f'{s}_world_component_log'] = beta_cell * sw
                rec[f'{s}_ai_excess_component_log'] = final_intensity * sx
                rec[f'{s}_valuation_severity_scalar'] = float(
                    sc['valuation_severity_scalar'])
            rows.append(rec)

    stress = pd.DataFrame(rows)
    return stress.sort_values(
        ['country_bucket', 'client_industry_label']).reset_index(drop=True)


def build_single_stock_vector(ss_input, ci_old, scenario_params):
    """Recompute the original V5 single-stock overrides from V4 inputs."""
    theta_world = float(ci_old['theta_ai_abs_world_reference'].dropna().iloc[0])
    rows = []
    for _, r in ss_input.iterrows():
        beta = float(r['beta_world_stock'])
        theta = float(r['theta_ai_abs_stock'])
        econ = float(r['economic_ai_intensity'])
        raw_stat, stat = stat_excess_intensity(
            theta, beta, theta_world, MAX_INTENSITY)
        final = WEIGHT_STAT * stat + WEIGHT_ECON * econ
        final = min(MAX_INTENSITY, max(0.0, final))

        rec = {
            'ticker': r['ticker'],
            'model_scope': 'single_stock_override',
            'beta_world_stock': beta,
            'theta_ai_abs_stock': theta,
            'theta_ai_abs_world_reference': theta_world,
            'stat_ai_excess_intensity_raw': raw_stat,
            'stat_ai_excess_intensity': stat,
            'economic_ai_intensity': econ,
            'statistical_weight': WEIGHT_STAT,
            'economic_weight': WEIGHT_ECON,
            'final_ai_excess_intensity': final,
            'residual_ai_beta_diagnostic': r.get(
                'residual_ai_beta_diagnostic', np.nan),
            'n_months': r.get('n_months', np.nan),
            'formula_log_return': 'beta_world_stock*S_WORLD_log + final_ai_excess_intensity*S_AI_EXCESS_log',
            'recommended_use': 'Use this row instead of country-industry row when ticker matches.'
        }

        for _, sc in scenario_params.iterrows():
            s = sc['scenario']
            sw = float(sc['S_WORLD_log'])
            sx = float(sc['S_AI_EXCESS_log'])
            logret = beta * sw + final * sx
            rec[f'{s}_stress_log'] = logret
            rec[f'{s}_stress_simple'] = math.exp(logret) - 1
            rec[f'{s}_stress_pct'] = 100 * (math.exp(logret) - 1)
            rec[f'{s}_world_component_log'] = beta * sw
            rec[f'{s}_ai_excess_component_log'] = final * sx
            rec[f'{s}_valuation_severity_scalar'] = float(
                sc['valuation_severity_scalar'])
        rows.append(rec)

    return pd.DataFrame(rows).sort_values(
        'base_stress_pct').reset_index(drop=True)


def run_from_original_v5_inputs(base_dir, output_dir):
    """Convenience entry point using the filenames in the original V5 builder."""
    base_dir = Path(base_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    ci_old = pd.read_csv(base_dir / 'country_industry_stress_vector_v4.csv')
    country_est = pd.read_csv(base_dir / 'country_factor_estimates_v4_return_model_input.csv')
    industry_est = pd.read_csv(base_dir / 'industry_factor_estimates_v4_return_model_input.csv')
    industry_map = pd.read_csv(base_dir / 'client_industry_mapping_v4_return_model_input.csv')
    scenario_v4 = pd.read_csv(base_dir / 'scenario_parameters_v4.csv')
    valuation_summary = pd.read_csv(base_dir / 'valuation_severity_calibration_summary.csv')
    ss_input = pd.read_csv(base_dir / 'single_stock_override_vector_v4.csv')

    scenarios = build_scenario_parameters(scenario_v4, valuation_summary)
    ci = build_country_industry_vector(
        ci_old, country_est, industry_est, industry_map, scenarios)
    ss = build_single_stock_vector(ss_input, ci_old, scenarios)

    scenarios.to_csv(output_dir / 'scenario_parameters_v5.csv', index=False)
    ci.to_csv(output_dir / 'country_industry_stress_vector_v5.csv', index=False)
    ss.to_csv(output_dir / 'single_stock_override_vector_v5.csv', index=False)
    return ci, ss, scenarios
