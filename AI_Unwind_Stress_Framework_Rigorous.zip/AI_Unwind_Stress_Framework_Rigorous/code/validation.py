"""Mechanical invariants for the AI-led unwind stress framework."""
from __future__ import annotations
import numpy as np
import pandas as pd


def check_orthogonality(world, residual, tolerance=1e-10):
    w = np.asarray(world, dtype=float); x = np.asarray(residual, dtype=float)
    w = w - w.mean()
    inner = float(w @ x)
    return {"centered_inner_product": inner, "pass": abs(inner) <= tolerance}


def check_log_simple_identity(log_return, simple_return, tolerance=1e-12):
    err = float(np.nanmax(np.abs(np.exp(np.asarray(log_return))-1.0-np.asarray(simple_return))))
    return {"max_abs_error": err, "pass": err <= tolerance}


def check_component_identity(total_log, market_log, ai_log, size_log=0.0, tolerance=1e-12):
    err = float(np.nanmax(np.abs(
        np.asarray(total_log)-np.asarray(market_log)-np.asarray(ai_log)-np.asarray(size_log)
    )))
    return {"max_abs_error": err, "pass": err <= tolerance}


def check_ai_intensity_bounds(values, lower=0.0, upper=1.5, tolerance=1e-12):
    x = np.asarray(values, dtype=float)
    return {"minimum":float(np.nanmin(x)), "maximum":float(np.nanmax(x)),
            "pass": bool(np.nanmin(x)>=lower-tolerance and np.nanmax(x)<=upper+tolerance)}


def check_probability_vector(probabilities, tolerance=1e-10):
    p = np.asarray(probabilities, dtype=float)
    ok = np.all(p >= -tolerance) and abs(float(p.sum())-1.0) <= tolerance
    return {"sum":float(p.sum()), "minimum":float(p.min()), "pass":bool(ok)}


def check_large_cap_zero_overlay(size_overlay: pd.DataFrame, reference_bucket="Q5", tolerance=1e-12):
    x = size_overlay.loc[size_overlay["cap_bucket"].eq(reference_bucket), "size_overlay_log"].to_numpy(float)
    err = np.inf if len(x)==0 else float(np.max(np.abs(x)))
    return {"max_abs_overlay":err, "pass":bool(err<=tolerance)}
