"""Scenario calibration and deterministic stress operator.

The shock side is separated into broad-market de-risking and incremental
AI/TMT repricing. The Base AI/TMT-excess scalar is valuation calibrated; Severe
uses the full dot-com excess analogue; Extreme and Worst are governed tail
extrapolations. Fixed 1w/2w/1m/2m horizons preserve the observed post-peak
speed of the historical technology unwind rather than scaling a terminal loss
linearly through time.
"""
from __future__ import annotations

import math
from typing import Iterable

import numpy as np
import pandas as pd

BASE_KAPPA = 0.6707390702673786
MILD_KAPPA = 0.5 * BASE_KAPPA
SCENARIO_SPECS = (
    ("mild", 0.50, MILD_KAPPA),
    ("base", 1.00, BASE_KAPPA),
    ("severe", 1.00, 1.00),
    ("extreme", 1.00, 1.50),
    ("worst", 1.00, 2.00),
)
HORIZONS = {"1w": 5, "2w": 10, "1m": 21, "2m": 42}
TMT_INDUSTRIES = ("Hardw", "Softw", "Chips", "Telcm")


def simple_return(log_return):
    return np.exp(np.asarray(log_return, dtype=float)) - 1.0


def log_valuation_premium(tmt_pe: float, market_pe: float) -> float:
    """Log valuation premium ln(PE_TMT / PE_market)."""
    if tmt_pe <= 0 or market_pe <= 0:
        raise ValueError("PE inputs must be positive")
    return math.log(float(tmt_pe) / float(market_pe))


def calibrate_base_kappa(
    dotcom_reference_premium_log: float,
    current_forward_premium_log: float,
    current_spot_premium_log: float,
    current_trailing_premium_log: float,
    floor: float = 0.50,
    cap: float = 1.00,
) -> dict:
    """Calibrate the Base fraction of the full historical excess channel.

    Current blended premium = 50% forward + 25% current + 25% trailing.
    """
    current_blended = (
        0.50 * current_forward_premium_log
        + 0.25 * current_spot_premium_log
        + 0.25 * current_trailing_premium_log
    )
    if dotcom_reference_premium_log <= 0:
        raise ValueError("dot-com reference premium must be positive")
    raw = current_blended / dotcom_reference_premium_log
    governed = float(np.clip(raw, floor, cap))
    return {
        "dotcom_reference_premium_log": float(dotcom_reference_premium_log),
        "current_forward_premium_log": float(current_forward_premium_log),
        "current_spot_premium_log": float(current_spot_premium_log),
        "current_trailing_premium_log": float(current_trailing_premium_log),
        "current_blended_premium_log": float(current_blended),
        "kappa_raw": float(raw),
        "base_kappa": governed,
        "governance_floor": float(floor),
        "governance_cap": float(cap),
    }


def build_terminal_scenario_surface(raw_world_log: float, raw_ai_excess_log: float) -> pd.DataFrame:
    """Construct the five terminal scenario states from raw historical shocks."""
    rows = []
    for scenario, world_scale, kappa in SCENARIO_SPECS:
        sw = world_scale * float(raw_world_log)
        sx = kappa * float(raw_ai_excess_log)
        se = sw + sx
        rows.append({
            "horizon": "terminal",
            "scenario": scenario,
            "world_scale": world_scale,
            "ai_excess_severity_scalar": kappa,
            "S_WORLD_raw_dotcom_log": float(raw_world_log),
            "S_AI_EXCESS_raw_dotcom_log": float(raw_ai_excess_log),
            "S_WORLD_log": sw,
            "S_AI_EXCESS_log": sx,
            "S_AI_EPICENTER_log": se,
            "S_WORLD_simple": math.exp(sw) - 1.0,
            "S_WORLD_pct": 100.0 * (math.exp(sw) - 1.0),
            "S_AI_EXCESS_simple": math.exp(sx) - 1.0,
            "S_AI_EXCESS_pct": 100.0 * (math.exp(sx) - 1.0),
            "S_AI_EPICENTER_simple": math.exp(se) - 1.0,
            "S_AI_EPICENTER_pct": 100.0 * (math.exp(se) - 1.0),
        })
    return pd.DataFrame(rows)


def derive_fixed_horizon_raw_anchors(
    ff49_daily: pd.DataFrame,
    spx_close: pd.Series,
    date_col: str = "date",
    tmt_columns: Iterable[str] = TMT_INDUSTRIES,
    horizons: dict = HORIZONS,
) -> pd.DataFrame:
    """Derive fixed-endpoint dot-com shock anchors from the observed TMT peak.

    The TMT index is an equal-weight daily basket of FF49 Hardware, Software,
    Chips and Telecommunications. The peak is the maximum of that constructed
    index within the supplied reference window. For each horizon, the endpoint
    is exactly peak_pos + h trading observations.
    """
    ff = ff49_daily.copy()
    ff[date_col] = pd.to_datetime(ff[date_col])
    ff = ff.sort_values(date_col).reset_index(drop=True)
    missing = [c for c in tmt_columns if c not in ff.columns]
    if missing:
        raise ValueError(f"missing TMT columns: {missing}")
    ff["tmt_return"] = ff[list(tmt_columns)].astype(float).mean(axis=1)
    ff["tmt_index"] = (1.0 + ff["tmt_return"]).cumprod()
    peak_pos = int(np.nanargmax(ff["tmt_index"].to_numpy()))
    peak_date = pd.Timestamp(ff.loc[peak_pos, date_col])
    peak_value = float(ff.loc[peak_pos, "tmt_index"])

    spx = pd.Series(spx_close, copy=True).astype(float)
    if not isinstance(spx.index, pd.DatetimeIndex):
        raise TypeError("spx_close must have a DatetimeIndex")
    spx = spx.sort_index()

    rows = []
    for label, days in horizons.items():
        endpoint_pos = peak_pos + int(days)
        if endpoint_pos >= len(ff):
            raise ValueError(f"insufficient TMT history for {label}")
        endpoint_date = pd.Timestamp(ff.loc[endpoint_pos, date_col])
        if peak_date not in spx.index or endpoint_date not in spx.index:
            raise KeyError("S&P 500 series lacks a required anchor date")
        tmt_log = math.log(float(ff.loc[endpoint_pos, "tmt_index"]) / peak_value)
        world_log = math.log(float(spx.loc[endpoint_date]) / float(spx.loc[peak_date]))
        excess_log = tmt_log - world_log
        rows.append({
            "horizon": label,
            "horizon_trading_days": int(days),
            "peak_date": peak_date.strftime("%Y-%m-%d"),
            "anchor_date": endpoint_date.strftime("%Y-%m-%d"),
            "S_WORLD_raw_dotcom_log": world_log,
            "S_AI_EXCESS_raw_dotcom_log": excess_log,
            "S_AI_EPICENTER_raw_dotcom_log": tmt_log,
            "S_WORLD_raw_dotcom_simple": math.exp(world_log) - 1.0,
            "S_AI_EXCESS_raw_dotcom_simple": math.exp(excess_log) - 1.0,
            "S_AI_EPICENTER_raw_dotcom_simple": math.exp(tmt_log) - 1.0,
            "anchor_method": "observed_TMT_peak_plus_fixed_trading_days",
        })
    return pd.DataFrame(rows)


def build_horizon_scenario_surface(raw_anchors: pd.DataFrame) -> pd.DataFrame:
    """Apply scenario world scales and AI-excess scalars to raw horizon anchors."""
    rows = []
    for _, a in raw_anchors.iterrows():
        for scenario, world_scale, kappa in SCENARIO_SPECS:
            sw_raw = float(a["S_WORLD_raw_dotcom_log"])
            sx_raw = float(a["S_AI_EXCESS_raw_dotcom_log"])
            sw = world_scale * sw_raw
            sx = kappa * sx_raw
            se = sw + sx
            rows.append({
                "horizon": a["horizon"],
                "scenario": scenario,
                "horizon_trading_days": int(a["horizon_trading_days"]),
                "peak_date": a.get("peak_date", ""),
                "anchor_date": a.get("anchor_date", ""),
                "world_scale": world_scale,
                "ai_excess_severity_scalar": kappa,
                "S_WORLD_raw_dotcom_log": sw_raw,
                "S_AI_EXCESS_raw_dotcom_log": sx_raw,
                "S_AI_EPICENTER_raw_dotcom_log": sw_raw + sx_raw,
                "S_WORLD_log": sw,
                "S_AI_EXCESS_log": sx,
                "S_AI_EPICENTER_log": se,
                "S_WORLD_simple": math.exp(sw) - 1.0,
                "S_WORLD_pct": 100.0 * (math.exp(sw) - 1.0),
                "S_AI_EXCESS_simple": math.exp(sx) - 1.0,
                "S_AI_EXCESS_pct": 100.0 * (math.exp(sx) - 1.0),
                "S_AI_EPICENTER_simple": math.exp(se) - 1.0,
                "S_AI_EPICENTER_pct": 100.0 * (math.exp(se) - 1.0),
            })
    return pd.DataFrame(rows)


def stress_log_return(
    beta_world,
    world_shock_log,
    ai_intensity,
    ai_excess_shock_log,
    size_overlay_log=0.0,
):
    """Production stressed log return R = beta*S_W + I_AI*S_X + A_size."""
    return (
        np.asarray(beta_world, dtype=float) * float(world_shock_log)
        + np.asarray(ai_intensity, dtype=float) * float(ai_excess_shock_log)
        + np.asarray(size_overlay_log, dtype=float)
    )


def add_stress_columns(
    exposure_df: pd.DataFrame,
    scenario_df: pd.DataFrame,
    beta_col: str,
    ai_col: str,
) -> pd.DataFrame:
    """Materialize scenario stresses while retaining component attribution."""
    out = exposure_df.copy()
    for _, sc in scenario_df.iterrows():
        s = str(sc["scenario"])
        market_component = out[beta_col].astype(float) * float(sc["S_WORLD_log"])
        ai_component = out[ai_col].astype(float) * float(sc["S_AI_EXCESS_log"])
        total = market_component + ai_component
        out[f"{s}_world_component_log"] = market_component
        out[f"{s}_ai_excess_component_log"] = ai_component
        out[f"{s}_stress_log"] = total
        out[f"{s}_stress_simple"] = np.exp(total) - 1.0
        out[f"{s}_stress_pct"] = 100.0 * out[f"{s}_stress_simple"]
    return out
