Replicated theory and probability slide decks with formula-by-formula explanations and increased spacing in variable labels. Page counts are unchanged: 8 model slides and 3 probability slides.
