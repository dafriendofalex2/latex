import os, math, shutil, zipfile, textwrap
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch

BASE = Path('/mnt/data')
OUT = BASE / 'ai_unwind_theory_presentation_bundle'
OUT.mkdir(exist_ok=True)

plt.rcParams['figure.dpi'] = 180
plt.rcParams['font.size'] = 10

# ---------------- data loading helpers ----------------
def parse_ff49_daily(path):
    lines = Path(path).read_text(encoding='latin1').splitlines()
    start = None
    for i, l in enumerate(lines):
        if 'Average Value Weighted Returns -- Daily' in l:
            start = i + 1
            break
    header = [h.strip() for h in lines[start].split(',')]
    rows = []
    for l in lines[start+1:]:
        if not l.strip():
            break
        parts = [p.strip() for p in l.split(',')]
        if len(parts) != len(header):
            continue
        rows.append(parts)
    df = pd.DataFrame(rows, columns=header)
    df.rename(columns={df.columns[0]: 'date'}, inplace=True)
    df['date'] = pd.to_datetime(df['date'], format='%Y%m%d')
    for c in df.columns[1:]:
        df[c] = pd.to_numeric(df[c], errors='coerce')
    df = df.replace({-99.99: np.nan, -999: np.nan})
    for c in df.columns[1:]:
        df[c] = df[c] / 100.0
    return df


def parse_spx(path):
    df = pd.read_csv(path)
    if 'date' in df.columns:
        df['Date'] = pd.to_datetime(df['date'], format='%d-%b-%y')
        df['close'] = pd.to_numeric(df['close'], errors='coerce')
    else:
        datecol = [c for c in df.columns if c.lower().startswith('date')][0]
        closecol = [c for c in df.columns if c.lower() in ('close', 'price', 'close*', 'close/last')][0]
        df['Date'] = pd.to_datetime(df[datecol])
        df['close'] = pd.to_numeric(df[closecol], errors='coerce')
    return df[['Date', 'close']].dropna().sort_values('Date')

# core data
ci = pd.read_csv(BASE/'country_industry_stress_vector_v5(1).csv')
sc = pd.read_csv(BASE/'ai_unwind_v5_revised_kappa_short_horizon_scenario_parameters.csv')
mc = pd.read_csv(BASE/'ai_unwind_v5_market_cap_stress_factors_for_client_portfolio.csv')
mc_break = pd.read_csv(BASE/'ai_unwind_v5_market_cap_bucket_breakpoints.csv')
ss = pd.read_csv(BASE/'single_stock_override_vector_v5_all20.csv')
mc_long = pd.read_csv(BASE/'ai_unwind_v5_country_industry_market_cap_revised_kappa_all_scenarios_long.csv')

# ---------------- figures ----------------
figs = {}

def savefig(name):
    path = OUT / name
    plt.tight_layout()
    plt.savefig(path, bbox_inches='tight')
    plt.close()
    figs[name] = path
    return path

# 1. Flow overview
fig, ax = plt.subplots(figsize=(11.5, 5.2))
ax.set_xlim(0, 12)
ax.set_ylim(0, 5)
ax.axis('off')
boxes = [
    (0.4, 2.0, 2.0, 1.0, '1. Estimate\nexposures'),
    (3.0, 3.0, 2.4, 1.0, '2. Build\nAI-excess factor'),
    (3.0, 1.0, 2.4, 1.0, '3. Add economic\nAI relevance'),
    (6.0, 2.0, 2.4, 1.0, '4. Calibrate dot-com\nshock by horizon'),
    (9.0, 3.1, 2.1, 0.9, '5. Single-stock\noverrides'),
    (9.0, 1.9, 2.1, 0.9, '6. Country-industry\ndefault vector'),
    (9.0, 0.7, 2.1, 0.9, '7. Market-cap\noverlay'),
]
for x, y, w, h, txt in boxes:
    ax.add_patch(Rectangle((x, y), w, h, fill=False, linewidth=1.5))
    ax.text(x+w/2, y+h/2, txt, ha='center', va='center', fontsize=12)
for (x1,y1,x2,y2) in [
    (2.4,2.5,3.0,3.5),(2.4,2.5,3.0,1.5),
    (5.4,3.5,6.0,2.5),(5.4,1.5,6.0,2.5),
    (8.4,2.5,9.0,3.55),(8.4,2.5,9.0,2.35),(8.4,2.5,9.0,1.15),
]:
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='->',mutation_scale=12,linewidth=1.3))
ax.text(6,4.55,'AI Unwind Stress Framework: logical build-up',ha='center',fontsize=15,weight='bold')
ax.text(6,4.15,'Model idea: separate broad-market stress from AI/TMT-excess stress, then add targeted overlays.',ha='center',fontsize=11)
savefig('fig_flow_overview.png')

# 2. Dot-com peak path chart
ff49 = parse_ff49_daily(BASE/'49_Industry_Portfolios_Daily.csv')
spx = parse_spx(BASE/'spx.csv')
ff49['tmt_simple'] = ff49[['Hardw','Softw','Chips','Telcm']].mean(axis=1)
ff49['tmt_index'] = (1 + ff49['tmt_simple']).cumprod()
peak_window = ff49[(ff49['date'] >= pd.Timestamp('1998-01-01')) & (ff49['date'] <= pd.Timestamp('2002-12-31'))].copy()
peak_idx = peak_window['tmt_index'].idxmax()
peak_date = ff49.loc[peak_idx, 'date']
# window 42 trading days after peak
ff49_post = ff49[ff49['date'] >= peak_date].head(43).copy()
ff49_post['day'] = range(len(ff49_post))
ff49_post['tmt_norm'] = 100 * ff49_post['tmt_index'] / ff49_post['tmt_index'].iloc[0]
spx_post = spx[spx['Date'] >= peak_date].head(43).copy()
spx_post['day'] = range(len(spx_post))
spx_post['spx_norm'] = 100 * spx_post['close'] / spx_post['close'].iloc[0]
fig, ax = plt.subplots(figsize=(8.4, 5.4))
ax.plot(ff49_post['day'], ff49_post['tmt_norm'], label='Dot-com TMT proxy (FF49 Hardw/Softw/Chips/Telcm)')
ax.plot(spx_post['day'], spx_post['spx_norm'], label='S&P 500')
ax.axvline(5, linestyle='--', linewidth=1)
ax.axvline(10, linestyle='--', linewidth=1)
ax.axvline(21, linestyle='--', linewidth=1)
ax.axvline(42, linestyle='--', linewidth=1)
for x, lab in [(5,'1w'),(10,'2w'),(21,'1m'),(42,'2m')]:
    ax.text(x, ax.get_ylim()[0]+1.0, lab, ha='center', va='bottom', fontsize=9)
ax.set_title('Dot-com anchor path used to build short-horizon scenarios')
ax.set_xlabel('Trading days after TMT peak (peak date = %s)' % peak_date.date().isoformat())
ax.set_ylabel('Index level, peak = 100')
ax.legend(fontsize=9)
savefig('fig_dotcom_anchor_paths.png')

# 3. Scenario ladder grouped bars
order_h = ['1w','2w','1m','2m']
order_s = ['mild','base','severe','extreme','worst']
plotdf = sc.pivot(index='horizon', columns='scenario', values='S_AI_EPICENTER_pct').loc[order_h, order_s]
fig, ax = plt.subplots(figsize=(9.2, 5.2))
x = np.arange(len(order_h)); width = 0.15
for i,s in enumerate(order_s):
    ax.bar(x + (i-2)*width, plotdf[s], width=width, label=s)
ax.axhline(0, color='black', linewidth=0.8)
ax.set_xticks(x)
ax.set_xticklabels(order_h)
ax.set_ylabel('AI epicenter shock (%)')
ax.set_title('Scenario ladder by horizon: total AI epicenter shock')
ax.legend(ncol=5, fontsize=8)
savefig('fig_scenario_ladder.png')

# 4. 2m scenario decomposition stacked bars
plotdf2 = sc[sc['horizon']=='2m'].set_index('scenario').loc[order_s]
fig, ax = plt.subplots(figsize=(8.6, 5.0))
world = plotdf2['S_WORLD_pct'].values
ai = plotdf2['S_AI_EXCESS_pct'].values
ax.bar(order_s, world, label='Broad-market component')
ax.bar(order_s, ai, bottom=world, label='AI/TMT-excess component')
ax.set_ylabel('Shock contribution (%)')
ax.set_title('2-month scenario decomposition: market plus AI/TMT excess')
ax.legend(fontsize=9)
savefig('fig_scenario_decomposition_2m.png')

# 5. Exposure scatter for country-industry cells
cidf = ci[['country_bucket','client_industry_label','beta_world_cell','final_ai_excess_intensity']].dropna().copy()
fig, ax = plt.subplots(figsize=(8.1, 5.8))
ax.scatter(cidf['beta_world_cell'], cidf['final_ai_excess_intensity'], s=10, alpha=0.55)
# annotate top ai intensity rows
ann = cidf.sort_values('final_ai_excess_intensity', ascending=False).head(10)
for _,r in ann.iterrows():
    label = f"{r['country_bucket']} / {r['client_industry_label'][:18]}"
    ax.text(r['beta_world_cell']+0.01, r['final_ai_excess_intensity']+0.005, label, fontsize=7)
ax.set_xlabel('Broad-market exposure $\\beta_{b,g}^W$')
ax.set_ylabel('Final AI-excess intensity $I_{b,g}^{AI}$')
ax.set_title('Country-industry exposure map')
savefig('fig_country_industry_scatter.png')

# 6. Single-stock override scatter
fig, ax = plt.subplots(figsize=(8.1, 5.8))
ax.scatter(ss['beta_world_stock'], ss['final_ai_excess_intensity'], s=30)
for _,r in ss.iterrows():
    ax.text(r['beta_world_stock']+0.01, r['final_ai_excess_intensity']+0.008, r['ticker'], fontsize=7)
ax.set_xlabel('Single-stock world beta $\\beta_i^W$')
ax.set_ylabel('Single-stock AI-excess intensity $I_i^{AI}$')
ax.set_title('Single-stock override layer: 20 override names')
savefig('fig_single_stock_override_scatter.png')

# 7. Market-cap overlay severe/worst by horizon
mcp = mc[mc['scenario'].isin(['severe','extreme','worst'])].copy()
cap_order = ['micro_small_q1','small_mid_q2','mid_q3','upper_mid_large_q4','large_mega_q5_reference']
label_map = dict(zip(mc_break['cap_bucket'], mc_break['bucket_label']))
fig, ax = plt.subplots(figsize=(8.8, 5.4))
# plot worst scenario lines by bucket
for cb in cap_order:
    sub = mcp[(mcp['cap_bucket']==cb) & (mcp['scenario']=='worst')].set_index('horizon').loc[order_h]
    ax.plot(order_h, sub['size_overlay_pct'], marker='o', label=label_map[cb])
ax.axhline(0, color='black', linewidth=0.8)
ax.set_ylabel('Worst-case market-cap overlay (%)')
ax.set_title('Market-cap overlay: smaller buckets receive larger additional stress')
ax.legend(fontsize=8, loc='lower left')
savefig('fig_market_cap_overlay.png')

# 8. Representative Korea technology hardware example by cap bucket
example = mc_long[(mc_long['country_bucket']=='Korea') &
                  (mc_long['client_industry_label']=='technology hardware & storage &peripheral') &
                  (mc_long['short_horizon']=='1m') &
                  (mc_long['scenario'].isin(['base','severe','extreme','worst']))].copy()
example['bucket_order'] = example['market_cap_bucket'].map({cb:i for i,cb in enumerate(cap_order)})
example = example.sort_values(['scenario','bucket_order'])
fig, ax = plt.subplots(figsize=(9.3, 5.2))
scen_plot = ['base','severe','extreme','worst']
width=0.18
x=np.arange(len(cap_order))
for i,scen in enumerate(scen_plot):
    sub = example[example['scenario']==scen].set_index('market_cap_bucket').loc[cap_order]
    ax.bar(x+(i-1.5)*width, sub['stress_pct'], width=width, label=scen)
ax.set_xticks(x)
ax.set_xticklabels([label_map[c].replace(' / ','\n') for c in cap_order], fontsize=8)
ax.set_ylabel('Final stress (%)')
ax.set_title('Representative example: Korea technology hardware by market-cap bucket (1m)')
ax.legend(fontsize=8, ncol=4)
savefig('fig_example_korea_buckets.png')

# 9. AI intensity blend illustration for representative exposures
rep = ci[['country_bucket','client_industry_label','cell_stat_ai_excess_intensity','cell_economic_ai_intensity','final_ai_excess_intensity']].dropna().copy()
# pick five rows with diverse intensities
reps = pd.concat([
    rep[(rep['country_bucket']=='Korea') & (rep['client_industry_label']=='technology hardware & storage &peripheral')].head(1),
    rep[(rep['country_bucket']=='Taiwan') & (rep['client_industry_label'].str.contains('semiconductor', case=False, na=False))].head(1),
    rep[(rep['country_bucket']=='United States') & (rep['client_industry_label'].str.contains('software', case=False, na=False))].head(1),
    rep[(rep['country_bucket']=='Europe Developed Markets') & (rep['client_industry_label'].str.contains('electronic equipment', case=False, na=False))].head(1),
    rep[(rep['client_industry_label'].str.contains('electric utilities', case=False, na=False))].head(1),
], ignore_index=True).drop_duplicates()
labels=[f"{r['country_bucket']}\n{r['client_industry_label'][:16]}" for _,r in reps.iterrows()]
fig, ax = plt.subplots(figsize=(8.8,5.4))
x=np.arange(len(reps)); width=0.22
ax.bar(x-width, reps['cell_stat_ai_excess_intensity'], width=width, label='Statistical AI intensity')
ax.bar(x, reps['cell_economic_ai_intensity'], width=width, label='Economic AI relevance')
ax.bar(x+width, reps['final_ai_excess_intensity'], width=width, label='Final blended AI intensity')
ax.set_xticks(x)
ax.set_xticklabels(labels, fontsize=8)
ax.set_ylabel('AI intensity')
ax.set_title('How the final AI-excess intensity is built')
ax.legend(fontsize=8)
savefig('fig_ai_intensity_blend.png')

# ---------------- prepare summary values ----------------
theta_world = float(ci['theta_ai_abs_world_reference'].dropna().iloc[0])
stat_w = float(ci['statistical_weight'].dropna().iloc[0])
econ_w = float(ci['economic_weight'].dropna().iloc[0])
row_count = len(ci)
num_countries = ci['country_bucket'].nunique()
num_industries = ci['client_industry_label'].nunique()
country_example = ci[(ci['country_bucket']=='Korea') & (ci['client_industry_label']=='technology hardware & storage &peripheral')].iloc[0]

# tables text
scenario_rows=[]
for h in order_h:
    sub = sc[sc['horizon']==h].set_index('scenario').loc[order_s]
    scenario_rows.append(
        f"{h} & {int(sub.iloc[0]['horizon_trading_days'])} & " +
        " & ".join([f"{sub.loc[s,'S_AI_EPICENTER_pct']:.2f}" for s in order_s]) + r" \\" )

bucket_rows=[]
for _,r in mc_break.iterrows():
    upper = '' if pd.isna(r['range_upper_usd_mn']) else f"{r['range_upper_usd_mn']:.0f}"
    bucket_rows.append(f"{r['bucket_label']} & {r['percentile_range']} & {r['current_range_label']} \\")

# note: get selected overlay rows for severe/worst 2m
ov_rows=[]
for cb in cap_order:
    sub = mc[(mc['cap_bucket']==cb) & (mc['horizon']=='2m')].set_index('scenario')
    ov_rows.append(f"{label_map[cb]} & {sub.loc['base','size_overlay_pct']:.2f} & {sub.loc['severe','size_overlay_pct']:.2f} & {sub.loc['extreme','size_overlay_pct']:.2f} & {sub.loc['worst','size_overlay_pct']:.2f} \\")

# ---------------- build latex document ----------------
tex = BASE/'ai_unwind_theory_presentation_for_management.tex'
pdf = BASE/'ai_unwind_theory_presentation_for_management.pdf'

# paths helper
p = lambda name: (OUT/name).as_posix()

def esc(s):
    return str(s).replace('&','\\&').replace('%','\\%').replace('_','\\_').replace('$','\\$')

latex = rf'''

documentclass[11pt]{{article}}
\usepackage{{graphicx}}
\usepackage{{amsmath}}
\usepackage{{array}}
\setlength{{\parindent}}{{0pt}}
\setlength{{\parskip}}{{0.6em}}
\begin{{document}}

\title{{Theoretical Methodology of the AI Unwind Stress Framework}}
\author{{Prepared for Senior Management}}
\date{{July 2026}}
\maketitle

\section*{{Executive summary}}
This note explains, in a logically ordered way, how the AI unwind stress framework is constructed. The framework starts from a simple idea: a portfolio loses money in an AI unwind for two different reasons. First, the broad equity market sells off. Second, the AI/TMT complex sells off by more than the market. The model therefore decomposes stress into a \emph{{market component}} and an \emph{{AI/TMT-excess component}}, estimates how exposed each country-industry bucket is to those two forces, and then applies short-horizon scenarios anchored in the dot-com unwind. The resulting default output is a country-industry stress vector; a single-stock override layer is then used for the most AI-concentrated names, and a market-cap overlay is added when a smaller-cap holding should be penalized further for fragility and liquidity risk.

In one sentence, the final logic is:
\[
\text{{final stress}} = \text{{market stress}} + \text{{AI/TMT-excess stress}} + \text{{targeted overlays}}.
\]

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.96\textwidth]{{{p('fig_flow_overview.png')}}}
\caption{{The logical build-up of the framework. Each step answers a distinct question: what are we exposed to, how large is the shock, and what adjustments are needed beyond the default country-industry layer?}}
\end{{figure}}

\clearpage
\section{{The core problem the model is solving}}
The stress engine is designed for a very specific use case: translate the hypothesis of an AI bubble unwind into shocks that can be applied consistently across a prime brokerage or financing book. That requires three design choices.

First, the framework must be \emph{{cross-sectional}}: it should say how Korea semiconductors differ from U.S. software or European industrial electronics. Second, it must be \emph{{scenario based}}: it needs mild, base, severe, extreme, and worst cases, and it must cover shorter horizons such as 1 week, 2 weeks, 1 month, and 2 months rather than only peak-to-trough loss. Third, it must be \emph{{implementable}}: the final outputs must be vectors that map directly onto client positions.

The key modeling simplification is that an AI unwind is not treated as an entirely new asset class. Instead, it is treated as an equity selloff with an additional technology/AI excess leg. This gives a clean decomposition and makes the resulting shocks interpretable.

\section{{Step 1: decompose the shock into two forces}}
For a country-industry bucket indexed by $(b,g)$, the model writes the stressed \emph{{log return}} as
\[
R_{{b,g}}^{{s,h}} = \beta_{{b,g}}^W S_W^{{s,h}} + I_{{b,g}}^{{AI}} S_X^{{s,h}}.
\]
Each symbol has a precise meaning:
\begin{{itemize}}
\item $R_{{b,g}}^{{s,h}}$: stressed log return for country bucket $b$, industry bucket $g$, scenario $s$, and horizon $h$.
\item $\beta_{{b,g}}^W$: broad-market exposure of that country-industry bucket.
\item $S_W^{{s,h}}$: broad-market log shock in scenario $s$ and horizon $h$.
\item $I_{{b,g}}^{{AI}}$: AI-excess intensity of the bucket.
\item $S_X^{{s,h}}$: AI/TMT-excess log shock over and above the market.
\end{{itemize}}

This decomposition is the backbone of the entire framework. The broad-market term captures the fact that most equity buckets fall when the market falls. The AI-excess term captures the additional loss experienced by assets that are specifically linked to the AI/TMT complex.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.88\textwidth]{{{p('fig_dotcom_anchor_paths.png')}}}
\caption{{The short-horizon scenarios are anchored in the early path of the dot-com unwind. The TMT proxy falls much more rapidly than the broad market, which is exactly why the framework separates the market leg from the excess AI/TMT leg.}}
\end{{figure}}

\section{{Step 2: estimate broad-market exposure}}
The first quantity to estimate is $\beta_{{b,g}}^W$. Conceptually, this is simple: if the world equity market drops by 1\%, how much does the relevant country-industry bucket tend to move? The model estimates a country beta and an industry beta, and combines them into a cell-level exposure. In the final country-industry vector there are {row_count} rows, covering {num_countries} country buckets and {num_industries} client-facing industry labels.

A high $\beta_{{b,g}}^W$ means the bucket is naturally cyclical or market-sensitive. A lower $\beta_{{b,g}}^W$ means the bucket is more defensive. Importantly, this beta does \emph{{not}} say anything yet about AI. It only says how much of the bucket behaves like general equity risk.

\section{{Step 3: isolate AI/TMT-specific exposure through orthogonalization}}
The next task is to measure how much a bucket is exposed specifically to the AI complex rather than to general equities. The framework first measures an absolute AI sensitivity, denoted $\theta_{{b,g}}^{{AI}}$, and compares it with the world reference AI sensitivity, denoted $\theta_W^{{AI}}$. In the current implementation,
\[
\theta_W^{{AI}} = {theta_world:.6f}.
\]

The statistical AI-excess intensity is then defined as
\[
I_{{b,g}}^{{stat}} = \frac{{\theta_{{b,g}}^{{AI}} - \beta_{{b,g}}^W\theta_W^{{AI}}}}{{1-\theta_W^{{AI}}}}.
\]

This formula is the orthogonalization step. The numerator removes the part of the bucket's AI sensitivity that can already be explained by ordinary market exposure. The denominator rescales the residual into an AI-excess intensity. Financially, this answers the right question: \emph{{after controlling for ordinary market exposure, how much extra AI/TMT sensitivity remains?}}

This is the most important conceptual distinction in the framework. Without orthogonalization, the model would double count market risk and AI risk. With orthogonalization, the AI/TMT term represents a cleaner, more targeted excess exposure.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.84\textwidth]{{{p('fig_country_industry_scatter.png')}}}
\caption{{Cross-sectional map of country-industry exposures. The horizontal axis is broad-market beta $\beta_{{b,g}}^W$; the vertical axis is the final AI-excess intensity. Highly exposed cells sit toward the upper-right.}}
\end{{figure}}

\section{{Step 4: blend statistical evidence with economic judgment}}
Purely statistical estimates are not enough. Some sectors should be recognized as economically AI-linked even if the time-series estimate is noisy, and some sectors should not receive a large AI score merely because of accidental co-movement. The framework therefore blends the statistical signal with an economic AI relevance score.

For a country-industry bucket, the final AI intensity is
\[
I_{{b,g}}^{{AI}} = w_s I_{{b,g}}^{{stat}} + w_e I_{{b,g}}^{{econ}},
\]
where $I_{{b,g}}^{{econ}}$ is the economic AI relevance score, $w_s={stat_w:.2f}$ is the statistical weight, and $w_e={econ_w:.2f}$ is the economic weight.

This blended approach is important for governance. It ensures that the model is not a black box and that the final ranking of AI-linked industries is sensible from a business perspective.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.90\textwidth]{{{p('fig_ai_intensity_blend.png')}}}
\caption{{The AI-excess intensity is not taken from a single regression coefficient. It is a blend of a statistical estimate and an economic relevance score, which improves robustness and interpretability.}}
\end{{figure}}

\clearpage
\section{{Step 5: calibrate the shock size from the dot-com unwind}}
Once exposures are estimated, the next question is the size of the shock. The framework does not assume that the current AI trade will mechanically repeat the full dot-com path. Instead, it uses the dot-com unwind as an anchor and scales the AI/TMT-excess leg by scenario severity.

For each horizon $h$, the broad-market shock and AI/TMT-excess shock are measured directly from the dot-com path:
\[
S_W^h = \log\left(\frac{{P_W(t_h)}}{{P_W(t_0)}}\right),
\qquad
S_X^h = \log\left(\frac{{P_E(t_h)}}{{P_E(t_0)}}\right) - S_W^h.
\]
Here:
\begin{{itemize}}
\item $P_W(t)$ is the broad-market index level at time $t$.
\item $P_E(t)$ is the AI/TMT epicenter index level at time $t$.
\item $t_0$ is the dot-com TMT peak date.
\item $t_h$ is the date $h$ trading days after the peak.
\end{{itemize}}

Scenario severity then determines how much of the dot-com AI/TMT excess shock is applied. Mild and base scale the AI/TMT excess leg down. Severe applies the full dot-com excess leg. Extreme and worst apply multiples above one. In the current revised ladder, extreme corresponds to $\kappa=1.5$ and worst corresponds to $\kappa=2.0$.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.88\textwidth]{{{p('fig_scenario_ladder.png')}}}
\caption{{Scenario ladder by horizon. Short horizons still allow very meaningful downside once the AI/TMT excess leg is included.}}
\end{{figure}}

\begin{{center}}
\small
\begin{{tabular}}{{lrrrrrr}}
Horizon & Days & Mild & Base & Severe & Extreme & Worst \\
\hline
{chr(10).join(scenario_rows)}
\hline
\end{{tabular}}
\end{{center}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.84\textwidth]{{{p('fig_scenario_decomposition_2m.png')}}}
\caption{{For the 2-month horizon, most of the scenario differentiation comes from the AI/TMT-excess leg rather than the broad-market leg.}}
\end{{figure}}

\section{{Step 6: convert the theoretical shock into a usable country-industry vector}}
After Steps 1 through 5, the model can produce a default stress number for every country-industry cell. That default vector is the main production object because every position can be mapped to a country and an industry, even when no stock-specific override is available.

A useful way to interpret the output is this: $\beta_{{b,g}}^W$ controls the \emph{{market directionality}} of the cell, while $I_{{b,g}}^{{AI}}$ controls its \emph{{AI concentration}}. A bucket with ordinary market beta but high AI intensity will suffer more than a generic equity sector in the same market. Conversely, a bucket with high market beta but low AI intensity behaves more like a cyclical equity risk than an AI bubble exposure.

For example, the Korea technology hardware \& storage/peripheral row has a broad-market beta of approximately {country_example['beta_world_cell']:.3f} and a final AI-excess intensity of approximately {country_example['final_ai_excess_intensity']:.3f}. This is why it remains relatively sensitive even before any market-cap overlay is applied.

\section{{Step 7: add the single-stock override layer when the name itself matters}}
The country-industry vector is the default, but some stocks are so central to the AI trade that a generic bucket is not sufficient. For these names the framework uses a single-stock override layer. The logic is identical in structure:
\[
R_i^{{s,h}} = \beta_i^W S_W^{{s,h}} + I_i^{{AI}} S_X^{{s,h}}.
\]
Here $i$ indexes the stock rather than the country-industry cell. The override set currently contains 20 names, including the original U.S. AI epicenter names and additional international or supplementary names. This improves fidelity for names such as NVIDIA, AMD, Broadcom, TSMC, Samsung Electronics, ASML, Micron, and others.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.84\textwidth]{{{p('fig_single_stock_override_scatter.png')}}}
\caption{{Single-stock override layer. These names sit on their own exposure map and replace the generic country-industry row when the ticker matches.}}
\end{{figure}}

\clearpage
\section{{Step 8: add the market-cap overlay}}
The latest extension of the framework recognizes that not all names in the same country-industry bucket should receive the same final treatment. Smaller-cap names are usually more fragile in a crash because of liquidity, financing, and balance-sheet considerations. Instead of replacing the factor stress, the framework adds a market-cap overlay on top of it.

Let $m$ denote the market-cap bucket. The final country-industry-market-cap stress is
\[
R_{{b,g,m}}^{{s,h}} = R_{{b,g}}^{{s,h}} + A_m^{{s,h}},
\]
where $A_m^{{s,h}}$ is the market-cap overlay for bucket $m$, scenario $s$, and horizon $h$.

The overlay is calibrated from Fama--French daily market-equity portfolios. The top quintile acts as the large-cap reference bucket and receives zero overlay. Smaller buckets receive increasingly negative overlays, especially in severe, extreme, and worst cases.

\begin{{center}}
\small
\begin{{tabular}}{{lll}}
Bucket & Percentile range & Current range \\
\hline
{chr(10).join(bucket_rows)}
\hline
\end{{tabular}}
\end{{center}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.88\textwidth]{{{p('fig_market_cap_overlay.png')}}}
\caption{{Worst-case market-cap overlay by horizon. The large/mega bucket remains the zero-overlay reference; smaller buckets receive increasingly negative add-ons.}}
\end{{figure}}

\begin{{center}}
\small
\begin{{tabular}}{{lrrrr}}
Bucket & 2m base & 2m severe & 2m extreme & 2m worst \\
\hline
{chr(10).join(ov_rows)}
\hline
\end{{tabular}}
\end{{center}}

\section{{Step 9: an illustrative worked example}}
To see the full logic in action, consider Korea technology hardware \& storage/peripheral. The country-industry stress is the same across market-cap buckets because the underlying country and industry are unchanged. The only difference comes from the market-cap overlay. Therefore, as one moves from the large/mega reference bucket to the micro bucket, the final stress becomes more negative, while the theoretical structure of the model remains unchanged.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.92\textwidth]{{{p('fig_example_korea_buckets.png')}}}
\caption{{Representative example. The same Korea technology-hardware row becomes more severe as market cap gets smaller because the market-cap overlay is added on top of the country-industry stress.}}
\end{{figure}}

\section{{Step 10: how to apply the final stress to a position}}
The model is built in log-return space because additive decomposition is clean there. To convert the stressed log return to a simple return, the framework uses
\[
\text{{stress simple return}} = e^{{R}} - 1.
\]
If a position has signed market value $MV_i$, then the stressed P\&L is
\[
\text{{stress P\&L}}_i = - MV_i \left(e^{{R_i}} - 1\right).
\]
This convention is intuitive: a negative stress return produces a negative P\&L on a long position and a positive P\&L on a short position.

Operationally, the application rule is straightforward.
\begin{{enumerate}}
\item Map the position to a country and industry.
\item If the ticker is in the override set, use the single-stock override row.
\item Otherwise, use the country-industry row.
\item If market-cap treatment is required, add the market-cap overlay for the appropriate bucket.
\item Convert the log shock to a simple return and then to position-level P\&L.
\end{{enumerate}}

\section*{{Key management takeaways}}
\begin{{itemize}}
\item The model is intentionally simple at the top level: \emph{{market selloff plus AI/TMT excess selloff plus targeted overlays}}.
\item The orthogonalization step matters because it prevents double counting market beta as AI beta.
\item Scenario severity is driven primarily by the AI/TMT excess leg, which is why base, severe, extreme, and worst diverge materially even at short horizons.
\item The country-industry vector is the scalable default object; the single-stock and market-cap layers improve fidelity where generic treatment would be too blunt.
\item Large-cap treatment does not change under the market-cap extension; smaller-cap names become more severe because they pick up a negative overlay.
\end{{itemize}}

\section*{{Files included in the bundle}}
This bundle contains the PDF, the LaTeX source, all figure PNG files, and the build script used to generate the note. The document is intended to function as a standalone theory section that can be quoted or excerpted directly into management materials.

\end{{document}}
'''
# latex should start with backslash
latex = latex.replace('\ndocumentclass','\\documentclass')
tex.write_text(latex)

# compile
os.chdir(BASE)
os.system(f'pdflatex -interaction=nonstopmode {tex.name} > /tmp/theory_pres.log 2>&1')
os.system(f'pdflatex -interaction=nonstopmode {tex.name} >> /tmp/theory_pres.log 2>&1')

# copy outputs into bundle
for fp in [tex, pdf, BASE/'build_theory_presentation.py'] + list(figs.values()):
    if Path(fp).exists():
        dst = OUT / Path(fp).name
        if Path(fp).resolve() != dst.resolve():
            shutil.copy2(fp, dst)

# zip
zip_path = BASE/'ai_unwind_theory_presentation_bundle.zip'
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for fp in OUT.iterdir():
        z.write(fp, arcname=fp.name)

print('done', pdf.exists(), zip_path.exists())
print('pdf', pdf)
print('zip', zip_path)
