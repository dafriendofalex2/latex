# Reduced AI Bubble Unwind Stress Vector

This folder contains a vanilla-LaTeX report, empirical output data, visualizations, and the Python analysis code.

## Main files

- `main.pdf` - compiled report preview.
- `latex/main.tex` - package-free vanilla LaTeX source.
- `data/stress_vector_ai_stocks.csv` - stock-level stress vector for the modelled AI names.
- `data/stress_vector_ff49_industries.csv` - Fama-French 49 industry spillover vector.
- `data/stress_vector_combined.csv` - combined stress vector.
- `data/spy_direct_index_impact_summary.csv` - direct SPY/S&P 500 concentration impact.
- `figures/*.png` - all visualizations.
- `code/analysis.py` - full empirical pipeline.
- `code/make_report.py` - creates the vanilla LaTeX report.

## Key result

The base AI factor shock is calibrated to the dot-com TMT 24-month relative drawdown:

- AI factor log shock: -0.758
- Simple equivalent: -53.1%
- Direct S&P 500 concentration impact from modelled AI names in uploaded SPY holdings: -10.61 percentage points

The SPY holdings file does not contain usable sector/SIC mapping, so the exact index-level direct AI concentration impact is reported separately from the FF49 industry spillover vector.
