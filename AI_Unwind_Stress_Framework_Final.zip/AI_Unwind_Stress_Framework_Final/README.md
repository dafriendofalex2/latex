# AI-Led Equity Unwind Stress Framework

Final leadership and technical-team methodology bundle.

## Contents

- `AI_Unwind_Stress_Framework_Final.tex` - portable LaTeX source.
- `AI_Unwind_Stress_Framework_Final.pdf` - compiled report.
- `code/` - executable Python modules reproduced in the corresponding report sections.
- `data/` - reference historical severity observations, terminal shock anchor, fixed-horizon raw anchors, and size breakpoints.
- `outputs/` - reference terminal/horizon scenario tables and probability-calibration outputs.
- `figures/` - report figures generated from the reference tables.
- `requirements.txt` - Python package requirements.

## Core production specification

- AI vulnerability: 60% statistical evidence + 40% economic relevance.
- Country/industry economic relevance: 35% country + 65% industry.
- Country-industry tilt exponent: 0.50.
- AI-intensity cap: 1.50.
- Base AI/TMT-excess severity scalar: 0.6707390702673786.
- Five severity scalars: 0.3353695351, 0.6707390703, 1.0, 1.5, 2.0.
- Fixed horizons: 5, 10, 21, 42 trading days.
- Probability weights estimate severity conditional on a qualifying burst; they do not estimate burst timing.

## Reproduction

Install dependencies from `requirements.txt`. All modules are self-contained and intentionally transparent. Reference output CSVs are included for numerical cross-checking.
