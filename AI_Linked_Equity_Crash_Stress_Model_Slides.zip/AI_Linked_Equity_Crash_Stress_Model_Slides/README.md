# AI-Linked Equity Crash Stress Model - Theory Slides

This bundle contains a concise LaTeX Beamer presentation of the mathematical theory behind the AI-linked equity crash stress model, plus a speaker script for every slide.

## Files

- `AI_Linked_Equity_Crash_Stress_Model_Slides.pdf` - compiled slide deck
- `AI_Linked_Equity_Crash_Stress_Model_Slides.tex` - LaTeX Beamer source
- `Speaker_Script.pdf` - compiled speaking script
- `Speaker_Script.tex` - LaTeX source for the speaking script
- `render_montage.png` - visual QA montage of all slides

## Slide count

15 pages total, including title slide.
