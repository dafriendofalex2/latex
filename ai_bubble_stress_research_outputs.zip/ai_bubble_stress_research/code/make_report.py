from pathlib import Path
import pandas as pd
import numpy as np

OUT = Path('/mnt/data/ai_bubble_stress_research')
DAT = OUT/'data'
LAT = OUT/'latex'
LAT.mkdir(parents=True, exist_ok=True)

def fnum(x, nd=3):
    if pd.isna(x): return ''
    return f'{x:.{nd}f}'
def pct(x, nd=1):
    if pd.isna(x): return ''
    return f'{100*x:.{nd}f}\%'
def esc(s):
    s = str(s)
    repl = {'&':'\\&','%':'\\%','$':'\\$','#':'\\#','_':'\\_','{':'\\{','}':'\\}','~':'\\~{}','^':'\\^{}','\\':'\\textbackslash{}'}
    # don't use textbackslash if no packages? \textbackslash is LaTeX symbol from textcomp? Better avoid backslash in strings.
    s = s.replace('\\','/')
    for k,v in repl.items():
        if k != '\\': s=s.replace(k,v)
    return s

def tabular(headers, rows, spec=None, fontsize='small'):
    if spec is None:
        spec = 'l' * len(headers)
    out=[]
    out.append('\\begin{%s}' % fontsize if fontsize else '')
    out.append('\\begin{center}')
    out.append('\\begin{tabular}{' + spec + '}')
    out.append('\\hline')
    out.append(' & '.join(headers) + ' \\\\')
    out.append('\\hline')
    for r in rows:
        out.append(' & '.join(r) + ' \\\\')
    out.append('\\hline')
    out.append('\\end{tabular}')
    out.append('\\end{center}')
    out.append('\\end{%s}' % fontsize if fontsize else '')
    return '\n'.join([x for x in out if x])

meta = pd.read_csv(DAT/'analysis_metadata.csv').iloc[0]
scenarios = pd.read_csv(DAT/'scenario_definitions.csv')
dot = pd.read_csv(DAT/'dotcom_tmt_relative_drawdowns.csv')
reg = pd.read_csv(DAT/'historical_signal_drawdown_regression.csv')
q = pd.read_csv(DAT/'historical_drawdown_quantiles.csv')
cur = pd.read_csv(DAT/'current_ai_signal_summary.csv').iloc[0]
stock = pd.read_csv(DAT/'stress_vector_ai_stocks.csv')
ind = pd.read_csv(DAT/'stress_vector_ff49_industries.csv')
spy = pd.read_csv(DAT/'spy_direct_index_impact_summary.csv')
spy_names = pd.read_csv(DAT/'spy_ai_holdings_direct_impacts.csv')

# tables
metadata_rows = [
    ['FF3 factors', esc(meta['ff3_start']) + ' to ' + esc(meta['ff3_end'])],
    ['FF49 industries', esc(meta['ff49_start']) + ' to ' + esc(meta['ff49_end'])],
    ['Current AI factor', esc(meta['ai_start']) + ' to ' + esc(meta['ai_end'])],
    ['AI tickers used', esc(meta['ai_tickers'])],
    ['TMT base basket', esc(meta['tmt_base'])],
    ['TMT broad basket', esc(meta['tmt_broad'])],
    ['Historical calibration rows', fnum(meta['historical_calibration_n'],0)],
]
metadata_tab = tabular(['Object','Coverage / definition'], metadata_rows, spec='lp{8cm}', fontsize='small')

scen_rows=[]
for _,r in scenarios.iterrows():
    scen_rows.append([esc(r['scenario']), fnum(r['AI_factor_log_shock'],3), pct(r['AI_factor_simple_equiv'],1), esc(r['calibration'][:58])])
scen_tab = tabular(['Scenario','Log shock','Simple equiv.','Calibration'], scen_rows, spec='lrrp{7cm}', fontsize='small')

dot_rows=[]
for _,r in dot.iterrows():
    if r['basket']=='base':
        dot_rows.append([esc(r['basket']), esc(r['peak_date']), str(int(r['horizon_months'])), fnum(r['log_relative_drawdown'],3), pct(r['simple_relative_drawdown'],1), esc(r['trough_date'])])
dot_tab = tabular(['Basket','Peak','H','Log DD','Simple DD','Trough'], dot_rows, spec='llrrrr', fontsize='small')

reg_rows=[]
for _,r in reg.iterrows():
    dep = r['dependent_variable'].replace('future_min_cum_rel_log_','D')
    reg_rows.append([esc(dep), fnum(r['alpha'],4), fnum(r['beta_X_growth'],3), fnum(r['beta_V_stretch'],3), fnum(r['t_beta_X'],2), fnum(r['t_beta_V'],2), fnum(r['r2'],3), str(int(r['n']))])
reg_tab = tabular(['Dep.','a','bX','bV','t(bX)','t(bV)','R2','N'], reg_rows, spec='lrrrrrrr', fontsize='small')

cur_rows = [
    ['Current date', esc(cur['current_date'])],
    ['X growth signal', fnum(cur['X_growth_signal'],4)],
    ['V stretch signal', fnum(cur['V_stretch_signal'],4)],
    ['X z-score vs history', fnum(cur['X_z_vs_history'],2)],
    ['V z-score vs history', fnum(cur['V_z_vs_history'],2)],
    ['B score', fnum(cur['B_score'],2)],
    ['B percentile vs historical industries', pct(cur['B_percentile_vs_historical_industries'],1)],
    ['Raw AI basket market beta', fnum(cur['AI_raw_market_beta'],2)],
    ['AI factor regression R2', fnum(cur['AI_factor_regression_r2'],3)],
]
cur_tab = tabular(['Statistic','Value'], cur_rows, spec='lr', fontsize='small')

stock_rows=[]
for _,r in stock.sort_values('base_simple_return').iterrows():
    stock_rows.append([esc(r['ticker']), fnum(r['lambda_AI_factor'],2), fnum(r['beta_market'],2), pct(r['mild_simple_return'],1), pct(r['base_simple_return'],1), pct(r['severe_simple_return'],1), fnum(r['r2'],2)])
stock_tab = tabular(['Ticker','lambda','mkt beta','Mild','Base','Severe','R2'], stock_rows, spec='lrrrrrr', fontsize='small')

spy_rows=[]
for _,r in spy.iterrows():
    spy_rows.append([esc(r['scenario']), pct(r['ai_weight_in_spy_modelled'],1), pct(r['direct_index_impact_simple'],2)])
spy_tab = tabular(['Scenario','Modelled AI weight','Direct index impact'], spy_rows, spec='lrr', fontsize='small')

spy_name_rows=[]
for _,r in spy_names.sort_values('base_direct_index_impact').iterrows():
    spy_name_rows.append([esc(r['ticker']), esc(r['model_ticker']), pct(r['weight_decimal'],2), pct(r['base_simple_return'],1), pct(r['base_direct_index_impact'],2)])
spy_name_tab = tabular(['Holding','Model','SPY wt.','Base ret.','Base index pp'], spy_name_rows, spec='llrrr', fontsize='small')

ind_top = ind.sort_values('base_simple_return').head(20)
ind_rows=[]
for _,r in ind_top.iterrows():
    ind_rows.append([esc(r['industry']), fnum(r['beta_AI_spillover'],2), pct(r['mild_simple_return'],1), pct(r['base_simple_return'],1), pct(r['severe_simple_return'],1), fnum(r['r2'],2)])
ind_tab = tabular(['Industry','AI beta','Mild','Base','Severe','R2'], ind_rows, spec='lrrrrr', fontsize='small')

fig_rows=[]
figs = [
    ['01_dotcom_tmt_relative_performance.png','Dot-com TMT relative performance versus market'],
    ['02_historical_signal_vs_drawdown.png','Historical signal score versus future 24-month drawdown'],
    ['03_current_ai_factor.png','Current AI raw basket, market, and pure AI factor'],
    ['04_ai_shock_scenarios.png','AI factor shock scenarios'],
    ['05_base_ai_stock_vector.png','Base scenario AI stock stress vector'],
    ['06_base_industry_spillover_vector.png','Base scenario largest industry spillovers'],
    ['07_base_spy_direct_impact_by_name.png','Base scenario direct S&P 500 impact by modelled AI names'],
]
for a,b in figs: fig_rows.append([esc('figures/'+a), esc(b)])
fig_tab = tabular(['File','Content'], fig_rows, spec='lp{8cm}', fontsize='small')

data_rows = []
for file, desc in [
    ('data/scenario_definitions.csv','AI factor shocks used for mild/base/severe scenarios'),
    ('data/stress_vector_ai_stocks.csv','Stock-level vector for modelled AI names'),
    ('data/stress_vector_ff49_industries.csv','Industry-level spillover vector for Fama-French 49 industries'),
    ('data/stress_vector_combined.csv','Combined stress vector with AI stocks and industry shocks'),
    ('data/spy_direct_index_impact_summary.csv','Direct S&P 500 concentration impact from current SPY holdings'),
    ('data/spy_ai_holdings_direct_impacts.csv','Name-level SPY direct-impact decomposition'),
    ('data/dotcom_tmt_relative_drawdowns.csv','Dot-com TMT relative drawdown template'),
    ('data/historical_industry_signal_drawdown_sample.csv','Historical FF49 signal and future drawdown panel'),
    ('data/historical_signal_drawdown_regression.csv','Historical regression of future drawdown on signals'),
    ('data/current_ai_monthly_factor.csv','Current AI basket, market, and residual AI factor series'),
]:
    data_rows.append([esc(file), esc(desc)])
data_tab = tabular(['File','Description'], data_rows, spec='lp{8cm}', fontsize='small')

latex = r'''
\documentclass[11pt]{article}
\begin{document}
\sloppy
\title{Mathematical and Empirical Report: Reduced AI Bubble Unwind Stress Vector}
\author{}
\date{}
\maketitle

\section{Model objects and data coverage}

''' + metadata_tab + r'''

The output is a conditional stress vector. The model does not estimate the probability or timing of an AI crash. It estimates the return vector conditional on an AI factor shock. The final object is
\[
R^s = (R_1^s, R_2^s, \ldots, R_N^s)',
\]
where \(s\) indexes mild, base, and severe AI unwind scenarios.

\section{Mathematical specification}

Let \(\mathcal{A}\) be the AI basket. The raw AI basket return is
\[
R_t^{AI,raw} = \sum_{i \in \mathcal{A}} \omega_i^{AI} R_{i,t}.
\]
In this empirical run, \(\omega_i^{AI}=1/|\mathcal{A}|\) because market capitalization histories for the AI basket were not required for the first-pass vector.

The pure AI factor removes the market component:
\[
R_t^{AI,raw} = a + b R_t^{MKT} + u_t,
\]
\[
F_t^{AI} = u_t.
\]
This follows the same practical logic as an orthogonalized thematic factor: the factor should describe AI-specific return variation rather than simply broad market beta.

The Barberis-Greenwood-Jin-Shleifer extrapolative structure is implemented through a growth signal and a stretch signal. The growth signal is
\[
X_t^{AI} = (1-\theta)\sum_{k=1}^{K}\theta^{k-1}F_{t-k}^{AI}, \quad 0<\theta<1.
\]
The stretch signal uses cumulative AI-specific relative performance:
\[
Z_t^{AI}=\sum_{u \leq t}F_u^{AI},
\]
\[
V_t^{AI}=Z_t^{AI}-{1\over L}\sum_{\ell=1}^{L}Z_{t-\ell}^{AI}.
\]
The stress shock is not treated as a point forecast. It is a scenario value calibrated from past data:
\[
S_s^{AI} \in \{S_{mild}^{AI},S_{base}^{AI},S_{severe}^{AI}\}.
\]

For each AI stock, estimate
\[
R_{i,t} = \alpha_i + \lambda_i F_t^{AI} + \beta_i^{MKT}R_t^{MKT}+\varepsilon_{i,t}.
\]
Then the AI stock stress return is
\[
R_i^s=\lambda_i S_s^{AI}.
\]

For each Fama-French industry \(j\), estimate
\[
R_{j,t} = \alpha_j + \beta_j^{AI}F_t^{AI}+\beta_j^{MKT}R_t^{MKT}+\varepsilon_{j,t}.
\]
The industry spillover return is
\[
R_j^s=\beta_j^{AI}S_s^{AI}.
\]

For an index with weights \(w_i\), the direct AI concentration impact is
\[
DirectImpact_s=\sum_{i\in\mathcal{A}}w_iR_i^s.
\]
The complete index impact would be
\[
R_{Index}^s=\sum_i w_iR_i^s.
\]
In this run, the SPY holdings file gives current constituent weights but not usable sector or SIC mapping, so the report computes the exact direct concentration impact and reports the non-AI spillover as a separate Fama-French 49 industry vector.

\section{Past-data calibration}

The past-data component has two layers. First, the dot-com TMT relative drawdown is used as the base crash template. Second, the whole Fama-French 49-industry history is used to calibrate how high extrapolation/stretch states are associated with later relative drawdowns.

For each historical industry \(j\), monthly relative log return is
\[
r_{j,t}^{rel}=r_{j,t}-r_t^{MKT}.
\]
The historical growth signal is
\[
X_{j,t}=(1-\theta)\sum_{k=1}^{24}\theta^{k-1}r_{j,t-k}^{rel}.
\]
The historical stretch signal is
\[
V_{j,t}=Z_{j,t}-{1\over 60}\sum_{\ell=1}^{60}Z_{j,t-\ell}, \quad Z_{j,t}=\sum_{u\leq t}r_{j,u}^{rel}.
\]
The future drawdown target over horizon \(H\) is
\[
D_{j,t}^{H}=\min_{1\leq h\leq H}\sum_{u=1}^{h}r_{j,t+u}^{rel}.
\]
The historical regression used for diagnostics is
\[
D_{j,t}^{H}=c_H+b_{X,H}X_{j,t}+b_{V,H}V_{j,t}+e_{j,t}^{H}.
\]

\subsection{Dot-com TMT drawdown template}

''' + dot_tab + r'''

The base scenario uses the 24-month base TMT relative drawdown. In log return form this is \(-0.758\), equivalent to a \(-53.1\%\) relative simple return.

\subsection{Historical signal-drawdown diagnostics}

''' + reg_tab + r'''

The regression is diagnostic, not used as a precise prediction equation. The important empirical object is the conditional left tail of future drawdowns in high-signal historical states. The scenario table below combines the conditional historical distribution with the dot-com TMT template.

\section{Current AI factor diagnostics}

''' + cur_tab + r'''

The current AI factor sample ends in April 2026 because the uploaded Fama-French factor data ends in April 2026. The current growth and stretch signals are negative because the AI basket had already weakened by the final date of the sample. For stress construction, this does not invalidate the exercise: the shock is conditional and scenario-based. The historical top-signal distribution and the dot-com drawdown template are used to define the stress shocks.

\section{Scenario definitions}

''' + scen_tab + r'''

The shock values are in AI-factor log-return units. The base scenario is directly calibrated to the dot-com TMT relative crash. The mild scenario is the 25th percentile of future 24-month relative drawdowns in high-signal historical Fama-French industry states. The severe scenario is the more negative of the high-signal 5th percentile and 1.25 times the dot-com base drawdown.

\section{Final stock-level AI stress vector}

The table below is the stock-level stress vector for modelled AI names. The full machine-readable vector is in \verb|data/stress_vector_ai_stocks.csv|.

''' + stock_tab + r'''

Under the base scenario, the largest model-implied losses are in the highest AI-factor loading stocks. SMCI and PLTR have the largest estimated sensitivity to the orthogonal AI factor. NVDA, AMD, and AVGO also have large direct losses. The megacap platform names have smaller AI-factor loadings, but their index weights make them important for direct S\&P 500 impact.

\section{Direct S\&P 500 concentration impact}

''' + spy_tab + r'''

The modelled AI names represent about 28.0\% of SPY in the uploaded holdings file. This includes both GOOGL and GOOG by applying the GOOGL model shock to GOOG as a proxy.

''' + spy_name_tab + r'''

The base direct concentration impact is about \(-10.61\) percentage points for the S\&P 500. This is not a full market-impact estimate because non-AI spillovers are reported separately at industry level.

\section{Fama-French 49 industry spillover vector}

The table below shows the twenty most negative base-scenario industry spillovers. The full 49-industry vector is in \verb|data/stress_vector_ff49_industries.csv|.

''' + ind_tab + r'''

Software, chips, and hardware are the most negative industry-level spillovers, which is consistent with the interpretation that the AI shock is a technology-theme shock. Some non-technology industries have negative but much smaller estimated AI betas. Several defensive or unrelated industries have positive estimated coefficients in this short current-period regression; those should not be interpreted as true safe-haven effects, only as current-sample empirical betas.

\section{Output vector files}

''' + data_tab + r'''

\section{Visualizations}

The LaTeX source is kept package-free. The figures are exported separately as PNG files so that the report remains vanilla LaTeX. They are included in the zip under \verb|figures/|.

''' + fig_tab + r'''

\section{Implementation notes}

All return vectors in the CSV files include both log-return shocks and simple-return equivalents. For portfolio stress testing, the log-return vector is preferable when aggregating continuous shocks; the simple-return vector is preferable when applying direct mark-to-market losses to dollar positions.

For a client portfolio with signed dollar exposures \(x_c\), the next-stage stress loss is
\[
L_c^s=-x_c'R^s.
\]
The vector \(R^s\) can be chosen at stock level where available and at industry level for residual or mapped exposures.

The model should be read as a stress framework, not a forecast. Its useful output is the conditional vector
\[
R^s = \{R_i^s\}_{i=1}^{N},
\]
not a claim that an AI crash will occur or that the exact loss will equal one scenario value.

\end{document}
'''

# Remove unsupported p{...} if vanilla LaTeX tabular supports p columns yes standard.
(LAT/'main.tex').write_text(latex, encoding='utf-8')
print(LAT/'main.tex')
