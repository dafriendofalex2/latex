BOYU CAPITAL PUBLIC-DOMAIN CLIENT PROFILE - VANILLA LATEX BUNDLE

Information cut-off: 11 August 2026

BUILD
-----
This version is intentionally package-free. It requires only a basic LaTeX installation with the standard article class and pdflatex.

Run exactly:

    pdflatex main.tex
    pdflatex main.tex

The second pass resolves the table of contents and citations.

NOT REQUIRED
------------
No geometry, hyperref, xcolor, booktabs, tabularx, longtable, tcolorbox, enumitem, microtype, fancyhdr, titlesec, BibTeX, Biber, latexmk, Perl, Python, or shell-escape is required.

FILES
-----
main.tex            Main report
references.tex      Inline LaTeX bibliography (no BibTeX)
source_links.txt    Full public-source URLs (kept outside TeX for portability)
Boyu_Capital_Citi_Client_Profile_2026-08-11.pdf   Compiled output

CITI RELATIONSHIP
-----------------
The revision explicitly incorporates the publicly verifiable Citi relationship. CSRC records list Citibank as the main custodian bank for Boyu Capital Investment Management Co., Limited under the Qualified Foreign Investor regime, with the Boyu approval dated 16 November 2020 and the pairing still present in the March 2026 register. The report separately distinguishes public facts from internal Citi wallet information that must be sourced from bank systems.
