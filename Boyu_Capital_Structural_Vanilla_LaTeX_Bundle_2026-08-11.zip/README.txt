BOYU CAPITAL - VANILLA LATEX BUNDLE
Information cut-off: 11 August 2026

Build requirements:
- Standard LaTeX / pdfLaTeX only
- No external packages
- No geometry, hyperref, xcolor, booktabs, tabularx, longtable, tikz, bibtex, biber, latexmk or Perl

Compile:
  pdflatex main.tex
  pdflatex main.tex

The document is intentionally self-contained: references are included in main.tex.
