"""AI-exposure construction used by country, industry, and single-stock rows."""
from __future__ import annotations
import numpy as np

STATISTICAL_WEIGHT = 0.60
ECONOMIC_WEIGHT = 0.40
COUNTRY_ECONOMIC_WEIGHT = 0.35
INDUSTRY_ECONOMIC_WEIGHT = 0.65
INTENSITY_CAP = 1.50


def statistical_ai_excess_intensity(
    theta_abs, beta_world, theta_world_ai,
    lower: float = 0.0, upper: float = INTENSITY_CAP,
):
    """Beta-adjust raw AI co-movement into one-sided adverse AI intensity.

    theta_abs ~= beta_world*theta_world_ai
                 + I_stat*(1-theta_world_ai)
    hence
    I_stat_raw = (theta_abs-beta_world*theta_world_ai)/(1-theta_world_ai).
    """
    den = 1.0 - float(theta_world_ai)
    if abs(den) < 1e-12:
        raise ValueError("theta_world_ai is too close to one for stable normalization")
    raw = (float(theta_abs) - float(beta_world) * float(theta_world_ai)) / den
    return float(raw), float(np.clip(raw, lower, upper))


def economic_ai_cell(country_score, industry_score):
    """Governed structural score: 35% country, 65% industry."""
    return float(
        COUNTRY_ECONOMIC_WEIGHT * float(country_score)
        + INDUSTRY_ECONOMIC_WEIGHT * float(industry_score)
    )


def blend_ai_intensity(
    statistical_intensity, economic_intensity,
    statistical_weight: float = STATISTICAL_WEIGHT,
    economic_weight: float = ECONOMIC_WEIGHT,
    lower: float = 0.0, upper: float = INTENSITY_CAP,
):
    """Final empirical/structural blend: 60% statistical, 40% economic."""
    if abs(statistical_weight + economic_weight - 1.0) > 1e-12:
        raise ValueError("statistical and economic weights must sum to one")
    pre = (
        statistical_weight * float(statistical_intensity)
        + economic_weight * float(economic_intensity)
    )
    return float(np.clip(pre, lower, upper))


def stock_ai_intensity(beta_world, theta_abs, theta_world_ai, economic_score):
    """Convenience wrapper used by approved ticker overrides."""
    raw, stat = statistical_ai_excess_intensity(theta_abs, beta_world, theta_world_ai)
    final = blend_ai_intensity(stat, economic_score)
    return {
        "stat_ai_excess_intensity_raw": raw,
        "stat_ai_excess_intensity": stat,
        "economic_ai_intensity": float(economic_score),
        "statistical_weight": STATISTICAL_WEIGHT,
        "economic_weight": ECONOMIC_WEIGHT,
        "final_ai_excess_intensity": final,
    }
