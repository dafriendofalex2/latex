Revised theory-presentation slides with senior-friendly formula explanations, increased variable-label spacing, and a more integrated final implementation/results slide. Page count is unchanged: 8 model slides and 3 probability slides.

Revision v4: slide 4 now includes the OLS derivation of theta_i_abs and then shows how it feeds into the beta-adjusted AI exposure score.
