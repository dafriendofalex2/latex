"""Path-similarity diagnostic supporting dot-com as an analogue; not a production dependency."""
import numpy as np
import pandas as pd


def normalize_log_path(price):
    p = pd.Series(price,dtype=float).dropna()
    lp=np.log(p)
    return lp-lp.iloc[0]


def path_score(current_path, historical_path):
    a=np.asarray(current_path,float); b=np.asarray(historical_path,float)
    n=min(len(a),len(b)); a=a[-n:]; b=b[-n:]
    rmse=float(np.sqrt(np.mean((a-b)**2)))
    mae=float(np.mean(np.abs(a-b)))
    corr=float(np.corrcoef(a,b)[0,1]) if n>2 else np.nan
    da=np.diff(a); db=np.diff(b)
    corr_inc=float(np.corrcoef(da,db)[0,1]) if n>3 else np.nan
    return {'rmse_log_level':rmse,'mae_log_level':mae,
            'corr_level':corr,'corr_increment':corr_inc}


def search_lead(current_ai_price, dotcom_reference_price, peak_position,
                max_lead=150):
    current=normalize_log_path(current_ai_price)
    N=len(current)
    ref=np.log(pd.Series(dotcom_reference_price,dtype=float).dropna())
    rows=[]
    for lead in range(max_lead+1):
        end=peak_position-lead
        start=end-N+1
        if start<0 or end>=len(ref): continue
        hist=ref.iloc[start:end+1]
        hist=(hist-hist.iloc[0]).to_numpy()
        s=path_score(current.to_numpy(),hist)
        rows.append({'lead_trading_days':lead,**s})
    out=pd.DataFrame(rows)
    return out.sort_values('rmse_log_level').reset_index(drop=True)
