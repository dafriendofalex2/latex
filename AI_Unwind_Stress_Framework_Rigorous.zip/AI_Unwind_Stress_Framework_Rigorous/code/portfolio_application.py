"""Position-level application hierarchy and stress P&L mechanics."""
from __future__ import annotations
import re
import numpy as np
import pandas as pd


def normalize_label(value):
    return re.sub(r"[^a-z0-9]+", " ", str(value).lower()).strip()


def normalize_ticker(value):
    return re.sub(r"[^A-Z0-9]+", "", str(value).upper())


def market_cap_bucket(market_cap_usd, breakpoints: pd.DataFrame):
    value = float(market_cap_usd)
    for _, row in breakpoints.sort_values("range_lower_usd").iterrows():
        lo = float(row["range_lower_usd"])
        hi = row.get("range_upper_usd", np.nan)
        if (pd.isna(hi) and value >= lo) or (not pd.isna(hi) and lo <= value < float(hi)):
            return row["cap_bucket"]
    return breakpoints.iloc[-1]["cap_bucket"]


def apply_stress(
    positions: pd.DataFrame,
    country_industry: pd.DataFrame,
    single_stock: pd.DataFrame,
    country_map: pd.DataFrame,
    size_breakpoints: pd.DataFrame | None = None,
    size_overlays: pd.DataFrame | None = None,
    scenario: str = "base",
    horizon: str = "2m",
):
    """Map factors, replace with ticker overrides, add size, and compute P&L."""
    pos = positions.copy()
    required = ["country", "industry", "signed_market_value_usd"]
    missing = [c for c in required if c not in pos.columns]
    if missing:
        raise ValueError(f"missing required position columns: {missing}")

    pos["country_key"] = pos["country"].map(normalize_label)
    pos["industry_key"] = pos["industry"].map(normalize_label)
    pos["ticker_key"] = pos["ticker"].map(normalize_ticker) if "ticker" in pos else ""

    cmap = country_map.copy()
    cmap["country_key"] = cmap["client_country_label"].map(normalize_label)
    pos = pos.merge(cmap[["country_key", "country_bucket"]], on="country_key", how="left")
    pos["country_bucket"] = pos["country_bucket"].fillna("World Fallback")

    ci = country_industry.copy()
    ci["industry_key"] = ci["client_industry_label"].map(normalize_label)
    stress_col = f"{scenario}_stress_log"
    cols = ["country_bucket", "industry_key", "beta_world_cell",
            "final_ai_excess_intensity", stress_col]
    pos = pos.merge(ci[cols], on=["country_bucket", "industry_key"], how="left")
    pos["selected_stress_log"] = pos[stress_col]
    pos["stress_source"] = "country_industry"

    ss = single_stock.copy()
    if len(ss):
        ss["ticker_key"] = ss["ticker"].map(normalize_ticker)
        sstress = f"{scenario}_stress_log"
        lookup = ss.set_index("ticker_key")[sstress].to_dict()
        override = pos["ticker_key"].isin(lookup)
        pos.loc[override, "selected_stress_log"] = pos.loc[override, "ticker_key"].map(lookup)
        pos.loc[override, "stress_source"] = "single_stock_override"

    pos["size_overlay_log"] = 0.0
    if size_breakpoints is not None and size_overlays is not None and "market_cap_usd" in pos:
        has_mc = pos["market_cap_usd"].notna()
        pos.loc[has_mc, "cap_bucket"] = pos.loc[has_mc, "market_cap_usd"].map(
            lambda x: market_cap_bucket(x, size_breakpoints)
        )
        ov = size_overlays.copy()
        ov = ov[(ov["scenario"] == scenario) & (ov["horizon"] == horizon)]
        ov_map = ov.set_index("cap_bucket")["size_overlay_log"].to_dict()
        pos.loc[has_mc, "size_overlay_log"] = pos.loc[has_mc, "cap_bucket"].map(ov_map).fillna(0.0)

    pos["final_stress_log"] = pos["selected_stress_log"] + pos["size_overlay_log"]
    pos["stress_simple"] = np.exp(pos["final_stress_log"]) - 1.0
    pos["stress_pct"] = 100.0 * pos["stress_simple"]
    pos["stress_pnl_usd"] = -pos["signed_market_value_usd"] * pos["stress_simple"]
    pos["adverse_stress_loss_usd"] = pos["stress_pnl_usd"].clip(lower=0.0)
    if "client_level_margin_usd" in pos.columns:
        pos["stress_loss_to_margin"] = (
            pos["adverse_stress_loss_usd"] / pos["client_level_margin_usd"].replace(0.0, np.nan)
        )
    return pos
