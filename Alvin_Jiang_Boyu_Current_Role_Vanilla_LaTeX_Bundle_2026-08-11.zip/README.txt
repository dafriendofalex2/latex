ALVIN JIANG / BOYU CAPITAL - VANILLA LATEX BUNDLE
Information cut-off: 11 August 2026

Files:
  main.tex            - source document
  main.pdf            - compiled PDF
  source_register.csv - source URLs and treatment notes

Build requirements:
  Standard LaTeX / pdfLaTeX only.
  No external packages are used.
  No geometry, hyperref, xcolor, booktabs, BibTeX/Biber, latexmk,
  Perl, Python, shell escape or external fonts are required.

Compile:
  pdflatex main.tex
  pdflatex main.tex
