"""Return-estimation utilities for the AI-led equity unwind framework.

This module implements the empirical layer used to estimate broad-market beta,
absolute co-movement with the raw AI basket, and the signed residual-AI loading
retained as a diagnostic.  The production stress engine consumes the resulting
coefficients; it does not re-fit regressions while stressing a portfolio.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
import numpy as np
import pandas as pd

HAC_LAGS = 3
MIN_MONTHS = 24
MONTH_END = "ME"


@dataclass(frozen=True)
class HACRegressionResult:
    alpha: float
    beta: np.ndarray
    se: np.ndarray
    tstat: np.ndarray
    residual: np.ndarray
    r_squared: float
    n_obs: int
    nw_lags: int

    def to_dict(self):
        return asdict(self)


def month_end_log_returns(price: pd.Series) -> pd.Series:
    """Convert a strictly positive daily price series to month-end log returns."""
    p = pd.Series(price, copy=True).dropna().astype(float)
    if not isinstance(p.index, pd.DatetimeIndex):
        raise TypeError("price must have a DatetimeIndex")
    if (p <= 0).any():
        raise ValueError("prices must be strictly positive")
    month_end = p.sort_index().resample(MONTH_END).last().dropna()
    out = np.log(month_end).diff().dropna()
    out.name = getattr(price, "name", None)
    return out


def ols_hac(y, X, lags: int = HAC_LAGS) -> HACRegressionResult:
    """OLS coefficients with Bartlett-kernel Newey-West covariance.

    X must already include an intercept column.  HAC changes inference, not the
    OLS point estimate.  This is deliberately explicit for auditability.
    """
    y = np.asarray(y, dtype=float).reshape(-1)
    X = np.asarray(X, dtype=float)
    mask = np.isfinite(y) & np.all(np.isfinite(X), axis=1)
    y, X = y[mask], X[mask]
    n, k = X.shape
    if n <= k:
        raise ValueError("insufficient observations")

    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    residual = y - X @ beta
    xtx_inv = np.linalg.pinv(X.T @ X)

    # Newey-West 'meat'.
    meat = np.zeros((k, k), dtype=float)
    for t in range(n):
        zt = X[t] * residual[t]
        meat += np.outer(zt, zt)
    L = min(int(lags), n - 1)
    for ell in range(1, L + 1):
        weight = 1.0 - ell / (L + 1.0)
        for t in range(ell, n):
            zt = X[t] * residual[t]
            zlag = X[t - ell] * residual[t - ell]
            meat += weight * (np.outer(zt, zlag) + np.outer(zlag, zt))

    cov = xtx_inv @ meat @ xtx_inv
    se = np.sqrt(np.maximum(np.diag(cov), 0.0))
    tstat = np.divide(beta, se, out=np.full_like(beta, np.nan), where=se > 0)
    centered = y - y.mean()
    ss_tot = float(centered @ centered)
    ss_res = float(residual @ residual)
    r2 = np.nan if ss_tot <= 0 else 1.0 - ss_res / ss_tot
    return HACRegressionResult(
        alpha=float(beta[0]), beta=beta, se=se, tstat=tstat,
        residual=residual, r_squared=float(r2), n_obs=n, nw_lags=L,
    )


def orthogonal_ai_factor(ai_raw: pd.Series, world: pd.Series, lags: int = HAC_LAGS):
    """Residualize the raw AI basket on the broad market with an intercept."""
    d = pd.concat([ai_raw.rename("ai"), world.rename("world")], axis=1).dropna()
    X = np.column_stack([np.ones(len(d)), d["world"].to_numpy(float)])
    fit = ols_hac(d["ai"].to_numpy(float), X, lags=lags)
    residual = pd.Series(fit.residual, index=d.index, name="ai_residual")
    return fit, residual


def estimate_proxy_exposure(
    proxy_return: pd.Series,
    world_return: pd.Series,
    ai_raw_return: pd.Series,
    ai_residual_return: pd.Series,
    lags: int = HAC_LAGS,
    min_months: int = MIN_MONTHS,
) -> dict:
    """Estimate market beta, raw AI co-movement, and residual-AI diagnostic.

    Three regressions are intentionally kept distinct:
      proxy ~ 1 + world                    -> beta_world
      proxy ~ 1 + raw AI                   -> theta_ai_abs
      proxy ~ 1 + world + residual AI      -> signed diagnostic gamma
    """
    d_ai = pd.concat([proxy_return.rename("y"), ai_raw_return.rename("ai")], axis=1).dropna()
    d_w = pd.concat([proxy_return.rename("y"), world_return.rename("world")], axis=1).dropna()
    d_r = pd.concat([
        proxy_return.rename("y"), world_return.rename("world"),
        ai_residual_return.rename("ai_resid")
    ], axis=1).dropna()
    if min(len(d_ai), len(d_w), len(d_r)) < min_months:
        raise ValueError("insufficient common monthly observations")

    fit_ai = ols_hac(d_ai["y"], np.column_stack([np.ones(len(d_ai)), d_ai["ai"]]), lags)
    fit_w = ols_hac(d_w["y"], np.column_stack([np.ones(len(d_w)), d_w["world"]]), lags)
    fit_r = ols_hac(
        d_r["y"],
        np.column_stack([np.ones(len(d_r)), d_r["world"], d_r["ai_resid"]]),
        lags,
    )
    return {
        "theta_ai_abs_raw": float(fit_ai.beta[1]),
        "se_theta_ai_abs": float(fit_ai.se[1]),
        "t_theta_ai_abs": float(fit_ai.tstat[1]),
        "r2_ai_abs": fit_ai.r_squared,
        "n_abs_months": fit_ai.n_obs,
        "beta_world_raw": float(fit_w.beta[1]),
        "se_beta_world": float(fit_w.se[1]),
        "t_beta_world": float(fit_w.tstat[1]),
        "r2_world": fit_w.r_squared,
        "n_world_months": fit_w.n_obs,
        "beta_world_in_residual_model": float(fit_r.beta[1]),
        "gamma_ai_residual_raw": float(fit_r.beta[2]),
        "se_gamma_ai_residual": float(fit_r.se[2]),
        "t_gamma_ai_residual": float(fit_r.tstat[2]),
        "r2_residual_model": fit_r.r_squared,
        "n_residual_months": fit_r.n_obs,
        "start": d_r.index.min(),
        "end": d_r.index.max(),
    }


def precision_shrink(raw_estimate, standard_error, prior_mean, prior_variance):
    """Normal-normal empirical-Bayes precision shrinkage.

    The reliability weight q approaches one for precise observations and zero
    for noisy observations.  Raw estimate, q, prior, and posterior are returned
    separately so that shrinkage never becomes an invisible data transformation.
    """
    se2 = float(standard_error) ** 2
    tau2 = max(float(prior_variance), 0.0)
    if not np.isfinite(se2) or se2 < 0:
        return {"estimate": float(prior_mean), "reliability_weight": 0.0}
    if tau2 == 0:
        return {"estimate": float(prior_mean), "reliability_weight": 0.0}
    q = tau2 / (tau2 + se2)
    est = q * float(raw_estimate) + (1.0 - q) * float(prior_mean)
    return {"estimate": float(est), "reliability_weight": float(q)}
