from __future__ import annotations
from pathlib import Path
from io import StringIO
import re, math, shutil, zipfile, subprocess
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path('/mnt/data')
OUT = ROOT / 'dotcom_ai_stat_comparison'
FIG = OUT / 'figures'
OUT.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)
RNG_SEED = 20260713

# --------------------------
# Data loaders
# --------------------------
def load_daily_price_csv(path: Path, colname: str) -> pd.Series:
    df = pd.read_csv(path)
    df.columns = [str(c).strip() for c in df.columns]
    date_col = 'Date' if 'Date' in df.columns else ('observation_date' if 'observation_date' in df.columns else df.columns[0])
    val_col = 'Close' if 'Close' in df.columns else (colname if colname in df.columns else df.columns[1])
    out = df[[date_col, val_col]].copy()
    out.columns = ['date', colname]
    out['date'] = pd.to_datetime(out['date'])
    out[colname] = pd.to_numeric(out[colname], errors='coerce')
    out = out.dropna().sort_values('date')
    m = out.set_index('date')[colname].resample('ME').last().dropna()
    m = m[m.index <= pd.Timestamp('2026-06-30')]
    return m.rename(colname)

def parse_ff49(path: Path) -> pd.DataFrame:
    lines = path.read_text(errors='ignore').splitlines()
    start = None
    for i, line in enumerate(lines):
        if 'Average Value Weighted Returns -- Monthly' in line:
            start = i + 1
            break
    if start is None:
        raise ValueError('Could not find monthly value-weighted section')
    header = lines[start]
    data_lines = []
    for line in lines[start+1:]:
        if not line.strip():
            break
        first = line.split(',')[0].strip()
        if not re.fullmatch(r'\d{6}', first):
            break
        data_lines.append(line)
    df = pd.read_csv(StringIO(header + '\n' + '\n'.join(data_lines)))
    df = df.rename(columns={df.columns[0]:'yyyymm'})
    df['date'] = pd.to_datetime(df['yyyymm'].astype(str), format='%Y%m') + pd.offsets.MonthEnd(0)
    df = df.drop(columns=['yyyymm']).set_index('date')
    df.columns = [c.strip() for c in df.columns]
    df = df.apply(pd.to_numeric, errors='coerce')
    df = df.mask(df <= -99)
    return np.log1p(df / 100.0)

# Current AI ETF files reuploaded in this conversation.
ETF_PATHS = {
    'SMH': ROOT/'smh_us_d(3).csv',
    'SOXX': ROOT/'soxx_us_d(2).csv',
    'IGV': ROOT/'igv_us_d(1).csv',
    'SKYY': ROOT/'skyy_us_d(1).csv',
    'AIQ': ROOT/'aiq_us_d(1).csv',
    'IXN': ROOT/'ixn_us_d(2).csv',
}
price_df = pd.concat({t: load_daily_price_csv(p, t) for t,p in ETF_PATHS.items() if p.exists()}, axis=1).sort_index()
sp500 = load_daily_price_csv(ROOT/'SP500 (1).csv', 'SP500')
nasdaq100 = load_daily_price_csv(ROOT/'NASDAQ100.csv', 'NASDAQ100')
nasdaqcom = load_daily_price_csv(ROOT/'NASDAQCOM.csv', 'NASDAQCOM')
ff49 = parse_ff49(ROOT/'49_Industry_Portfolios(1).csv')

# --------------------------
# Construct price paths
# --------------------------
def norm_index_from_prices(df: pd.DataFrame, components: list[str], start, end) -> pd.Series:
    sub = df[components].dropna(how='any')
    sub = sub[(sub.index >= pd.Timestamp(start)) & (sub.index <= pd.Timestamp(end))]
    norm = sub.divide(sub.iloc[0]).multiply(100.0)
    return norm.mean(axis=1)

def log_index_from_returns(ret: pd.Series, start, end) -> pd.Series:
    sub = ret[(ret.index >= pd.Timestamp(start)) & (ret.index <= pd.Timestamp(end))].dropna()
    idx = np.exp(sub.cumsum()) * 100.0
    idx = idx / idx.iloc[0] * 100.0
    return idx

def price_index_from_series(s: pd.Series, start, end) -> pd.Series:
    sub = s[(s.index >= pd.Timestamp(start)) & (s.index <= pd.Timestamp(end))].dropna()
    return sub / sub.iloc[0] * 100.0

ai_components = [c for c in ['SMH','SOXX','IGV','SKYY','AIQ'] if c in price_df.columns]
semis_components = [c for c in ['SMH','SOXX'] if c in price_df.columns]
ai_start = pd.Timestamp('2022-11-30')
ai_end = min(price_df[ai_components].dropna().index.max(), sp500.dropna().index.max(), pd.Timestamp('2026-06-30'))
T = len(pd.date_range(ai_start, ai_end, freq='ME'))
dotcom_end = pd.Timestamp('2000-03-31')
dotcom_start = (dotcom_end - pd.DateOffset(months=T-1)) + pd.offsets.MonthEnd(0)

# Dot-com TMT from Fama-French 49 industries.
tmt_cols = [c for c in ['Hardw','Softw','Chips','Telcm'] if c in ff49.columns]
tmt_ret = ff49[tmt_cols].mean(axis=1, skipna=True).rename('TMT_Core')
all49_ret = ff49.mean(axis=1, skipna=True).rename('All49')

tmt_idx = log_index_from_returns(tmt_ret, dotcom_start, dotcom_end).rename('Dot-com TMT core')
all49_idx = log_index_from_returns(all49_ret, dotcom_start, dotcom_end).rename('FF49 all industries')
ndx100 = price_index_from_series(nasdaq100, dotcom_start, dotcom_end).rename('Dot-com NASDAQ-100')
ndxcom = price_index_from_series(nasdaqcom, dotcom_start, dotcom_end).rename('Dot-com NASDAQ Composite')

ai_etf = norm_index_from_prices(price_df, ai_components, ai_start, ai_end).rename('Current AI ETF basket')
semis = norm_index_from_prices(price_df, semis_components, ai_start, ai_end).rename('Current semis ETF basket')
ixn = norm_index_from_prices(price_df, ['IXN'], ai_start, ai_end).rename('Current IXN global tech')
sp_idx = price_index_from_series(sp500, ai_start, ai_end).rename('S&P 500')

# Align by months to endpoint.
def aligned(series: pd.Series, label: str) -> pd.DataFrame:
    s = series.dropna()
    if len(s) > T:
        s = s.iloc[-T:]
    return pd.DataFrame({'m': np.arange(len(s))-len(s)+1, label: s.values})

aligned_df = pd.DataFrame({'m': np.arange(-T+1, 1)})
for s, label in [(tmt_idx,'Dot-com TMT core'),(ndx100,'Dot-com NASDAQ-100'),(ndxcom,'Dot-com NASDAQ Comp'),(ai_etf,'Current AI ETF basket'),(semis,'Current semis ETF basket'),(ixn,'Current global tech')]:
    aligned_df = aligned_df.merge(aligned(s, label), on='m', how='left')

dot_excess = np.log(tmt_idx / all49_idx).rename('Dot-com TMT excess')
ai_excess = np.log(ai_etf / sp_idx).rename('Current AI ETF excess')
semi_excess = np.log(semis / sp_idx).rename('Current semis excess')
excess_df = pd.DataFrame({'m': np.arange(-T+1, 1)})
for s, label in [(dot_excess,'Dot-com TMT minus All49'),(ai_excess,'AI ETF minus S&P 500'),(semi_excess,'Semis minus S&P 500')]:
    excess_df = excess_df.merge(aligned(s, label), on='m', how='left')

# --------------------------
# Statistics
# --------------------------
def monthly_returns_from_index(idx: pd.Series) -> pd.Series:
    return np.log(idx).diff().dropna()

def max_drawdown(idx: pd.Series) -> float:
    x = idx.dropna()
    return (x / x.cummax() - 1.0).min()

def ols_acceleration(log_idx: pd.Series):
    y = np.asarray(log_idx.dropna(), dtype=float)
    y = y - y[0]
    n = len(y)
    t = np.arange(n, dtype=float)
    X = np.column_stack([np.ones(n), t, t*t])
    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    resid = y - X @ beta
    s2 = resid @ resid / max(n - 3, 1)
    cov = s2 * np.linalg.inv(X.T @ X)
    se = np.sqrt(np.diag(cov))
    return beta[1], beta[2], beta[1]/se[1], beta[2]/se[2]

def full_adf_t(log_idx: pd.Series):
    y = np.asarray(log_idx.dropna(), dtype=float)
    z = np.diff(y); x = y[:-1]
    X = np.column_stack([np.ones(len(x)), x])
    beta = np.linalg.lstsq(X, z, rcond=None)[0]
    resid = z - X @ beta
    s2 = resid @ resid / max(len(z)-2, 1)
    cov = s2 * np.linalg.inv(X.T @ X)
    se = np.sqrt(np.diag(cov))
    return beta[1], beta[1]/se[1]

# Efficient no-lag recursive ADF/GSADF.
def make_cumsums(y):
    y = np.asarray(y, dtype=float)
    x = y[:-1]; z = np.diff(y)
    return {name: np.concatenate([[0.0], np.cumsum(arr)]) for name,arr in [('x',x),('z',z),('xx',x*x),('xz',x*z),('zz',z*z)]}

def adf_t_window(c, a, b):
    m = b - a
    if m < 3: return np.nan
    def seg(name): return c[name][b] - c[name][a]
    sx, sz, sxx, sxz, szz = seg('x'), seg('z'), seg('xx'), seg('xz'), seg('zz')
    Sxx = sxx - sx*sx/m
    Sxz = sxz - sx*sz/m
    Szz = szz - sz*sz/m
    if Sxx <= 1e-12: return np.nan
    beta = Sxz / Sxx
    rss = Szz - beta*Sxz
    dof = m - 2
    if dof <= 0 or rss <= 0: return np.nan
    se = math.sqrt((rss/dof)/Sxx)
    return beta / se

def gsadf(y, min_window=None):
    y = np.asarray(y, dtype=float)
    n = len(y)
    if min_window is None:
        min_window = max(12, int(math.floor((0.01 + 1.8/math.sqrt(n))*n)))
    c = make_cumsums(y)
    best = -np.inf
    for b in range(min_window, n):
        for a in range(0, b - min_window + 1):
            tv = adf_t_window(c, a, b)
            if np.isfinite(tv) and tv > best:
                best = tv
    return best, min_window

def mc_gsadf_cv(n, min_window, nrep=50, seed=RNG_SEED):
    rng = np.random.default_rng(seed + n + min_window)
    vals = np.empty(nrep)
    for i in range(nrep):
        vals[i] = gsadf(np.cumsum(rng.standard_normal(n)), min_window)[0]
    return np.quantile(vals, [0.90,0.95,0.99])

series_for_metrics = {
    'Dot-com TMT core': tmt_idx,
    'Dot-com NASDAQ-100': ndx100,
    'Dot-com NASDAQ Composite': ndxcom,
    'Current AI ETF basket': ai_etf,
    'Current semis ETF basket': semis,
    'Current IXN global tech': ixn,
}
rows = []
for name, idx in series_for_metrics.items():
    idx = idx.dropna()
    r = monthly_returns_from_index(idx)
    cum = idx.iloc[-1]/idx.iloc[0] - 1
    ann = math.exp(r.mean()*12)-1
    vol = r.std(ddof=1)*math.sqrt(12)
    slope, accel, slope_t, accel_t = ols_acceleration(np.log(idx))
    beta_adf, t_adf = full_adf_t(np.log(idx))
    rows.append({
        'series': name,
        'start': idx.index.min().strftime('%Y-%m'),
        'end': idx.index.max().strftime('%Y-%m'),
        'months': len(idx),
        'cum_return_pct': 100*cum,
        'ann_return_pct': 100*ann,
        'ann_vol_pct': 100*vol,
        'max_dd_pct': 100*max_drawdown(idx),
        'terminal_index': idx.iloc[-1],
        'trend_slope_monthly_log': slope,
        'accel_quad_log': accel,
        'accel_t': accel_t,
        'adf_beta': beta_adf,
        'adf_t': t_adf,
    })
metrics = pd.DataFrame(rows)

def excess_metrics(label, ex):
    x = ex.dropna()
    total = x.iloc[-1] - x.iloc[0]
    ann = math.exp(total/(len(x)-1)*12)-1
    return {'series':label,'start':x.index.min().strftime('%Y-%m'),'end':x.index.max().strftime('%Y-%m'),'months':len(x),'log_excess_total':total,'excess_return_pct_equiv':100*(math.exp(total)-1),'ann_excess_pct_equiv':100*ann}
excess_metrics_df = pd.DataFrame([
    excess_metrics('Dot-com TMT minus All49', dot_excess),
    excess_metrics('Current AI ETF minus S&P 500', ai_excess),
    excess_metrics('Current semis minus S&P 500', semi_excess),
])

common = aligned_df[['Dot-com TMT core','Current AI ETF basket']].dropna()
log_dot = np.log(common['Dot-com TMT core']/common['Dot-com TMT core'].iloc[0])
log_ai = np.log(common['Current AI ETF basket']/common['Current AI ETF basket'].iloc[0])
path_corr = float(np.corrcoef(log_dot, log_ai)[0,1])
rmse_log = float(math.sqrt(np.mean((log_dot-log_ai)**2)))
terminal_gap_log = float(log_ai.iloc[-1]-log_dot.iloc[-1])

# GSADF comparison.
ff_win_start = '1990-01-31'; ff_win_end = '2002-12-31'
tmt_long = log_index_from_returns(tmt_ret, ff_win_start, ff_win_end)
all49_long = log_index_from_returns(all49_ret, ff_win_start, ff_win_end)
y_tech_rel = np.log((tmt_long/all49_long).dropna().values)
y_tmt_raw = np.log(tmt_long.dropna().values)
y_ai_rel = (ai_excess.dropna() - ai_excess.dropna().iloc[0]).values
y_ai_raw = np.log(ai_etf.dropna().values)

gsadf_rows = []
for label, y in [('Dot-com TMT relative, 1990-2002', y_tech_rel),('Dot-com TMT raw, 1990-2002', y_tmt_raw),('Current AI ETF relative, 2022-2026', y_ai_rel),('Current AI ETF raw, 2022-2026', y_ai_raw)]:
    stat, minw = gsadf(y)
    cv90, cv95, cv99 = mc_gsadf_cv(len(y), minw, nrep=50)
    gsadf_rows.append({'series':label,'T':len(y),'min_window':minw,'GSADF':stat,'cv90':cv90,'cv95':cv95,'cv99':cv99,'reject_95':stat>cv95})
gsadf_df = pd.DataFrame(gsadf_rows)

# Save machine-readable outputs.
metrics.to_csv(OUT/'summary_metrics.csv', index=False)
excess_metrics_df.to_csv(OUT/'excess_metrics.csv', index=False)
gsadf_df.to_csv(OUT/'recursive_adf_gsadf_results.csv', index=False)
aligned_df.to_csv(OUT/'aligned_price_paths.csv', index=False)
excess_df.to_csv(OUT/'aligned_excess_paths.csv', index=False)

# --------------------------
# Figures
# --------------------------
plt.rcParams.update({'font.size': 9})
def savefig(name):
    plt.tight_layout()
    plt.savefig(FIG/name, dpi=180, bbox_inches='tight')
    plt.close()

plt.figure(figsize=(8.2,5.1))
for col in ['Dot-com TMT core','Dot-com NASDAQ-100','Current AI ETF basket','Current semis ETF basket','Current global tech']:
    plt.plot(aligned_df['m'], aligned_df[col], label=col, linewidth=1.8)
plt.axhline(100, linewidth=0.8)
plt.xlabel('Months to peak/current endpoint')
plt.ylabel('Index level, start = 100')
plt.title('Dot-com pre-peak trend versus current AI trend')
plt.legend(loc='upper left', fontsize=7)
savefig('fig_01_aligned_price_paths.png')

plt.figure(figsize=(8.2,4.8))
for col in ['Dot-com TMT minus All49','AI ETF minus S&P 500','Semis minus S&P 500']:
    plt.plot(excess_df['m'], np.exp(excess_df[col])-1, label=col, linewidth=1.8)
plt.axhline(0, linewidth=0.8)
plt.xlabel('Months to peak/current endpoint')
plt.ylabel('Cumulative excess return')
plt.title('Theme excess performance over broad market proxy')
plt.legend(loc='upper left', fontsize=7)
savefig('fig_02_excess_performance.png')

plot_metrics = metrics[metrics['series'].isin(['Dot-com TMT core','Current AI ETF basket','Current semis ETF basket','Dot-com NASDAQ-100'])].copy()
labels = plot_metrics['series'].tolist()
x = np.arange(len(labels)); width = 0.25
plt.figure(figsize=(8.6,4.8))
plt.bar(x-width, plot_metrics['cum_return_pct'], width, label='Cumulative return')
plt.bar(x, plot_metrics['ann_return_pct'], width, label='Annualized return')
plt.bar(x+width, plot_metrics['ann_vol_pct'], width, label='Annualized volatility')
plt.xticks(x, labels, rotation=25, ha='right')
plt.ylabel('Percent')
plt.title('Return and risk summary over matched windows')
plt.legend(fontsize=8)
savefig('fig_03_metric_bars.png')

roll_df = pd.DataFrame({'m':np.arange(-T+1,1)})
for label, idx in [('Dot-com TMT core',tmt_idx),('Current AI ETF basket',ai_etf),('Current semis ETF basket',semis)]:
    roll = np.exp(monthly_returns_from_index(idx).rolling(12).sum().dropna()) - 1
    roll_df = roll_df.merge(aligned(roll, label), on='m', how='left')
plt.figure(figsize=(8.2,4.8))
for col in ['Dot-com TMT core','Current AI ETF basket','Current semis ETF basket']:
    plt.plot(roll_df['m'], roll_df[col], label=col, linewidth=1.8)
plt.axhline(0, linewidth=0.8)
plt.xlabel('Months to peak/current endpoint')
plt.ylabel('Trailing 12-month return')
plt.title('Rolling 12-month momentum')
plt.legend(loc='upper left', fontsize=8)
savefig('fig_04_rolling_12m_momentum.png')

plt.figure(figsize=(8.4,4.5))
x = np.arange(len(gsadf_df))
plt.bar(x, gsadf_df['GSADF'])
plt.plot(x, gsadf_df['cv95'], marker='o', linestyle='--', label='95 pct MC critical value')
plt.xticks(x, ['Dotcom rel','Dotcom raw','AI rel','AI raw'])
plt.ylabel('GSADF statistic')
plt.title('Recursive right-tailed ADF diagnostics')
plt.legend(fontsize=8)
savefig('fig_05_gsadf.png')

plt.figure(figsize=(8.2,3.0))
ax = plt.gca(); ax.axis('off')
boxes = [
    ('1. Build monthly\nprice indexes', 0.08),
    ('2. Align pre-peak\nwindows', 0.27),
    ('3. Compute market\nexcess trend', 0.47),
    ('4. Test acceleration\nand explosiveness', 0.67),
    ('5. Use evidence as\nprecursor to stress model', 0.87),
]
for text, x0 in boxes:
    ax.text(x0, 0.5, text, ha='center', va='center', bbox=dict(boxstyle='round,pad=0.35', fc='white', ec='black'), fontsize=8)
for x1,x2 in zip([0.16,0.36,0.56,0.76],[0.20,0.40,0.60,0.80]):
    ax.annotate('', xy=(x2,0.5), xytext=(x1,0.5), arrowprops=dict(arrowstyle='->', lw=1.2))
plt.title('Empirical comparison workflow')
savefig('fig_06_workflow.png')

# --------------------------
# LaTeX report
# --------------------------
def esc(s):
    return str(s).replace('&','\\&').replace('%','\\%').replace('_','\\_').replace('#','\\#')

def fmt(x, d=1):
    return '--' if pd.isna(x) else f'{x:.{d}f}'

def table_metrics(df):
    out=[]
    for _,r in df.iterrows():
        cells=[esc(r['series']), str(int(r['months'])), fmt(r['cum_return_pct'],1), fmt(r['ann_return_pct'],1), fmt(r['ann_vol_pct'],1), fmt(r['max_dd_pct'],1), fmt(r['accel_t'],2), fmt(r['adf_t'],2)]
        out.append(' & '.join(cells) + r' \\')
    return '\n'.join(out)

def table_excess(df):
    out=[]
    for _,r in df.iterrows():
        cells=[esc(r['series']), str(int(r['months'])), fmt(r['excess_return_pct_equiv'],1), fmt(r['ann_excess_pct_equiv'],1)]
        out.append(' & '.join(cells) + r' \\')
    return '\n'.join(out)

def table_gsadf(df):
    out=[]
    for _,r in df.iterrows():
        rej='Yes' if bool(r['reject_95']) else 'No'
        cells=[esc(r['series']), str(int(r['T'])), str(int(r['min_window'])), fmt(r['GSADF'],2), fmt(r['cv95'],2), rej]
        out.append(' & '.join(cells) + r' \\')
    return '\n'.join(out)

mrow={r['series']:r for _,r in metrics.iterrows()}
erow={r['series']:r for _,r in excess_metrics_df.iterrows()}
repl = {
    '__T__': str(T),
    '__AI_START__': ai_start.strftime('%Y-%m'),
    '__AI_END__': ai_end.strftime('%Y-%m'),
    '__DOT_START__': dotcom_start.strftime('%Y-%m'),
    '__DOT_END__': dotcom_end.strftime('%Y-%m'),
    '__DOT_CUM__': fmt(mrow['Dot-com TMT core']['cum_return_pct'],1),
    '__AI_CUM__': fmt(mrow['Current AI ETF basket']['cum_return_pct'],1),
    '__SEMI_CUM__': fmt(mrow['Current semis ETF basket']['cum_return_pct'],1),
    '__DOT_EX__': fmt(erow['Dot-com TMT minus All49']['excess_return_pct_equiv'],1),
    '__AI_EX__': fmt(erow['Current AI ETF minus S&P 500']['excess_return_pct_equiv'],1),
    '__SEMI_EX__': fmt(erow['Current semis minus S&P 500']['excess_return_pct_equiv'],1),
    '__METRICS_TABLE__': table_metrics(metrics),
    '__EXCESS_TABLE__': table_excess(excess_metrics_df),
    '__GSADF_TABLE__': table_gsadf(gsadf_df),
    '__PATH_CORR__': fmt(path_corr,2),
    '__RMSE__': fmt(rmse_log,2),
    '__GAP__': fmt(terminal_gap_log,2),
}

template = r'''
\documentclass[10pt]{article}
\usepackage{graphicx}
\setlength{\parindent}{0pt}
\setlength{\parskip}{0.55em}
\title{Dot-Com Technology and Current AI Price Dynamics: A Statistical Comparison}
\author{Alex Zhang}
\date{July 2026}

\begin{document}
\maketitle

\begin{abstract}
This note compares the price trend before the dot-com peak with the current AI equity trend. The purpose is not to prove that AI is a bubble. The purpose is narrower: to measure whether the current AI price path has started to resemble the statistical shape of a historical technology boom before its peak. The exercise is designed as a precursor to the AI unwind stress framework. It asks whether the empirical preconditions for a stress topic are present: rapid theme appreciation, theme outperformance over the broad market, acceleration in the price path, and recursive right-tailed evidence of exuberant dynamics.
\end{abstract}

\section{Executive summary}
The matched-window comparison uses __T__ monthly observations. The current AI window runs from __AI_START__ to __AI_END__. The dot-com comparison window is the same length and ends at the March 2000 technology peak, running from __DOT_START__ to __DOT_END__.

The headline result is mixed. On raw price appreciation, the current AI ETF basket is strong, but it does not dominate the late dot-com TMT industry trend in the matched window. The dot-com TMT core returned __DOT_CUM__ percent over the matched pre-peak window. The current AI ETF basket returned __AI_CUM__ percent, while the semiconductor ETF basket returned __SEMI_CUM__ percent. On market-relative terms, the dot-com TMT core outperformed the broad Fama-French 49-industry proxy by __DOT_EX__ percent. The current AI ETF basket outperformed the S\&P 500 by __AI_EX__ percent, and the semiconductor basket by __SEMI_EX__ percent.

The statistical interpretation is therefore: current AI has meaningful boom-like price behavior, especially in semiconductors, but the broad ETF AI basket is not yet a mechanical replay of the dot-com TMT episode. This is useful for the research setup. It supports a conditional stress framework rather than an unconditional crash prediction. The evidence says that the AI theme has enough price momentum and excess performance to justify stress research, but the data do not say that the current episode must end like 2000.

\begin{figure}[h]
\centering
\includegraphics[width=0.92\textwidth]{figures/fig_01_aligned_price_paths.png}
\caption{Matched-window price paths. All series are normalized to 100 at the start of the comparison window. The horizontal axis counts months to the dot-com peak or current endpoint.}
\end{figure}

\section{Research question}
The research question is:
\[
\hbox{How similar is the current AI price trend to the dot-com technology trend before its peak?}
\]
This question sits before the stress model. It does not yet ask how much Korea technology hardware, Taiwan semiconductors, or NVDA should fall in an unwind. It first asks whether the theme-level price path has the kind of rapid appreciation and excess performance that makes an AI unwind a legitimate risk topic.

The analysis is deliberately statistical rather than narrative. There are many qualitative reasons why AI is different from dot-com: larger incumbent firms, real revenue, massive cloud demand, and existing profitability. There are also similarities: concentrated leadership, extrapolated growth expectations, valuation stretch, and supply-chain spillovers. The point of this note is to put the price-path comparison on a transparent quantitative footing.

\section{Data and empirical objects}
The dot-com side uses three objects. First, the NASDAQ Composite and NASDAQ-100 are used as broad technology price indexes. Second, the Fama-French 49 industry data are used to build a TMT core from the monthly value-weighted returns of hardware, software, chips, and telecom. Third, the average of the 49 industries is used as a broad contemporaneous market proxy.

The current AI side uses uploaded daily ETF price files converted to month-end prices. The AI ETF basket is the equal-weighted average of SMH, SOXX, IGV, SKYY, and AIQ. BOTZ was part of the prior model architecture, but it was not included in the current reuploaded file set, so it is not used in the main basket here. A separate semiconductor basket uses SMH and SOXX only. IXN is reported as a global technology benchmark. The S\&P 500 daily file is used as the current broad-market comparison.

Let $P_t^D$ denote the dot-com TMT price index at month $t$. Let $P_t^A$ denote the current AI price index at month $t$. Each index is normalized to 100 at the beginning of its own window:
\[
I_t^D=100\times {P_t^D\over P_0^D},\qquad
I_t^A=100\times {P_t^A\over P_0^A}.
\]
Here $I_t^D$ is the normalized dot-com index, $I_t^A$ is the normalized AI index, $P_0^D$ is the dot-com index level at the beginning of the matched window, and $P_0^A$ is the AI index level at the beginning of the current window.

\begin{figure}[h]
\centering
\includegraphics[width=0.92\textwidth]{figures/fig_06_workflow.png}
\caption{Workflow from raw price data to statistical comparison.}
\end{figure}

\section{Step 1: total price appreciation}
The first statistic is simply the cumulative return over the matched window:
\[
R_{0,T}= {P_T\over P_0}-1.
\]
Here $P_0$ is the initial price index, $P_T$ is the final price index, and $R_{0,T}$ is the total simple return over the window.

This statistic is intentionally simple. It answers how much the theme rose before the endpoint. It does not adjust for market performance. It does not distinguish fundamentals from speculative repricing. It is the first descriptive layer.

\begin{center}
\small
\begin{tabular}{lrrrrrrr}
Series & Months & Cum. \% & Ann. \% & Vol. \% & Max DD \% & Accel t & ADF t \\
\hline
__METRICS_TABLE__
\end{tabular}
\end{center}

The current semiconductor trend is visually and statistically the most dot-com-like current AI proxy. The broader AI ETF basket is still strong, but it is less extreme because it includes software, cloud, and broader thematic ETFs rather than only semiconductor leadership.

\section{Step 2: market-relative excess performance}
A theme can rise because the whole market is rising. Therefore the second statistic removes a broad market benchmark. Define log excess performance as
\[
X_t=\log P_t^{theme}-\log P_t^{market}.
\]
Here $P_t^{theme}$ is the theme price index and $P_t^{market}$ is the broad market index. The change in $X_t$ over the window is
\[
\Delta X_{0,T}=X_T-X_0
=\log\left({P_T^{theme}/P_0^{theme}\over P_T^{market}/P_0^{market}}\right).
\]
This is the log return of the theme relative to the market. Converted back to a simple relative return, it is $\exp(\Delta X_{0,T})-1$.

Financially, this is the better bubble precursor than raw return. A broad bull market can lift many assets. A theme bubble should show that the theme rises more than the market around it.

\begin{figure}[h]
\centering
\includegraphics[width=0.92\textwidth]{figures/fig_02_excess_performance.png}
\caption{Cumulative market-relative excess performance. Dot-com TMT is measured relative to the Fama-French 49-industry broad proxy. Current AI and semiconductors are measured relative to the S\&P 500.}
\end{figure}

\begin{center}
\small
\begin{tabular}{lrrr}
Series & Months & Total excess \% & Ann. excess \% \\
\hline
__EXCESS_TABLE__
\end{tabular}
\end{center}

\section{Step 3: acceleration in the trend}
A bubble-like trend is often not just high return. It often accelerates. To measure this, estimate a quadratic trend in log price:
\[
y_t=a+bt+ct^2+u_t.
\]
Here $y_t=\log(P_t/P_0)$ is the cumulative log price path, $t$ is the month number, $a$ is the intercept, $b$ is the linear growth rate, $c$ is the acceleration coefficient, and $u_t$ is the residual. A positive $c$ means that the trend bends upward over time.

This is not a structural model. It is a simple shape statistic. If the current AI path has a high positive acceleration coefficient, the price path is becoming steeper as the episode develops. That is the mathematical analogue of saying that investor extrapolation is intensifying.

\begin{figure}[h]
\centering
\includegraphics[width=0.92\textwidth]{figures/fig_04_rolling_12m_momentum.png}
\caption{Trailing 12-month momentum. The series show how recent price pressure evolves through the window.}
\end{figure}

The table above reports the $t$-statistic on $c$ as ``Accel t''. The current AI basket and semiconductor basket both show positive acceleration over the window, but the magnitude and statistical strength depend on the chosen proxy. This is why the conclusion should be phrased as evidence of boom-like dynamics, not proof of a deterministic replay of 2000.

\section{Step 4: recursive right-tailed ADF diagnostic}
The final statistical diagnostic is a recursive right-tailed ADF test. For a candidate series $y_t$, estimate
\[
\Delta y_t=\alpha+\beta y_{t-1}+\varepsilon_t.
\]
Here $y_t$ is a log price or log relative-price series, $\Delta y_t=y_t-y_{t-1}$ is the monthly change, $\alpha$ is an intercept, $\beta$ measures local explosiveness, and $\varepsilon_t$ is the residual. If the implied autoregressive root is above one, then $\beta>0$.

The recursive diagnostic estimates this regression over many subwindows and records the largest right-tailed $t$-statistic. This gives the generalized supremum ADF statistic:
\[
GSADF=\sup_{r_1,r_2} ADF_{r_1,r_2}.
\]
Here $r_1$ and $r_2$ index the start and end of a recursive window. The statistic is compared with Monte Carlo finite-sample critical values generated under a random-walk null with the same sample length.

\begin{figure}[h]
\centering
\includegraphics[width=0.88\textwidth]{figures/fig_05_gsadf.png}
\caption{Recursive right-tailed ADF diagnostics. The bar is the observed GSADF statistic. The dashed marker is the Monte Carlo 95 percent critical value under a random-walk null.}
\end{figure}

\begin{center}
\small
\begin{tabular}{lrrrrl}
Series & T & Min win & GSADF & 95\% CV & Reject 95\% \\
\hline
__GSADF_TABLE__
\end{tabular}
\end{center}

The recursive result is the cleanest warning against overclaiming. Dot-com technology relative performance shows stronger explosive-root evidence over the full 1990-2002 dot-com panel. Current AI has local exuberance, but the shorter sample and broader ETF composition make the statistical evidence less conclusive than the late-1990s TMT episode.

\section{Step 5: similarity of the price paths}
To summarize shape similarity, align the two main paths by months-to-end and compare cumulative log indexes. Let
\[
z_t^D=\log(I_t^D/100),\qquad z_t^A=\log(I_t^A/100).
\]
The path correlation is
\[
\rho_{path}=corr(z_t^D,z_t^A),
\]
and the path distance is
\[
RMSE=\sqrt{{1\over T}\sum_{t=1}^{T}(z_t^D-z_t^A)^2}.
\]
For the main matched comparison, the path correlation between dot-com TMT and the current AI ETF basket is __PATH_CORR__. The log-path RMSE is __RMSE__. The terminal log gap, defined as AI minus dot-com, is __GAP__. A negative terminal gap means the current AI ETF basket ends below the dot-com TMT path on the matched-window normalized scale.

\begin{figure}[h]
\centering
\includegraphics[width=0.92\textwidth]{figures/fig_03_metric_bars.png}
\caption{Matched-window return and risk summary.}
\end{figure}

\section{Interpretation for the broader AI unwind project}
The comparison supports three conclusions.

First, current AI has produced a real theme-level price boom. This is visible in the normalized price paths, market-relative returns, and rolling momentum. The result is not merely a narrative claim.

Second, the current AI boom is not statistically identical to the dot-com pre-peak path. The current AI basket is broader and less extreme than the late-1990s TMT core. Semiconductors are closer to the dot-com pattern than the broad AI ETF basket.

Third, this is exactly why the later AI unwind framework should be conditional and scenario-based. The data motivate a stress question, not a point forecast. The correct research bridge is:
\[
\hbox{AI price trend evidence}\quad\Longrightarrow\quad
\hbox{plausible AI-excess repricing risk}\quad\Longrightarrow\quad
\hbox{country-industry stress vector}.
\]
The statistical comparison does not say that AI must crash. It says that the theme has enough boom-like price behavior to justify asking how a repricing would transmit through countries, industries, and client positions.

\section{Limitations}
The main limitation is proxy choice. The dot-com TMT core is built from Fama-French industries, while the current AI basket is built from ETFs. These are not identical instruments. The dot-com series are monthly industry portfolio returns; the AI series are ETF prices converted to month-end levels.

Second, the current AI window is not a completed cycle. The dot-com window is selected with knowledge of the March 2000 peak. The current AI endpoint is simply the latest full month in the uploaded files. This makes the comparison useful as a current-state diagnostic, but not as a completed-cycle study.

Third, the analysis is price-based. It does not directly compare earnings growth, capex, valuation multiples, or realized AI adoption. Those variables matter for deciding how much of current AI value is fundamental and how much is excess premium. This note therefore should be used as a precursor to the valuation and stress framework, not as a substitute for it.

\section{Files generated}
The source bundle contains the LaTeX file, figures, the Python script, and the following machine-readable outputs: summary metrics, excess metrics, GSADF results, aligned price paths, and aligned excess paths.

\end{document}
'''
tex = template
for k,v in repl.items():
    tex = tex.replace(k, str(v))
tex_path = OUT/'dotcom_ai_statistical_comparison.tex'
tex_path.write_text(tex, encoding='utf-8')

# Compile LaTeX.
for _ in range(2):
    subprocess.run(['pdflatex','-interaction=nonstopmode', tex_path.name], cwd=OUT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

# Bundle.
zip_path = ROOT/'dotcom_ai_statistical_comparison_source_bundle.zip'
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in [tex_path, OUT/'summary_metrics.csv', OUT/'excess_metrics.csv', OUT/'recursive_adf_gsadf_results.csv', OUT/'aligned_price_paths.csv', OUT/'aligned_excess_paths.csv', ROOT/'run_dotcom_ai_comparison.py']:
        z.write(p, arcname=p.name)
    for p in sorted(FIG.glob('*.png')):
        z.write(p, arcname=f'figures/{p.name}')

for src,dst in [(OUT/'dotcom_ai_statistical_comparison.pdf', ROOT/'dotcom_ai_statistical_comparison.pdf'), (tex_path, ROOT/'dotcom_ai_statistical_comparison.tex')]:
    if src.exists():
        shutil.copy(src, dst)

print('ai_components', ai_components)
print('tmt_cols', tmt_cols)
print(metrics.to_string(index=False))
print(excess_metrics_df.to_string(index=False))
print(gsadf_df.to_string(index=False))
print('path_corr', path_corr, 'rmse', rmse_log, 'terminal_gap', terminal_gap_log)
print('PDF', (ROOT/'dotcom_ai_statistical_comparison.pdf').exists())
print('ZIP', zip_path.exists())
