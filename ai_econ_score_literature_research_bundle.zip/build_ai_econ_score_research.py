import os, math, shutil, zipfile, textwrap
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch

BASE=Path('/mnt/data')
OUT=BASE/'ai_econ_score_literature_research_bundle'
OUT.mkdir(exist_ok=True)

plt.rcParams['figure.dpi']=170
plt.rcParams['font.size']=10

# ---------------- load model data ----------------
ci = pd.read_csv(BASE/'country_industry_stress_vector_v5(1).csv')
# Keep unique cells
cells = ci[['country_bucket','client_industry_label','industry_bucket','beta_world_cell',
            'cell_stat_ai_excess_intensity','cell_stat_ai_excess_intensity_raw',
            'country_economic_ai_intensity','client_industry_economic_ai_intensity',
            'cell_economic_ai_intensity','final_ai_excess_intensity']].drop_duplicates().copy()

# ---------------- proposed literature-backed channel score ----------------
# Channel weights: compute/advanced chips, equipment, memory, cloud/software, power/data-center
weights = {'compute':0.30, 'equipment':0.20, 'memory':0.15, 'cloud':0.20, 'power':0.15}

# default scoring functions, intentionally transparent keyword / taxonomy mapping
# The taxonomy has no separate semiconductors label, so "technology hardware" absorbs chips/hardware.
def industry_channels(label):
    s = str(label).lower().strip()
    ch = dict(compute=0.0, equipment=0.0, memory=0.0, cloud=0.0, power=0.0)
    note=[]
    # direct compute / chip / hardware channel
    if 'technology hardware' in s:
        ch.update(compute=1.00, equipment=0.45, memory=0.70, cloud=0.25, power=0.10); note.append('AI compute hardware, servers, storage, accelerators')
    elif 'communication equipment' in s:
        ch.update(compute=0.55, equipment=0.40, memory=0.20, cloud=0.35, power=0.15); note.append('data-center networking and connectivity hardware')
    elif 'electronic equipment' in s:
        ch.update(compute=0.45, equipment=0.55, memory=0.15, cloud=0.20, power=0.25); note.append('instrumentation, components, manufacturing and AI infrastructure supply')
    elif 'electrical equipment' in s:
        ch.update(compute=0.20, equipment=0.45, memory=0.05, cloud=0.10, power=0.85); note.append('transformers, switchgear, power infrastructure for data centers')
    # software / cloud / platform
    elif 'it services' in s:
        ch.update(compute=0.10, equipment=0.05, memory=0.05, cloud=0.75, power=0.05); note.append('enterprise AI integration and cloud/software services')
    elif 'interactive media' in s:
        ch.update(compute=0.10, equipment=0.05, memory=0.05, cloud=0.65, power=0.05); note.append('AI platform, ad-tech, content and model deployment exposure')
    elif s == 'media' or 'wireless telecommunication' in s or 'telecommunication' in s:
        ch.update(compute=0.05, equipment=0.10, memory=0.05, cloud=0.25, power=0.10); note.append('digital distribution, connectivity and platform adjacency')
    elif 'professional services' in s or 'commercial services' in s:
        ch.update(compute=0.00, equipment=0.00, memory=0.00, cloud=0.35, power=0.00); note.append('AI adoption and consulting / services channel')
    elif 'health care technology' in s:
        ch.update(compute=0.05, equipment=0.05, memory=0.00, cloud=0.35, power=0.00); note.append('software-enabled vertical AI adoption')
    # power / data center
    elif 'independent power' in s or 'renewables' in s:
        ch.update(compute=0.00, equipment=0.10, memory=0.00, cloud=0.00, power=0.80); note.append('data-center electricity demand and interconnection')
    elif 'electric utilities' in s:
        ch.update(compute=0.00, equipment=0.05, memory=0.00, cloud=0.00, power=0.65); note.append('grid load growth from data centers')
    elif 'multi utilities' in s:
        ch.update(compute=0.00, equipment=0.05, memory=0.00, cloud=0.00, power=0.45); note.append('indirect grid and load exposure')
    elif 'gas utilities' in s:
        ch.update(compute=0.00, equipment=0.05, memory=0.00, cloud=0.00, power=0.25); note.append('possible backup / generation exposure')
    elif 'water utilities' in s:
        ch.update(compute=0.00, equipment=0.05, memory=0.00, cloud=0.00, power=0.20); note.append('water/cooling adjacency for data centers')
    # industrials / automation / components
    elif 'mchinery' in s or 'machinery' in s or 'industrial conlomerates' in s or 'aerospace' in s:
        ch.update(compute=0.05, equipment=0.25, memory=0.00, cloud=0.10, power=0.10); note.append('industrial automation and AI-enabled capital equipment')
    elif 'auto components' in s or 'automobiles' in s:
        ch.update(compute=0.10, equipment=0.10, memory=0.05, cloud=0.10, power=0.05); note.append('embedded AI / autonomy adjacency')
    elif 'building products' in s or 'construction & engineering' in s or 'construction materials' in s:
        ch.update(compute=0.00, equipment=0.10, memory=0.00, cloud=0.05, power=0.20); note.append('data-center construction and power-infrastructure capex')
    elif 'metals' in s or 'mining' in s or 'chemicals' in s:
        ch.update(compute=0.00, equipment=0.10, memory=0.00, cloud=0.00, power=0.15); note.append('materials input to power and equipment capex')
    # financial/professional/real estate/defensive buckets
    elif 'capital markets' in s or 'banks' in s or 'consumer finance' in s or 'insurance' in s:
        ch.update(compute=0.00, equipment=0.00, memory=0.00, cloud=0.15, power=0.00); note.append('AI adoption, but not AI infrastructure supply chain')
    elif 're management' in s or 'reit' in s or 'real estate' in s:
        # industrial REITs can include data centers, but taxonomy here is broad; modest score.
        power = 0.25 if 'industrial' in s else 0.10
        ch.update(compute=0.00, equipment=0.00, memory=0.00, cloud=0.05, power=power); note.append('property exposure, only modest data-center adjacency in broad taxonomy')
    elif 'biotechnology' in s or 'pharma' in s or 'health care' in s:
        ch.update(compute=0.00, equipment=0.00, memory=0.00, cloud=0.20, power=0.00); note.append('AI adoption in R&D / workflow, not core infrastructure')
    elif 'index' in s or 'muni' in s or 'lstd' in s:
        ch.update(compute=0.00, equipment=0.00, memory=0.00, cloud=0.00, power=0.00); note.append('not an operating AI exposure bucket')
    else:
        ch.update(compute=0.00, equipment=0.00, memory=0.00, cloud=0.05, power=0.00); note.append('weak general AI-adoption exposure')
    score = sum(weights[k]*ch[k] for k in weights)
    return {**ch, 'literature_industry_score':score, 'industry_score_rationale':'; '.join(note)}


def country_channels(country):
    c = str(country).lower().strip()
    ch = dict(compute=0.0, equipment=0.0, memory=0.0, cloud=0.0, power=0.0)
    note=[]
    if 'taiwan' in c:
        ch.update(compute=1.00, equipment=0.45, memory=0.20, cloud=0.15, power=0.10); note.append('advanced foundry / packaging concentration')
    elif c == 'united states':
        ch.update(compute=0.80, equipment=0.35, memory=0.35, cloud=1.00, power=0.55); note.append('hyperscalers, chip designers, cloud/software and data centers')
    elif 'korea' in c:
        ch.update(compute=0.60, equipment=0.25, memory=1.00, cloud=0.15, power=0.10); note.append('HBM/memory and electronics supply chain')
    elif 'netherlands' in c:
        ch.update(compute=0.35, equipment=1.00, memory=0.05, cloud=0.10, power=0.15); note.append('lithography / semiconductor equipment bottleneck')
    elif 'japan' in c:
        ch.update(compute=0.35, equipment=0.65, memory=0.25, cloud=0.15, power=0.20); note.append('equipment, materials, electronics and diversified power system')
    elif 'china' in c:
        ch.update(compute=0.45, equipment=0.25, memory=0.25, cloud=0.40, power=0.25); note.append('large AI demand base and domestic hardware/software push')
    elif 'germany' in c:
        ch.update(compute=0.20, equipment=0.45, memory=0.05, cloud=0.20, power=0.25); note.append('industrial equipment, automation and power infrastructure')
    elif 'sweden' in c or 'switzerland' in c or 'france' in c or 'united kingdom' in c:
        ch.update(compute=0.15, equipment=0.25, memory=0.05, cloud=0.30, power=0.20); note.append('software, industrials and power/infrastructure adjacency')
    elif 'developed europe' in c:
        ch.update(compute=0.15, equipment=0.30, memory=0.05, cloud=0.25, power=0.20); note.append('diversified European technology and grid exposure')
    elif 'india' in c:
        ch.update(compute=0.10, equipment=0.10, memory=0.00, cloud=0.45, power=0.20); note.append('IT services/software adoption channel')
    elif 'singapore' in c or 'hong kong' in c:
        ch.update(compute=0.10, equipment=0.10, memory=0.05, cloud=0.30, power=0.20); note.append('regional cloud/data-center and services hub')
    elif 'world' in c or 'developed ex-us' in c or 'asia ex-japan' in c or 'emerging asia' in c:
        ch.update(compute=0.15, equipment=0.15, memory=0.10, cloud=0.20, power=0.15); note.append('broad diversified regional exposure')
    else:
        ch.update(compute=0.05, equipment=0.05, memory=0.00, cloud=0.10, power=0.10); note.append('mainly indirect diversified exposure')
    score=sum(weights[k]*ch[k] for k in weights)
    return {**ch, 'literature_country_score':score, 'country_score_rationale':'; '.join(note)}

# build industry and country tables
industries = pd.DataFrame([{'client_industry_label':lab, **industry_channels(lab)} for lab in sorted(cells['client_industry_label'].dropna().unique())])
countries = pd.DataFrame([{'country_bucket':cty, **country_channels(cty)} for cty in sorted(cells['country_bucket'].dropna().unique())])

# combine into cells
cell_new = cells.merge(industries, on='client_industry_label', how='left', suffixes=('','_ind')).merge(countries, on='country_bucket', how='left', suffixes=('','_cty'))
# Since duplicate channel names from country have suffixes; rename cleaner
for k in weights:
    if k+'_cty' in cell_new.columns:
        cell_new.rename(columns={k+'_cty':'country_'+k, k:'industry_'+k}, inplace=True)
# But if suffixes didn't apply for columns, check and adjust
for k in list(weights.keys()):
    if k in cell_new.columns and 'industry_'+k not in cell_new.columns:
        cell_new.rename(columns={k:'industry_'+k}, inplace=True)

cell_new['literature_cell_score'] = 0.65*cell_new['literature_industry_score'] + 0.35*cell_new['literature_country_score']
cell_new['proposed_final_ai_intensity'] = 0.45*cell_new['cell_stat_ai_excess_intensity'].fillna(0) + 0.55*cell_new['literature_cell_score'].fillna(0)
cell_new['old_minus_new_econ'] = cell_new['cell_economic_ai_intensity'] - cell_new['literature_cell_score']
cell_new['new_minus_old_econ'] = cell_new['literature_cell_score'] - cell_new['cell_economic_ai_intensity']
cell_new['structural_minus_stat'] = cell_new['literature_cell_score'] - cell_new['cell_stat_ai_excess_intensity'].fillna(0)

# external evidence channel table
source_table = pd.DataFrame([
    {'channel':'Compute / advanced chips','score_component':'compute','weight':weights['compute'], 'support':'AI hardware and compute are central to modern AI progress; frontier AI depends on specialized accelerators, advanced-node manufacturing and packaging.', 'examples':'technology hardware, Taiwan, United States, advanced chips'},
    {'channel':'Semiconductor equipment / lithography','score_component':'equipment','weight':weights['equipment'], 'support':'Advanced chip capacity depends on lithography, process tools and upstream equipment bottlenecks.', 'examples':'Netherlands, semiconductor equipment, electronic/electrical equipment'},
    {'channel':'Memory / bandwidth / HBM','score_component':'memory','weight':weights['memory'], 'support':'AI training and inference are constrained by memory bandwidth, high-bandwidth memory and data-center GPU memory systems.', 'examples':'Korea, memory semiconductors, HBM-linked suppliers'},
    {'channel':'Cloud / software / platform adoption','score_component':'cloud','weight':weights['cloud'], 'support':'LLMs have broad task exposure and scale through software/tooling; hyperscalers and platform firms are direct infrastructure spenders and monetization channels.', 'examples':'United States, IT services, software/platform/media'},
    {'channel':'Power / data-center infrastructure','score_component':'power','weight':weights['power'], 'support':'AI data centers create electricity, grid-interconnection, cooling and power equipment demand.', 'examples':'electric utilities, independent power, electrical equipment, construction'},
])

# save data outputs
industry_csv = BASE/'ai_econ_literature_industry_scores.csv'
country_csv = BASE/'ai_econ_literature_country_scores.csv'
cell_csv = BASE/'ai_econ_literature_cell_scores_and_regression_comparison.csv'
source_csv = BASE/'ai_econ_literature_channel_source_map.csv'
industries.to_csv(industry_csv, index=False)
countries.to_csv(country_csv, index=False)
cell_new.to_csv(cell_csv, index=False)
source_table.to_csv(source_csv, index=False)

# ---------------- statistics ----------------
def pearson(x,y):
    x=pd.Series(x).astype(float); y=pd.Series(y).astype(float)
    ok=x.notna() & y.notna()
    return float(np.corrcoef(x[ok],y[ok])[0,1]) if ok.sum()>2 else np.nan

def spearman(x,y):
    return pearson(pd.Series(x).rank(), pd.Series(y).rank())

def linreg(x,y):
    x=np.asarray(x, dtype=float); y=np.asarray(y, dtype=float)
    ok=np.isfinite(x) & np.isfinite(y)
    x=x[ok]; y=y[ok]
    X=np.vstack([np.ones_like(x), x]).T
    beta=np.linalg.lstsq(X,y,rcond=None)[0]
    pred=X@beta
    ss_res=((y-pred)**2).sum(); ss_tot=((y-y.mean())**2).sum()
    r2=1-ss_res/ss_tot if ss_tot>0 else np.nan
    return float(beta[0]), float(beta[1]), float(r2)

stat_col='cell_stat_ai_excess_intensity'
old_econ='cell_economic_ai_intensity'
new_econ='literature_cell_score'
final_old='final_ai_excess_intensity'
final_new='proposed_final_ai_intensity'

p_econ_stat=pearson(cell_new[new_econ], cell_new[stat_col])
s_econ_stat=spearman(cell_new[new_econ], cell_new[stat_col])
intc, slope, r2 = linreg(cell_new[new_econ], cell_new[stat_col].fillna(0))
p_old_new=pearson(cell_new[old_econ], cell_new[new_econ])
s_old_new=spearman(cell_new[old_econ], cell_new[new_econ])

# bins for validation
cell_new['structural_score_decile']=pd.qcut(cell_new[new_econ].rank(method='first'), 10, labels=False)+1
bin_stats=cell_new.groupby('structural_score_decile').agg(
    mean_literature_score=(new_econ,'mean'),
    median_regression_stat=(stat_col,'median'),
    mean_regression_stat=(stat_col,'mean'),
    count=(stat_col,'size')
).reset_index()
bin_csv=BASE/'ai_econ_literature_binned_validation.csv'
bin_stats.to_csv(bin_csv,index=False)

# quadrant classification
stat_threshold=0.15
struct_threshold=0.35
cell_new['quadrant']=np.select([
    (cell_new[new_econ]>=struct_threshold)&(cell_new[stat_col]>=stat_threshold),
    (cell_new[new_econ]>=struct_threshold)&(cell_new[stat_col]<stat_threshold),
    (cell_new[new_econ]<struct_threshold)&(cell_new[stat_col]>=stat_threshold),
], ['high structural / high regression','high structural / low regression','low structural / high regression'], default='low structural / low regression')
quad=cell_new['quadrant'].value_counts().rename_axis('quadrant').reset_index(name='count')
quad_csv=BASE/'ai_econ_literature_quadrant_counts.csv'
quad.to_csv(quad_csv,index=False)

# compare stress impact under revised 2m base/severe maybe
sc=pd.read_csv(BASE/'ai_unwind_v5_revised_kappa_short_horizon_scenario_parameters.csv')
scenario_2m_base=sc[(sc['horizon']=='2m')&(sc['scenario']=='base')].iloc[0]
scenario_2m_worst=sc[(sc['horizon']=='2m')&(sc['scenario']=='worst')].iloc[0]
for scen_name, scen in [('base_2m',scenario_2m_base),('worst_2m',scenario_2m_worst)]:
    w=float(scen['S_WORLD_log']); x=float(scen['S_AI_EXCESS_log'])
    cell_new[f'{scen_name}_stress_old_econ_log']=cell_new['beta_world_cell']*w + cell_new['final_ai_excess_intensity']*x
    cell_new[f'{scen_name}_stress_new_econ_log']=cell_new['beta_world_cell']*w + cell_new['proposed_final_ai_intensity']*x
    cell_new[f'{scen_name}_stress_old_econ_pct']=(np.exp(cell_new[f'{scen_name}_stress_old_econ_log'])-1)*100
    cell_new[f'{scen_name}_stress_new_econ_pct']=(np.exp(cell_new[f'{scen_name}_stress_new_econ_log'])-1)*100
    cell_new[f'{scen_name}_stress_delta_pct']=cell_new[f'{scen_name}_stress_new_econ_pct']-cell_new[f'{scen_name}_stress_old_econ_pct']
stress_csv=BASE/'ai_econ_literature_new_score_stress_impact.csv'
cell_new.to_csv(stress_csv,index=False)

# ---------------- figures ----------------
figs=[]
def fpath(name):
    p=OUT/name
    figs.append(p)
    return p

def savefig(path):
    plt.tight_layout()
    plt.savefig(path, bbox_inches='tight')
    plt.close()

# 1 architecture diagram
fig, ax = plt.subplots(figsize=(10.5,5.5))
ax.axis('off'); ax.set_xlim(0,12); ax.set_ylim(0,6)
# boxes
boxes=[(0.4,3.7,2.0,1.0,'Literature\nchannels'),(0.4,1.3,2.0,1.0,'Return\nregression'),
       (3.2,4.4,2.3,0.8,'Industry score\n$I_g^{struct}$'),(3.2,3.2,2.3,0.8,'Country score\n$I_b^{struct}$'),
       (6.2,3.7,2.2,1.0,'Cell prior\n$I_{b,g}^{econ}$'),(6.2,1.3,2.2,1.0,'Statistical score\n$I_{b,g}^{stat}$'),
       (9.1,2.5,2.2,1.0,'Final AI intensity\n$I_{b,g}^{AI}$')]
for x,y,w,h,t in boxes:
    ax.add_patch(Rectangle((x,y),w,h,fill=False,linewidth=1.5))
    ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=12)
# channel bullets
ax.text(0.45,5.15,'compute / equipment / memory /\ncloud-software / power',fontsize=9,va='top')
# arrows
for p1,p2 in [((2.4,4.2),(3.2,4.8)),((2.4,4.2),(3.2,3.6)),((5.5,4.8),(6.2,4.2)),((5.5,3.6),(6.2,4.2)),((2.4,1.8),(6.2,1.8)),((8.4,4.2),(9.1,3.0)),((8.4,1.8),(9.1,3.0))]:
    ax.add_patch(FancyArrowPatch(p1,p2,arrowstyle='->',mutation_scale=12,linewidth=1.2))
ax.text(10.2,1.15,'$I^{AI}=0.45 I^{stat}+0.55 I^{econ}$',ha='center',fontsize=11)
ax.set_title('Construction of the literature-backed economic AI relevance score',fontsize=15,weight='bold')
savefig(fpath('fig_01_score_architecture.png'))

# 2 channel weights
fig, ax=plt.subplots(figsize=(7.5,4.4))
wt=pd.Series(weights).rename(index={'compute':'Compute / chips','equipment':'Equipment','memory':'Memory / HBM','cloud':'Cloud / software','power':'Power / data center'})
ax.bar(wt.index, wt.values)
ax.set_ylabel('Weight')
ax.set_title('Proposed structural-channel weights')
ax.set_ylim(0,0.35)
ax.tick_params(axis='x',rotation=25)
savefig(fpath('fig_02_channel_weights.png'))

# 3 industry top scores
ind_plot=industries.sort_values('literature_industry_score',ascending=False).head(20).sort_values('literature_industry_score')
fig, ax=plt.subplots(figsize=(8.2,7.0))
ax.barh(ind_plot['client_industry_label'], ind_plot['literature_industry_score'])
ax.set_xlabel('Literature-backed industry structural score')
ax.set_title('Highest structural AI relevance by industry bucket')
savefig(fpath('fig_03_top_industry_scores.png'))

# 4 industry channel heatmap top 20
ind_heat=industries.sort_values('literature_industry_score',ascending=False).head(20).copy()
mat=ind_heat[['compute','equipment','memory','cloud','power']].values
fig, ax=plt.subplots(figsize=(8.2,7.2))
im=ax.imshow(mat, aspect='auto')
ax.set_yticks(np.arange(len(ind_heat))); ax.set_yticklabels(ind_heat['client_industry_label'], fontsize=8)
ax.set_xticks(np.arange(5)); ax.set_xticklabels(['Compute','Equipment','Memory','Cloud','Power'], rotation=25)
ax.set_title('Evidence-channel composition of top industry scores')
for i in range(mat.shape[0]):
    for j in range(mat.shape[1]):
        ax.text(j,i,f'{mat[i,j]:.2f}',ha='center',va='center',fontsize=6)
plt.colorbar(im, ax=ax, shrink=0.8, label='Channel score')
savefig(fpath('fig_04_industry_channel_heatmap.png'))

# 5 country scores
cty_plot=countries.sort_values('literature_country_score',ascending=False).head(18).sort_values('literature_country_score')
fig, ax=plt.subplots(figsize=(8.1,6.0))
ax.barh(cty_plot['country_bucket'], cty_plot['literature_country_score'])
ax.set_xlabel('Literature-backed country structural score')
ax.set_title('Country / region score reflects AI supply-chain concentration')
savefig(fpath('fig_05_country_scores.png'))

# 6 distribution of stat vs literature vs old econ
fig, ax=plt.subplots(figsize=(8.4,5.0))
for col,label in [(stat_col,'Regression/statistical score'),(new_econ,'Literature-backed econ prior'),(old_econ,'Previous econ prior')]:
    ax.hist(cell_new[col].dropna(), bins=35, alpha=0.45, label=label)
ax.set_xlabel('AI relevance / intensity score')
ax.set_ylabel('Number of country-industry cells')
ax.set_title('Distribution: regression result vs structural prior')
ax.legend(fontsize=8)
savefig(fpath('fig_06_distribution_scores.png'))

# 7 scatter regression vs literature with line
plot=cell_new[[new_econ,stat_col,'country_bucket','client_industry_label']].dropna().copy()
fig, ax=plt.subplots(figsize=(7.4,5.6))
ax.scatter(plot[new_econ], plot[stat_col], s=11, alpha=0.55)
xx=np.linspace(plot[new_econ].min(),plot[new_econ].max(),100)
ax.plot(xx, intc+slope*xx, linewidth=1.8, label=f'OLS: stat = {intc:.2f} + {slope:.2f} struct, R2={r2:.2f}')
ax.axvline(struct_threshold, linestyle='--', linewidth=1)
ax.axhline(stat_threshold, linestyle='--', linewidth=1)
ax.set_xlabel('Literature-backed structural score $I^{econ}$')
ax.set_ylabel('Regression-derived statistical score $I^{stat}$')
ax.set_title('External structural prior versus regression result')
ax.legend(fontsize=8)
savefig(fpath('fig_07_scatter_structural_vs_stat.png'))

# 8 binned validation
fig, ax=plt.subplots(figsize=(8.2,4.8))
ax.plot(bin_stats['structural_score_decile'], bin_stats['mean_regression_stat'], marker='o', label='Mean regression score')
ax.plot(bin_stats['structural_score_decile'], bin_stats['median_regression_stat'], marker='o', label='Median regression score')
ax.set_xlabel('Decile of literature-backed structural score')
ax.set_ylabel('Regression-derived score')
ax.set_title('Regression evidence rises with structural-score decile')
ax.legend(fontsize=8)
savefig(fpath('fig_08_binned_validation.png'))

# 9 quadrant counts
q_order=['high structural / high regression','high structural / low regression','low structural / high regression','low structural / low regression']
quad_plot=quad.set_index('quadrant').reindex(q_order).fillna(0).reset_index()
fig, ax=plt.subplots(figsize=(8.0,4.8))
ax.barh(quad_plot['quadrant'], quad_plot['count'])
ax.set_xlabel('Number of cells')
ax.set_title('Interpreting agreement and disagreement with regression')
savefig(fpath('fig_09_quadrant_counts.png'))

# 10 top structural - stat gaps
gap=cell_new.sort_values('structural_minus_stat',ascending=False).head(20).copy()
gap['label']=gap['country_bucket']+' / '+gap['client_industry_label']
gap=gap.sort_values('structural_minus_stat')
fig, ax=plt.subplots(figsize=(8.5,7.0))
ax.barh(gap['label'], gap['structural_minus_stat'])
ax.set_xlabel('Literature score minus regression score')
ax.set_title('Where literature suggests exposure the regression may understate')
savefig(fpath('fig_10_structural_minus_regression.png'))

# 11 old vs new econ scatter
fig, ax=plt.subplots(figsize=(7.5,5.5))
ax.scatter(cell_new[old_econ], cell_new[new_econ], s=11, alpha=0.55)
lims=[0,max(cell_new[old_econ].max(),cell_new[new_econ].max())]
ax.plot(lims,lims,linestyle='--',linewidth=1)
ax.set_xlabel('Previous economic prior')
ax.set_ylabel('Literature-backed economic prior')
ax.set_title(f'Previous prior versus literature-backed prior (Pearson {p_old_new:.2f})')
savefig(fpath('fig_11_old_vs_new_prior.png'))

# 12 final blended distribution
fig, ax=plt.subplots(figsize=(8.2,4.8))
ax.hist(cell_new[final_old].dropna(), bins=35, alpha=0.5, label='Current final AI intensity')
ax.hist(cell_new[final_new].dropna(), bins=35, alpha=0.5, label='Proposed final AI intensity')
ax.set_xlabel('Final blended AI intensity')
ax.set_ylabel('Number of cells')
ax.set_title('Distribution of final AI intensity after replacing the structural prior')
ax.legend(fontsize=8)
savefig(fpath('fig_12_final_blended_distribution.png'))

# 13 stress impact distribution 2m worst
fig, ax=plt.subplots(figsize=(8.2,4.8))
ax.hist(cell_new['worst_2m_stress_delta_pct'].dropna(), bins=40)
ax.axvline(0, linestyle='--', linewidth=1)
ax.set_xlabel('New prior stress minus old prior stress, pct points')
ax.set_ylabel('Number of cells')
ax.set_title('2m worst-case stress impact of literature-backed prior')
savefig(fpath('fig_13_stress_impact_distribution.png'))

# 14 selected heatmap countries x industries
sel_countries=['United States','Taiwan','Korea','Netherlands','Japan','China','Germany','India']
sel_industries=['technology hardware & storage &peripheral','communication equipment','electrical equipment','electronic equipment & instrument','IT services','interactive media &services','independent power & renewables','electric utilities','banks','food products']
heat=cell_new[cell_new['country_bucket'].isin(sel_countries)&cell_new['client_industry_label'].isin(sel_industries)]
heat=heat.pivot_table(index='client_industry_label',columns='country_bucket',values=new_econ,aggfunc='mean').reindex(sel_industries)[sel_countries]
fig, ax=plt.subplots(figsize=(10.0,6.4))
im=ax.imshow(heat.values, aspect='auto')
ax.set_xticks(np.arange(len(sel_countries))); ax.set_xticklabels(sel_countries,rotation=35,ha='right',fontsize=8)
ax.set_yticks(np.arange(len(sel_industries))); ax.set_yticklabels(sel_industries,fontsize=8)
ax.set_title('Example literature-backed country-industry structural scores')
for i in range(heat.shape[0]):
    for j in range(heat.shape[1]):
        val=heat.values[i,j]
        if np.isfinite(val): ax.text(j,i,f'{val:.2f}',ha='center',va='center',fontsize=7)
plt.colorbar(im, ax=ax, shrink=0.8, label='Structural score')
savefig(fpath('fig_14_cell_heatmap.png'))

# 15 stress old/new scatter
fig, ax=plt.subplots(figsize=(7.4,5.6))
ax.scatter(cell_new['worst_2m_stress_old_econ_pct'],cell_new['worst_2m_stress_new_econ_pct'],s=10,alpha=0.55)
mn=min(cell_new['worst_2m_stress_old_econ_pct'].min(),cell_new['worst_2m_stress_new_econ_pct'].min())
mx=max(cell_new['worst_2m_stress_old_econ_pct'].max(),cell_new['worst_2m_stress_new_econ_pct'].max())
ax.plot([mn,mx],[mn,mx],linestyle='--',linewidth=1)
ax.set_xlabel('2m worst stress using previous final intensity (%)')
ax.set_ylabel('2m worst stress using proposed final intensity (%)')
ax.set_title('Stress-vector effect of proposed economic prior')
savefig(fpath('fig_15_stress_old_vs_new.png'))

# ---------------- LaTeX report ----------------
# helper tables
source_rows=[]
for _,r in source_table.iterrows():
    source_rows.append(f"{r['channel']} & {r['weight']:.2f} & {r['examples']} \\")

top_ind_rows=[]
for _,r in industries.sort_values('literature_industry_score',ascending=False).head(12).iterrows():
    top_ind_rows.append(f"{str(r['client_industry_label']).replace('&','\\&')} & {r['literature_industry_score']:.2f} & {r['industry_score_rationale'].replace('&','\\&')} \\")

top_cty_rows=[]
for _,r in countries.sort_values('literature_country_score',ascending=False).head(12).iterrows():
    top_cty_rows.append(f"{str(r['country_bucket']).replace('&','\\&')} & {r['literature_country_score']:.2f} & {r['country_score_rationale'].replace('&','\\&')} \\")

quad_rows=[]
for _,r in quad_plot.iterrows():
    quad_rows.append(f"{r['quadrant'].replace('&','\\&')} & {int(r['count'])} \\")

# top revisions
rev=cell_new[['country_bucket','client_industry_label','cell_economic_ai_intensity','literature_cell_score','new_minus_old_econ']].dropna().copy()
rev=rev.sort_values('new_minus_old_econ',ascending=False).head(10)
rev_rows=[]
for _,r in rev.iterrows():
    rev_rows.append(f"{r['country_bucket'].replace('&','\\&')} / {r['client_industry_label'].replace('&','\\&')} & {r['cell_economic_ai_intensity']:.2f} & {r['literature_cell_score']:.2f} & {r['new_minus_old_econ']:.2f} \\")

tex=BASE/'ai_econ_score_literature_research_report.tex'
pdf=BASE/'ai_econ_score_literature_research_report.pdf'

# citation references in report, with URLs visible in text; final answer will cite via web tool.
latex=rf'''
\documentclass[11pt]{{article}}
\usepackage{{graphicx}}
\usepackage{{amsmath}}
\usepackage{{array}}
\setlength{{\parindent}}{{0pt}}
\setlength{{\parskip}}{{0.55em}}
\begin{{document}}

\title{{Literature-Backed Construction and Validation of the Economic AI Relevance Score}}
\author{{AI Unwind Stress Framework - Methodology Appendix}}
\date{{July 2026}}
\maketitle

\section*{{Executive summary}}
This note rebuilds the economic AI relevance score as a literature-backed structural prior. The goal is not to pretend that external sources provide a single observable variable called AI economic exposure. They do not. The defensible construction is instead to define a transparent scoring rubric, anchor each channel in the literature and industry evidence, and then test whether the resulting structural prior is directionally consistent with the regression-derived AI-excess score.

The proposed score uses five channels: compute and advanced chips, semiconductor equipment, memory and HBM, cloud/software adoption, and power/data-center infrastructure. The resulting cell-level score is
\[
I^{{econ}}_{{b,g}}=0.65 I^{{struct}}_g + 0.35 I^{{struct}}_b,
\]
where $I^{{struct}}_g$ is the industry structural score and $I^{{struct}}_b$ is the country/region structural score. The final model can then keep the same production blend:
\[
I^{{AI}}_{{b,g}}=0.45 I^{{stat}}_{{b,g}}+0.55 I^{{econ}}_{{b,g}}.
\]

The empirical validation is intentionally modest but useful. Across the existing country-industry universe, the Pearson correlation between the literature-backed prior and the regression-derived statistical score is {p_econ_stat:.2f}; the Spearman rank correlation is {s_econ_stat:.2f}; and the cross-sectional regression of the statistical score on the structural prior has an $R^2$ of {r2:.2f}. That is enough to show that the literature prior is not arbitrary, while also preserving the important role of the regression layer.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.96\textwidth]{{{(OUT/'fig_01_score_architecture.png').as_posix()}}}
\caption{{Score construction. The literature score is not a replacement for the regression. It is a transparent structural prior that is blended with the regression-derived AI-excess estimate.}}
\end{{figure}}

\clearpage
\section{{Why a structural prior is needed}}
The return regression is the empirical anchor of the model, but it has known limits. It only sees what has already appeared in market returns. It can be noisy for shorter histories, countries with imperfect proxies, and industries where the AI link is structural but not yet fully repriced. A purely regression-based score would therefore understate exposure in areas where the economic mechanism is clear but historical price data is incomplete.

The structural score solves a different problem. It asks: based on the external literature and observed AI supply chain, which industries and countries are economically connected to the AI capex and adoption cycle? This makes the prior forward-looking, auditable, and explainable.

\section{{Literature-backed channels}}
The channel design follows directly from the external literature and market evidence. LLMs are treated as a general-purpose technology that diffuses through software and tooling. AI infrastructure depends on advanced chips, manufacturing equipment, HBM and memory bandwidth, hyperscaler/cloud deployment, and data-center power infrastructure. These are the channels the model scores.

\begin{{center}}
\small
\begin{{tabular}}{{p{{3.0cm}}p{{1.2cm}}p{{8.0cm}}}}
Channel & Weight & Example exposures \\
\hline
{chr(10).join(source_rows)}
\hline
\end{{tabular}}
\end{{center}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.78\textwidth]{{{(OUT/'fig_02_channel_weights.png').as_posix()}}}
\caption{{Proposed channel weights. Compute receives the largest single weight because advanced compute sits at the center of the AI infrastructure stack. Equipment, cloud/software, memory, and power/data-center channels are then added to capture the full supply chain.}}
\end{{figure}}

\section{{Industry score construction}}
For each industry $g$, assign five channel scores between zero and one:
\[
C_g^{{compute}}, C_g^{{equipment}}, C_g^{{memory}}, C_g^{{cloud}}, C_g^{{power}}.
\]
Then compute
\[
I^{{struct}}_g = 0.30 C_g^{{compute}} + 0.20 C_g^{{equipment}} + 0.15 C_g^{{memory}} + 0.20 C_g^{{cloud}} + 0.15 C_g^{{power}}.
\]

This is deliberately simple. It turns qualitative literature evidence into a reproducible score. The score is highest when an industry has direct AI-infrastructure linkage and lower when the linkage is only through general AI adoption.

\begin{{center}}
\small
\begin{{tabular}}{{p{{5.0cm}}p{{1.0cm}}p{{7.0cm}}}}
Industry bucket & Score & Rationale \\
\hline
{chr(10).join(top_ind_rows)}
\hline
\end{{tabular}}
\end{{center}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.88\textwidth]{{{(OUT/'fig_03_top_industry_scores.png').as_posix()}}}
\caption{{Highest industry scores under the literature-backed construction.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.90\textwidth]{{{(OUT/'fig_04_industry_channel_heatmap.png').as_posix()}}}
\caption{{Channel composition for the top industry scores. This is useful for management because it shows why a bucket receives a high score rather than just reporting the number.}}
\end{{figure}}

\clearpage
\section{{Country and regional score construction}}
Country scores capture supply-chain concentration and regional AI infrastructure exposure. For example, Taiwan receives a high score because it sits at the advanced foundry and packaging center of the AI hardware supply chain. Korea receives a high score because memory and HBM are critical AI infrastructure bottlenecks. The Netherlands receives a high score through lithography and semiconductor-equipment concentration. The United States receives a high score through hyperscalers, software platforms, chip designers, and data-center capex.

\begin{{center}}
\small
\begin{{tabular}}{{p{{4.0cm}}p{{1.0cm}}p{{7.5cm}}}}
Country / region & Score & Rationale \\
\hline
{chr(10).join(top_cty_rows)}
\hline
\end{{tabular}}
\end{{center}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.88\textwidth]{{{(OUT/'fig_05_country_scores.png').as_posix()}}}
\caption{{Country/region scores reflect supply-chain concentration rather than generic market beta.}}
\end{{figure}}

\section{{Cell-level score}}
The industry score is more important than the country score because the business model determines the primary exposure. The country still matters because AI supply chains are geographically concentrated. The cell score is therefore
\[
I^{{econ}}_{{b,g}}=0.65 I^{{struct}}_g + 0.35 I^{{struct}}_b.
\]
This rule means that Taiwan banks do not automatically become AI epicenter exposures simply because Taiwan is important to AI hardware; conversely, technology hardware in a less central country still receives a meaningful score because the industry itself is exposed.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.96\textwidth]{{{(OUT/'fig_14_cell_heatmap.png').as_posix()}}}
\caption{{Example country-industry scores. High scores appear when both the country and the industry are structurally close to the AI infrastructure stack.}}
\end{{figure}}

\clearpage
\section{{Validation against the regression-derived score}}
The literature score should not be expected to perfectly match the regression score. They are measuring different things. The regression score is backward-looking market evidence; the literature prior is forward-looking structural exposure. Still, the two should be directionally related. If the literature score had no relation to the regression score, that would be a warning sign.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.86\textwidth]{{{(OUT/'fig_06_distribution_scores.png').as_posix()}}}
\caption{{Distributional comparison. The regression score is more compressed because many sectors have little measured residual AI beta; the structural prior is intentionally more graded across the supply chain.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.82\textwidth]{{{(OUT/'fig_07_scatter_structural_vs_stat.png').as_posix()}}}
\caption{{Structural prior versus regression-derived statistical score. The positive slope supports the ranking logic, while the dispersion shows why both layers are useful.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.82\textwidth]{{{(OUT/'fig_08_binned_validation.png').as_posix()}}}
\caption{{Binned validation. Moving from low to high structural-score deciles generally increases the regression-derived AI-excess score.}}
\end{{figure}}

\section{{How to interpret disagreement with the regression}}
Disagreement is not necessarily a failure. There are four cases:
\begin{{itemize}}
\item High structural / high regression: strongest evidence. Both the literature and market returns support high AI exposure.
\item High structural / low regression: forward-looking or underpriced exposure. This is common in power, electrical equipment, and some infrastructure-adjacent buckets.
\item Low structural / high regression: possible noisy co-movement or cyclical beta not fully removed by the regression.
\item Low structural / low regression: low-priority AI exposure.
\end{{itemize}}

\begin{{center}}
\small
\begin{{tabular}}{{lr}}
Quadrant & Count \\
\hline
{chr(10).join(quad_rows)}
\hline
\end{{tabular}}
\end{{center}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.82\textwidth]{{{(OUT/'fig_09_quadrant_counts.png').as_posix()}}}
\caption{{Agreement and disagreement between literature prior and regression result.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.90\textwidth]{{{(OUT/'fig_10_structural_minus_regression.png').as_posix()}}}
\caption{{Where the literature-backed prior is materially above the regression score. These are the areas where the structural story says the return history may understate forward-looking AI exposure.}}
\end{{figure}}

\clearpage
\section{{Comparison with the previous economic prior}}
The literature-backed score is not a radical break from the previous prior. The Pearson correlation between the previous economic prior and the proposed literature-backed prior is {p_old_new:.2f}; the Spearman rank correlation is {s_old_new:.2f}. The new version is better because every high score is attached to an explicit evidence channel and source-backed rationale.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.82\textwidth]{{{(OUT/'fig_11_old_vs_new_prior.png').as_posix()}}}
\caption{{Previous prior versus literature-backed prior. The diagonal line represents no change.}}
\end{{figure}}

Largest upward changes:
\begin{{center}}
\small
\begin{{tabular}}{{p{{7.5cm}}rrr}}
Cell & Old prior & New prior & Difference \\
\hline
{chr(10).join(rev_rows)}
\hline
\end{{tabular}}
\end{{center}}

\section{{Effect on final AI intensity and stress shocks}}
The final score can keep the same blend with the regression result:
\[
I^{{AI}}_{{b,g}}=0.45 I^{{stat}}_{{b,g}}+0.55 I^{{econ}}_{{b,g}}.
\]
This preserves the empirical anchor while giving the literature-backed prior enough weight to capture structural AI exposure that is not yet cleanly visible in returns.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.82\textwidth]{{{(OUT/'fig_12_final_blended_distribution.png').as_posix()}}}
\caption{{Final blended intensity under the current versus proposed structural prior.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.82\textwidth]{{{(OUT/'fig_13_stress_impact_distribution.png').as_posix()}}}
\caption{{Distribution of stress changes under the 2-month worst scenario. Negative values mean the proposed score makes the shock more severe; positive values mean the shock is less severe.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.82\textwidth]{{{(OUT/'fig_15_stress_old_vs_new.png').as_posix()}}}
\caption{{Old versus proposed 2-month worst stress. The diagonal represents no change.}}
\end{{figure}}

\section{{How to present this to senior management}}
The recommended language is:

\emph{{The economic AI relevance score is a literature-backed structural prior. It is not estimated from returns and it is not a black-box external variable. It is constructed from five externally supported exposure channels: compute and advanced chips, semiconductor equipment, memory/HBM, cloud/software adoption, and power/data-center infrastructure. The regression layer tells us what markets have already priced; the literature layer captures forward-looking structural exposure that may not yet be cleanly visible in historical returns.}}

The important caveat is that literature can justify the channels and ranking, but not the exact second decimal place of every score. The numeric score remains a model assumption, now made auditable through a transparent scoring rubric.

\section*{{References used for channel design}}
\begin{{enumerate}}
\item Eloundou, Manning, Mishkin, and Rock, \emph{{GPTs are GPTs: An Early Look at the Labor Market Impact Potential of Large Language Models}}, 2023.
\item Stanford Institute for Human-Centered AI, \emph{{AI Index Report 2025}} and \emph{{AI Index Report 2026}}.
\item IEA and LBNL evidence on data-center electricity demand and AI-related load growth; LBNL, \emph{{2024 United States Data Center Energy Usage Report}}.
\item Chen, Wang, Colacelli, Lee, and Xie, \emph{{Electricity Demand and Grid Impacts of AI Data Centers: Challenges and Prospects}}, 2025.
\item Chen et al., \emph{{Concentrated siting of AI data centers drives regional power-system stress under rising global compute demand}}, 2026.
\item ASML-related evidence on EUV lithography and AI chipmaking demand.
\item TSMC-related evidence on AI-chip manufacturing, advanced nodes and advanced packaging.
\item HBM and AI-infrastructure memory literature, including research on HBM cost/bandwidth constraints for AI workloads.
\end{{enumerate}}

\end{{document}}
'''
tex.write_text(latex)

# compile
os.chdir(BASE)
os.system(f'pdflatex -interaction=nonstopmode {tex.name} > /tmp/ai_econ_score_report.log 2>&1')
os.system(f'pdflatex -interaction=nonstopmode {tex.name} >> /tmp/ai_econ_score_report.log 2>&1')

# copy files to bundle dir
bundle_files=[pdf,tex,industry_csv,country_csv,cell_csv,source_csv,bin_csv,quad_csv,stress_csv,BASE/'build_ai_econ_score_research.py']+figs
for fp in bundle_files:
    fp=Path(fp)
    if fp.exists():
        dst=OUT/fp.name
        if fp.resolve()!=dst.resolve():
            shutil.copy2(fp,dst)

zip_path=BASE/'ai_econ_score_literature_research_bundle.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for fp in OUT.iterdir():
        z.write(fp,arcname=fp.name)

print('Created',pdf,pdf.exists())
print('Created',zip_path,zip_path.exists(),zip_path.stat().st_size/1024/1024 if zip_path.exists() else None)
print('stats',p_econ_stat,s_econ_stat,r2,p_old_new,s_old_new)
