"""Ticker-level precision overrides using the same market + AI-excess model."""
from __future__ import annotations
from typing import Mapping
import numpy as np
import pandas as pd

from return_estimation import month_end_log_returns
from orthogonalization import ols_slope, orthogonalize_ai
from ai_exposure import stock_ai_intensity


def build_ai_factor(component_prices: Mapping[str, pd.Series], world_price: pd.Series):
    """Aligned monthly world and equal-weight thematic basket returns."""
    world = month_end_log_returns(world_price).rename("world")
    components = [month_end_log_returns(p).rename(name) for name, p in component_prices.items()]
    if not components:
        raise ValueError("at least one AI thematic component is required")
    comp = pd.concat(components, axis=1).dropna()
    ai = comp.mean(axis=1).rename("ai")
    factors = pd.concat([world, ai], axis=1).dropna()
    theta_world_ai, intercept, residual = orthogonalize_ai(factors["ai"], factors["world"])
    factors["ai_residual"] = residual
    return factors, theta_world_ai


def estimate_stock_override(ticker, stock_price, factors, theta_world_ai, economic_ai_intensity):
    stock = month_end_log_returns(stock_price).rename("stock")
    d = pd.concat([stock, factors[["world", "ai", "ai_residual"]]], axis=1).dropna()
    beta_world = ols_slope(d["stock"], d["world"])
    theta_abs = ols_slope(d["stock"], d["ai"])
    residual_beta = ols_slope(d["stock"], d["ai_residual"])
    intensity = stock_ai_intensity(beta_world, theta_abs, theta_world_ai, economic_ai_intensity)
    return {
        "ticker": ticker,
        "beta_world_stock": beta_world,
        "theta_ai_abs_stock": theta_abs,
        "theta_ai_abs_world_reference": theta_world_ai,
        "residual_ai_beta_diagnostic": residual_beta,
        "n_months": len(d),
        **intensity,
    }


def apply_scenarios(stock_table: pd.DataFrame, scenario_table: pd.DataFrame):
    """Materialize scenario returns; ticker rows replace generic rows downstream."""
    out = stock_table.copy()
    for _, sc in scenario_table.iterrows():
        s = str(sc["scenario"])
        lr = (
            out["beta_world_stock"].astype(float) * float(sc["S_WORLD_log"])
            + out["final_ai_excess_intensity"].astype(float) * float(sc["S_AI_EXCESS_log"])
        )
        out[f"{s}_stress_log"] = lr
        out[f"{s}_stress_simple"] = np.exp(lr) - 1.0
        out[f"{s}_stress_pct"] = 100.0 * out[f"{s}_stress_simple"]
    return out
