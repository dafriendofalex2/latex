# Data dictionary

- exposure_multipliers.csv: regression diagnostics, economic overlay, and final AI stress multipliers.
- stress_vector_ai_stocks_total_return.csv: mild/base/severe total projected returns by AI stock over 24 months.
- spy_ai_weights.csv: covered AI weights in SPY holdings, with GOOG proxied by GOOGL.
- base_spy_contributions.csv: base case weight-times-return contributions to SPY.
- projected_ai_basket_paths.csv: normalized projected AI basket path by scenario.
- projected_spy_paths.csv: normalized projected SPY weighted path by scenario.
- projected_nasdaq_paths.csv: normalized projected NASDAQ proxy path by scenario.
- historical_signal_future_drawdown_sample.csv: sample of FF49 historical signal and future drawdown observations.
- omitted_candidate_ai_weights.csv: visible SPY weights for candidate AI/AI-adjacent names not fully covered.
