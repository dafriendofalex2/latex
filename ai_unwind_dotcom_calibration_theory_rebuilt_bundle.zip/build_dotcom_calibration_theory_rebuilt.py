import os, math, shutil, zipfile, textwrap
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch

BASE = Path('/mnt/data')
OUT = BASE/'ai_unwind_dotcom_calibration_theory_rebuilt_bundle'
OUT.mkdir(exist_ok=True)
plt.rcParams['figure.dpi'] = 180
plt.rcParams['font.size'] = 10

# ---------------- Helpers ----------------
def parse_ff49_daily(path):
    lines = Path(path).read_text(encoding='latin1').splitlines()
    start=None
    for i,l in enumerate(lines):
        if 'Average Value Weighted Returns -- Daily' in l:
            start=i+1; break
    header=[h.strip() for h in lines[start].split(',')]
    rows=[]
    for l in lines[start+1:]:
        if not l.strip(): break
        parts=[p.strip() for p in l.split(',')]
        if len(parts)==len(header): rows.append(parts)
    df=pd.DataFrame(rows, columns=header)
    df.rename(columns={df.columns[0]:'date'}, inplace=True)
    df['date']=pd.to_datetime(df['date'], format='%Y%m%d')
    for c in df.columns[1:]:
        df[c]=pd.to_numeric(df[c], errors='coerce')/100.0
    df=df.replace({-0.9999: np.nan, -9.99: np.nan})
    return df

def load_spx(path):
    df=pd.read_csv(path)
    df['date']=pd.to_datetime(df['date'], format='%d-%b-%y')
    df['close']=pd.to_numeric(df['close'], errors='coerce')
    return df[['date','close']].dropna().sort_values('date')

def savefig(name):
    p=OUT/name
    plt.tight_layout()
    plt.savefig(p, bbox_inches='tight')
    plt.close()
    return p

def pct(x): return 100*(np.exp(x)-1)

# ---------------- Data ----------------
sc = pd.read_csv(BASE/'ai_unwind_v5_revised_kappa_short_horizon_scenario_parameters.csv')
val = pd.read_csv(BASE/'valuation_severity_calibration_summary(1).csv')
ci = pd.read_csv(BASE/'country_industry_stress_vector_v5(1).csv')
ss = pd.read_csv(BASE/'single_stock_override_vector_v5_all20.csv')

kappa_base = float(val.loc[val['parameter']=='base_valuation_severity_scalar_kappa','value'].iloc[0])
dotcom_premium = float(val.loc[val['parameter']=='dotcom_reference_premium_log','value'].iloc[0])
current_forward = float(val.loc[val['parameter']=='current_forward_premium_log','value'].iloc[0])
current_current = float(val.loc[val['parameter']=='current_current_premium_log','value'].iloc[0])
current_trailing = float(val.loc[val['parameter']=='current_trailing_premium_log','value'].iloc[0])
current_blended = float(val.loc[val['parameter']=='current_blended_premium_log','value'].iloc[0])

ff = parse_ff49_daily(BASE/'49_Industry_Portfolios_Daily.csv')
ff = ff[(ff['date'] >= '1998-01-01') & (ff['date'] <= '2001-12-31')].copy()
ff['tmt_ret'] = ff[['Hardw','Softw','Chips','Telcm']].mean(axis=1)
ff['tmt_index'] = (1+ff['tmt_ret']).cumprod()
spx = load_spx(BASE/'spx.csv')
spx = spx[(spx['date'] >= '1998-01-01') & (spx['date'] <= '2001-12-31')].copy()
spx['spx_index'] = spx['close']/spx['close'].iloc[0]
peak_date = pd.to_datetime(sc['peak_date'].iloc[0])

# selected scenario/horizon orders
h_order=['1w','2w','1m','2m']
s_order=['mild','base','severe','extreme','worst']
sc['horizon'] = pd.Categorical(sc['horizon'], h_order, ordered=True)
sc['scenario'] = pd.Categorical(sc['scenario'], s_order, ordered=True)
sc = sc.sort_values(['horizon','scenario'])

# ---------------- Figures ----------------
figs=[]
# 1 calibration workflow with formulas
fig, ax = plt.subplots(figsize=(11.6,5.4))
ax.axis('off'); ax.set_xlim(0,12); ax.set_ylim(0,5)
boxes=[
    (0.3,2.1,2.0,1.0,'1. Dot-com\nprice paths'),
    (2.8,2.1,2.1,1.0,'2. Raw shocks\n$S_W^h, S_E^h$'),
    (5.3,2.1,2.1,1.0,'3. Excess shock\n$S_X^h=S_E^h-S_W^h$'),
    (7.8,3.1,2.0,0.9,'4. Valuation\n$\\kappa_{base}$'),
    (7.8,1.1,2.0,0.9,'5. Scenario\n$\\kappa_s,\\alpha_s$'),
    (10.1,2.1,1.7,1.0,'6. Final factor\nshock')
]
for x,y,w,h,t in boxes:
    ax.add_patch(Rectangle((x,y),w,h,fill=False,linewidth=1.5))
    ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=12)
for a,b,c,d in [(2.3,2.6,2.8,2.6),(4.9,2.6,5.3,2.6),(7.4,2.6,7.8,3.55),(7.4,2.6,7.8,1.55),(9.8,3.55,10.1,2.6),(9.8,1.55,10.1,2.6)]:
    ax.add_patch(FancyArrowPatch((a,b),(c,d),arrowstyle='->',mutation_scale=13,linewidth=1.3))
ax.text(6,4.55,'Dot-com calibration is a transformation, not a lookup table',ha='center',fontsize=16,weight='bold')
ax.text(6,4.15,'Raw dot-com market and TMT moves are decomposed first; valuation and scenario assumptions scale only the AI/TMT-excess leg.',ha='center',fontsize=10.5)
figs.append(savefig('fig_01_calibration_workflow.png'))

# 2 price paths around peak
fig, ax = plt.subplots(figsize=(9,5.4))
ff_plot=ff[(ff['date']>=pd.Timestamp('1999-01-01'))&(ff['date']<=pd.Timestamp('2000-09-30'))].copy()
spx_plot=spx[(spx['date']>=pd.Timestamp('1999-01-01'))&(spx['date']<=pd.Timestamp('2000-09-30'))].copy()
# normalize at peak approximately align
ff_peak_val=float(ff.loc[ff['date']==peak_date,'tmt_index'].iloc[0])
spx_peak_val=float(spx.loc[spx['date']==peak_date,'spx_index'].iloc[0])
ax.plot(ff_plot['date'],100*ff_plot['tmt_index']/ff_peak_val,label='TMT epicenter proxy, peak=100')
ax.plot(spx_plot['date'],100*spx_plot['spx_index']/spx_peak_val,label='S&P 500 broad market, peak-date=100')
ax.axvline(peak_date,linestyle='--',linewidth=1)
ax.set_title('Raw dot-com inputs: broad market versus TMT epicenter')
ax.set_ylabel('Index level, normalized at 2000-03-27')
ax.legend(fontsize=9)
figs.append(savefig('fig_02_raw_paths.png'))

# 3 horizon marker chart
fig, ax = plt.subplots(figsize=(9,5.2))
post_ff=ff[ff['date']>=peak_date].copy().head(65)
post_spx=spx[spx['date']>=peak_date].copy().head(65)
post_ff['day']=range(len(post_ff)); post_spx['day']=range(len(post_spx))
ax.plot(post_ff['day'],100*post_ff['tmt_index']/post_ff['tmt_index'].iloc[0],label='TMT epicenter proxy')
ax.plot(post_spx['day'],100*post_spx['spx_index']/post_spx['spx_index'].iloc[0],label='S&P 500')
for _,r in sc.drop_duplicates('horizon').iterrows():
    d=int(r['horizon_trading_days']); ax.axvline(d,linestyle=':',linewidth=1)
    ax.text(d, ax.get_ylim()[0]+1, str(r['horizon']), ha='center', va='bottom', fontsize=9)
ax.set_title('Horizon anchors: 1w, 2w, 1m, 2m after the TMT peak')
ax.set_xlabel('Trading days after 2000-03-27')
ax.set_ylabel('Index level, peak=100')
ax.legend(fontsize=9)
figs.append(savefig('fig_03_horizon_anchors.png'))

# 4 raw decomposition table/stack by horizon
raw = sc.drop_duplicates('horizon').set_index('horizon').loc[h_order]
fig, ax = plt.subplots(figsize=(9,5.0))
x=np.arange(len(h_order)); width=0.6
w = raw['S_WORLD_raw_dotcom_log'].values*100
xex = raw['S_AI_EXCESS_raw_dotcom_log'].values*100
ax.bar(x,w,width,label='$S_W^h$ broad-market log shock')
ax.bar(x,xex,width,bottom=w,label='$S_X^h$ AI/TMT-excess log shock')
ax.set_xticks(x); ax.set_xticklabels(h_order)
ax.set_ylabel('Log shock contribution, percent log points')
ax.set_title('Raw dot-com decomposition: TMT loss = market loss + excess TMT loss')
ax.legend(fontsize=9)
figs.append(savefig('fig_04_raw_decomposition.png'))

# 5 valuation kappa calculation
fig, ax = plt.subplots(figsize=(8.8,5.0))
labels=['Dot-com\nreference premium','Current\nforward premium','Current\ncurrent premium','Current\ntrailing premium','Current\nblended premium']
vals=[dotcom_premium,current_forward,current_current,current_trailing,current_blended]
ax.bar(np.arange(len(vals)), vals)
ax.axhline(dotcom_premium,linestyle='--',linewidth=1)
ax.set_xticks(np.arange(len(vals))); ax.set_xticklabels(labels,fontsize=9)
ax.set_ylabel('Log valuation premium')
ax.set_title(r'Base severity: $\kappa_{base} =$ current blended premium / dot-com premium')
ax.text(3.3, max(vals)*0.82, rf'$\kappa_{{base}}={current_blended:.3f}/{dotcom_premium:.3f}={kappa_base:.3f}$', fontsize=13)
figs.append(savefig('fig_05_kappa_calculation.png'))

# 6 scenario kappa ladder
ladder = pd.DataFrame({'scenario':s_order,'alpha':[0.5,1,1,1,1], 'kappa':[0.5*kappa_base,kappa_base,1,1.5,2.0]})
fig, ax = plt.subplots(figsize=(8.4,4.8))
xx=np.arange(len(ladder)); wid=0.36
ax.bar(xx-wid/2, ladder['alpha'], wid, label=r'Broad-market scale $\alpha_s$')
ax.bar(xx+wid/2, ladder['kappa'], wid, label=r'AI/TMT-excess scale $\kappa_s$')
ax.set_xticks(xx); ax.set_xticklabels(s_order)
ax.set_ylabel('Multiplier')
ax.set_title('Scenario mechanics: market scale and excess-AI scale are separate')
ax.legend(fontsize=9)
figs.append(savefig('fig_06_kappa_ladder.png'))

# 7 equation surface for 2m: stress vs kappa for AI intensity values
raw_2m = raw.loc['2m']
kappas=np.linspace(0,2.2,100)
fig, ax = plt.subplots(figsize=(8.8,5.1))
for I in [0,0.25,0.5,0.75,1.0,1.25]:
    R = 1.0*raw_2m['S_WORLD_raw_dotcom_log'] + I*kappas*raw_2m['S_AI_EXCESS_raw_dotcom_log']
    ax.plot(kappas, 100*(np.exp(R)-1), label=f'I={I:.2f}')
for k in [kappa_base,1,1.5,2]: ax.axvline(k, linestyle=':', linewidth=0.8)
ax.set_title('How kappa enters the stress formula: 2m horizon, beta=1')
ax.set_xlabel(r'AI/TMT-excess severity $\kappa_s$')
ax.set_ylabel('Final simple shock (%)')
ax.legend(ncol=3,fontsize=8)
figs.append(savefig('fig_07_kappa_sensitivity_by_intensity.png'))

# 8 heatmap horizon/scenario epicenter shocks
heat = sc.pivot(index='horizon',columns='scenario',values='S_AI_EPICENTER_pct').loc[h_order,s_order]
fig, ax = plt.subplots(figsize=(9,4.5))
im=ax.imshow(heat.values, aspect='auto')
ax.set_xticks(np.arange(len(s_order))); ax.set_xticklabels(s_order)
ax.set_yticks(np.arange(len(h_order))); ax.set_yticklabels(h_order)
for i in range(len(h_order)):
    for j in range(len(s_order)):
        ax.text(j,i,f'{heat.values[i,j]:.1f}%',ha='center',va='center',fontsize=9)
ax.set_title('AI epicenter shock generated by alpha and kappa')
plt.colorbar(im, ax=ax, label='Simple return shock (%)')
figs.append(savefig('fig_08_epicenter_heatmap.png'))

# 9 waterfall for 2m base/worst
for scenario in ['base','worst']:
    r = sc[(sc['horizon']=='2m')&(sc['scenario']==scenario)].iloc[0]
    fig, ax = plt.subplots(figsize=(8.2,4.8))
    comps=[r['S_WORLD_log']*100,r['S_AI_EXCESS_log']*100]
    ax.bar(['Broad market\n$\\alpha_s S_W$', 'AI/TMT excess\n$\\kappa_s S_X$'], comps)
    ax.axhline(0, color='black', linewidth=0.8)
    ax.set_ylabel('Log shock contribution, percent log points')
    ax.set_title(f'2m {scenario}: epicenter log shock is the sum of two scaled pieces')
    total=sum(comps)
    ax.text(0.5, min(comps)*0.75, f'Total log shock = {total:.1f} pp\nSimple shock = {r["S_AI_EPICENTER_pct"]:.1f}%', ha='center', fontsize=11)
    figs.append(savefig(f'fig_09_waterfall_2m_{scenario}.png'))

# 10 stress surface beta/I for 2m base
r = sc[(sc['horizon']=='2m')&(sc['scenario']=='base')].iloc[0]
beta_grid = np.linspace(0.6,1.6,81)
I_grid = np.linspace(0,1.25,81)
B,I = np.meshgrid(beta_grid, I_grid)
R = B*r['S_WORLD_log'] + I*r['S_AI_EXCESS_log']
Z=100*(np.exp(R)-1)
fig, ax = plt.subplots(figsize=(8.4,5.4))
cs=ax.contourf(B,I,Z,levels=18)
plt.colorbar(cs, ax=ax,label='2m base simple shock (%)')
ax.set_xlabel(r'World beta $\beta^W$')
ax.set_ylabel(r'AI intensity $I^{AI}$')
ax.set_title('After calibration: how factor shocks translate into row stress')
# annotate median cell maybe
ax.scatter([1.0],[kappa_base],marker='x',s=50,label='Illustrative beta=1, AI intensity=base kappa')
ax.legend(fontsize=8, loc='lower left')
figs.append(savefig('fig_10_stress_surface_2m_base.png'))

# 11 sample rows by construction (broad market, epicenter, sample cells/stocks)
# Build sample shocks manually for 2m scenarios maybe from index/etf sample file if exists
samples=[]
# beta/I pairs illustrative
pairs=[('Broad market: beta=1, I=0',1.0,0.0),('AI epicenter: beta=1, I=1',1.0,1.0),('High beta, low AI: beta=1.4, I=0.1',1.4,0.1),('Moderate beta, high AI: beta=1.1, I=0.8',1.1,0.8),('NVDA override',float(ss[ss['ticker']=='NVDA']['beta_world_stock'].iloc[0]),float(ss[ss['ticker']=='NVDA']['final_ai_excess_intensity'].iloc[0]))]
for name,beta,Iv in pairs:
    row={'name':name,'beta':beta,'I':Iv}
    for scen in s_order:
        rr=sc[(sc['horizon']=='2m')&(sc['scenario']==scen)].iloc[0]
        R=beta*rr['S_WORLD_log']+Iv*rr['S_AI_EXCESS_log']
        row[scen]=100*(np.exp(R)-1)
    samples.append(row)
sample_df=pd.DataFrame(samples)
sample_csv=BASE/'ai_unwind_dotcom_calibration_theory_sample_shocks.csv'
sample_df.to_csv(sample_csv,index=False)
fig, ax = plt.subplots(figsize=(10,5.0))
xx=np.arange(len(sample_df)); wid=0.16
for j,scen in enumerate(s_order):
    ax.bar(xx+(j-2)*wid, sample_df[scen], wid, label=scen)
ax.set_xticks(xx); ax.set_xticklabels(sample_df['name'], rotation=20, ha='right', fontsize=8)
ax.set_ylabel('2m simple shock (%)')
ax.set_title('Sample shocks: same calibrated factors, different beta and AI intensity')
ax.legend(ncol=5, fontsize=8)
figs.append(savefig('fig_11_sample_shocks.png'))

# 12 actual country-industry distribution by scenario/horizon from existing v5 revised kappa CI outputs, use 2m country-industry rows
ci2m = pd.read_csv(BASE/'ai_unwind_v5_2m_country_industry_revised_kappa_all_scenarios.csv')
# columns are scenario_stress_pct? inspect quick dynamically
cols=[c for c in ci2m.columns if c.endswith('_stress_pct')]
if cols:
    fig, ax = plt.subplots(figsize=(8.8,4.8))
    data=[ci2m[c].dropna().values for c in cols]
    labels=[c.replace('_stress_pct','') for c in cols]
    ax.boxplot(data, labels=labels, showfliers=False)
    ax.set_ylabel('Country-industry simple shock (%)')
    ax.set_title('Distribution of calibrated 2m shocks across the country-industry vector')
    figs.append(savefig('fig_12_distribution_by_scenario.png'))

# Export calibration table
calib = sc.copy()
calib.to_csv(BASE/'ai_unwind_dotcom_calibration_theory_rebuilt_table.csv', index=False)

# ---------------- LaTeX ----------------
def fig(name): return name

raw_rows=[]
for h in h_order:
    r=raw.loc[h]
    raw_rows.append(f"{h} & {int(r['horizon_trading_days'])} & {r['anchor_date']} & {r['S_WORLD_raw_dotcom_log']*100:.2f} & {r['S_AI_EXCESS_raw_dotcom_log']*100:.2f} & {r['S_AI_EPICENTER_raw_dotcom_log']*100:.2f} & {r['S_AI_EPICENTER_pct']:.2f} \\")
scenario_rows=[]
for s in s_order:
    a=float(ladder[ladder['scenario']==s]['alpha'].iloc[0]); k=float(ladder[ladder['scenario']==s]['kappa'].iloc[0])
    scenario_rows.append(f"{s} & {a:.3f} & {k:.3f} \\")

tex_path=BASE/'ai_unwind_dotcom_calibration_theory_rebuilt.tex'
pdf_path=BASE/'ai_unwind_dotcom_calibration_theory_rebuilt.pdf'
latex = rf'''
\documentclass[11pt]{{article}}
\usepackage{{graphicx}}
\usepackage{{amsmath}}
\usepackage{{array}}
\setlength{{\parindent}}{{0pt}}
\setlength{{\parskip}}{{0.65em}}
\begin{{document}}

\title{{Dot-Com Calibration Mechanics for the AI Unwind Framework}}
\author{{Theory Presentation Note - Corrected Calibration Version}}
\date{{July 2026}}
\maketitle

\section*{{Executive summary}}
This note focuses on the mechanics of the dot-com calibration. The key point is that the model does not simply copy a dot-com drawdown number. It takes the dot-com episode apart into two pieces: a broad-market move and a TMT-excess move. It then scales those pieces separately. The broad-market piece is scaled by a market stress multiplier $\alpha_s$. The AI/TMT-excess piece is scaled by a scenario severity multiplier $\kappa_s$.

The central production formula is therefore
\[
\boxed{{
R_i^{{s,h}} = \beta_i^W \alpha_s S_W^h + I_i^{{AI}} \kappa_s S_X^h
}}
\]
where $S_W^h$ is the raw dot-com broad-market shock, $S_X^h$ is the raw dot-com TMT-excess shock, $\beta_i^W$ is the row's market beta, and $I_i^{{AI}}$ is the row's AI-excess intensity.

This is the most important message for the presentation: $\kappa$ is not a cosmetic scenario label. It is the object that converts a full dot-com TMT-excess shock into the desired AI-bubble severity for base, severe, extreme, and worst cases.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.98\textwidth]{{fig_01_calibration_workflow.png}}
\caption{{Calibration workflow. The model first decomposes dot-com into market and TMT-excess components; only then does it apply valuation and scenario multipliers.}}
\end{{figure}}

\clearpage
\section{{Step 1: choose a dot-com epicenter and a broad-market anchor}}
The dot-com calibration needs two price paths. The first is the broad market, represented by the S\&P 500. The second is a TMT epicenter proxy, represented by an equal-weight Fama--French 49-industry basket of Hardware, Software, Chips, and Telecommunications.

The model needs both. If we use only the broad market, we miss the excess damage to technology. If we use only TMT, we cannot tell how much of the TMT loss is just ordinary market de-risking. The pair of paths lets us separate market beta from AI/TMT excess risk.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.90\textwidth]{{fig_02_raw_paths.png}}
\caption{{Raw dot-com calibration inputs. The TMT epicenter sells off much more severely than the broad market, which motivates the decomposition.}}
\end{{figure}}

\section{{Step 2: define horizon-specific raw shocks}}
Let $t_0$ be the TMT peak date and let $t_h$ be the date $h$ trading days after the peak. For each horizon, define
\[
S_W^h = \log\left(\frac{{P_W(t_h)}}{{P_W(t_0)}}\right),
\qquad
S_E^h = \log\left(\frac{{P_E(t_h)}}{{P_E(t_0)}}\right),
\]
where $P_W$ is the broad-market index and $P_E$ is the epicenter TMT index. Then define the raw TMT-excess shock as
\[
\boxed{{S_X^h = S_E^h - S_W^h.}}
\]
This is the key decomposition. In log space, the epicenter drawdown is exactly the market drawdown plus the excess drawdown:
\[
S_E^h = S_W^h + S_X^h.
\]

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.90\textwidth]{{fig_03_horizon_anchors.png}}
\caption{{The model does not use one drawdown for every use case. It reads the dot-com path at 1w, 2w, 1m, and 2m after the peak.}}
\end{{figure}}

\begin{{center}}
\small
\begin{{tabular}}{{lrrrrrr}}
Horizon & Days & Anchor date & $S_W^h$ log pp & $S_X^h$ log pp & $S_E^h$ log pp & Epicenter simple shock \\
\hline
{chr(10).join(raw_rows)}
\hline
\end{{tabular}}
\end{{center}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.88\textwidth]{{fig_04_raw_decomposition.png}}
\caption{{Raw decomposition by horizon. The TMT loss is not treated as one opaque number. It is split into a market piece and an excess-TMT piece.}}
\end{{figure}}

\clearpage
\section{{Step 3: calibrate the base $\kappa$ from valuation severity}}
The full dot-com excess shock may be too severe for a base case if the current AI valuation premium is smaller than the dot-com premium. The model therefore defines a base severity multiplier:
\[
\boxed{{
\kappa_{{base}} = \frac{{\pi_{{current}}}}{{\pi_{{dotcom}}}}
}}
\]
where $\pi$ is the log valuation premium of AI/TMT relative to the market.

The dot-com reference premium is
\[
\pi_{{dotcom}} = {dotcom_premium:.6f}.
\]
The current premium is blended from current forward, current, and trailing earnings multiple premiums:
\[
\pi_{{current}} = 0.50\pi_{{forward}} + 0.25\pi_{{current\ PE}} + 0.25\pi_{{trailing}}
= {current_blended:.6f}.
\]
So the base severity is
\[
\boxed{{
\kappa_{{base}} = \frac{{{current_blended:.6f}}}{{{dotcom_premium:.6f}}} = {kappa_base:.6f}.
}}
\]

Interpretation: the base case applies about {100*kappa_base:.1f}\% of the historical dot-com TMT-excess shock. The severe case applies 100\% of the historical TMT-excess shock. Extreme and worst go beyond the full dot-com analogue.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.90\textwidth]{{fig_05_kappa_calculation.png}}
\caption{{Base $\kappa$ is a valuation-severity ratio, not an arbitrary scenario multiplier.}}
\end{{figure}}

\section{{Step 4: define scenario mechanics with $\alpha_s$ and $\kappa_s$}}
For each scenario $s$, the market leg and the AI/TMT-excess leg are scaled separately:
\[
S_W^{{s,h}} = \alpha_s S_W^h,
\qquad
S_X^{{s,h}} = \kappa_s S_X^h.
\]
The scenario epicenter shock is therefore
\[
\boxed{{
S_E^{{s,h}} = \alpha_s S_W^h + \kappa_s S_X^h.
}}
\]

\begin{{center}}
\small
\begin{{tabular}}{{lrr}}
Scenario & Market scale $\alpha_s$ & AI/TMT-excess scale $\kappa_s$ \\
\hline
{chr(10).join(scenario_rows)}
\hline
\end{{tabular}}
\end{{center}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.86\textwidth]{{fig_06_kappa_ladder.png}}
\caption{{Scenario construction. $\alpha_s$ controls broad market stress; $\kappa_s$ controls the excess AI/TMT severity.}}
\end{{figure}}

\clearpage
\section{{Step 5: generalize from the epicenter to every row}}
The scenario epicenter formula assumes beta $=1$ and AI intensity $=1$. For a general country-industry row or single-stock override, the same calibrated shocks are applied through that row's exposures:
\[
\boxed{{
R_i^{{s,h}} = \beta_i^W \alpha_s S_W^h + I_i^{{AI}} \kappa_s S_X^h.
}}
\]
This is where the calibration becomes useful. The dot-com path supplies $S_W^h$ and $S_X^h$. The valuation work supplies $\kappa_{{base}}$. The scenario design supplies $\alpha_s$ and $\kappa_s$. The cross-sectional model supplies $\beta_i^W$ and $I_i^{{AI}}$. The final stress is the product of these pieces.

A row with high market beta but low AI intensity is mainly exposed to the broad-market leg. A row with high AI intensity is sensitive to $\kappa$ because $\kappa$ scales the excess AI/TMT shock. This is exactly the intended behavior.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.88\textwidth]{{fig_07_kappa_sensitivity_by_intensity.png}}
\caption{{The same $\kappa$ produces very different final shocks depending on the row's AI intensity. This is why the model separates scenario calibration from cross-sectional exposure.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.88\textwidth]{{fig_10_stress_surface_2m_base.png}}
\caption{{Stress surface after calibration. The calibrated factor shocks are fixed for the scenario; beta and AI intensity determine where each row lands on the surface.}}
\end{{figure}}

\section{{Step 6: read the scenario outputs as generated values, not assumptions}}
The final epicenter shocks are not picked by hand. They are generated mechanically from $S_W^h$, $S_X^h$, $\alpha_s$, and $\kappa_s$.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.88\textwidth]{{fig_08_epicenter_heatmap.png}}
\caption{{Generated epicenter shocks. These are the output of the calibration formulas, not the starting assumptions.}}
\end{{figure}}

The next two charts show the same logic as a waterfall. For the two-month horizon, the base case uses the full broad-market dot-com shock and {100*kappa_base:.1f}\% of the dot-com TMT-excess shock. The worst case uses the same broad-market shock but twice the dot-com TMT-excess shock.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.82\textwidth]{{fig_09_waterfall_2m_base.png}}
\caption{{Two-month base case: full market shock plus valuation-adjusted AI/TMT-excess shock.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.82\textwidth]{{fig_09_waterfall_2m_worst.png}}
\caption{{Two-month worst case: full market shock plus $\kappa=2$ times the dot-com AI/TMT-excess shock.}}
\end{{figure}}

\clearpage
\section{{Worked interpretation: why $\kappa$ matters}}
Suppose two rows have the same market beta but different AI intensity. The broad-market term is the same for both. The only difference is the second term:
\[
I_i^{{AI}} \kappa_s S_X^h.
\]
So increasing $\kappa_s$ does not simply make the whole market worse. It specifically increases the severity of the AI/TMT-excess channel. This is exactly why the model can stress a broad index, a generic cyclical industry, Korea technology hardware, and NVIDIA differently while using the same calibrated scenario.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.94\textwidth]{{fig_11_sample_shocks.png}}
\caption{{Sample two-month shocks. All bars use the same calibrated factor shocks; differences come from $\beta^W$ and $I^{{AI}}$.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.86\textwidth]{{fig_12_distribution_by_scenario.png}}
\caption{{Distribution of calibrated two-month country-industry shocks. Scenario severity changes the whole distribution through the $\kappa$ channel, but the cross-section is still determined by beta and AI intensity.}}
\end{{figure}}

\section{{Implementation recipe}}
The calibration can be explained as a five-line implementation recipe:
\begin{{enumerate}}
\item Pick the dot-com TMT peak $t_0$.
\item For each horizon $h$, compute raw log shocks $S_W^h$ and $S_E^h$.
\item Define the raw excess shock $S_X^h=S_E^h-S_W^h$.
\item Set scenario multipliers $\alpha_s$ and $\kappa_s$, with $\kappa_{{base}}=\pi_{{current}}/\pi_{{dotcom}}$.
\item Apply $R_i^{{s,h}}=\beta_i^W \alpha_s S_W^h+I_i^{{AI}}\kappa_s S_X^h$ to every row.
\end{{enumerate}}

\section*{{Presentation takeaway}}
The dot-com calibration is convincing because each piece has a role. Dot-com supplies the historical stress path. Log decomposition separates broad-market de-risking from TMT-specific excess. Valuation severity converts the full historical excess shock into a base-case AI severity. Scenario $\kappa$ creates the severity ladder. Cross-sectional beta and AI intensity distribute the same calibrated shocks across countries, industries, ETFs, and single names.

The most important formula to show in the presentation is:
\[
\boxed{{
R_i^{{s,h}} = \beta_i^W \alpha_s S_W^h + I_i^{{AI}} \kappa_s S_X^h,
\qquad
S_X^h=S_E^h-S_W^h,
\qquad
\kappa_{{base}}=\frac{{\pi_{{current}}}}{{\pi_{{dotcom}}}}.
}}
\]
This formula is the bridge between the dot-com historical analogue and the production stress vector.

\end{{document}}
'''
tex_path.write_text(latex)

# Copy figs into OUT; compile within OUT for relative paths
for p in figs:
    # already in OUT
    pass
shutil.copy2(tex_path, OUT/tex_path.name)
# data files
shutil.copy2(sample_csv, OUT/sample_csv.name)
shutil.copy2(BASE/'ai_unwind_dotcom_calibration_theory_rebuilt_table.csv', OUT/'ai_unwind_dotcom_calibration_theory_rebuilt_table.csv')
# compile
cwd=os.getcwd(); os.chdir(OUT)
os.system('pdflatex -interaction=nonstopmode ai_unwind_dotcom_calibration_theory_rebuilt.tex > /tmp/rebuilt_calibration.log 2>&1')
os.system('pdflatex -interaction=nonstopmode ai_unwind_dotcom_calibration_theory_rebuilt.tex >> /tmp/rebuilt_calibration.log 2>&1')
os.chdir(cwd)
# copy pdf top-level
if (OUT/pdf_path.name).exists():
    shutil.copy2(OUT/pdf_path.name, pdf_path)
# zip
zip_path=BASE/'ai_unwind_dotcom_calibration_theory_rebuilt_bundle.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for fp in OUT.iterdir():
        if fp.is_file(): z.write(fp, arcname=fp.name)
print('created', pdf_path.exists(), zip_path.exists(), zip_path.stat().st_size/1e6)
