# Validation notes

- LaTeX compiled twice with `pdflatex -interaction=nonstopmode -halt-on-error`.
- Final PDF preflight: openable, 42 pages, not encrypted, text-native.
- Final PDF rendered at 150 DPI for every page; representative title, theory, table, implementation, appendix-code, and references pages were visually inspected.
- Final compile has no overfull-box or unresolved-reference warnings.
- Every Python file passes `python -m py_compile`.
- Runtime sanity checks passed for OLS AI residual orthogonality and the conditional-probability model-average / bootstrap code.
- The scenario-cell sanity test reproduces boundaries close to 43.85%, 59.10%, 70.13%, and 79.55% under the recovered V5 anchors.
