"""Verified peak-anchored short-horizon extension to the original V5 exposure model."""
import math
import numpy as np
import pandas as pd

TMT_COLS = ['Hardw', 'Softw', 'Chips', 'Telcm']


def build_tmt_simple_return(ff49_daily):
    missing = [c for c in TMT_COLS if c not in ff49_daily.columns]
    if missing:
        raise ValueError(f'Missing FF49 TMT columns: {missing}')
    return ff49_daily[TMT_COLS].mean(axis=1)


def wealth_log_from_simple(r):
    r = pd.Series(r, dtype=float)
    return np.log1p(r).cumsum()


def peak_anchored_raw_shocks(ff49_daily, spx_close, horizons=(5,10,21,42)):
    """
    For each deadline h, choose the worst TMT cumulative return reached by h.
    Evaluate the broad-market cumulative return on that same anchor date, then
    define AI/TMT excess = epicenter - market in log space.
    """
    tmt_r = build_tmt_simple_return(ff49_daily)
    tmt_log = wealth_log_from_simple(tmt_r)
    spx_log = np.log(pd.Series(spx_close, dtype=float))

    aligned = pd.concat([
        tmt_log.rename('tmt_log_level'),
        spx_log.rename('world_log_level')
    ], axis=1).dropna()

    peak_date = aligned['tmt_log_level'].idxmax()
    peak_pos = aligned.index.get_loc(peak_date)
    rows = []
    for h in horizons:
        window = aligned.iloc[peak_pos+1:min(peak_pos+h+1, len(aligned))]
        if window.empty:
            continue
        tmt_cum = window['tmt_log_level'] - aligned.loc[peak_date, 'tmt_log_level']
        anchor_date = tmt_cum.idxmin()
        s_e = float(tmt_cum.loc[anchor_date])
        s_w = float(aligned.loc[anchor_date, 'world_log_level'] - aligned.loc[peak_date, 'world_log_level'])
        s_x = s_e - s_w
        rows.append({
            'horizon_trading_days': h,
            'peak_date': peak_date,
            'anchor_date': anchor_date,
            'S_AI_EPICENTER_raw_dotcom_log': s_e,
            'S_WORLD_raw_dotcom_log': s_w,
            'S_AI_EXCESS_raw_dotcom_log': s_x,
        })
    return pd.DataFrame(rows)


def build_horizon_scenario_surface(raw_anchors, base_kappa):
    specs = [
        ('mild', 0.50, 0.50 * base_kappa),
        ('base', 1.00, base_kappa),
        ('severe', 1.00, 1.00),
        ('extreme', 1.00, 1.50),
        ('worst', 1.00, 2.00),
    ]
    rows = []
    for _, a in raw_anchors.iterrows():
        for scenario, world_scale, kappa in specs:
            sw_raw = float(a['S_WORLD_raw_dotcom_log'])
            sx_raw = float(a['S_AI_EXCESS_raw_dotcom_log'])
            sw = world_scale * sw_raw
            sx = kappa * sx_raw
            se = sw + sx
            rows.append({
                **a.to_dict(),
                'scenario': scenario,
                'world_scale': world_scale,
                'ai_excess_severity_scalar': kappa,
                'S_WORLD_log': sw,
                'S_AI_EXCESS_log': sx,
                'S_AI_EPICENTER_log': se,
                'S_WORLD_simple': math.exp(sw)-1,
                'S_AI_EXCESS_simple': math.exp(sx)-1,
                'S_AI_EPICENTER_simple': math.exp(se)-1,
            })
    return pd.DataFrame(rows)


def apply_horizon_surface(exposure_df, scenario_surface, beta_col, ai_col,
                          horizon_days):
    out = exposure_df.copy()
    use = scenario_surface[scenario_surface['horizon_trading_days'].eq(horizon_days)]
    for _, sc in use.iterrows():
        s = sc['scenario']
        logret = out[beta_col] * sc['S_WORLD_log'] + out[ai_col] * sc['S_AI_EXCESS_log']
        out[f'{s}_stress_log'] = logret
        out[f'{s}_stress_simple'] = np.exp(logret)-1
        out[f'{s}_stress_pct'] = 100*out[f'{s}_stress_simple']
    return out
