Hong Kong's 50 Richest Families & Family Offices - 2026
Research cut-off: 19 August 2026
Ranking valuation date: 23 January 2026 (Forbes Hong Kong 50 Richest 2026)

Bundle contents:
1. PDF report - concise, readable research report with embedded source hyperlinks.
2. Word report - editable version of the same report.
3. Excel workbook - full ranked database, family-office map, methodology, dashboard and row-level source URLs.

Method note:
The source ranking mixes individuals and family fortunes. Related dynasties/branches are tagged rather than mechanically consolidated because family trusts and beneficial interests can overlap. Family trusts, foundations, operating companies and institutional asset managers are not labelled as family offices without public evidence.
