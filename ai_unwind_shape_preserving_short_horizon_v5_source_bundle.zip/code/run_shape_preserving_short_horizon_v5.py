import os, re, math, json, shutil, subprocess, zipfile, textwrap
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path('/mnt/data')
OUT = ROOT / 'ai_unwind_short_horizon_shape_preserving_v5'
DATA = OUT / 'data'
FIG = OUT / 'figures'
CODE = OUT / 'code'
for d in [OUT, DATA, FIG, CODE]: d.mkdir(parents=True, exist_ok=True)

PATHS = {
    'ci': ROOT / 'country_industry_stress_vector_v5(1).csv',
    'ss': ROOT / 'single_stock_override_vector_v5(1).csv',
    'scenario': ROOT / 'scenario_parameters_v5.csv',
    'spx': ROOT / 'spx(1).csv',
    'ff49_daily': ROOT / '49_Industry_Portfolios_Daily(1).csv',
    'ff_factors_daily': ROOT / 'F-F_Research_Data_Factors_daily(1).csv',
}
for k,p in PATHS.items():
    if not p.exists():
        raise FileNotFoundError(f'Missing {k}: {p}')

# -------------------- parsing --------------------
def parse_ff49_daily(path: Path) -> pd.DataFrame:
    lines = path.read_text(errors='replace').splitlines()
    header_idx = None
    for i, line in enumerate(lines):
        if line.strip().startswith(',Agric'):
            header_idx = i; break
    if header_idx is None:
        raise ValueError('Cannot find FF49 header line starting with ,Agric')
    header = [x.strip() for x in lines[header_idx].split(',')]
    cols = ['date'] + header[1:]
    rows = []
    for line in lines[header_idx+1:]:
        first = line.split(',',1)[0].strip()
        if not re.match(r'^\d{8}$', first): break
        parts = [x.strip() for x in line.split(',')]
        if len(parts) >= len(cols): rows.append(parts[:len(cols)])
    df = pd.DataFrame(rows, columns=cols)
    df['date'] = pd.to_datetime(df['date'], format='%Y%m%d')
    for c in cols[1:]:
        df[c] = pd.to_numeric(df[c], errors='coerce')/100.0
        df.loc[df[c] <= -0.99, c] = np.nan
    return df.set_index('date').sort_index()

def parse_ff_factors_daily(path: Path) -> pd.DataFrame:
    lines = path.read_text(errors='replace').splitlines()
    header_idx = None
    for i,line in enumerate(lines):
        if line.strip().startswith(',Mkt-RF'):
            header_idx = i; break
    if header_idx is None: raise ValueError('Cannot find FF factors header')
    header = [x.strip() for x in lines[header_idx].split(',')]
    cols = ['date'] + header[1:]
    rows = []
    for line in lines[header_idx+1:]:
        first = line.split(',',1)[0].strip()
        if not re.match(r'^\d{8}$', first): break
        parts = [x.strip() for x in line.split(',')]
        if len(parts) >= len(cols): rows.append(parts[:len(cols)])
    df = pd.DataFrame(rows, columns=cols)
    df['date'] = pd.to_datetime(df['date'], format='%Y%m%d')
    for c in cols[1:]: df[c] = pd.to_numeric(df[c], errors='coerce')/100.0
    return df.set_index('date').sort_index()

def parse_spx(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = [c.strip().lower() for c in df.columns]
    if 'date' not in df.columns or 'close' not in df.columns:
        raise ValueError(f'SPX needs date and close cols; got {df.columns.tolist()}')
    # Uploaded file has dd-Mon-yy, but use mixed parser fallback.
    dt = pd.to_datetime(df['date'], format='%d-%b-%y', errors='coerce')
    if dt.isna().mean() > 0.1:
        dt = pd.to_datetime(df['date'], errors='coerce')
    df['date'] = dt
    df['close'] = pd.to_numeric(df['close'], errors='coerce')
    df = df.dropna(subset=['date','close']).drop_duplicates('date').sort_values('date').set_index('date')
    df['spx_log_ret'] = np.log(df['close']).diff()
    df['spx_simple_ret'] = df['close'].pct_change()
    return df

def simple_from_log(x): return float(np.exp(x)-1.0)
def pct_from_log(x): return 100.0*simple_from_log(x)
def fmt_pct(x): return f'{x:.2f}\\%'

def esc(s):
    return str(s).replace('\\','\\textbackslash{}').replace('&','\\&').replace('%','\\%').replace('$','\\$').replace('#','\\#').replace('_','\\_').replace('{','\\{').replace('}','\\}').replace('~','\\textasciitilde{}').replace('^','\\textasciicircum{}')

def table(headers, rows, align=None):
    if align is None: align='l'*len(headers)
    out=['\\begin{center}','\\begin{tabular}{'+align+'}','\\hline',' & '.join(headers)+' \\\\','\\hline']
    for row in rows: out.append(' & '.join(map(str,row))+' \\\\')
    out += ['\\hline','\\end{tabular}','\\end{center}']
    return '\n'.join(out)

# -------------------- data loading --------------------
ci = pd.read_csv(PATHS['ci'])
ss = pd.read_csv(PATHS['ss'])
scenario = pd.read_csv(PATHS['scenario'])
ff49 = parse_ff49_daily(PATHS['ff49_daily'])
ff = parse_ff_factors_daily(PATHS['ff_factors_daily'])
spx = parse_spx(PATHS['spx'])

# validate
for c in ['country_bucket','client_industry_label','mild_stress_log','base_stress_log','severe_stress_log','beta_world_cell','final_ai_excess_intensity']:
    if c not in ci.columns: raise ValueError(f'CI missing {c}')
for c in ['ticker','mild_stress_log','base_stress_log','severe_stress_log','beta_world_stock','final_ai_excess_intensity']:
    if c not in ss.columns: raise ValueError(f'SS missing {c}')
for c in ['scenario','world_scale','valuation_severity_scalar','S_AI_EPICENTER_log','S_WORLD_log','S_AI_EXCESS_log']:
    if c not in scenario.columns: raise ValueError(f'Scenario missing {c}')
TMT_COLS = ['Hardw','Softw','Chips','Telcm']
if any(c not in ff49.columns for c in TMT_COLS): raise ValueError('FF49 missing one of '+repr(TMT_COLS))

# construct TMT and broad series
orig_ff_cols = list(ff49.columns)
ff49['TMT4_simple'] = ff49[TMT_COLS].mean(axis=1, skipna=False)
ff49['TMT4_log'] = np.log1p(ff49['TMT4_simple'])
ff49['TMT3_simple'] = ff49[['Hardw','Softw','Chips']].mean(axis=1, skipna=False)
ff49['TMT3_log'] = np.log1p(ff49['TMT3_simple'])
ff49['TMT5_simple'] = ff49[['Hardw','Softw','Chips','Telcm','BusSv']].mean(axis=1, skipna=False)
ff49['TMT5_log'] = np.log1p(ff49['TMT5_simple'])
ff49['All49_simple'] = ff49[orig_ff_cols].mean(axis=1, skipna=True)
ff49['All49_log'] = np.log1p(ff49['All49_simple'])
ff['ff_market_simple'] = ff['Mkt-RF'] + ff['RF']
ff['ff_market_log'] = np.log1p(ff['ff_market_simple'])
common = ff49[['TMT4_simple','TMT4_log','TMT3_simple','TMT3_log','TMT5_simple','TMT5_log','All49_simple','All49_log']].join(spx[['close','spx_log_ret','spx_simple_ret']], how='inner')
common = common.join(ff[['ff_market_simple','ff_market_log']], how='left')
common = common.dropna(subset=['TMT4_log','spx_log_ret'])
cal = common.loc['1995-01-01':'2002-12-31'].copy()
cal['TMT4_wealth'] = np.exp(cal['TMT4_log'].cumsum())
cal['SPX_wealth'] = cal['close']/cal['close'].iloc[0]
cal['All49_wealth'] = np.exp(cal['All49_log'].cumsum())
peak_date = cal.loc[:'2000-03-31','TMT4_wealth'].idxmax()
trough_date = cal.loc[peak_date:,'TMT4_wealth'].idxmin()
terminal_window = common.loc[(common.index>peak_date)&(common.index<=trough_date)]
terminal_tmt_log_daily = terminal_window['TMT4_log'].sum()
terminal_world_log_daily = terminal_window['spx_log_ret'].sum()
terminal_excess_log_daily = terminal_tmt_log_daily - terminal_world_log_daily
# Note: this terminal_daily is a raw-daily audit, not equal to v5 scenario terminal, which was calibrated from monthly v5 model.

dates = list(common.index)
peak_pos = dates.index(peak_date)

def horizon_anchor(h, label):
    exact_end = dates[peak_pos+h]
    fwd = common.iloc[peak_pos+1:peak_pos+h+1].copy()
    for col in ['TMT4_log','TMT3_log','TMT5_log','spx_log_ret','All49_log','ff_market_log']:
        fwd['cum_'+col] = fwd[col].cumsum()
    anchor_date = fwd['cum_TMT4_log'].idxmin() # max drawdown reached by deadline
    n = dates.index(anchor_date) - peak_pos
    to_anchor = common.iloc[peak_pos+1:peak_pos+n+1]
    to_end = common.iloc[peak_pos+1:peak_pos+h+1]
    def s(df, col): return float(df[col].sum())
    out = {
        'horizon': label, 'horizon_trading_days': h,
        'peak_date': peak_date.strftime('%Y-%m-%d'),
        'anchor_date': anchor_date.strftime('%Y-%m-%d'),
        'trading_days_to_anchor': int(n),
        'calendar_days_to_anchor': int((anchor_date-peak_date).days),
        'exact_end_date': exact_end.strftime('%Y-%m-%d'),
        'calendar_days_to_exact_end': int((exact_end-peak_date).days),
        'S_TMT_log': s(to_anchor,'TMT4_log'),
        'S_WORLD_log': s(to_anchor,'spx_log_ret'),
        'S_ALL49_log': s(to_anchor,'All49_log'),
        'S_FF_MARKET_log': s(to_anchor,'ff_market_log'),
        'S_TMT3_log_audit': s(to_anchor,'TMT3_log'),
        'S_TMT5_log_audit': s(to_anchor,'TMT5_log'),
        'endpoint_S_TMT_log': s(to_end,'TMT4_log'),
        'endpoint_S_WORLD_log': s(to_end,'spx_log_ret'),
        'endpoint_S_ALL49_log': s(to_end,'All49_log'),
        'endpoint_S_FF_MARKET_log': s(to_end,'ff_market_log'),
        'endpoint_S_TMT3_log_audit': s(to_end,'TMT3_log'),
        'endpoint_S_TMT5_log_audit': s(to_end,'TMT5_log'),
    }
    out['S_AI_EXCESS_log'] = out['S_TMT_log'] - out['S_WORLD_log']
    out['endpoint_S_AI_EXCESS_log'] = out['endpoint_S_TMT_log'] - out['endpoint_S_WORLD_log']
    out['S_AI_EXCESS_vs_ALL49_log'] = out['S_TMT_log'] - out['S_ALL49_log']
    out['S_AI_EXCESS_vs_FF_MARKET_log'] = out['S_TMT_log'] - out['S_FF_MARKET_log']
    return out

anchors = pd.DataFrame([horizon_anchor(5,'1w'), horizon_anchor(10,'2w'), horizon_anchor(21,'1m')])
for c in [c for c in anchors.columns if c.endswith('_log') or '_log_' in c]:
    anchors[c.replace('_log','_simple')] = np.exp(anchors[c])-1
    anchors[c.replace('_log','_pct')] = 100*(np.exp(anchors[c])-1)
anchors.to_csv(DATA/'horizon_anchor_diagnostics.csv', index=False)
anchors.to_csv(ROOT/'ai_unwind_v5_shape_preserving_anchor_diagnostics.csv', index=False)

# scenario anchors by original v5 shock-decomposition formula
scenario = scenario.copy(); scenario['scenario'] = scenario['scenario'].str.lower()
scenario_order = ['mild','base','severe']
scenario = scenario.set_index('scenario').loc[scenario_order].reset_index()
rows = []
for _,a in anchors.iterrows():
    for _,s in scenario.iterrows():
        sc = s['scenario']; ws = float(s['world_scale']); k = float(s['valuation_severity_scalar'])
        S_W = ws*float(a['S_WORLD_log'])
        S_X = k*float(a['S_AI_EXCESS_log'])
        S_E = S_W + S_X
        terminal_epi = float(s['S_AI_EPICENTER_log'])
        rho = S_E / terminal_epi if terminal_epi != 0 else np.nan
        rows.append({
            'horizon': a['horizon'], 'horizon_trading_days': int(a['horizon_trading_days']), 'scenario': sc,
            'world_scale': ws, 'valuation_severity_scalar': k,
            'peak_date': a['peak_date'], 'anchor_date': a['anchor_date'], 'trading_days_to_anchor': int(a['trading_days_to_anchor']), 'exact_end_date': a['exact_end_date'],
            'raw_dotcom_TMT_log': float(a['S_TMT_log']), 'raw_dotcom_world_log': float(a['S_WORLD_log']), 'raw_dotcom_TMT_excess_log': float(a['S_AI_EXCESS_log']),
            'raw_dotcom_TMT_pct': pct_from_log(a['S_TMT_log']), 'raw_dotcom_world_pct': pct_from_log(a['S_WORLD_log']), 'raw_dotcom_TMT_excess_pct': pct_from_log(a['S_AI_EXCESS_log']),
            'S_WORLD_log': S_W, 'S_AI_EXCESS_log': S_X, 'S_AI_EPICENTER_log': S_E,
            'S_WORLD_pct': pct_from_log(S_W), 'S_AI_EXCESS_pct': pct_from_log(S_X), 'S_AI_EPICENTER_pct': pct_from_log(S_E),
            'terminal_v5_S_AI_EPICENTER_log': terminal_epi, 'terminal_v5_S_AI_EPICENTER_pct': pct_from_log(terminal_epi),
            'horizon_translation_ratio_to_terminal': rho,
            'method': 'shape preserving translation: row short-horizon stress = terminal v5 row stress times horizon AI-epicenter shock over terminal v5 AI-epicenter shock'
        })
scen = pd.DataFrame(rows)
scen.to_csv(DATA/'shape_preserving_scenario_parameters.csv', index=False)
scen.to_csv(ROOT/'ai_unwind_v5_shape_preserving_short_horizon_scenario_parameters.csv', index=False)

# Direct factor scenario for diagnostic only
factor_rows=[]
for _,srow in scen.iterrows():
    h=srow['horizon']; sc=srow['scenario']
    factor_rows.append({'horizon':h,'scenario':sc,'S_WORLD_log':srow['S_WORLD_log'],'S_AI_EXCESS_log':srow['S_AI_EXCESS_log'],'S_AI_EPICENTER_log':srow['S_AI_EPICENTER_log']})
factor_scen = pd.DataFrame(factor_rows)

# Apply shape preserving to CI and SS
base_cols = []
for sc in scenario_order:
    base_cols += [f'{sc}_stress_log',f'{sc}_stress_simple',f'{sc}_stress_pct',f'{sc}_horizon_translation_ratio_to_terminal',f'{sc}_terminal_v5_stress_log',f'{sc}_terminal_v5_stress_pct',f'{sc}_scenario_epicenter_log',f'{sc}_scenario_epicenter_pct']

def apply_shape(df, h):
    out = df.copy()
    drop = [c for c in out.columns if c in base_cols or c in ['short_horizon','short_horizon_method']]
    if drop: out = out.drop(columns=drop)
    out.insert(0,'short_horizon',h)
    out.insert(1,'short_horizon_method','shape_preserving_v5_terminal_cross_section')
    ssub = scen[scen['horizon']==h]
    for _,sr in ssub.iterrows():
        sc = sr['scenario']; rho = float(sr['horizon_translation_ratio_to_terminal'])
        terminal_log = df[f'{sc}_stress_log'].astype(float)
        new_log = rho * terminal_log
        out[f'{sc}_stress_log'] = new_log
        out[f'{sc}_stress_simple'] = np.exp(new_log)-1
        out[f'{sc}_stress_pct'] = 100*(np.exp(new_log)-1)
        out[f'{sc}_horizon_translation_ratio_to_terminal'] = rho
        out[f'{sc}_terminal_v5_stress_log'] = terminal_log
        out[f'{sc}_terminal_v5_stress_pct'] = 100*(np.exp(terminal_log)-1)
        out[f'{sc}_scenario_epicenter_log'] = float(sr['S_AI_EPICENTER_log'])
        out[f'{sc}_scenario_epicenter_pct'] = float(sr['S_AI_EPICENTER_pct'])
    return out

for h in ['1w','2w','1m']:
    ci_out = apply_shape(ci, h)
    ss_out = apply_shape(ss, h)
    ci_out.to_csv(DATA/f'ai_unwind_v5_{h}_shape_preserving_stress_vector.csv', index=False)
    ss_out.to_csv(DATA/f'ai_unwind_v5_{h}_shape_preserving_single_stock_override.csv', index=False)
    ci_out.to_csv(ROOT/f'ai_unwind_v5_{h}_shape_preserving_stress_vector.csv', index=False)
    ss_out.to_csv(ROOT/f'ai_unwind_v5_{h}_shape_preserving_single_stock_override.csv', index=False)

# Benchmark consistency diagnostics: country-industry should inherit terminal consistency; single stock may exceed if terminal override did.
diag=[]
for h in ['1w','2w','1m']:
    ci_h = pd.read_csv(DATA/f'ai_unwind_v5_{h}_shape_preserving_stress_vector.csv')
    ss_h = pd.read_csv(DATA/f'ai_unwind_v5_{h}_shape_preserving_single_stock_override.csv')
    for sc in scenario_order:
        epi = float(scen[(scen.horizon==h)&(scen.scenario==sc)]['S_AI_EPICENTER_log'].iloc[0])
        diag.append({'dataset':'country_industry','horizon':h,'scenario':sc,'n_rows':len(ci_h), 'min_log':ci_h[f'{sc}_stress_log'].min(), 'epicenter_log':epi, 'rows_more_severe_than_epicenter':int((ci_h[f'{sc}_stress_log'] < epi - 1e-12).sum())})
        diag.append({'dataset':'single_stock_override','horizon':h,'scenario':sc,'n_rows':len(ss_h), 'min_log':ss_h[f'{sc}_stress_log'].min(), 'epicenter_log':epi, 'rows_more_severe_than_epicenter':int((ss_h[f'{sc}_stress_log'] < epi - 1e-12).sum())})
diag=pd.DataFrame(diag)
for c in ['min_log','epicenter_log']:
    diag[c.replace('_log','_pct')] = 100*(np.exp(diag[c])-1)
diag.to_csv(DATA/'shape_preserving_validation_checks.csv', index=False)
diag.to_csv(ROOT/'ai_unwind_v5_shape_preserving_validation_checks.csv', index=False)

# Representative rows
rep_specs = [
    ('Korea index & ETF', lambda d: (d['country_bucket'].eq('Korea') & d['client_industry_label'].str.lower().eq('index & etf'))),
    ('Korea technology hardware', lambda d: (d['country_bucket'].eq('Korea') & d['client_industry_label'].str.lower().str.contains('technology hardware', na=False))),
    ('Taiwan technology hardware', lambda d: (d['country_bucket'].eq('Taiwan') & d['client_industry_label'].str.lower().str.contains('technology hardware', na=False))),
    ('United States technology hardware', lambda d: (d['country_bucket'].eq('United States') & d['client_industry_label'].str.lower().str.contains('technology hardware', na=False))),
]
rep_rows=[]
for h in ['1w','2w','1m']:
    ci_h=pd.read_csv(DATA/f'ai_unwind_v5_{h}_shape_preserving_stress_vector.csv')
    ss_h=pd.read_csv(DATA/f'ai_unwind_v5_{h}_shape_preserving_single_stock_override.csv')
    for name,fn in rep_specs:
        m=fn(ci_h)
        if m.any():
            r=ci_h[m].iloc[0]
            rep_rows.append({'row':name,'horizon':h,'dataset':'country_industry','mild_pct':r['mild_stress_pct'],'base_pct':r['base_stress_pct'],'severe_pct':r['severe_stress_pct']})
    for t in ['NVDA','AMD','AVGO','MSFT']:
        m=ss_h['ticker'].eq(t)
        if m.any():
            r=ss_h[m].iloc[0]
            rep_rows.append({'row':t,'horizon':h,'dataset':'single_stock_override','mild_pct':r['mild_stress_pct'],'base_pct':r['base_stress_pct'],'severe_pct':r['severe_stress_pct']})
rep=pd.DataFrame(rep_rows)
rep.to_csv(DATA/'shape_preserving_representative_results.csv', index=False)
rep.to_csv(ROOT/'ai_unwind_v5_shape_preserving_representative_results.csv', index=False)

# Cross-sectional distribution summary
summ=[]
for h in ['1w','2w','1m']:
    ci_h=pd.read_csv(DATA/f'ai_unwind_v5_{h}_shape_preserving_stress_vector.csv')
    for sc in scenario_order:
        vals=ci_h[f'{sc}_stress_pct'].dropna()
        summ.append({'horizon':h,'scenario':sc,'n':len(vals),'min_pct':vals.min(),'p05_pct':vals.quantile(0.05),'p25_pct':vals.quantile(0.25),'median_pct':vals.median(),'p75_pct':vals.quantile(0.75),'max_pct':vals.max()})
summ=pd.DataFrame(summ)
summ.to_csv(DATA/'shape_preserving_distribution_summary.csv', index=False)
summ.to_csv(ROOT/'ai_unwind_v5_shape_preserving_distribution_summary.csv', index=False)

# Daily audit around peak
daily_audit = common.loc[peak_date: dates[peak_pos+21], ['TMT4_simple','TMT4_log','spx_simple_ret','spx_log_ret','All49_simple','All49_log']].copy()
daily_audit['TMT4_cum_log_from_peak'] = daily_audit['TMT4_log'].where(daily_audit.index>peak_date,0).cumsum()
daily_audit['SPX_cum_log_from_peak'] = daily_audit['spx_log_ret'].where(daily_audit.index>peak_date,0).cumsum()
daily_audit['TMT4_cum_pct_from_peak'] = 100*(np.exp(daily_audit['TMT4_cum_log_from_peak'])-1)
daily_audit['SPX_cum_pct_from_peak'] = 100*(np.exp(daily_audit['SPX_cum_log_from_peak'])-1)
daily_audit.to_csv(DATA/'raw_daily_audit_21d_after_tmt_peak.csv')
daily_audit.to_csv(ROOT/'ai_unwind_v5_shape_preserving_raw_daily_audit_21d_after_tmt_peak.csv')

# Data audit
data_audit=pd.DataFrame([
    {'item':'FF49 daily rows','value':len(ff49)},
    {'item':'FF49 daily start','value':ff49.index.min().strftime('%Y-%m-%d')},
    {'item':'FF49 daily end','value':ff49.index.max().strftime('%Y-%m-%d')},
    {'item':'SPX rows parsed','value':len(spx)},
    {'item':'SPX start','value':spx.index.min().strftime('%Y-%m-%d')},
    {'item':'SPX end','value':spx.index.max().strftime('%Y-%m-%d')},
    {'item':'Aligned dot-com daily rows 1995-2002','value':len(cal)},
    {'item':'TMT peak date','value':peak_date.strftime('%Y-%m-%d')},
    {'item':'TMT trough date audit','value':trough_date.strftime('%Y-%m-%d')},
    {'item':'Terminal daily TMT drawdown audit pct','value':pct_from_log(terminal_tmt_log_daily)},
    {'item':'Terminal daily SPX drawdown audit pct','value':pct_from_log(terminal_world_log_daily)},
    {'item':'V5 CI rows','value':len(ci)},
    {'item':'V5 single-stock rows','value':len(ss)},
])
data_audit.to_csv(DATA/'shape_preserving_data_audit.csv', index=False)
data_audit.to_csv(ROOT/'ai_unwind_v5_shape_preserving_data_audit.csv', index=False)

# -------------------- charts --------------------
plt.rcParams.update({'figure.figsize':(8,4.8),'font.size':10})
# 21d path from peak
fig,ax=plt.subplots()
plot_df=daily_audit.reset_index()
plot_df['trading_day']=range(len(plot_df))
ax.plot(plot_df['trading_day'], plot_df['TMT4_cum_pct_from_peak'], label='TMT4')
ax.plot(plot_df['trading_day'], plot_df['SPX_cum_pct_from_peak'], label='S&P 500')
for _,a in anchors.iterrows():
    n=int(a['trading_days_to_anchor']);
    ax.scatter([n],[a['S_TMT_pct']], s=30)
    ax.annotate(a['horizon'], (n, a['S_TMT_pct']), textcoords='offset points', xytext=(5,-10))
ax.axhline(0, linewidth=0.8)
ax.set_title('Dot-com TMT and S&P 500 cumulative returns after TMT peak')
ax.set_xlabel('Trading days after TMT peak')
ax.set_ylabel('Cumulative return (%)')
ax.legend()
ax.grid(True, alpha=0.3)
fig.tight_layout(); fig.savefig(FIG/'fig_dotcom_path_21d.png', dpi=180); plt.close(fig)

# Scenario epi shocks
fig,ax=plt.subplots()
labels=[]; vals=[]
for h in ['1w','2w','1m']:
    for sc in ['mild','base','severe']:
        labels.append(f'{h} {sc}')
        vals.append(scen[(scen.horizon==h)&(scen.scenario==sc)]['S_AI_EPICENTER_pct'].iloc[0])
y=np.arange(len(labels))
ax.barh(y, vals)
ax.set_yticks(y); ax.set_yticklabels(labels)
ax.axvline(0, linewidth=0.8)
ax.set_title('Short-horizon AI epicenter shocks')
ax.set_xlabel('Simple return shock (%)')
ax.grid(True, axis='x', alpha=0.3)
fig.tight_layout(); fig.savefig(FIG/'fig_scenario_epicenter_shocks.png', dpi=180); plt.close(fig)

# Translation ratios
fig,ax=plt.subplots()
for sc in ['mild','base','severe']:
    sub=scen[scen.scenario==sc]
    ax.plot(sub['horizon'], 100*sub['horizon_translation_ratio_to_terminal'], marker='o', label=sc)
ax.set_title('Short-horizon translation ratio versus terminal v5 shock')
ax.set_ylabel('Percent of terminal v5 AI epicenter shock')
ax.set_xlabel('Horizon')
ax.grid(True, alpha=0.3); ax.legend()
fig.tight_layout(); fig.savefig(FIG/'fig_translation_ratios.png', dpi=180); plt.close(fig)

# Representative base results (CI only)
fig,ax=plt.subplots()
ci_rep=rep[(rep.dataset=='country_industry') & (rep.row.isin(['Korea technology hardware','Taiwan technology hardware','Korea index & ETF','United States technology hardware']))]
# arrange grouped as x labels row-horizon maybe simpler horizontal bars for 1m base
plot=ci_rep[ci_rep.horizon=='1m'].copy().sort_values('base_pct')
ax.barh(plot['row'], plot['base_pct'])
ax.axvline(0, linewidth=0.8)
ax.set_title('Representative country-industry base stress: 1-month')
ax.set_xlabel('Stress (%)')
ax.grid(True, axis='x', alpha=0.3)
fig.tight_layout(); fig.savefig(FIG/'fig_representative_1m_base.png', dpi=180); plt.close(fig)

# Direct factor vs shape-preserving diagnostic for 1m base top rows
# Compute direct factor for CI for diagnostic comparison only.
ci_direct=ci.copy()
sr=scen[(scen.horizon=='1m')&(scen.scenario=='base')].iloc[0]
ci_direct['direct_1m_base_log']=ci_direct['beta_world_cell']*sr['S_WORLD_log']+ci_direct['final_ai_excess_intensity']*sr['S_AI_EXCESS_log']
ci_direct['direct_1m_base_pct']=100*(np.exp(ci_direct['direct_1m_base_log'])-1)
ci_shape=pd.read_csv(DATA/'ai_unwind_v5_1m_shape_preserving_stress_vector.csv')
comp=ci_direct[['country_bucket','client_industry_label','direct_1m_base_pct']].join(ci_shape[['base_stress_pct']].rename(columns={'base_stress_pct':'shape_1m_base_pct'}))
comp['gap_pct']=comp['direct_1m_base_pct']-comp['shape_1m_base_pct']
comp.to_csv(DATA/'direct_factor_vs_shape_preserving_1m_base_diagnostic.csv', index=False)
comp.to_csv(ROOT/'ai_unwind_v5_direct_factor_vs_shape_preserving_1m_base_diagnostic.csv', index=False)
fig,ax=plt.subplots()
plot=comp.sort_values('direct_1m_base_pct').head(10).copy()
ax.scatter(plot['shape_1m_base_pct'], plot['direct_1m_base_pct'])
for _,r in plot.iterrows(): ax.annotate(r['country_bucket'][:8], (r['shape_1m_base_pct'], r['direct_1m_base_pct']), fontsize=7)
lo=min(plot['shape_1m_base_pct'].min(), plot['direct_1m_base_pct'].min())-1
hi=max(plot['shape_1m_base_pct'].max(), plot['direct_1m_base_pct'].max())+1
ax.plot([lo,hi],[lo,hi], linewidth=0.8)
ax.set_title('Diagnostic: direct factor method over-amplifies 1m base tails')
ax.set_xlabel('Shape-preserving 1m base stress (%)')
ax.set_ylabel('Direct beta/intensity 1m base stress (%)')
ax.grid(True, alpha=0.3)
fig.tight_layout(); fig.savefig(FIG/'fig_direct_vs_shape_diagnostic.png', dpi=180); plt.close(fig)

# -------------------- LaTeX report --------------------
anchor_rows=[]
for _,a in anchors.iterrows():
    anchor_rows.append([esc(a['horizon']), esc(a['anchor_date']), str(int(a['trading_days_to_anchor'])), fmt_pct(a['S_TMT_pct']), fmt_pct(a['S_WORLD_pct']), fmt_pct(a['S_AI_EXCESS_pct'])])
scenario_rows=[]
for _,r in scen.iterrows():
    scenario_rows.append([esc(r['horizon']), esc(r['scenario']), fmt_pct(r['S_WORLD_pct']), fmt_pct(r['S_AI_EXCESS_pct']), fmt_pct(r['S_AI_EPICENTER_pct']), f"{100*r['horizon_translation_ratio_to_terminal']:.1f}\%"])
rep_rows_l=[]
for _,r in rep[(rep.dataset=='country_industry') & (rep.row.isin(['Korea index & ETF','Korea technology hardware','Taiwan technology hardware','United States technology hardware']))].iterrows():
    rep_rows_l.append([esc(r['row']), esc(r['horizon']), fmt_pct(r['mild_pct']), fmt_pct(r['base_pct']), fmt_pct(r['severe_pct'])])
ss_rows_l=[]
for _,r in rep[(rep.dataset=='single_stock_override') & (rep.row.isin(['NVDA','AMD','AVGO','MSFT']))].iterrows():
    ss_rows_l.append([esc(r['row']), esc(r['horizon']), fmt_pct(r['mild_pct']), fmt_pct(r['base_pct']), fmt_pct(r['severe_pct'])])
val_rows=[]
for _,r in diag.iterrows():
    if r['dataset']=='country_industry':
        val_rows.append([esc(r['horizon']), esc(r['scenario']), str(int(r['rows_more_severe_than_epicenter'])), fmt_pct(r['min_pct']), fmt_pct(r['epicenter_pct'])])

def minipage_fig(path, caption):
    return f"\\begin{{center}}\n\\includegraphics[width=0.92\\linewidth]{{{path}}}\n\n{{\\small {esc(caption)}}}\n\\end{{center}}"

tex = r'''
\documentclass[10pt]{article}
\usepackage{graphicx}
\setlength{\parindent}{0pt}
\setlength{\parskip}{6pt}
\setlength{\oddsidemargin}{0.15in}
\setlength{\evensidemargin}{0.15in}
\setlength{\textwidth}{6.2in}
\setlength{\topmargin}{-0.25in}
\setlength{\textheight}{9.1in}
\begin{document}
\begin{center}
{\Large AI Unwind Stress Framework: Short-Horizon Horizon Translation}\\
\vspace{4pt}
{\large One-Week, Two-Week, and One-Month Margin Horizons}\\
\vspace{4pt}
{\small Alex Zhang \quad July 2026}
\end{center}

\section*{Executive summary}
This note corrects the prior short-horizon extension. The issue was not the raw dot-com daily data. The issue was methodological: applying the terminal v5 beta/intensity exposure equation directly to short-horizon shocks changes the balance between the market component and the AI-excess component. For short horizons, that can over-amplify high-beta or high-AI-intensity rows and can make current AI rows look more severe than the dot-com TMT anchor. That is not the intended interpretation of this stress framework.

The corrected implementation uses a horizon-translation approach. First, the dot-com short-horizon AI epicenter shock is measured directly from daily data. Second, that shock is translated into each v5 scenario. Third, the existing terminal v5 cross-sectional severity profile is preserved. In formula form, for row $i$, scenario $s$, and horizon $h$:
\[
\widehat R_{i}^{s,h}
=
\rho^{s,h}\widehat R_{i}^{s,PTT},
\qquad
\rho^{s,h}
=
{S_E^{s,h}\over S_E^{s,PTT}}.
\]
Here $\widehat R_{i}^{s,h}$ is the row-level short-horizon stress; $\widehat R_{i}^{s,PTT}$ is the original terminal v5 peak-to-trough row-level stress; $S_E^{s,h}$ is the short-horizon AI epicenter shock; $S_E^{s,PTT}$ is the terminal v5 AI epicenter shock. This is not a mechanical cap. It is a consistency-preserving translation of the original v5 result to shorter margin horizons.

\section*{Why the previous method was not acceptable}
The previous direct method used
\[
\widehat R_i^{s,h}=\beta_i^W S_W^{s,h}+I_i^{AI}S_X^{s,h}.
\]
That equation is valid as a factor shock model, but it is not automatically valid as a short-horizon translation of the v5 peak-to-trough result. The reason is that $\beta_i^W$ and $I_i^{AI}$ were calibrated for a terminal stress vector. If the short-horizon market/excess decomposition has a different mix from the terminal decomposition, applying the same two loadings directly can change the cross-sectional ranking in a way that is driven by the short-horizon decomposition rather than by the original v5 model.

Financially, this means that a row can become more severe than the dot-com TMT anchor not because the dot-com short-horizon anchor says so, but because its market beta and AI intensity are both loaded onto a short-horizon shock vector whose market/excess split is different from the terminal setup. That is why simply capping rows after the fact is also not satisfactory. The cleaner fix is to preserve the original v5 cross-sectional severity profile and only replace the time horizon of the historical anchor.

\section*{Data and anchor construction}
Daily dot-com TMT returns are built from the Fama-French 49 Industry Portfolios using an equal-weight basket of Hardw, Softw, Chips, and Telcm. The broad market leg uses the uploaded daily S\&P 500 file. The dot-com TMT peak is found in the daily TMT basket before March 2000. For each margin horizon, the primary anchor is the maximum TMT drawdown reached by the deadline, not necessarily the exact endpoint close-to-close return. This is the more conservative interpretation for margin risk because a margin call can be triggered before the exact horizon endpoint.

'''
tex += table(['Horizon','Anchor date','Trading days','TMT drawdown','S\&P shock','TMT excess'], anchor_rows, 'llrrrr')
tex += r'''

The one-week and two-week anchors are close because the daily TMT basket sold off sharply immediately after the TMT peak. This is visible in the daily path below. The one-month anchor is materially worse because the selloff extended to April 14, 2000.

'''
tex += minipage_fig('figures/fig_dotcom_path_21d.png','Daily cumulative returns after the dot-com TMT peak. The markers show the short-horizon max-drawdown anchors used for one week, two weeks, and one month.')
tex += r'''

\section*{Scenario construction}
The short-horizon epicenter shock keeps the original v5 mild/base/severe logic. Let $S_W^h$ be the raw broad-market shock over horizon $h$, and let $S_X^h$ be the raw TMT-excess shock over horizon $h$. For scenario $s$:
\[
S_E^{s,h}=a_sS_W^h+k_sS_X^h.
\]
Here $a_s$ is the v5 market scale for scenario $s$ and $k_s$ is the v5 valuation severity scalar for scenario $s$. In the uploaded v5 scenario file, mild uses a half market shock and half of the base valuation scalar; base uses the full market shock and the base valuation scalar; severe uses the full market shock and the full dot-com excess shock.

'''
tex += table(['Horizon','Scenario','World shock','AI/TMT excess','AI epicenter','Terminal ratio'], scenario_rows, 'llrrrr')
tex += minipage_fig('figures/fig_scenario_epicenter_shocks.png','AI epicenter shocks by horizon and scenario.')
tex += minipage_fig('figures/fig_translation_ratios.png','The translation ratio is the short-horizon AI epicenter shock divided by the terminal v5 AI epicenter shock for the same scenario.')
tex += r'''

\section*{Corrected row-level application}
The corrected short-horizon row-level stress is
\[
\widehat R_i^{s,h}=\rho^{s,h}\widehat R_i^{s,PTT},
\qquad
\rho^{s,h}={S_E^{s,h}\over S_E^{s,PTT}}.
\]
Every variable is defined as follows. $i$ is the country-industry row. $s$ is the scenario: mild, base, or severe. $h$ is the margin horizon: one week, two weeks, or one month. $\widehat R_i^{s,h}$ is the final short-horizon stress for row $i$. $\widehat R_i^{s,PTT}$ is the original v5 peak-to-trough stress for row $i$. $S_E^{s,h}$ is the AI epicenter short-horizon shock. $S_E^{s,PTT}$ is the AI epicenter terminal peak-to-trough shock in the original v5 scenario table. $\rho^{s,h}$ is the arrival fraction implied by the historical dot-com short-horizon AI epicenter drawdown.

This has an important consistency property:
\[
{\widehat R_i^{s,h}\over S_E^{s,h}}
=
{\widehat R_i^{s,PTT}\over S_E^{s,PTT}}.
\]
The row's severity relative to the AI epicenter is therefore unchanged from the original v5 model. Only the time horizon is changed. This is why the country-industry vector no longer produces a short-horizon AI result that is more severe than the benchmark if it was not already more severe in the original v5 peak-to-trough vector.

'''
tex += minipage_fig('figures/fig_direct_vs_shape_diagnostic.png','Diagnostic comparison for the one-month base case. The direct factor method pushes some high-beta rows below the shape-preserving result because it recomputes the row loss from a new short-horizon market/excess mix. The shape-preserving method keeps the original v5 cross-section.')
tex += r'''

\section*{Representative country-industry results}
'''
tex += table(['Row','Horizon','Mild','Base','Severe'], rep_rows_l, 'llrrr')
tex += minipage_fig('figures/fig_representative_1m_base.png','Representative one-month base stresses for selected country-industry rows.')
tex += r'''

\section*{Single-stock override interpretation}
The single-stock override vector is different from the country-industry vector. The original v5 single-stock overrides already allow names such as AMD and NVDA to be more severe than the AI epicenter benchmark because those overrides intentionally include individual-stock beta and individual-stock AI intensity. Therefore, the shape-preserving translation keeps that property. This is not a new short-horizon error; it is inherited from the terminal single-stock override design. If the intended business use is a benchmark-consistent portfolio stress rather than an idiosyncratic single-name stress, the country-industry vector should be the primary output and the single-stock override should be treated as an additional idiosyncratic overlay.

'''
tex += table(['Ticker','Horizon','Mild','Base','Severe'], ss_rows_l, 'llrrr')
tex += r'''

\section*{Validation checks}
The key validation test is whether the country-industry short-horizon vector violates the AI epicenter benchmark when the original terminal v5 country-industry vector did not. Under the corrected shape-preserving translation, this does not occur.

'''
tex += table(['Horizon','Scenario','CI rows more severe than epicenter','Worst CI row','Epicenter'], val_rows, 'llrrr')
tex += r'''

\section*{Conclusion}
The corrected result is not a mechanical row cap and does not rebuild the whole model. It fixes the method definition. The previous direct short-horizon factor application answered a different question: what happens if the v5 beta and AI-intensity loadings are applied to a new short-horizon market/excess shock vector. The more appropriate question for margin-horizon extension is: given the existing v5 peak-to-trough stress vector, how much of that stress historically arrived within one week, two weeks, or one month in the dot-com TMT episode?

The answer is the shape-preserving horizon translation used here. It directly anchors on dot-com short-horizon drawdowns, preserves the original v5 cross-section, and avoids producing current AI country-industry stresses that are more severe than the historical TMT benchmark unless that was already an explicit feature of the original v5 override design.

\end{document}
'''
tex_path = OUT/'ai_unwind_shape_preserving_short_horizon_v5_report.tex'
tex_path.write_text(tex)
# copy figures relative
# compile from OUT
cmd = ['pdflatex','-interaction=nonstopmode',tex_path.name]
subprocess.run(cmd, cwd=OUT, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
subprocess.run(cmd, cwd=OUT, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
# copy outputs to root
pdf_src = OUT/'ai_unwind_shape_preserving_short_horizon_v5_report.pdf'
shutil.copy2(pdf_src, ROOT/'ai_unwind_shape_preserving_short_horizon_v5_report.pdf')
shutil.copy2(tex_path, ROOT/'ai_unwind_shape_preserving_short_horizon_v5_report.tex')
# copy script
shutil.copy2(Path(__file__), CODE/'run_shape_preserving_short_horizon_v5.py') if '__file__' in globals() else None
shutil.copy2(ROOT/'run_shape_preserving_short_horizon_v5.py', CODE/'run_shape_preserving_short_horizon_v5.py')
# bundle
bundle = ROOT/'ai_unwind_shape_preserving_short_horizon_v5_source_bundle.zip'
with zipfile.ZipFile(bundle, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for p in OUT.rglob('*'):
        if p.is_file(): z.write(p, p.relative_to(OUT))
    # include root copies of key csv names as convenience in data already included

summary = {
    'peak_date': peak_date.strftime('%Y-%m-%d'),
    'anchors': anchors[['horizon','anchor_date','trading_days_to_anchor','S_TMT_pct','S_WORLD_pct','S_AI_EXCESS_pct']].to_dict('records'),
    'scenario_parameters': scen[['horizon','scenario','S_AI_EPICENTER_pct','horizon_translation_ratio_to_terminal']].to_dict('records'),
    'ci_validation': diag[diag.dataset.eq('country_industry')][['horizon','scenario','rows_more_severe_than_epicenter','min_pct','epicenter_pct']].to_dict('records'),
    'single_stock_note': 'single-stock overrides inherit terminal v5 idiosyncratic severity; they can exceed epicenter if terminal v5 did.'
}
(OUT/'run_summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, indent=2))
