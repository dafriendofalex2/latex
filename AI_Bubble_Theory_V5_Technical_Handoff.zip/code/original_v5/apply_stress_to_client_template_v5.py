import pandas as pd
import numpy as np
import re

def norm_label(x):
    return re.sub(r'[^a-z0-9]+',' ',str(x).lower()).strip()

def size_loss_multiplier(market_cap_usd):
    try:
        mc = float(market_cap_usd)
    except Exception:
        return 1.20
    if np.isnan(mc) or mc <= 0:
        return 1.20
    if mc >= 10_000_000_000:
        return 1.00
    if mc >= 2_000_000_000:
        return 1.05
    if mc >= 300_000_000:
        return 1.10
    return 1.20

def apply_stress(client_csv,
                 stress_vector_csv='data/country_industry_stress_vector_v5.csv',
                 single_stock_csv='data/single_stock_override_vector_v5.csv',
                 country_mapping_csv='data/client_country_mapping_template_v5.csv',
                 scenario='base',
                 output_csv='client_stress_output_v5.csv',
                 use_single_stock_overrides=True,
                 apply_market_cap_overlay=False):
    client = pd.read_csv(client_csv)
    stress = pd.read_csv(stress_vector_csv)
    single = pd.read_csv(single_stock_csv)
    country_map = pd.read_csv(country_mapping_csv)

    required = ['country','industry','signed_market_value_usd']
    missing = [c for c in required if c not in client.columns]
    if missing:
        raise ValueError(f'Missing required client columns: {missing}')

    client['country_normalized'] = client['country'].map(norm_label)
    client['industry_normalized'] = client['industry'].map(norm_label)
    if 'ticker' in client.columns:
        client['ticker_upper'] = client['ticker'].astype(str).str.upper().str.replace(r'[^A-Z0-9]+','',regex=True)
    else:
        client['ticker_upper'] = ''

    if 'client_country_normalized' not in country_map.columns:
        country_map['client_country_normalized'] = country_map['client_country_label'].map(norm_label)

    client = client.merge(
        country_map[['client_country_normalized','country_bucket','country_proxy_ticker','region_group','reliability_country']],
        left_on='country_normalized', right_on='client_country_normalized', how='left'
    )
    client['country_bucket'] = client['country_bucket'].fillna('World Fallback')

    scenario_cols = [f'{scenario}_stress_simple', f'{scenario}_stress_pct', f'{scenario}_stress_log']
    key_cols = ['country_bucket','client_industry_normalized','model_scope','reliability_flag','industry_bucket','beta_world_cell','final_ai_excess_intensity'] + scenario_cols
    stress_small = stress[key_cols].rename(columns={
        f'{scenario}_stress_simple':'stress_simple',
        f'{scenario}_stress_pct':'stress_pct',
        f'{scenario}_stress_log':'stress_log'
    })
    out = client.merge(stress_small, left_on=['country_bucket','industry_normalized'], right_on=['country_bucket','client_industry_normalized'], how='left')

    if use_single_stock_overrides:
        single_small = single[['ticker',f'{scenario}_stress_simple',f'{scenario}_stress_pct',f'{scenario}_stress_log','beta_world_stock','final_ai_excess_intensity']].rename(columns={
            'ticker':'ticker_upper',
            f'{scenario}_stress_simple':'single_stock_stress_simple',
            f'{scenario}_stress_pct':'single_stock_stress_pct',
            f'{scenario}_stress_log':'single_stock_stress_log'
        })
        out = out.merge(single_small, on='ticker_upper', how='left')
        use_override = out['single_stock_stress_simple'].notna()
        out.loc[use_override,'stress_simple'] = out.loc[use_override,'single_stock_stress_simple']
        out.loc[use_override,'stress_pct'] = out.loc[use_override,'single_stock_stress_pct']
        out.loc[use_override,'stress_log'] = out.loc[use_override,'single_stock_stress_log']
        out.loc[use_override,'model_scope'] = 'single_stock_override'
        out.loc[use_override,'reliability_flag'] = 'single-stock'

    out['stress_pnl_usd'] = -out['signed_market_value_usd'] * out['stress_simple']
    out['adverse_stress_loss_usd'] = out['stress_pnl_usd'].clip(lower=0)

    if apply_market_cap_overlay:
        if 'holding_market_cap_usd' not in out.columns:
            raise ValueError('holding_market_cap_usd is required when apply_market_cap_overlay=True')
        out['size_loss_multiplier'] = out['holding_market_cap_usd'].map(size_loss_multiplier)
    else:
        out['size_loss_multiplier'] = 1.0

    out['adverse_stress_loss_usd_after_size_overlay'] = out['adverse_stress_loss_usd'] * out['size_loss_multiplier']
    if 'client_level_margin_usd' in out.columns:
        out['stress_loss_to_margin'] = out['adverse_stress_loss_usd_after_size_overlay'] / out['client_level_margin_usd']
    out.to_csv(output_csv, index=False)
    return out

if __name__ == '__main__':
    # Example:
    # apply_stress('client_positions.csv', scenario='base', output_csv='client_stress_output_v5.csv')
    pass
