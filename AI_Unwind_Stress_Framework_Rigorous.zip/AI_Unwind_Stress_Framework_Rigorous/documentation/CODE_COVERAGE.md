# Code Coverage and Paper Correspondence

Every material model mechanism described in the paper has an executable implementation in `code/` and is reproduced inline in the corresponding paper section.

| Model block | Main mathematical object | Executable source |
|---|---|---|
| Canonical stress operator | `R = beta*S_W + I_AI*S_X + A_size`; log/simple conversion; signed P&L | `code/core_operator.py` |
| Return estimation | month-end log returns; OLS; Newey-West/HAC inference; proxy exposure estimation; precision shrinkage | `code/return_estimation.py` |
| AI orthogonalization | `r_A = alpha + theta_W^AI r_W + x`; residual AI/TMT factor | `code/orthogonalization.py` |
| Statistical AI exposure | `(theta_abs - beta_W*theta_W^AI)/(1-theta_W^AI)`; clipping | `code/ai_exposure.py` |
| Economic AI exposure | 35% country / 65% industry structural score | `code/ai_exposure.py` |
| Final AI intensity | 60% statistical / 40% economic blend | `code/ai_exposure.py` |
| Country-industry lift | country baseline, square-root industry tilt, coherence projection | `code/country_industry.py` |
| Dot-com analogue diagnostic | normalized log-price path comparison and lead search | `code/analogue_validation.py` |
| Valuation severity | log valuation premium and Base severity scalar | `code/valuation_calibration.py` |
| Terminal scenarios | Mild/Base/Severe/Extreme/Worst market and AI-excess shock decomposition | `code/horizon_scenarios.py` |
| Fixed horizons | 5/10/21/42 trading-day peak-anchored shock surface | `code/horizon_scenarios.py` |
| Single-stock precision layer | ticker beta/theta estimation, 60/40 intensity, scenario materialization | `code/single_stock.py` |
| Market-cap fragility | bottom-decile market windows, relative size underperformance, scenario quantiles | `code/market_cap.py` |
| Portfolio application | country-industry mapping, ticker replacement, size overlay, P&L, loss-to-margin | `code/portfolio_application.py` |
| Conditional probability model | log-loss Voronoi cells; Beta/Gamma/Weibull/Lognormal fits; D-scale likelihoods; AICc averaging | `code/probability_model.py` |
| Probability uncertainty | 5,000 episode-level bootstrap refits; Jeffreys-Dirichlet cross-check; GPD diagnostic | `code/probability_model.py` |
| Mechanical validation | orthogonality, log/simple identity, component identity, bounds, probability sum, zero reference overlay | `code/validation.py` |

The source files are intentionally small enough that each statistical assumption can be reviewed without navigating unrelated report-generation or packaging code.
