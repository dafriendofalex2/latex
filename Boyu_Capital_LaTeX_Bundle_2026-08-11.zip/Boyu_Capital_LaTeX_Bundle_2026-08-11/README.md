# Boyu Capital public-domain client profile research

Information cut-off: 11 August 2026.

## Files
- `main.tex` - source LaTeX document.
- `references.tex` - manually maintained bibliography used by `main.tex` (no BibTeX required).
- `Boyu_Capital_Public_Domain_Client_Profile_2026-08-11.pdf` - compiled report.
- `source_register.csv` - compact source / evidence register.

## Compile
Run three times from a clean directory so the table of contents, citations and page references settle:

```bash
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

## Research conventions
- Official / regulatory sources take priority.
- Reuters / Bloomberg / FT and transaction counsel are used for reported deal facts.
- Current consolidated Boyu AUM is **not** stated as a confirmed figure because Boyu's current public website does not disclose it.
- A 2022 investee press release described Boyu as having over US$40bn AUM; this is retained as a historical reference only.
- Public market prices are not required for the report's conclusions. If a price is added, the requested market-data cut-off is the 10 Aug. 2026 close.
