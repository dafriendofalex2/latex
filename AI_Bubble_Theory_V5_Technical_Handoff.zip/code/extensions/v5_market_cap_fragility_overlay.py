"""
Empirical market-cap fragility overlay developed after the original V5 engine.
The overlay is separate from AI intensity and additive in log-return space.
"""
import numpy as np
import pandas as pd

SCENARIO_QUANTILES = {
    'mild': 0.50,
    'base': 0.25,
    'severe': 0.10,
    'extreme': 0.05,
}


def rolling_log_return(simple_return, window):
    return np.log1p(pd.Series(simple_return, dtype=float)).rolling(window).sum()


def calibrate_size_fragility(size_returns, broad_return,
                             horizons=(5,10,21,42), stress_decile=0.10,
                             reference_col='Q5'):
    """
    Calibrate relative size underperformance in bottom-decile broad-market
    rolling windows. Worst uses the historical minimum; other scenarios use
    governed conditional quantiles.
    """
    rows = []
    for h in horizons:
        broad_h = rolling_log_return(broad_return, h)
        threshold = broad_h.quantile(stress_decile)
        stress_mask = broad_h <= threshold
        ref = rolling_log_return(size_returns[reference_col], h)
        for bucket in size_returns.columns:
            rel = rolling_log_return(size_returns[bucket], h) - ref
            sample = rel[stress_mask].dropna()
            for scenario, q in SCENARIO_QUANTILES.items():
                overlay = float(sample.quantile(q)) if len(sample) else np.nan
                rows.append({'horizon_days':h,'market_cap_bucket':bucket,
                             'scenario':scenario,'size_overlay_log':min(0.0,overlay)})
            worst = float(sample.min()) if len(sample) else np.nan
            rows.append({'horizon_days':h,'market_cap_bucket':bucket,
                         'scenario':'worst','size_overlay_log':min(0.0,worst)})
    out = pd.DataFrame(rows)
    out.loc[out['market_cap_bucket'].eq(reference_col), 'size_overlay_log'] = 0.0
    return out


def add_size_overlay(country_industry_stress_log, size_overlay_log):
    return np.asarray(country_industry_stress_log) + np.minimum(0.0, np.asarray(size_overlay_log))
