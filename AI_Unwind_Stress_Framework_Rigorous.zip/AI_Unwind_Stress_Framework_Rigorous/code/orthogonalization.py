"""Market/AI factor orthogonalization and projection diagnostics."""
from __future__ import annotations
import numpy as np


def ols_slope(y, x):
    """OLS slope with an intercept: Cov(y,x)/Var(x)."""
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    mask = np.isfinite(y) & np.isfinite(x)
    y, x = y[mask], x[mask]
    if len(y) < 3:
        return np.nan
    xc, yc = x - x.mean(), y - y.mean()
    den = float(xc @ xc)
    return np.nan if den <= 0 else float((xc @ yc) / den)


def orthogonalize_ai(ai_returns, world_returns):
    """Remove the fitted broad-market component from the raw AI basket.

    r_A,t = alpha_A + theta_W^AI r_W,t + x_t.
    With an intercept, x_t is orthogonal to centered r_W,t in sample.
    """
    ai = np.asarray(ai_returns, dtype=float)
    world = np.asarray(world_returns, dtype=float)
    mask = np.isfinite(ai) & np.isfinite(world)
    ai, world = ai[mask], world[mask]
    theta_world_ai = ols_slope(ai, world)
    intercept = float(ai.mean() - theta_world_ai * world.mean())
    residual_ai = ai - intercept - theta_world_ai * world
    return theta_world_ai, intercept, residual_ai


def orthogonality_diagnostic(world_returns, residual_ai):
    """Return covariance, correlation and projection inner product."""
    w = np.asarray(world_returns, dtype=float)
    x = np.asarray(residual_ai, dtype=float)
    mask = np.isfinite(w) & np.isfinite(x)
    w, x = w[mask], x[mask]
    wc = w - w.mean()
    cov = float(np.mean(wc * (x - x.mean())))
    corr = float(np.corrcoef(w, x)[0, 1]) if len(w) > 2 else np.nan
    inner = float(wc @ x)
    return {"covariance": cov, "correlation": corr, "centered_inner_product": inner}
