AI Dot-Com Comparison - Jul. 14 cutoff, 180 trading day window

This bundle uses a fixed Jul. 14, 2026 cutoff and a 180-trading-day window.

Key outputs
- Window length: 180 trading days
- Current window: 2025-10-23 to 2026-07-14
- Dot-com peak: 2000-03-27
- Best-fit lead: 114 trading days
- Final-window path correlation: 0.7542
- Final-window RMSE: 0.2396
- Best-fit RMSE: 0.0503
- Best-fit correlation: 0.7226
- Remaining historical move from matched point: 91.6785%

Note
This is an illustrative path-comparison deck, not a core model input or market forecast.
