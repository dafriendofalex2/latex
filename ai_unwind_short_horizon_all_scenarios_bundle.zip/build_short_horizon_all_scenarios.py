import pandas as pd, numpy as np, math, os, zipfile, shutil
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE=Path('/mnt/data')
OUT=BASE/'ai_unwind_short_horizon_all_scenarios_bundle'
OUT.mkdir(exist_ok=True)

# ---------- helpers ----------
def parse_ff49_daily(path):
    lines=Path(path).read_text(encoding='latin1').splitlines()
    start=None
    for i,l in enumerate(lines):
        if 'Average Value Weighted Returns -- Daily' in l:
            start=i+1; break
    if start is None: raise RuntimeError('Missing FF49 value-weighted daily section')
    header=[h.strip() for h in lines[start].split(',')]
    rows=[]
    for l in lines[start+1:]:
        if not l.strip(): break
        parts=[p.strip() for p in l.split(',')]
        if len(parts)==len(header): rows.append(parts)
    df=pd.DataFrame(rows, columns=header).rename(columns={header[0]:'date'})
    df['date']=pd.to_datetime(df['date'], format='%Y%m%d')
    for c in df.columns[1:]: df[c]=pd.to_numeric(df[c], errors='coerce')
    df=df.replace({-99.99:np.nan, -999.0:np.nan})
    for c in df.columns[1:]: df[c]=df[c]/100.0
    return df

def parse_spx(path):
    df=pd.read_csv(path)
    if {'date','close'}.issubset(df.columns):
        df['Date']=pd.to_datetime(df['date'], format='%d-%b-%y')
        df['close']=pd.to_numeric(df['close'], errors='coerce')
    else:
        dcol=[c for c in df.columns if c.lower().startswith('date')][0]
        ccol=[c for c in df.columns if c.lower() in ('close','price')][0]
        df['Date']=pd.to_datetime(df[dcol])
        df['close']=pd.to_numeric(df[ccol], errors='coerce')
    return df[['Date','close']].dropna().sort_values('Date')

def pct_from_log(x): return 100*(math.exp(x)-1)
def esc(s): return str(s).replace('&','\\&').replace('%','\\%').replace('_','\\_')

def strip_stress_cols(df):
    prefixes=['mild_','base_','severe_','worst_']
    keep=[]
    for c in df.columns:
        if c in ('short_horizon','short_horizon_anchor_method'): continue
        if any(c.startswith(p) and ('stress' in c or 'component' in c or 'valuation' in c) for p in prefixes): continue
        keep.append(c)
    return df[keep].copy()

# ---------- load inputs ----------
ci=pd.read_csv(BASE/'country_industry_stress_vector_v5(1).csv')
st_path=BASE/'single_stock_override_vector_v5_all20.csv'
if not st_path.exists(): st_path=BASE/'single_stock_override_vector_v5(1).csv'
stocks=pd.read_csv(st_path)
scen_v5=pd.read_csv(BASE/'scenario_parameters_v5.csv')
base_kappa=float(scen_v5.loc[scen_v5['scenario']=='base','valuation_severity_scalar'].iloc[0])

# ---------- construct scenario parameters ----------
ff=parse_ff49_daily(BASE/'49_Industry_Portfolios_Daily.csv')
cols=['Hardw','Softw','Chips','Telcm']
missing=[c for c in cols if c not in ff.columns]
if missing: raise RuntimeError(f'Missing FF49 TMT columns: {missing}')
ff['tmt_simple']=ff[cols].mean(axis=1, skipna=False)
ff['tmt_log']=np.log1p(ff['tmt_simple'])
spx=parse_spx(BASE/'spx.csv')
spx['world_log']=np.log(spx['close']/spx['close'].shift(1))
spx=spx.dropna()
common=pd.merge(ff[['date','tmt_log']], spx[['Date','close','world_log']], left_on='date', right_on='Date', how='inner').drop(columns=['Date'])
common=common.sort_values('date').reset_index(drop=True)
common['tmt_log_level']=common['tmt_log'].cumsum()
window=common[(common['date']>=pd.Timestamp('1998-01-01')) & (common['date']<=pd.Timestamp('2002-12-31'))]
peak_idx=window['tmt_log_level'].idxmax()
peak_date=common.loc[peak_idx,'date']

horizons={'1w':5,'2w':10,'1m':21,'2m':42}
scenario_defs={
    'mild':(0.5,0.5*base_kappa,'Half market shock and half of base AI-excess severity.'),
    'base':(1.0,base_kappa,'Full market shock and valuation-adjusted base AI-excess severity.'),
    'severe':(1.0,1.0,'Full market shock and full dot-com AI/TMT-excess analogue.'),
    'worst':(1.0,1.5,'Full market shock and 1.5x dot-com AI/TMT-excess analogue.'),
}
scen_rows=[]
for h,days in horizons.items():
    end_idx=peak_idx+days
    S_E_raw=float(common.loc[end_idx,'tmt_log_level']-common.loc[peak_idx,'tmt_log_level'])
    S_W_raw=math.log(float(common.loc[end_idx,'close'])/float(common.loc[peak_idx,'close']))
    S_X_raw=S_E_raw-S_W_raw
    for name,(wscale,kappa,desc) in scenario_defs.items():
        S_W=wscale*S_W_raw
        S_X=kappa*S_X_raw
        S_E=S_W+S_X
        scen_rows.append({
            'horizon':h,'scenario':name,'horizon_trading_days':days,
            'peak_date':peak_date.date().isoformat(),'anchor_date':common.loc[end_idx,'date'].date().isoformat(),
            'world_scale':wscale,'valuation_severity_scalar':kappa,
            'S_WORLD_raw_dotcom_log':S_W_raw,'S_AI_EXCESS_raw_dotcom_log':S_X_raw,'S_AI_EPICENTER_raw_dotcom_log':S_E_raw,
            'S_WORLD_log':S_W,'S_AI_EXCESS_log':S_X,'S_AI_EPICENTER_log':S_E,
            'S_WORLD_simple':math.exp(S_W)-1,'S_WORLD_pct':pct_from_log(S_W),
            'S_AI_EXCESS_simple':math.exp(S_X)-1,'S_AI_EXCESS_pct':pct_from_log(S_X),
            'S_AI_EPICENTER_simple':math.exp(S_E)-1,'S_AI_EPICENTER_pct':pct_from_log(S_E),
            'description':desc,
            'anchor_method':'peak_anchored_fixed_horizon_from_ff49_tmt_peak',
            'broad_market_proxy':'S&P 500 daily close, uploaded spx.csv',
            'tmt_proxy':'Equal-weight daily FF49 Hardw, Softw, Chips, Telcm'
        })
scen=pd.DataFrame(scen_rows)
scen_path=BASE/'ai_unwind_v5_short_horizon_all_scenario_parameters.csv'
scen.to_csv(scen_path,index=False)

# ---------- apply to vectors ----------
def apply_to_vector(df,beta_col,intensity_col,horizon):
    out=strip_stress_cols(df)
    out.insert(0,'short_horizon_anchor_method','peak_anchored_fixed_horizon_from_ff49_tmt_peak')
    out.insert(1,'short_horizon',horizon)
    sub=scen[scen['horizon']==horizon].set_index('scenario')
    for s in ['mild','base','severe','worst']:
        S_W=float(sub.loc[s,'S_WORLD_log']); S_X=float(sub.loc[s,'S_AI_EXCESS_log'])
        out[f'{s}_stress_log']=out[beta_col]*S_W+out[intensity_col]*S_X
        out[f'{s}_stress_simple']=np.exp(out[f'{s}_stress_log'])-1
        out[f'{s}_stress_pct']=100*out[f'{s}_stress_simple']
        out[f'{s}_world_component_log']=out[beta_col]*S_W
        out[f'{s}_ai_excess_component_log']=out[intensity_col]*S_X
        out[f'{s}_valuation_severity_scalar']=float(sub.loc[s,'valuation_severity_scalar'])
    return out

ci_paths={}; st_paths={}; ci_long=[]; st_long=[]
for h in horizons:
    co=apply_to_vector(ci,'beta_world_cell','final_ai_excess_intensity',h)
    so=apply_to_vector(stocks,'beta_world_stock','final_ai_excess_intensity',h)
    cp=BASE/f'ai_unwind_v5_{h}_country_industry_all_scenarios.csv'
    sp=BASE/f'ai_unwind_v5_{h}_single_stock_all20_all_scenarios.csv'
    co.to_csv(cp,index=False); so.to_csv(sp,index=False)
    ci_paths[h]=cp; st_paths[h]=sp
    for s in ['mild','base','severe','worst']:
        ccols=['country_bucket','country_proxy_ticker','country_region_group','client_industry_label','client_industry_normalized','industry_bucket','industry_proxy_ticker','industry_sector_group','model_scope','reliability_flag','beta_world_cell','final_ai_excess_intensity']
        tmp=co[ccols].copy(); tmp['horizon']=h; tmp['scenario']=s; tmp['valuation_severity_scalar']=co[f'{s}_valuation_severity_scalar']; tmp['stress_log']=co[f'{s}_stress_log']; tmp['stress_simple']=co[f'{s}_stress_simple']; tmp['stress_pct']=co[f'{s}_stress_pct']; ci_long.append(tmp)
        scols=[c for c in ['ticker','security_name','model_scope','beta_world_stock','final_ai_excess_intensity','economic_ai_intensity','stat_ai_excess_intensity','n_months'] if c in so.columns]
        tmp2=so[scols].copy(); tmp2['horizon']=h; tmp2['scenario']=s; tmp2['valuation_severity_scalar']=so[f'{s}_valuation_severity_scalar']; tmp2['stress_log']=so[f'{s}_stress_log']; tmp2['stress_simple']=so[f'{s}_stress_simple']; tmp2['stress_pct']=so[f'{s}_stress_pct']; st_long.append(tmp2)
ci_long=pd.concat(ci_long, ignore_index=True); st_long=pd.concat(st_long, ignore_index=True)
ci_long_path=BASE/'ai_unwind_v5_country_industry_short_horizon_all_scenarios_long.csv'
st_long_path=BASE/'ai_unwind_v5_single_stock_all20_short_horizon_all_scenarios_long.csv'
ci_long.to_csv(ci_long_path,index=False); st_long.to_csv(st_long_path,index=False)
ci_sevw_path=BASE/'ai_unwind_v5_country_industry_severe_worst_long.csv'
st_sevw_path=BASE/'ai_unwind_v5_single_stock_all20_severe_worst_long.csv'
ci_long[ci_long['scenario'].isin(['severe','worst'])].to_csv(ci_sevw_path,index=False)
st_long[st_long['scenario'].isin(['severe','worst'])].to_csv(st_sevw_path,index=False)

# ---------- figures ----------
FIG=BASE/'ai_unwind_short_horizon_all_scenarios_figures'; FIG.mkdir(exist_ok=True)
# scenario ladder
pivot=scen.pivot(index='horizon',columns='scenario',values='S_AI_EPICENTER_pct').loc[['1w','2w','1m','2m'],['mild','base','severe','worst']]
plt.figure(figsize=(8,5)); x=np.arange(len(pivot.index)); width=0.2
for i,s in enumerate(['mild','base','severe','worst']): plt.bar(x+(i-1.5)*width,pivot[s],width=width,label=s)
plt.xticks(x,pivot.index); plt.ylabel('AI/TMT epicenter shock (%)'); plt.title('Peak-anchored short-horizon shock ladder'); plt.legend(); plt.tight_layout()
fig_anchor=FIG/'fig_short_horizon_shock_ladder.png'; plt.savefig(fig_anchor,dpi=180); plt.close()
# ci dist
plt.figure(figsize=(8,5)); labels=[]; data=[]
for h in ['1w','2w','1m','2m']:
    df=pd.read_csv(ci_paths[h]); data.append(df['severe_stress_pct'].values); labels.append(f'{h} severe'); data.append(df['worst_stress_pct'].values); labels.append(f'{h} worst')
plt.boxplot(data, labels=labels, showfliers=False); plt.xticks(rotation=45,ha='right'); plt.ylabel('Country-industry stress (%)'); plt.title('Country-industry distribution: severe and worst'); plt.tight_layout()
fig_ci_dist=FIG/'fig_country_industry_distribution.png'; plt.savefig(fig_ci_dist,dpi=180); plt.close()
# representatives
ci2m=pd.read_csv(ci_paths['2m'])
rep_defs=[('Korea Index / ETF', lambda d:(d['country_bucket'].str.contains('Korea',case=False,na=False))&(d['client_industry_label'].str.contains('Index|ETF',case=False,na=False))),('Korea Tech Hardware', lambda d:(d['country_bucket'].str.contains('Korea',case=False,na=False))&(d['client_industry_label'].str.contains('Technology Hardware',case=False,na=False))),('Taiwan Tech Hardware', lambda d:(d['country_bucket'].str.contains('Taiwan',case=False,na=False))&(d['client_industry_label'].str.contains('Technology Hardware',case=False,na=False))),('U.S. Tech Hardware', lambda d:(d['country_bucket'].str.contains('United States',case=False,na=False))&(d['client_industry_label'].str.contains('Technology Hardware',case=False,na=False))),('U.S. Software', lambda d:(d['country_bucket'].str.contains('United States',case=False,na=False))&(d['client_industry_label'].str.contains('Software',case=False,na=False)))]
rep=[]
for name,fn in rep_defs:
    sub=ci2m[fn(ci2m)]
    if len(sub):
        r=sub.iloc[0]; rep.append({'row':name,'severe':r['severe_stress_pct'],'worst':r['worst_stress_pct']})
rep_df=pd.DataFrame(rep)
plt.figure(figsize=(8,4.8)); y=np.arange(len(rep_df)); bh=.36
plt.barh(y-bh/2,rep_df['severe'],height=bh,label='severe'); plt.barh(y+bh/2,rep_df['worst'],height=bh,label='worst'); plt.yticks(y,rep_df['row']); plt.xlabel('2-month stress (%)'); plt.title('Representative country-industry rows: 2m severe vs worst'); plt.legend(); plt.tight_layout()
fig_rep=FIG/'fig_representative_ci_2m.png'; plt.savefig(fig_rep,dpi=180); plt.close()
# stock heatmap / bar
st2m=pd.read_csv(st_paths['2m']); order=st2m.sort_values('worst_stress_pct')['ticker'].tolist()
heat=pd.DataFrame({h:pd.read_csv(st_paths[h]).set_index('ticker')['worst_stress_pct'] for h in ['1w','2w','1m','2m']}).loc[order]
plt.figure(figsize=(7,10)); plt.imshow(heat.values,aspect='auto'); plt.xticks(range(4),heat.columns); plt.yticks(range(len(heat)),heat.index)
for i in range(heat.shape[0]):
    for j in range(heat.shape[1]): plt.text(j,i,f'{heat.values[i,j]:.1f}',ha='center',va='center',fontsize=7)
plt.colorbar(label='Worst-case stress (%)'); plt.title('All-20 single-stock overrides: worst-case stress'); plt.tight_layout()
fig_heat=FIG/'fig_all20_worst_heatmap.png'; plt.savefig(fig_heat,dpi=180); plt.close()
plt.figure(figsize=(10,8)); y=np.arange(len(order)); bh=.35; idx=st2m.set_index('ticker').loc[order]
plt.barh(y-bh/2,idx['severe_stress_pct'],height=bh,label='severe'); plt.barh(y+bh/2,idx['worst_stress_pct'],height=bh,label='worst'); plt.yticks(y,order); plt.xlabel('2-month stress (%)'); plt.title('All-20 single-stock overrides: 2m severe vs worst'); plt.legend(); plt.tight_layout()
fig_stock_bar=FIG/'fig_all20_2m_severe_worst.png'; plt.savefig(fig_stock_bar,dpi=180); plt.close()

# ---------- report ----------
anchor_lines=[]
for h in ['1w','2w','1m','2m']:
    sub=scen[scen['horizon']==h].set_index('scenario')
    anchor_lines.append(f"{h} & {sub.loc['base','S_AI_EPICENTER_pct']:.2f} & {sub.loc['severe','S_AI_EPICENTER_pct']:.2f} & {sub.loc['worst','S_AI_EPICENTER_pct']:.2f} & {sub.loc['base','S_WORLD_pct']:.2f} & {sub.loc['base','S_AI_EXCESS_pct']:.2f} " + r'\\')
rep_lines=[f"{esc(r['row'])} & {r['severe']:.1f} & {r['worst']:.1f} " + r'\\' for _,r in rep_df.iterrows()]
stock_lines=[]
for _,r in st2m.sort_values('worst_stress_pct').iterrows():
    sec=r['security_name'] if 'security_name' in r.index and pd.notna(r['security_name']) else ''
    stock_lines.append(f"{esc(r['ticker'])} & {esc(sec)} & {r['beta_world_stock']:.2f} & {r['final_ai_excess_intensity']:.2f} & {r['severe_stress_pct']:.1f} & {r['worst_stress_pct']:.1f} " + r'\\')

report_tex=BASE/'ai_unwind_short_horizon_all_scenarios_report.tex'
report_pdf=BASE/'ai_unwind_short_horizon_all_scenarios_report.pdf'
tex=[]
tex += [r'\documentclass[10pt]{article}', r'\usepackage{graphicx}', r'\setlength{\parindent}{0pt}', r'\setlength{\parskip}{6pt}', r'\begin{document}']
tex += [r'\title{AI Unwind Stress Framework: Short-Horizon Severe and Worst-Case Extension}', r'\author{Alex Zhang}', r'\date{July 2026}', r'\maketitle']
tex += [r'\section*{Executive summary}', 'This note extends the short-horizon output layer of the AI unwind stress framework. The extension provides mild, base, severe, and worst-case shocks for both the country-industry vector and the all-20 single-stock override vector, and it adds a two-month horizon.', 'The horizons are 1 week, 2 weeks, 1 month, and 2 months, implemented as 5, 10, 21, and 42 trading days. The model equation is unchanged:', r'\[', r'\widehat R_i^{s,h} = \beta_i^W S_W^{s,h} + I_i^{AI} S_X^{s,h}.', r'\]', r'Here $\widehat R_i^{s,h}$ is the stressed log return for row or stock $i$ under scenario $s$ and horizon $h$; $\beta_i^W$ is the row world beta; $I_i^{AI}$ is the final AI-excess intensity; $S_W^{s,h}$ is the broad-market shock; and $S_X^{s,h}$ is the AI/TMT excess shock over the market.', r'The severe case uses the full dot-com short-horizon AI/TMT-excess analogue. The worst case keeps the same broad-market shock but applies $\kappa=1.5$ to the AI/TMT-excess shock.']
tex += [r'\section*{Scenario construction}', 'The short-horizon anchor is measured directly from the dot-com TMT peak rather than by scaling the terminal peak-to-trough shock. Let $t_0$ be the dot-com TMT peak date, and let $t_h$ be the trading date $h$ sessions later. The severe raw components are:', r'\[', r'S_E^h = \log\left(\frac{P_E(t_h)}{P_E(t_0)}\right), \quad S_W^h = \log\left(\frac{P_W(t_h)}{P_W(t_0)}\right), \quad S_X^h = S_E^h - S_W^h.', r'\]', f'The peak date used by this construction is {peak_date.date().isoformat()}.']
tex += [r'\begin{center}', r'\begin{tabular}{lrrrrr}', r'Horizon & Base epicenter & Severe epicenter & Worst epicenter & Base world & Base AI excess \\', r'\hline'] + anchor_lines + [r'\hline', r'\end{tabular}', r'\end{center}']
tex += [r'\begin{figure}[h!]', r'\centering', rf'\includegraphics[width=0.82\textwidth]{{{fig_anchor.as_posix()}}}', r'\caption{Peak-anchored short-horizon scenario ladder across mild, base, severe, and worst.}', r'\end{figure}']
tex += [r'\section*{Country-industry vector results}', r'The country-industry outputs apply the same v5 row-level exposures, using $\beta_i^W=$ \texttt{beta\_world\_cell} and $I_i^{AI}=$ \texttt{final\_ai\_excess\_intensity}. No country or industry exposure is re-estimated in this step; only the scenario shock vector is changed.']
tex += [r'\begin{figure}[h!]', r'\centering', rf'\includegraphics[width=0.94\textwidth]{{{fig_ci_dist.as_posix()}}}', r'\caption{Distribution of country-industry stress across severe and worst cases. Outliers are hidden to make the central distribution readable.}', r'\end{figure}']
tex += [r'\begin{figure}[h!]', r'\centering', rf'\includegraphics[width=0.86\textwidth]{{{fig_rep.as_posix()}}}', r'\caption{Representative two-month country-industry rows under severe and worst cases.}', r'\end{figure}']
tex += [r'\begin{center}', r'\begin{tabular}{lrr}', r'Representative row & 2m severe & 2m worst \\', r'\hline'] + rep_lines + [r'\hline', r'\end{tabular}', r'\end{center}']
tex += [r'\section*{Single-stock override results}', r'The single-stock outputs use the all-20 override universe. The formula remains identical to the country-industry layer, but uses $\beta_i^W=$ \texttt{beta\_world\_stock}.']
tex += [r'\begin{figure}[h!]', r'\centering', rf'\includegraphics[width=0.62\textwidth]{{{fig_heat.as_posix()}}}', r'\caption{Worst-case stress heatmap for the 20 single-stock override rows.}', r'\end{figure}']
tex += [r'\begin{figure}[h!]', r'\centering', rf'\includegraphics[width=0.94\textwidth]{{{fig_stock_bar.as_posix()}}}', r'\caption{Two-month severe versus worst-case single-stock override shocks.}', r'\end{figure}']
tex += [r'\begin{center}', r'\small', r'\begin{tabular}{llrrrr}', r'Ticker & Security & $\beta^W$ & $I^{AI}$ & 2m severe & 2m worst \\', r'\hline'] + stock_lines + [r'\hline', r'\end{tabular}', r'\end{center}']
tex += [r'\section*{Delivered artifacts}', 'The output bundle contains the scenario parameter file, four country-industry CSVs, four all-20 single-stock CSVs, long-form summary files, severe/worst convenience files, figure files, the LaTeX source, this PDF report, and the Python build script.', r'\end{document}']
report_tex.write_text('\n'.join(tex))
os.chdir(BASE)
os.system(f'pdflatex -interaction=nonstopmode {report_tex.name} > /tmp/short_all_scenarios_latex.log 2>&1')
os.system(f'pdflatex -interaction=nonstopmode {report_tex.name} >> /tmp/short_all_scenarios_latex.log 2>&1')

# ---------- bundle ----------
files=[scen_path,ci_long_path,st_long_path,ci_sevw_path,st_sevw_path,report_tex,report_pdf,BASE/'build_short_horizon_all_scenarios.py',fig_anchor,fig_ci_dist,fig_rep,fig_heat,fig_stock_bar]
files += list(ci_paths.values()) + list(st_paths.values())
for f in files:
    f=Path(f)
    if f.exists():
        dst=OUT/f.name
        if f.resolve()!=dst.resolve(): shutil.copy2(f,dst)
zip_path=BASE/'ai_unwind_short_horizon_all_scenarios_bundle.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in OUT.iterdir(): z.write(p,arcname=p.name)
print('Wrote',zip_path)
print('Report',report_pdf,report_pdf.exists())
print(scen[['horizon','scenario','anchor_date','S_WORLD_pct','S_AI_EXCESS_pct','S_AI_EPICENTER_pct']].to_string(index=False))
print('CI rows',len(ci),'stock rows',len(stocks))
