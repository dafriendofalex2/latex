import os, math, shutil, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch, Circle

BASE = Path('/mnt/data')
OUT = BASE / 'ai_unwind_revised_theory_report_bundle'
FIG = OUT / 'figures'
OUT.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)

plt.rcParams['figure.dpi'] = 180
plt.rcParams['font.size'] = 10

# ---------------- helpers ----------------
def savefig(name):
    path = FIG / name
    plt.tight_layout()
    plt.savefig(path, bbox_inches='tight')
    plt.close()
    return path

def tex_escape(s):
    return str(s).replace('\\','\\textbackslash{}').replace('&','\\&').replace('%','\\%').replace('_','\\_').replace('$','\\$').replace('#','\\#')

def read_stooq(path):
    df = pd.read_csv(path)
    df['Date'] = pd.to_datetime(df['Date'])
    df = df.sort_values('Date')
    return df[['Date','Close']].rename(columns={'Close':'close'})

def read_fred_index(path, name):
    df = pd.read_csv(path)
    df['Date'] = pd.to_datetime(df['observation_date'])
    df['close'] = pd.to_numeric(df[name], errors='coerce')
    return df[['Date','close']].dropna().sort_values('Date')

def parse_ff49_daily(path):
    lines = Path(path).read_text(encoding='latin1').splitlines()
    start = None
    for i,l in enumerate(lines):
        if 'Average Value Weighted Returns -- Daily' in l:
            start = i+1
            break
    header = [h.strip() for h in lines[start].split(',')]
    rows=[]
    for l in lines[start+1:]:
        if not l.strip():
            break
        parts=[p.strip() for p in l.split(',')]
        if len(parts)!=len(header):
            continue
        rows.append(parts)
    df=pd.DataFrame(rows, columns=header)
    df.rename(columns={df.columns[0]:'date'}, inplace=True)
    df['date']=pd.to_datetime(df['date'], format='%Y%m%d')
    for c in df.columns[1:]:
        df[c]=pd.to_numeric(df[c], errors='coerce')
    df=df.replace({-99.99:np.nan,-999:np.nan})
    for c in df.columns[1:]:
        df[c]=df[c]/100.0
    return df

def parse_spx(path):
    df=pd.read_csv(path)
    if 'date' in df.columns:
        df['Date']=pd.to_datetime(df['date'], format='%d-%b-%y')
        df['close']=pd.to_numeric(df['close'], errors='coerce')
    else:
        datecol=[c for c in df.columns if c.lower().startswith('date')][0]
        closecol=[c for c in df.columns if c.lower() in ('close','price','close*','close/last')][0]
        df['Date']=pd.to_datetime(df[datecol])
        df['close']=pd.to_numeric(df[closecol], errors='coerce')
    return df[['Date','close']].dropna().sort_values('Date')

def month_log_returns(price_df, end_date='2026-06-30'):
    s = price_df.set_index('Date')['close'].astype(float)
    s = s[s.index <= pd.Timestamp(end_date)]
    m = s.resample('ME').last().dropna()
    return np.log(m / m.shift(1)).dropna()

def ols_slope(y,x):
    x=np.asarray(x); y=np.asarray(y)
    mask=np.isfinite(x)&np.isfinite(y)
    x=x[mask]; y=y[mask]
    xm=x.mean(); ym=y.mean()
    den=((x-xm)**2).sum()
    if den==0: return np.nan
    return ((x-xm)*(y-ym)).sum()/den

# ---------------- load data ----------------
ci = pd.read_csv(BASE/'country_industry_stress_vector_v5(1).csv')
ci_eq = ci[ci['model_scope'].eq('equity_factor_stress')].copy()
sc = pd.read_csv(BASE/'ai_unwind_v5_revised_kappa_short_horizon_scenario_parameters.csv')
ci_long = pd.read_csv(BASE/'ai_unwind_v5_country_industry_revised_kappa_all_scenarios_long.csv')
mc_long = pd.read_csv(BASE/'ai_unwind_v5_country_industry_market_cap_revised_kappa_all_scenarios_long.csv')
mc = pd.read_csv(BASE/'ai_unwind_v5_market_cap_stress_factors_for_client_portfolio.csv')
mc_break = pd.read_csv(BASE/'ai_unwind_v5_market_cap_bucket_breakpoints.csv')
ss = pd.read_csv(BASE/'single_stock_override_vector_v5_all20.csv')
ss_long = pd.read_csv(BASE/'ai_unwind_v5_single_stock_all20_revised_kappa_all_scenarios_long.csv')

order_h = ['1w','2w','1m','2m']
order_s = ['mild','base','severe','extreme','worst']
cap_order = ['micro_small_q1','small_mid_q2','mid_q3','upper_mid_large_q4','large_mega_q5_reference']
cap_label = dict(zip(mc_break['cap_bucket'], mc_break['bucket_label']))

theta_world = float(ci['theta_ai_abs_world_reference'].dropna().iloc[0])
stat_w = float(ci['statistical_weight'].dropna().iloc[0])
econ_w = float(ci['economic_weight'].dropna().iloc[0])
row_count = len(ci)
num_countries = ci['country_bucket'].nunique()
num_industries = ci['client_industry_label'].nunique()

# Current AI basket for orthogonalization illustrations
world = month_log_returns(read_stooq(BASE/'spy_us_d (1).csv'))
ai_components = {}
for k, fname in [('SMH','smh_us_d(3).csv'),('SOXX','soxx_us_d(2).csv'),('IGV','igv_us_d(1).csv'),('SKYY','skyy_us_d(1).csv'),('AIQ','aiq_us_d(1).csv')]:
    ai_components[k] = month_log_returns(read_stooq(BASE/fname))
ai_df = pd.concat(ai_components, axis=1).dropna()
ai_basket = ai_df.mean(axis=1)
factors = pd.concat([world.rename('world'), ai_basket.rename('ai')], axis=1).dropna()
theta_world_reg = ols_slope(factors['ai'], factors['world'])
alpha_world_reg = factors['ai'].mean() - theta_world_reg * factors['world'].mean()
ai_resid = factors['ai'] - (alpha_world_reg + theta_world_reg * factors['world'])
raw_corr = np.corrcoef(factors['world'], factors['ai'])[0,1]
resid_corr = np.corrcoef(factors['world'], ai_resid)[0,1]

# Dot-com anchor paths
ff49 = parse_ff49_daily(BASE/'49_Industry_Portfolios_Daily.csv')
spx = parse_spx(BASE/'spx.csv')
ff49['tmt_simple'] = ff49[['Hardw','Softw','Chips','Telcm']].mean(axis=1)
ff49['tmt_index'] = (1 + ff49['tmt_simple']).cumprod()
peak_window = ff49[(ff49['date'] >= '1998-01-01') & (ff49['date'] <= '2002-12-31')].copy()
peak_idx = peak_window['tmt_index'].idxmax()
peak_date = ff49.loc[peak_idx,'date']
ff49_post = ff49[ff49['date'] >= peak_date].head(43).copy()
ff49_post['day'] = range(len(ff49_post))
ff49_post['tmt_norm'] = 100 * ff49_post['tmt_index'] / ff49_post['tmt_index'].iloc[0]
spx_post = spx[spx['Date'] >= peak_date].head(43).copy()
spx_post['day'] = range(len(spx_post))
spx_post['spx_norm'] = 100 * spx_post['close'] / spx_post['close'].iloc[0]

# Sample shock table
sample_rows = []
proxy_specs = [
    ('World ETF / broad market', 'World Fallback', 'index & ETF'),
    ('S&P 500 / U.S. broad ETF', 'United States', 'index & ETF'),
    ('Japan / Nikkei-type ETF', 'Japan', 'index & ETF'),
    ('Korea ETF', 'Korea', 'index & ETF'),
    ('Taiwan ETF', 'Taiwan', 'index & ETF'),
    ('China ETF', 'China', 'index & ETF'),
    ('Developed Europe ETF', 'Developed Europe Fallback', 'index & ETF'),
]
for label,country,industry in proxy_specs:
    sub = ci_long[(ci_long['country_bucket'].eq(country)) & (ci_long['client_industry_label'].eq(industry))]
    for _,r in sub.iterrows():
        sample_rows.append({
            'sample_proxy': label,
            'country_bucket': country,
            'client_industry_label': industry,
            'short_horizon': r['short_horizon'],
            'scenario': r['scenario'],
            'stress_pct': r['stress_pct'],
            'stress_log': r['stress_log'],
            'source': 'country_industry_index_row',
        })
# Nasdaq / AI epicenter proxy from scenario table
for _,r in sc.iterrows():
    sample_rows.append({
        'sample_proxy': 'NASDAQ / AI epicenter proxy',
        'country_bucket': 'United States',
        'client_industry_label': 'AI/TMT epicenter proxy',
        'short_horizon': r['horizon'],
        'scenario': r['scenario'],
        'stress_pct': r['S_AI_EPICENTER_pct'],
        'stress_log': r['S_AI_EPICENTER_log'],
        'source': 'scenario_epicenter_shock',
    })
sample = pd.DataFrame(sample_rows)
sample.to_csv(BASE/'ai_unwind_sample_index_etf_shocks_for_theory_presentation.csv', index=False)

# ---------------- figures ----------------
# 01 architecture but focused
fig, ax = plt.subplots(figsize=(12.5,6.1))
ax.set_xlim(0,14); ax.set_ylim(0,7); ax.axis('off')
blocks = [
    (0.4,4.8,2.4,1.0,'Return data\nworld, AI basket, ETFs'),
    (0.4,3.2,2.4,1.0,'Economic AI map\ncountry + industry'),
    (0.4,1.6,2.4,1.0,'Dot-com anchor\n1w, 2w, 1m, 2m'),
    (3.4,5.2,2.5,0.9,'Broad market beta\n$\\beta^W$'),
    (3.4,3.8,2.5,0.9,'Raw AI sensitivity\n$\\theta^{AI}$'),
    (3.4,2.4,2.5,0.9,'Orthogonal AI\nexcess intensity'),
    (6.5,4.5,2.6,1.1,'Country-industry\nstress vector'),
    (6.5,2.6,2.6,1.1,'Scenario ladder\n$\\kappa$ scaling'),
    (9.8,5.1,3.0,0.9,'Single-stock override\nfor AI epicenter names'),
    (9.8,3.5,3.0,0.9,'Default row\ncountry x industry'),
    (9.8,1.9,3.0,0.9,'Market-cap overlay\nfor small-cap fragility'),
]
for x,y,w,h,t in blocks:
    ax.add_patch(Rectangle((x,y),w,h,fill=False,linewidth=1.4))
    ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=11)
for a in [(2.8,5.3,3.4,5.65),(2.8,5.3,3.4,4.25),(5.9,4.25,6.5,5.05),(5.9,2.85,6.5,5.05),(2.8,3.7,3.4,2.85),(2.8,2.1,6.5,3.15),(9.1,5.05,9.8,5.55),(9.1,5.05,9.8,3.95),(9.1,3.15,9.8,2.35)]:
    ax.add_patch(FancyArrowPatch((a[0],a[1]),(a[2],a[3]),arrowstyle='->',mutation_scale=12,linewidth=1.2))
ax.text(7,6.65,'Model construction: one consistent chain from data to stress vectors',ha='center',fontsize=15,weight='bold')
ax.text(7,6.30,'Central idea: isolate the AI/TMT excess factor first, then apply it only where the exposure exists.',ha='center',fontsize=10.5)
savefig('01_model_construction_flow.png')

# 02 orthogonalization geometry
fig, ax = plt.subplots(figsize=(8.5,6))
ax.scatter(factors['world'], factors['ai'], s=14, alpha=0.55)
xx = np.linspace(factors['world'].min(), factors['world'].max(), 100)
yy = alpha_world_reg + theta_world_reg * xx
ax.plot(xx, yy, linewidth=1.4)
# pick a point with visible residual
idx = (factors['ai'] - (alpha_world_reg + theta_world_reg*factors['world'])).abs().sort_values(ascending=False).index[2]
x0 = factors.loc[idx,'world']; y0=factors.loc[idx,'ai']; yhat=alpha_world_reg+theta_world_reg*x0
ax.plot([x0,x0],[yhat,y0], linestyle='--', linewidth=1.2)
ax.text(x0, (y0+yhat)/2, ' residual\nAI-excess', fontsize=9, va='center')
ax.set_xlabel('World monthly log return')
ax.set_ylabel('AI basket monthly log return')
ax.set_title('Orthogonalization: AI basket = market-driven AI + residual AI-excess')
ax.text(0.02,0.95, f'Raw correlation = {raw_corr:.2f}\nResidual correlation = {resid_corr:.2f}', transform=ax.transAxes, va='top', bbox=dict(fill=False, linewidth=0.8))
savefig('02_orthogonalization_geometry.png')

# 03 raw vs residual two panels
fig, axes = plt.subplots(1,2,figsize=(11.5,4.9))
axes[0].scatter(factors['world'], factors['ai'], s=14, alpha=0.6)
axes[0].plot(xx, yy, linewidth=1.2)
axes[0].set_title('Before: raw AI basket still moves with the market')
axes[0].set_xlabel('World monthly log return'); axes[0].set_ylabel('Raw AI basket return')
axes[1].scatter(factors['world'], ai_resid, s=14, alpha=0.6)
axes[1].axhline(0, linewidth=1.2)
axes[1].set_title('After: residual AI-excess is approximately market-neutral')
axes[1].set_xlabel('World monthly log return'); axes[1].set_ylabel('Residual AI-excess return')
savefig('03_before_after_residualization.png')

# 04 correlation before and after
fig, ax = plt.subplots(figsize=(7.3,4.7))
ax.bar(['Raw AI basket\nvs world','Orthogonal AI residual\nvs world'], [raw_corr, resid_corr])
ax.axhline(0, color='black', linewidth=0.8)
for i,v in enumerate([raw_corr, resid_corr]):
    ax.text(i, v+(0.03 if v>=0 else -0.08), f'{v:.2f}', ha='center', fontsize=11)
ax.set_ylabel('Correlation')
ax.set_title('Market co-movement is removed from the AI factor')
savefig('04_correlation_before_after.png')

# 05 theta decomposition scatter
cidf = ci_eq[['country_bucket','client_industry_label','beta_world_cell','theta_ai_abs_cell','final_ai_excess_intensity','cell_stat_ai_excess_intensity','cell_economic_ai_intensity']].dropna().copy()
cidf['market_explained_ai'] = cidf['beta_world_cell'] * theta_world
cidf['residual_ai_numerator'] = cidf['theta_ai_abs_cell'] - cidf['market_explained_ai']
fig, ax = plt.subplots(figsize=(8.5,5.9))
ax.scatter(cidf['market_explained_ai'], cidf['theta_ai_abs_cell'], s=11, alpha=0.55)
mn=min(cidf['market_explained_ai'].min(),cidf['theta_ai_abs_cell'].min())
mx=max(cidf['market_explained_ai'].max(),cidf['theta_ai_abs_cell'].max())
ax.plot([mn,mx],[mn,mx], linestyle='--', linewidth=1)
ann=cidf.sort_values('residual_ai_numerator', ascending=False).head(8)
for _,r in ann.iterrows():
    ax.text(r['market_explained_ai']+0.006,r['theta_ai_abs_cell']+0.006,f"{r['country_bucket']} / {r['client_industry_label'][:15]}",fontsize=6.5)
ax.set_xlabel('AI sensitivity explained by market beta: $\\beta^W\\theta_W^{AI}$')
ax.set_ylabel('Observed absolute AI sensitivity: $\\theta^{AI}$')
ax.set_title('Cross-sectional orthogonalization: what remains after market-driven AI sensitivity?')
savefig('05_theta_decomposition.png')

# 06 exposure map country-industry
fig, ax = plt.subplots(figsize=(8.3,5.8))
ax.scatter(cidf['beta_world_cell'], cidf['final_ai_excess_intensity'], s=11, alpha=0.55)
ann=cidf.sort_values('final_ai_excess_intensity', ascending=False).head(9)
for _,r in ann.iterrows():
    ax.text(r['beta_world_cell']+0.008,r['final_ai_excess_intensity']+0.005,f"{r['country_bucket']} / {r['client_industry_label'][:14]}", fontsize=6.5)
ax.set_xlabel('Broad-market beta $\\beta^W$')
ax.set_ylabel('Final AI-excess intensity $I^{AI}$')
ax.set_title('Final country-industry exposure map')
savefig('06_country_industry_exposure_map.png')

# 07 stat vs econ scatter
fig, ax = plt.subplots(figsize=(8.3,5.8))
ax.scatter(cidf['cell_stat_ai_excess_intensity'], cidf['cell_economic_ai_intensity'], s=11, alpha=0.55)
ann=cidf.sort_values('final_ai_excess_intensity', ascending=False).head(9)
for _,r in ann.iterrows():
    ax.text(r['cell_stat_ai_excess_intensity']+0.006,r['cell_economic_ai_intensity']+0.006,f"{r['country_bucket']} / {r['client_industry_label'][:14]}", fontsize=6.5)
ax.set_xlabel('Statistical residual AI intensity')
ax.set_ylabel('Economic AI relevance')
ax.set_title('Why the model combines measured sensitivity with economic relevance')
savefig('07_statistical_vs_economic.png')

# 08 dotcom anchor path
fig, ax = plt.subplots(figsize=(8.7,5.4))
ax.plot(ff49_post['day'], ff49_post['tmt_norm'], label='Dot-com TMT proxy')
ax.plot(spx_post['day'], spx_post['spx_norm'], label='S&P 500')
for x,lab in [(5,'1w'),(10,'2w'),(21,'1m'),(42,'2m')]:
    ax.axvline(x, linestyle='--', linewidth=1)
    ax.text(x, ax.get_ylim()[0]+1, lab, ha='center', va='bottom', fontsize=9)
ax.set_title('Dot-com anchor path used for short-horizon shock calibration')
ax.set_xlabel('Trading days after TMT peak (%s)' % peak_date.date().isoformat())
ax.set_ylabel('Index level, peak = 100')
ax.legend(fontsize=9)
savefig('08_dotcom_anchor_path.png')

# 09 scenario ladder
plotdf = sc.pivot(index='horizon', columns='scenario', values='S_AI_EPICENTER_pct').loc[order_h, order_s]
fig, ax = plt.subplots(figsize=(9.4,5.3))
x=np.arange(len(order_h)); width=0.15
for i,s in enumerate(order_s):
    ax.bar(x+(i-2)*width, plotdf[s], width=width, label=s)
ax.axhline(0,color='black',linewidth=0.8)
ax.set_xticks(x); ax.set_xticklabels(order_h)
ax.set_ylabel('AI epicenter shock (%)')
ax.set_title('Scenario ladder: total AI epicenter shock by horizon')
ax.legend(ncol=5, fontsize=8)
savefig('09_scenario_ladder.png')

# 10 scenario decomposition 2m
plotdf2 = sc[sc['horizon']=='2m'].set_index('scenario').loc[order_s]
fig, ax = plt.subplots(figsize=(8.7,5.2))
world_comp = plotdf2['S_WORLD_pct'].values
ai_comp = plotdf2['S_AI_EXCESS_pct'].values
ax.bar(order_s, world_comp, label='Broad-market component')
ax.bar(order_s, ai_comp, bottom=world_comp, label='AI/TMT-excess component')
ax.set_ylabel('Shock contribution (%)')
ax.set_title('2-month scenario decomposition: market plus AI/TMT excess')
ax.legend(fontsize=9)
savefig('10_2m_decomposition.png')

# 11 kappa sensitivity using 2m sample intensities
kappas=np.linspace(0,2.0,81)
base_2m=sc[(sc['horizon']=='2m') & (sc['scenario']=='severe')].iloc[0]
S_WORLD=base_2m['S_WORLD_log']; S_X_raw=base_2m['S_AI_EXCESS_log'] # severe raw is full dotcom excess
intensities=[0.1,0.3,0.6,1.0]
fig, ax=plt.subplots(figsize=(8.6,5.2))
for I in intensities:
    stress=np.exp(1.0*S_WORLD + I*(kappas*S_X_raw))-1
    ax.plot(kappas, stress*100, label=f'AI intensity {I:.1f}')
for k,lab in [(0.670739,'base'),(1.0,'severe'),(1.5,'extreme'),(2.0,'worst')]:
    ax.axvline(k, linestyle='--', linewidth=0.9)
    ax.text(k, ax.get_ylim()[0]+1, lab, rotation=90, va='bottom', ha='right', fontsize=8)
ax.set_xlabel('AI/TMT-excess severity scalar $\\kappa$')
ax.set_ylabel('2m simple stress return (%)')
ax.set_title('Why scenario severity matters most for high-AI-intensity assets')
ax.legend(fontsize=8)
savefig('11_kappa_sensitivity.png')

# 12 sample shock heatmap 2m proxies x scenarios
samp_2m = sample[sample['short_horizon']=='2m'].copy()
proxy_order = ['World ETF / broad market','S&P 500 / U.S. broad ETF','Developed Europe ETF','Japan / Nikkei-type ETF','China ETF','Korea ETF','Taiwan ETF','NASDAQ / AI epicenter proxy']
mat = samp_2m.pivot(index='sample_proxy', columns='scenario', values='stress_pct').loc[proxy_order, order_s]
fig, ax = plt.subplots(figsize=(9.5,5.8))
im = ax.imshow(mat.values, aspect='auto')
ax.set_xticks(np.arange(len(order_s))); ax.set_xticklabels(order_s)
ax.set_yticks(np.arange(len(proxy_order))); ax.set_yticklabels(proxy_order, fontsize=8)
for i in range(mat.shape[0]):
    for j in range(mat.shape[1]):
        ax.text(j,i,f'{mat.values[i,j]:.1f}',ha='center',va='center',fontsize=8)
ax.set_title('Sample index / ETF shocks: 2-month horizon (%)')
plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label='Stress return (%)')
savefig('12_sample_shocks_heatmap_2m.png')

# 13 sample 2m grouped bars
fig, ax = plt.subplots(figsize=(10,5.7))
x=np.arange(len(proxy_order)); width=0.15
for i,s in enumerate(order_s):
    ax.bar(x+(i-2)*width, mat[s], width=width, label=s)
ax.set_xticks(x); ax.set_xticklabels([p.replace(' / ','\n') for p in proxy_order], rotation=0, fontsize=7)
ax.set_ylabel('2m stress (%)')
ax.set_title('Sample shocks under mild/base/severe/extreme/worst')
ax.legend(ncol=5, fontsize=8)
savefig('13_sample_shocks_grouped_2m.png')

# 14 sample shocks by horizon under worst
samp_worst = sample[sample['scenario']=='worst'].pivot(index='short_horizon', columns='sample_proxy', values='stress_pct').loc[order_h, proxy_order]
fig, ax = plt.subplots(figsize=(9.5,5.4))
for proxy in proxy_order:
    ax.plot(order_h, samp_worst[proxy], marker='o', label=proxy)
ax.set_ylabel('Worst-case stress (%)')
ax.set_title('Sample shocks by horizon under worst case')
ax.legend(fontsize=7, ncol=2)
savefig('14_sample_shocks_by_horizon_worst.png')

# 15 1m sample shocks grouped severe/extreme/worst
samp_1m = sample[(sample['short_horizon']=='1m') & (sample['scenario'].isin(['severe','extreme','worst']))].pivot(index='sample_proxy', columns='scenario', values='stress_pct').loc[proxy_order, ['severe','extreme','worst']]
fig, ax = plt.subplots(figsize=(9.6,5.6))
x=np.arange(len(proxy_order)); width=0.24
for i,s in enumerate(['severe','extreme','worst']):
    ax.bar(x+(i-1)*width, samp_1m[s], width=width, label=s)
ax.set_xticks(x); ax.set_xticklabels([p.replace(' / ','\n') for p in proxy_order], fontsize=7)
ax.set_ylabel('1m stress (%)')
ax.set_title('Sample 1-month shocks: severe, extreme, worst')
ax.legend(ncol=3, fontsize=8)
savefig('15_sample_shocks_1m.png')

# 16 international ETF worst rank at 2m (not AI epicenter)
rank = samp_2m[(samp_2m['scenario']=='worst') & (~samp_2m['sample_proxy'].eq('NASDAQ / AI epicenter proxy'))].sort_values('stress_pct')
fig, ax = plt.subplots(figsize=(8.5,5.2))
ax.barh(rank['sample_proxy'], rank['stress_pct'])
ax.set_xlabel('2m worst stress (%)')
ax.set_title('International / broad ETF sample ranking under 2m worst case')
for i,v in enumerate(rank['stress_pct']):
    ax.text(v-0.3, i, f'{v:.1f}', va='center', ha='right', fontsize=8)
savefig('16_international_etf_worst_rank.png')

# 17 single stock 2m worst shocks
ss2 = ss_long[(ss_long['short_horizon']=='2m') & (ss_long['scenario']=='worst')].sort_values('stress_pct').head(15)
fig, ax=plt.subplots(figsize=(8.5,5.3))
ax.barh(ss2['ticker'], ss2['stress_pct'])
ax.set_xlabel('2m worst stress (%)')
ax.set_title('Single-stock override examples: 2m worst shocks')
for i,v in enumerate(ss2['stress_pct']):
    ax.text(v-0.5, i, f'{v:.1f}', va='center', ha='right', fontsize=7)
savefig('17_single_stock_2m_worst.png')

# 18 market cap overlay worst
fig, ax=plt.subplots(figsize=(8.8,5.3))
for cb in cap_order:
    sub=mc[(mc['cap_bucket']==cb) & (mc['scenario']=='worst')].set_index('horizon').loc[order_h]
    ax.plot(order_h, sub['size_overlay_pct'], marker='o', label=cap_label[cb])
ax.axhline(0,color='black',linewidth=0.8)
ax.set_ylabel('Additional size overlay (%)')
ax.set_title('Market-cap overlay: large-cap unchanged, smaller-cap more severe')
ax.legend(fontsize=7, loc='lower left')
savefig('18_market_cap_overlay_worst.png')

# 19 Korea bucket example 2m worst/base
example = mc_long[(mc_long['country_bucket']=='Korea') & (mc_long['client_industry_label']=='technology hardware & storage &peripheral') & (mc_long['short_horizon']=='2m') & (mc_long['scenario'].isin(['base','severe','extreme','worst']))].copy()
example['bucket_order']=example['market_cap_bucket'].map({c:i for i,c in enumerate(cap_order)})
fig, ax=plt.subplots(figsize=(9.5,5.4))
x=np.arange(len(cap_order)); width=0.2
for i,s in enumerate(['base','severe','extreme','worst']):
    sub=example[example['scenario']==s].set_index('market_cap_bucket').loc[cap_order]
    ax.bar(x+(i-1.5)*width, sub['stress_pct'], width=width, label=s)
ax.set_xticks(x); ax.set_xticklabels([cap_label[c].replace(' / ','\n') for c in cap_order], fontsize=7)
ax.set_ylabel('2m final stress (%)')
ax.set_title('Worked example: Korea technology hardware by market-cap bucket')
ax.legend(ncol=4, fontsize=8)
savefig('19_korea_market_cap_example.png')

# 20 production hierarchy
fig, ax = plt.subplots(figsize=(10.5,5.5))
ax.set_xlim(0,10); ax.set_ylim(0,6); ax.axis('off')
items=[(0.6,4.4,2.4,0.9,'Position\n(country, industry, ticker, cap)'),(4.0,4.4,2.2,0.9,'Ticker in override\nset?'),(7.1,5.0,2.2,0.8,'Use single-stock\nstress'),(7.1,3.8,2.2,0.8,'Use country-industry\nstress'),(4.0,2.4,2.2,0.9,'Market-cap\nbucket?'),(7.1,2.4,2.2,0.8,'Add size overlay'),(4.0,0.9,2.2,0.8,'Convert log shock\nto P&L')]
for x,y,w,h,t in items:
    ax.add_patch(Rectangle((x,y),w,h,fill=False,linewidth=1.4))
    ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=11)
for a in [(3.0,4.85,4.0,4.85),(6.2,4.85,7.1,5.4),(6.2,4.85,7.1,4.2),(8.2,3.8,5.1,3.3),(8.2,5.0,5.1,3.3),(6.2,2.85,7.1,2.85),(5.1,2.4,5.1,1.7)]:
    ax.add_patch(FancyArrowPatch((a[0],a[1]),(a[2],a[3]),arrowstyle='->',mutation_scale=12,linewidth=1.2))
ax.text(5,5.75,'How the final production shock is selected',ha='center',fontsize=15,weight='bold')
savefig('20_production_hierarchy.png')

# 21 additivity logic
fig, ax=plt.subplots(figsize=(10,4.6))
ax.axis('off'); ax.set_xlim(0,10); ax.set_ylim(0,4)
segments=[(0.5,1.6,2.2,0.8,'Broad market\n$\\beta^W S_W$'),(3.2,1.6,2.2,0.8,'AI/TMT excess\n$I^{AI}S_X$'),(5.9,1.6,2.2,0.8,'Market-cap overlay\n$A_m$')]
for x,y,w,h,t in segments:
    ax.add_patch(Rectangle((x,y),w,h,fill=False,linewidth=1.4))
    ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=12)
for x in [2.85,5.55,8.35]:
    ax.text(x,2.0,'+',ha='center',va='center',fontsize=20)
ax.text(9.0,2.0,'= final\nlog stress',ha='center',va='center',fontsize=12)
ax.text(5,3.4,'Log-space additivity keeps the pieces interpretable',ha='center',fontsize=15,weight='bold')
ax.text(5,0.8,'After addition, convert to simple return:  stress simple = exp(stress log) - 1.',ha='center',fontsize=11)
savefig('21_log_additivity.png')

# 22 validation/coherence: final vs country-industry with cap overlay
valid = mc_long[(mc_long['short_horizon']=='2m') & (mc_long['scenario']=='worst')].copy()
sample_valid = valid.sample(min(3000,len(valid)), random_state=1)
fig, ax=plt.subplots(figsize=(7.8,5.5))
ax.scatter(sample_valid['country_industry_stress_pct'], sample_valid['stress_pct'], s=6, alpha=0.35)
mn=min(sample_valid['country_industry_stress_pct'].min(),sample_valid['stress_pct'].min())
mx=max(sample_valid['country_industry_stress_pct'].max(),sample_valid['stress_pct'].max())
ax.plot([mn,mx],[mn,mx], linestyle='--', linewidth=1)
ax.set_xlabel('Country-industry stress (%)')
ax.set_ylabel('After market-cap overlay (%)')
ax.set_title('Validation: market-cap overlay never makes stress less severe')
savefig('22_overlay_validation.png')

# 23 formula pipeline diagram
fig, ax=plt.subplots(figsize=(12,4.6))
ax.axis('off'); ax.set_xlim(0,12); ax.set_ylim(0,4)
steps=[('Raw returns','measure\n$\\beta^W$, $\\theta^{AI}$'),('Orthogonalization','remove\nmarket-driven AI'),('AI intensity','blend statistical\n+ economic'),('Scenario','dot-com anchor\n+ $\\kappa$'),('Output','stress vector\n+ overlays')]
for i,(t,sub) in enumerate(steps):
    x=0.4+i*2.3
    ax.add_patch(Circle((x+0.7,2.3),0.55,fill=False,linewidth=1.4))
    ax.text(x+0.7,2.3,str(i+1),ha='center',va='center',fontsize=14,weight='bold')
    ax.text(x+0.7,1.35,t,ha='center',fontsize=11,weight='bold')
    ax.text(x+0.7,0.78,sub,ha='center',fontsize=9)
    if i<4:
        ax.add_patch(FancyArrowPatch((x+1.3,2.3),(x+2.1,2.3),arrowstyle='->',mutation_scale=12,linewidth=1.2))
ax.text(6,3.55,'The model is convincing because each stage has a defined statistical role',ha='center',fontsize=15,weight='bold')
savefig('23_theory_pipeline.png')

# ---------------- tables ----------------
scenario_rows=[]
for h in order_h:
    sub=sc[sc['horizon']==h].set_index('scenario').loc[order_s]
    scenario_rows.append(f"{h} & {int(sub.iloc[0]['horizon_trading_days'])} & " + ' & '.join([f"{sub.loc[s,'S_AI_EPICENTER_pct']:.2f}" for s in order_s]) + r" \\")

sample_2m_rows=[]
for proxy in proxy_order:
    sub=mat.loc[proxy]
    sample_2m_rows.append(tex_escape(proxy) + ' & ' + ' & '.join([f"{sub[s]:.2f}" for s in order_s]) + r" \\")

cap_rows=[]
for _,r in mc_break.iterrows():
    cap_rows.append(f"{tex_escape(r['bucket_label'])} & {r['percentile_range']} & {tex_escape(r['current_range_label'])} \\")

# ---------------- latex ----------------
tex_path = BASE/'ai_unwind_revised_theory_orthogonalization_and_sample_shocks.tex'
pdf_path = BASE/'ai_unwind_revised_theory_orthogonalization_and_sample_shocks.pdf'
fig = lambda name: (FIG/name).as_posix()

latex = r'''
\documentclass[11pt]{article}
\usepackage{graphicx}
\usepackage{amsmath}
\usepackage{array}
\usepackage{longtable}
\setlength{\parindent}{0pt}
\setlength{\parskip}{0.62em}
\begin{document}
\title{AI Unwind Stress Framework: Orthogonalized Theory and Sample Shocks}
\author{Prepared for Senior Management}
\date{July 2026}
\maketitle

\section*{Executive summary}
This report is a theory-first explanation of the AI unwind stress framework. It focuses on the part that makes the model defensible: the model does not simply say that technology stocks are risky and then assign large losses. It separates broad equity-market risk from AI/TMT-specific excess risk, estimates the two pieces separately, and then recombines them into implementable stress vectors.

The central equation is
\[
R_{b,g}^{s,h} = \beta_{b,g}^{W}S_W^{s,h} + I_{b,g}^{AI}S_X^{s,h}.
\]
This says that a country-industry bucket loses money through two channels: a broad-market channel and an AI/TMT-excess channel. The first channel is controlled by $\beta^W$. The second channel is controlled by $I^{AI}$. The key theoretical step is the construction of $I^{AI}$ using orthogonalization. Orthogonalization asks: after removing the part of AI-basket movement that is just the market, how much true AI/TMT excess exposure remains?

This matters because a raw AI regression would double count market risk. The AI basket rises and falls partly because all equities rise and fall. If that common market component is not removed, then a high-beta stock or country can look AI-sensitive even when it is mostly just market-sensitive. The orthogonalized framework avoids that mistake.

\begin{figure}[h!]
\centering
\includegraphics[width=0.98\textwidth]{FIG01}
\caption{The full model construction chain. The central statistical operation is orthogonalization: raw AI sensitivity is split into market-driven AI sensitivity and residual AI/TMT-excess sensitivity.}
\end{figure}

\clearpage
\section{What the model is trying to prove}
A senior decision-maker should be able to ask three questions about this model.

First, is the model actually measuring AI unwind risk, or is it just re-labeling ordinary equity beta as AI beta? Second, can the model explain why Taiwan semiconductors, U.S. software, Korea hardware, and broad Japan indices receive different shocks? Third, can the outputs be applied consistently to real portfolios?

The framework is designed to answer all three. It is not a one-factor equity drawdown model. It is also not a purely judgmental sector haircut model. It is a structured two-factor stress model:
\[
\text{equity stress} = \text{general market selloff} + \text{AI/TMT excess selloff}.
\]
The statistical role of the model is to determine how much of each bucket belongs to each side of that decomposition.

\section{Why a one-factor model is not enough}
Suppose we only used the broad-market factor. Then all equities would fall mainly according to market beta. That would correctly capture the fact that risky assets fall in a market shock, but it would miss the core story of an AI bubble unwind: the AI/TMT complex should underperform the market.

Suppose instead we used only an AI basket. That also fails, because the AI basket itself contains broad-market risk. When the market falls, AI stocks fall partly because they are equities, not only because they are AI stocks. Therefore a raw AI factor combines two things that must be separated:
\[
\text{raw AI basket} = \text{market component} + \text{AI/TMT excess component}.
\]
The model is good because it separates these two effects before assigning shocks.

\begin{figure}[h!]
\centering
\includegraphics[width=0.88\textwidth]{FIG02}
\caption{Orthogonalization in one picture. The fitted line is the part of the AI basket explained by the world market. The vertical residual is the AI/TMT-excess movement that remains after market movement is removed.}
\end{figure}

\section{The orthogonalization step}
Let $r_{W,t}$ be the broad-market return at time $t$, and let $r_{A,t}$ be the raw AI basket return. The first regression is
\[
r_{A,t} = a_A + \theta_W^{AI} r_{W,t} + x_t.
\]
Here $x_t$ is the residual AI/TMT-excess factor. By construction, $x_t$ is the part of the AI basket that is not explained by the market. In ordinary least squares, the residual is orthogonal to the regressor, so it has no linear correlation with the market in the fitted sample:
\[
\sum_t r_{W,t}x_t = 0.
\]

This is the formal reason the approach works. We can now stress the market and the AI/TMT excess component separately without double counting the same market shock twice.

The same idea can be written as a projection. The AI basket is projected onto the market factor, and the residual is the perpendicular component:
\[
r_A = \operatorname{Proj}(r_A|r_W) + x.
\]
The projection is the market-driven part. The residual $x$ is the orthogonal AI-excess part.

\begin{figure}[h!]
\centering
\includegraphics[width=0.98\textwidth]{FIG03}
\caption{Before and after residualization. The raw AI basket has visible market co-movement. After removing the market-fitted component, the residual AI-excess factor is centered around zero and has very low market correlation.}
\end{figure}

\begin{figure}[h!]
\centering
\includegraphics[width=0.72\textwidth]{FIG04}
\caption{The raw AI basket is correlated with the world market. The orthogonal AI residual is not. This is the statistical justification for treating market stress and AI-excess stress as separate terms.}
\end{figure}

\clearpage
\section{How orthogonalization becomes an exposure score}
For every country-industry bucket, the model estimates two raw sensitivities. The first is broad-market sensitivity:
\[
r_{b,g,t} = a_{b,g}^{W}+\beta_{b,g}^{W}r_{W,t}+\epsilon_{b,g,t}^{W}.
\]
The second is raw AI-basket sensitivity:
\[
r_{b,g,t} = a_{b,g}^{AI}+\theta_{b,g}^{AI}r_{A,t}+\epsilon_{b,g,t}^{AI}.
\]
But $\theta_{b,g}^{AI}$ is not yet the final AI exposure, because some of it is just ordinary market beta showing up through the AI basket. If the world market itself has AI sensitivity $\theta_W^{AI}$, then a bucket with market beta $\beta_{b,g}^{W}$ would be expected to have AI sensitivity
\[
\beta_{b,g}^{W}\theta_W^{AI}
\]
just from being exposed to the market.

Therefore the residual AI sensitivity is
\[
\theta_{b,g}^{AI}-\beta_{b,g}^{W}\theta_W^{AI}.
\]
The production intensity rescales that residual by the amount of AI-basket movement not explained by the market:
\[
I_{b,g}^{stat}=
\frac{\theta_{b,g}^{AI}-\beta_{b,g}^{W}\theta_W^{AI}}{1-\theta_W^{AI}}.
\]
In the current implementation, $\theta_W^{AI}=THETAWORLD$. This means that only the residual portion of AI sensitivity is assigned to the AI/TMT-excess leg.

This is the most important construction in the model. A high-beta non-AI sector should not receive a high AI shock merely because it is volatile. Conversely, an AI-linked sector should receive an extra shock only to the extent that its AI sensitivity remains after the market piece is removed.

\begin{figure}[h!]
\centering
\includegraphics[width=0.86\textwidth]{FIG05}
\caption{Observed AI sensitivity versus market-explained AI sensitivity. Points above the diagonal have residual AI/TMT-excess sensitivity. The model uses this residual, not the raw sensitivity, to build the AI-excess intensity.}
\end{figure}

\section{Why this is economically sensible}
The orthogonalized factor has the right economic interpretation. In an AI bubble unwind, the first question is not whether an asset falls when equities fall. Most equities do. The question is whether the asset falls more because the AI/TMT trade is specifically unwinding.

That is why the model uses two separate loadings:
\[
\beta^W \quad \text{for market risk}, \qquad I^{AI} \quad \text{for AI/TMT-excess risk}.
\]
A defensive non-AI sector can have low $\beta^W$ and low $I^{AI}$. A cyclical but non-AI sector can have high $\beta^W$ but low $I^{AI}$. A core AI sector can have both high $\beta^W$ and high $I^{AI}$. This is exactly the cross-sectional behavior we want.

\begin{figure}[h!]
\centering
\includegraphics[width=0.86\textwidth]{FIG06}
\caption{The final exposure map. The model differentiates market-sensitive sectors from AI-excess-sensitive sectors. The upper-right area is where the most concentrated AI-unwind stress appears.}
\end{figure}

\section{Why statistical exposure is blended with economic relevance}
The statistical residual is necessary, but it is not sufficient. Financial time series are noisy; some sectors have short histories, thin proxy coverage, or changing business mix. The model therefore blends the statistical residual AI exposure with an economic AI relevance score:
\[
I_{b,g}^{AI}=w_s I_{b,g}^{stat}+w_e I_{b,g}^{econ}.
\]
The current weights are $w_s=STATW$ and $w_e=ECONW$.

This is not a weakness of the model. It is a governance feature. The statistical component prevents arbitrary hand-waving. The economic component prevents the model from blindly trusting noisy regressions. The blend makes the output both data-driven and economically interpretable.

\begin{figure}[h!]
\centering
\includegraphics[width=0.86\textwidth]{FIG07}
\caption{Statistical residual AI intensity versus economic AI relevance. The final intensity uses both. This avoids treating the regression as a black box while still grounding the model in market data.}
\end{figure}

\clearpage
\section{How the scenario shock is calibrated}
The model needs shock sizes for several horizons. It uses the dot-com unwind as the historical anchor because that period is the closest large-scale technology valuation unwind in modern equity data.

For a horizon $h$, the broad-market shock is
\[
S_W^h=\log\left(\frac{P_W(t_h)}{P_W(t_0)}\right),
\]
and the AI/TMT epicenter shock is
\[
S_E^h=\log\left(\frac{P_E(t_h)}{P_E(t_0)}\right).
\]
The AI/TMT-excess shock is therefore
\[
S_X^h=S_E^h-S_W^h.
\]
This is again the same logic as orthogonalization: separate the common market fall from the technology-specific underperformance.

\begin{figure}[h!]
\centering
\includegraphics[width=0.88\textwidth]{FIG08}
\caption{Dot-com anchor path. The TMT proxy falls faster than the broad market. The difference between the two lines is the historical AI/TMT-excess shock used to scale scenarios.}
\end{figure}

Scenario severity is controlled through $\kappa$:
\[
S_X^{s,h}=\kappa_s S_X^h.
\]
Mild applies a partial version of the base case. Base uses the valuation-calibrated scalar. Severe uses full dot-com AI/TMT excess. Extreme uses $\kappa=1.5$. Worst uses $\kappa=2.0$.

\begin{center}
\small
\begin{tabular}{lrrrrrr}
Horizon & Days & Mild & Base & Severe & Extreme & Worst \\
\hline
SCENARIOTABLE
\hline
\end{tabular}
\end{center}
The table reports total AI epicenter shocks in percent.

\begin{figure}[h!]
\centering
\includegraphics[width=0.88\textwidth]{FIG09}
\caption{Scenario ladder across horizons. The key distinction between base, severe, extreme, and worst is the amount of AI/TMT-excess shock applied.}
\end{figure}

\begin{figure}[h!]
\centering
\includegraphics[width=0.84\textwidth]{FIG10}
\caption{For the 2-month horizon, the broad-market leg is fixed across base, severe, extreme, and worst. The AI/TMT-excess leg is what scales with scenario severity.}
\end{figure}

\begin{figure}[h!]
\centering
\includegraphics[width=0.84\textwidth]{FIG11}
\caption{Kappa sensitivity. Assets with higher AI intensity are much more sensitive to the scenario ladder because they load more strongly on the AI/TMT-excess leg.}
\end{figure}

\clearpage
\section{From theory to production outputs}
The theory leads to three production objects.

First, the country-industry vector is the default mapping object. It contains ROWCOUNT country-industry rows across NUMCOUNTRIES country buckets and NUMINDUSTRIES client-facing industry labels. Second, the single-stock override layer replaces the generic country-industry row for selected AI-concentrated stocks. Third, the market-cap overlay adds a small-cap fragility adjustment when the same country-industry shock should be more severe for smaller companies.

The final country-industry-market-cap equation is
\[
R_{b,g,m}^{s,h}=\beta_{b,g}^{W}S_W^{s,h}+I_{b,g}^{AI}S_X^{s,h}+A_m^{s,h},
\]
where $A_m^{s,h}$ is the market-cap overlay. Large-cap and mega-cap names have zero market-cap overlay by construction; smaller buckets receive a negative add-on.

\begin{figure}[h!]
\centering
\includegraphics[width=0.92\textwidth]{FIG20}
\caption{Production hierarchy. A ticker override is used when available; otherwise the country-industry row is used. The market-cap overlay is added only after the factor stress is chosen.}
\end{figure}

\begin{figure}[h!]
\centering
\includegraphics[width=0.90\textwidth]{FIG21}
\caption{All components are added in log-return space. This keeps the market, AI/TMT-excess, and market-cap components separately interpretable before converting to simple return.}
\end{figure}

\section{Sample shocks for presentation use}
The following sample charts are meant to help management understand what the model produces. The country ETF examples use the production index/ETF rows from the country-industry stress vector. The NASDAQ example is shown as an AI/TMT epicenter proxy, because it is intended to illustrate the high-AI-concentration end of the scenario ladder rather than a generic U.S. index row.

\begin{center}
\small
\begin{tabular}{lrrrrr}
Sample proxy & Mild & Base & Severe & Extreme & Worst \\
\hline
SAMPLETABLE
\hline
\end{tabular}
\end{center}
The table reports 2-month sample shocks in percent.

\begin{figure}[h!]
\centering
\includegraphics[width=0.94\textwidth]{FIG12}
\caption{Sample index/ETF shocks at the 2-month horizon. Taiwan, Korea, and the AI epicenter proxy receive much larger shocks because they have more AI/TMT concentration.}
\end{figure}

\begin{figure}[h!]
\centering
\includegraphics[width=0.96\textwidth]{FIG13}
\caption{The same sample shocks as grouped bars. This is a presentation-friendly view of how each scenario changes the magnitude of stress.}
\end{figure}

\begin{figure}[h!]
\centering
\includegraphics[width=0.92\textwidth]{FIG14}
\caption{Worst-case shocks by horizon. The curve steepens most for AI/TMT-heavy proxies.}
\end{figure}

\begin{figure}[h!]
\centering
\includegraphics[width=0.94\textwidth]{FIG15}
\caption{One-month severe, extreme, and worst sample shocks. This is useful when presenting shorter-horizon financing risk rather than long-run valuation downside.}
\end{figure}

\begin{figure}[h!]
\centering
\includegraphics[width=0.86\textwidth]{FIG16}
\caption{International ETF sample ranking under the 2-month worst case. The ranking is driven by both broad-market beta and AI-excess intensity.}
\end{figure}

\clearpage
\section{Single-stock and market-cap examples}
The same theory also explains why single-stock shocks can be materially larger than country-level ETF shocks. A concentrated AI name can have both high market beta and high residual AI-excess intensity. In that case, the single-stock override is not an arbitrary penalty; it is the same two-factor model applied at the ticker level.

\begin{figure}[h!]
\centering
\includegraphics[width=0.86\textwidth]{FIG17}
\caption{Single-stock override examples under the 2-month worst scenario. These shocks are larger because the names are more directly exposed to the AI/TMT-excess leg.}
\end{figure}

The market-cap layer answers a different question. It does not say that small-cap companies are more AI-sensitive. It says that, conditional on the same country-industry stress, smaller companies should receive an additional fragility and liquidity add-on.

\begin{center}
\small
\begin{tabular}{lll}
Bucket & Percentile range & Current range \\
\hline
CAPTABLE
\hline
\end{tabular}
\end{center}

\begin{figure}[h!]
\centering
\includegraphics[width=0.88\textwidth]{FIG18}
\caption{Market-cap overlay. Large-cap and mega-cap names are unchanged. Smaller-cap names receive increasingly negative additional stress.}
\end{figure}

\begin{figure}[h!]
\centering
\includegraphics[width=0.94\textwidth]{FIG19}
\caption{Worked example: Korea technology hardware by market-cap bucket. The country-industry stress is the same, but the smaller-cap buckets receive larger additional stress.}
\end{figure}

\section{Why the full framework is convincing}
The model is convincing because each step has a clear purpose.

\begin{itemize}
\item The broad-market beta captures ordinary equity drawdown risk.
\item Orthogonalization removes market contamination from the raw AI basket.
\item The residual AI/TMT-excess factor captures the part of the unwind that is specific to AI and technology leadership.
\item The cross-sectional AI intensity assigns that residual shock only where the exposure exists.
\item The dot-com anchor provides a disciplined way to size the shock rather than choosing arbitrary haircuts.
\item The scenario scalar $\kappa$ gives management a transparent severity lever.
\item The single-stock and market-cap layers are add-ons, not replacements, so the core theory remains intact.
\end{itemize}

The final P\&L formula is straightforward. Convert log stress to simple stress:
\[
\text{stress simple return}=e^R-1.
\]
Then apply it to signed market value:
\[
\text{stress P\&L}_i=-MV_i(e^{R_i}-1).
\]
This gives a consistent convention: long positions lose money under negative shocks, and short positions benefit unless the risk manager chooses to apply an adverse-only rule.

\begin{figure}[h!]
\centering
\includegraphics[width=0.82\textwidth]{FIG22}
\caption{Validation check. Adding the market-cap overlay never makes a stress less severe than the original country-industry stress.}
\end{figure}

\begin{figure}[h!]
\centering
\includegraphics[width=0.95\textwidth]{FIG23}
\caption{The model is not a loose collection of assumptions. Each stage has a precise statistical or economic role, and each stage feeds directly into the next.}
\end{figure}

\section*{Files included in the bundle}
The bundle includes this PDF, the LaTeX source, all figure files, the build script, and a CSV file containing the sample index/ETF shocks used in the presentation charts.

\end{document}
'''
repls = {
    'FIG01': fig('01_model_construction_flow.png'),
    'FIG02': fig('02_orthogonalization_geometry.png'),
    'FIG03': fig('03_before_after_residualization.png'),
    'FIG04': fig('04_correlation_before_after.png'),
    'FIG05': fig('05_theta_decomposition.png'),
    'FIG06': fig('06_country_industry_exposure_map.png'),
    'FIG07': fig('07_statistical_vs_economic.png'),
    'FIG08': fig('08_dotcom_anchor_path.png'),
    'FIG09': fig('09_scenario_ladder.png'),
    'FIG10': fig('10_2m_decomposition.png'),
    'FIG11': fig('11_kappa_sensitivity.png'),
    'FIG12': fig('12_sample_shocks_heatmap_2m.png'),
    'FIG13': fig('13_sample_shocks_grouped_2m.png'),
    'FIG14': fig('14_sample_shocks_by_horizon_worst.png'),
    'FIG15': fig('15_sample_shocks_1m.png'),
    'FIG16': fig('16_international_etf_worst_rank.png'),
    'FIG17': fig('17_single_stock_2m_worst.png'),
    'FIG18': fig('18_market_cap_overlay_worst.png'),
    'FIG19': fig('19_korea_market_cap_example.png'),
    'FIG20': fig('20_production_hierarchy.png'),
    'FIG21': fig('21_log_additivity.png'),
    'FIG22': fig('22_overlay_validation.png'),
    'FIG23': fig('23_theory_pipeline.png'),
    'THETAWORLD': f'{theta_world:.6f}',
    'STATW': f'{stat_w:.2f}',
    'ECONW': f'{econ_w:.2f}',
    'ROWCOUNT': str(row_count),
    'NUMCOUNTRIES': str(num_countries),
    'NUMINDUSTRIES': str(num_industries),
    'SCENARIOTABLE': '\n'.join(scenario_rows),
    'SAMPLETABLE': '\n'.join(sample_2m_rows),
    'CAPTABLE': '\n'.join(cap_rows),
}
for k,v in repls.items():
    latex = latex.replace(k, v)
tex_path.write_text(latex)

# copy build script into OUT
this_script = BASE/'build_revised_theory_report.py'
# compile
os.chdir(BASE)
for _ in range(2):
    os.system(f'pdflatex -interaction=nonstopmode {tex_path.name} > /tmp/revised_theory.log 2>&1')

# copy files to bundle
for pth in [tex_path, pdf_path, this_script, BASE/'ai_unwind_sample_index_etf_shocks_for_theory_presentation.csv']:
    if pth.exists():
        shutil.copy2(pth, OUT/pth.name)
# copy figures top level? already in FIG inside OUT, include.
zip_path = BASE/'ai_unwind_revised_theory_orthogonalization_and_sample_shocks_bundle.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for pth in OUT.rglob('*'):
        if pth.is_file():
            z.write(pth, arcname=pth.relative_to(OUT))
print('PDF', pdf_path, pdf_path.exists(), pdf_path.stat().st_size if pdf_path.exists() else None)
print('ZIP', zip_path, zip_path.exists(), zip_path.stat().st_size if zip_path.exists() else None)
