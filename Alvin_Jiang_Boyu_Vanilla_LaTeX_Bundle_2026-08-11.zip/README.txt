ALVIN JIANG / BOYU CAPITAL - VANILLA LATEX BUNDLE
Information cut-off: 11 August 2026

Files
- main.tex: source document
- main.pdf: compiled PDF
- source_register.csv: source URLs and research-use notes

Corporate-machine-safe build
  pdflatex main.tex
  pdflatex main.tex

The document intentionally uses no external LaTeX packages:
- no geometry
- no hyperref
- no xcolor
- no booktabs / tabularx / longtable
- no BibTeX / Biber
- no latexmk / Perl
- no shell escape

Only the standard article class and native LaTeX commands are used.
