Korean Global Cross-Holdings - Revised Comprehensive Screen
Cut-off: 12 August 2026
Core threshold: >= US$20m latest defensible stake value / proxy

Files:
- korean_global_crossholdings_master_v2.xlsx
- listed_foreign_holdings_v2.xlsx
- private_foreign_holdings_v2.xlsx
- watchlist_exclusions_v2.xlsx
- main_report.tex
- public_holdings_table.tex
- private_holdings_table.tex
- watchlist_exclusions_table.tex
- sources.tex
- korean_global_crossholdings_report_v2.pdf

Core rows:
- Public/listed: 20
- Private/unlisted: 53
- Watchlist/exclusions: 24

Important:
Private-company values are transaction / financing / invested-capital proxies unless explicitly stated otherwise.
This screen excludes ordinary investment portfolios and organically created foreign branches without a separately identifiable company stake.
