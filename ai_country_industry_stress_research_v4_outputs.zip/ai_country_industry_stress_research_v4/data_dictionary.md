# Data dictionary

`country_industry_stress_vector_v4.csv` key columns:
- `country_bucket`: model country or region bucket.
- `client_industry_label`: original client industry label supplied for the mapping table.
- `industry_bucket`: model industry proxy bucket.
- `beta_world_cell`: market-beta component used in the stress formula.
- `final_ai_excess_intensity`: AI-excess intensity before valuation scaling.
- `valuation_severity_scalar_base`: base valuation severity scalar applied to the AI-excess shock.
- `base_stress_simple`: base simple return shock.
- `base_stress_pct`: base return shock in percentage points.
- `severe_stress_simple`: full dot-com analogue simple return shock.
- `reliability_flag`: A/B/C/D/X mapping quality flag.

`single_stock_override_vector_v4.csv` key columns:
- `ticker`: override ticker.
- `beta_world_stock`: stock market-beta component.
- `final_ai_excess_intensity`: AI-excess intensity before valuation scaling.
- `base_stress_pct`: valuation-adjusted base shock.
- `severe_stress_pct`: full dot-com analogue shock.

`valuation_premium_calibration_inputs.csv`:
- `premium_log`: log AI/TMT valuation premium versus market.
- `premium_ratio`: exp(premium_log).
