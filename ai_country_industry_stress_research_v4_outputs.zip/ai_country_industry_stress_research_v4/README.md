# AI country-industry stress research v4

This package contains the final valuation-calibrated country-industry stress vector, single-stock override vector, report source, figures, and replication code.

Main files:
- `main.pdf`: report.
- `data/country_industry_stress_vector_v4.csv`: merge-ready country-industry stress vector.
- `data/single_stock_override_vector_v4.csv`: single-stock override vector for AI epicenter names.
- `data/scenario_parameters_v4.csv`: mild/base/severe shock assumptions.
- `data/valuation_severity_calibration_summary.csv`: Damodaran valuation calibration.
- `code/apply_stress_to_client_template_v4.py`: template for applying the vector to position data.
- `code/build_ai_country_industry_stress_v4.py`: replication script.

Base valuation severity scalar: 0.671.
