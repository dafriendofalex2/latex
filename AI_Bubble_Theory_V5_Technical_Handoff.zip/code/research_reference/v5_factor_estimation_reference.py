"""
Research-reference implementation for the upstream exposure-estimation layer.

Original V5 consumes audited country and industry coefficient tables produced by
an earlier return-estimation layer; it does not rerun these regressions itself.
This file makes the theory executable for technical review without claiming to
be a byte-identical copy of the original V4 estimator.
"""
import numpy as np
import pandas as pd


def log_returns(prices):
    p = pd.Series(prices, dtype=float)
    return np.log(p).diff().dropna()


def ols_with_intercept(y, x):
    z = pd.concat([pd.Series(y, name='y'), pd.Series(x, name='x')], axis=1).dropna()
    X = np.column_stack([np.ones(len(z)), z['x'].to_numpy()])
    yy = z['y'].to_numpy()
    coef = np.linalg.lstsq(X, yy, rcond=None)[0]
    residual = yy - X @ coef
    return {'alpha': coef[0], 'beta': coef[1], 'residual': pd.Series(residual, index=z.index), 'n': len(z)}


def orthogonalize_ai(ai_return, world_return):
    """x_t = r_A,t - a_A - theta_W^AI r_W,t."""
    fit = ols_with_intercept(ai_return, world_return)
    return fit['residual'], fit['beta'], fit['alpha']


def estimate_proxy_exposures(proxy_return, world_return, ai_return):
    market = ols_with_intercept(proxy_return, world_return)
    raw_ai = ols_with_intercept(proxy_return, ai_return)
    ai_resid, theta_world_ai, _ = orthogonalize_ai(ai_return, world_return)
    residual_diag = ols_with_intercept(proxy_return, ai_resid)
    return {
        'beta_world_raw': market['beta'],
        'theta_ai_abs_raw': raw_ai['beta'],
        'gamma_ai_resid_raw': residual_diag['beta'],
        'theta_ai_abs_world_reference': theta_world_ai,
        'n_market': market['n'],
        'n_ai': raw_ai['n'],
    }


def shrink_to_prior(raw, prior, reliability_weight):
    """z_final = q z_raw + (1-q) z_prior."""
    q = float(np.clip(reliability_weight, 0.0, 1.0))
    return q * float(raw) + (1.0 - q) * float(prior)


def beta_adjusted_statistical_intensity(theta_abs, beta_world, theta_world_ai,
                                        lower=0.0, upper=1.5):
    raw = (theta_abs - beta_world * theta_world_ai) / (1.0 - theta_world_ai)
    return raw, float(np.clip(raw, lower, upper))
