"""Stock-specific extension using the same original V5 exposure theory."""
import numpy as np
import pandas as pd


def month_log_returns(price_series):
    p = pd.Series(price_series, dtype=float).dropna()
    if not isinstance(p.index, pd.DatetimeIndex):
        raise ValueError('price_series must use DatetimeIndex')
    month_end = p.resample('ME').last().dropna()
    return np.log(month_end).diff().dropna()


def ols_slope(y, x):
    z = pd.concat([pd.Series(y), pd.Series(x)], axis=1).dropna()
    yy = z.iloc[:,0].to_numpy(float)
    xx = z.iloc[:,1].to_numpy(float)
    X = np.column_stack([np.ones(len(z)), xx])
    return float(np.linalg.lstsq(X, yy, rcond=None)[0][1])


def build_factor_frame(world_return, ai_basket_return):
    f = pd.concat([
        pd.Series(world_return, name='world'),
        pd.Series(ai_basket_return, name='ai')
    ], axis=1).dropna()
    b_ai_on_world = ols_slope(f['ai'], f['world'])
    f['ai_resid'] = f['ai'] - b_ai_on_world * f['world']
    return f, b_ai_on_world


def estimate_stock_override(stock_return, factor_df, theta_world,
                            economic_ai_intensity,
                            stat_weight=0.45, econ_weight=0.55,
                            intensity_cap=1.5):
    aligned = pd.concat([pd.Series(stock_return, name='stock'), factor_df], axis=1).dropna()
    beta_world = ols_slope(aligned['stock'], aligned['world'])
    theta_ai = ols_slope(aligned['stock'], aligned['ai'])
    resid_beta = ols_slope(aligned['stock'], aligned['ai_resid'])
    stat_raw = (theta_ai - beta_world * theta_world) / (1.0 - theta_world)
    stat_clip = min(intensity_cap, max(0.0, stat_raw))
    final_intensity = stat_weight * stat_clip + econ_weight * economic_ai_intensity
    return {
        'beta_world_stock': beta_world,
        'theta_ai_abs_stock': theta_ai,
        'theta_ai_abs_world_reference': theta_world,
        'stat_ai_excess_intensity_raw': stat_raw,
        'stat_ai_excess_intensity': stat_clip,
        'economic_ai_intensity': economic_ai_intensity,
        'statistical_weight': stat_weight,
        'economic_weight': econ_weight,
        'final_ai_excess_intensity': final_intensity,
        'residual_ai_beta_diagnostic': resid_beta,
        'n_months': len(aligned),
    }


def apply_scenarios(stock_table, scenario_table):
    out = stock_table.copy()
    for _, sc in scenario_table.iterrows():
        s = sc['scenario']
        lr = (out['beta_world_stock'] * sc['S_WORLD_log'] +
              out['final_ai_excess_intensity'] * sc['S_AI_EXCESS_log'])
        out[f'{s}_stress_log'] = lr
        out[f'{s}_stress_simple'] = np.exp(lr)-1
        out[f'{s}_stress_pct'] = 100*out[f'{s}_stress_simple']
    return out
