import os, re, math, json, shutil, zipfile, subprocess
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path('/mnt/data')
BASE = ROOT/'ai_country_industry_stress_research_v4'
OUT = ROOT/'ai_country_industry_stress_research_v5'
FIG = OUT/'figures'
DATA = OUT/'data'
CODE = OUT/'code'
INPUT = OUT/'model_inputs'
for p in [OUT]:
    if p.exists(): shutil.rmtree(p)
for d in [OUT,FIG,DATA,CODE,INPUT]: d.mkdir(parents=True, exist_ok=True)

# -----------------------------
# Helpers
# -----------------------------
def norm_label(s):
    return re.sub(r'[^a-z0-9]+',' ',str(s).lower()).strip()

def safe_tex(s):
    s=str(s)
    repl={'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}
    for a,b in repl.items(): s=s.replace(a,b)
    return s

def pct(x):
    return 100*(math.exp(x)-1)

def simple_from_log(x):
    return math.exp(x)-1

def read_csv(name):
    return pd.read_csv(BASE/'data'/name)

# -----------------------------
# Inputs from the v4 return-estimation layer
# These are model inputs, not final outputs. V5 recomputes the stress vector.
# -----------------------------
ci_old = read_csv('country_industry_stress_vector_v4.csv')
country_est = read_csv('country_factor_estimates_v4_return_model_input.csv')
industry_est = read_csv('industry_factor_estimates_v4_return_model_input.csv')
industry_map = read_csv('client_industry_mapping_v4_return_model_input.csv')
country_map = read_csv('client_country_mapping_template_v4_return_model_input.csv')
scenario_v4 = read_csv('scenario_parameters_v4.csv')
valuation_inputs = read_csv('valuation_premium_calibration_inputs.csv')
valuation_summary = read_csv('valuation_severity_calibration_summary.csv')
ss_input = read_csv('single_stock_override_vector_v4.csv')
# copy inputs for auditability
for src_name, df in [
    ('input_country_factor_estimates.csv', country_est),
    ('input_industry_factor_estimates.csv', industry_est),
    ('input_client_industry_mapping.csv', industry_map),
    ('input_client_country_mapping_template.csv', country_map),
    ('input_valuation_premium_calibration_inputs.csv', valuation_inputs),
    ('input_valuation_severity_calibration_summary.csv', valuation_summary),
    ('input_single_stock_estimates.csv', ss_input),
]:
    df.to_csv(INPUT/src_name, index=False)

# Key parameters. These are explicit governance choices.
THETA_WORLD = float(ci_old['theta_ai_abs_world_reference'].dropna().iloc[0])
KAPPA_BASE = float(valuation_summary.loc[valuation_summary['parameter'].eq('base_valuation_severity_scalar_kappa'),'value'].iloc[0])
KAPPA_SEVERE = 1.0
KAPPA_MILD = 0.5*KAPPA_BASE
LAMBDA_INDUSTRY_TILT = 0.50
WEIGHT_STAT = 0.45
WEIGHT_ECON = 0.55
COUNTRY_WEIGHT_ECON = 0.35
INDUSTRY_WEIGHT_ECON = 0.65
MAX_INTENSITY = 1.50
MONOTONIC_MARGIN = 0.05
HIGH_AI_INDUSTRY_THRESHOLD = 0.50

# Scenario shocks from v4/dot-com calibration.
base_row = scenario_v4[scenario_v4['scenario'].eq('base')].iloc[0]
S_WORLD_BASE = float(base_row['S_WORLD_log'])
S_AI_EXCESS_DOTCOM = float(scenario_v4[scenario_v4['scenario'].eq('severe')]['S_AI_EXCESS_log'].iloc[0])
# note: severe row retains full dot-com AI-excess. v4 base is valuation-scaled. We use severe for raw dot-com base.
scenario_params = pd.DataFrame([
    {'scenario':'mild', 'world_scale':0.50, 'valuation_severity_scalar':KAPPA_MILD, 'S_WORLD_log':0.50*S_WORLD_BASE, 'S_AI_EXCESS_log':KAPPA_MILD*S_AI_EXCESS_DOTCOM, 'description':'Half market shock plus half of valuation-adjusted AI-excess shock.'},
    {'scenario':'base', 'world_scale':1.00, 'valuation_severity_scalar':KAPPA_BASE, 'S_WORLD_log':S_WORLD_BASE, 'S_AI_EXCESS_log':KAPPA_BASE*S_AI_EXCESS_DOTCOM, 'description':'Full market de-risking plus valuation-adjusted AI-excess shock.'},
    {'scenario':'severe', 'world_scale':1.00, 'valuation_severity_scalar':KAPPA_SEVERE, 'S_WORLD_log':S_WORLD_BASE, 'S_AI_EXCESS_log':KAPPA_SEVERE*S_AI_EXCESS_DOTCOM, 'description':'Full dot-com analogue for the AI-excess component plus full market shock.'},
])
scenario_params['S_AI_EPICENTER_log'] = scenario_params['S_WORLD_log'] + scenario_params['S_AI_EXCESS_log']
for c in ['S_WORLD_log','S_AI_EXCESS_log','S_AI_EPICENTER_log']:
    scenario_params[c.replace('_log','_simple')] = np.exp(scenario_params[c])-1
    scenario_params[c.replace('_log','_pct')] = 100*scenario_params[c.replace('_log','_simple')]
scenario_params.to_csv(DATA/'scenario_parameters_v5.csv', index=False)

# -----------------------------
# Recompute country-index and country-industry stress vector
# -----------------------------
country_lookup = country_est.set_index('country_bucket').to_dict('index')
industry_lookup = industry_est.set_index('industry_bucket').to_dict('index')

def stat_excess_intensity(theta_abs, beta_world):
    # Correct decomposition: theta_abs ~= beta_world * theta_world + I_excess * (1 - theta_world).
    raw = (float(theta_abs) - float(beta_world)*THETA_WORLD) / max(1.0 - THETA_WORLD, 1e-8)
    return raw, min(MAX_INTENSITY, max(0.0, raw))

def reliability_flag(country_rel, industry_rel):
    flags=[str(country_rel),str(industry_rel)]
    if 'X' in flags: return 'X'
    if 'D' in flags: return 'D'
    if 'C' in flags: return 'C'
    if 'B' in flags: return 'B'
    return 'A'

# Build a unique country x client industry vector, using the existing mapping table as the source of industries.
rows=[]
# country buckets in country_est retain only successfully estimated proxies.
for _, crow in country_est.iterrows():
    cb = crow['country_bucket']
    beta_b = float(crow['beta_world_final'])
    theta_b = float(crow['theta_ai_abs_final'])
    econ_b = float(crow['country_economic_ai_intensity'])
    country_raw, country_stat = stat_excess_intensity(theta_b, beta_b)
    country_index_intensity = min(MAX_INTENSITY, max(0.0, WEIGHT_STAT*country_stat + WEIGHT_ECON*econ_b))
    for _, m in industry_map.iterrows():
        ib = m['industry_bucket']
        if ib == 'Out of Scope Fixed Income':
            rec = {
                'country_bucket':cb,
                'country_proxy_ticker':crow['ticker'],
                'country_region_group':crow['region_group'],
                'client_industry_label':m['client_industry_label'],
                'client_industry_normalized':m['client_industry_normalized'],
                'industry_bucket':ib,
                'industry_proxy_ticker':m.get('ticker',''),
                'industry_sector_group':'Out of Scope',
                'model_scope':'outside_equity_ai_model',
                'reliability_flag':'X',
                'beta_world_cell':np.nan,
                'final_ai_excess_intensity':np.nan,
                'formula_log_return':'not_applicable_fixed_income_or_muni',
                'formula_simple_return':'not_applicable',
                'recommended_client_pnl_formula':'not_applicable_in_equity_ai_model',
                'market_cap_overlay_formula':'not_applicable'
            }
            for _, sc in scenario_params.iterrows():
                s=sc['scenario']
                for suffix in ['stress_log','stress_simple','stress_pct','world_component_log','ai_excess_component_log','valuation_severity_scalar']:
                    rec[f'{s}_{suffix}']=np.nan
            rows.append(rec)
            continue
        if ib not in industry_lookup:
            continue
        irow = industry_lookup[ib]
        beta_g = float(irow['beta_world_final'])
        theta_g = float(irow['theta_ai_abs_final'])
        econ_g = float(m['client_industry_economic_ai_intensity'])
        if ib == 'Index or ETF':
            beta_cell = beta_b
            theta_cell = theta_b
            cell_raw_stat, cell_stat = country_raw, country_stat
            econ_cell = econ_b
            final_intensity_pre = country_index_intensity
            final_intensity = country_index_intensity
            monotonic_constraint_applied = False
            monotonic_floor = np.nan
        else:
            # Country is the baseline; industry ETF provides a tilt. The square-root tilt prevents a global industry proxy from overfitting a local cell.
            beta_cell = beta_b * (max(beta_g, 1e-6) ** LAMBDA_INDUSTRY_TILT)
            theta_cell = theta_b * ((max(theta_g, 1e-6)/max(THETA_WORLD, 1e-6)) ** LAMBDA_INDUSTRY_TILT)
            cell_raw_stat, cell_stat = stat_excess_intensity(theta_cell, beta_cell)
            econ_cell = COUNTRY_WEIGHT_ECON*econ_b + INDUSTRY_WEIGHT_ECON*econ_g
            final_intensity_pre = WEIGHT_STAT*cell_stat + WEIGHT_ECON*econ_cell
            final_intensity = final_intensity_pre
            monotonic_floor = np.nan
            monotonic_constraint_applied = False
            # Coherence projection: explicitly AI-linked industries should not be less AI-excess-sensitive than the broad country index.
            if econ_g >= HIGH_AI_INDUSTRY_THRESHOLD:
                monotonic_floor = country_index_intensity + MONOTONIC_MARGIN
                if final_intensity < monotonic_floor:
                    final_intensity = monotonic_floor
                    monotonic_constraint_applied = True
            final_intensity = min(MAX_INTENSITY, max(0.0, final_intensity))
        rf = reliability_flag(crow['reliability_country'], irow['reliability_industry'])
        rec = {
            'country_bucket':cb,
            'country_proxy_ticker':crow['ticker'],
            'country_region_group':crow['region_group'],
            'client_industry_label':m['client_industry_label'],
            'client_industry_normalized':m['client_industry_normalized'],
            'industry_bucket':ib,
            'industry_proxy_ticker':irow['ticker'],
            'industry_sector_group':irow['sector_group'],
            'model_scope':'equity_factor_stress',
            'reliability_flag':rf,
            'beta_world_country':beta_b,
            'beta_world_industry':beta_g,
            'beta_world_cell':beta_cell,
            'theta_ai_abs_country':theta_b,
            'theta_ai_abs_industry':theta_g,
            'theta_ai_abs_cell':theta_cell,
            'theta_ai_abs_world_reference':THETA_WORLD,
            'country_stat_ai_excess_intensity_raw':country_raw,
            'country_stat_ai_excess_intensity':country_stat,
            'country_index_final_ai_excess_intensity':country_index_intensity,
            'cell_stat_ai_excess_intensity_raw':cell_raw_stat,
            'cell_stat_ai_excess_intensity':cell_stat,
            'country_economic_ai_intensity':econ_b,
            'client_industry_economic_ai_intensity':econ_g,
            'cell_economic_ai_intensity':econ_cell,
            'statistical_weight':WEIGHT_STAT,
            'economic_weight':WEIGHT_ECON,
            'final_ai_excess_intensity_pre_coherence':final_intensity_pre,
            'monotonic_constraint_applied':monotonic_constraint_applied,
            'monotonic_floor_if_applicable':monotonic_floor,
            'final_ai_excess_intensity':final_intensity,
            'country_residual_ai_beta_diagnostic':crow['gamma_ai_resid_raw'],
            'industry_residual_ai_beta_diagnostic':irow['gamma_ai_resid_raw'],
            'country_abs_beta_tstat':crow['t_theta_ai_abs'],
            'industry_abs_beta_tstat':irow['t_theta_ai_abs'],
            'country_n_months':crow['n_abs_months'],
            'industry_n_months':irow['n_abs_months'],
            'formula_log_return':'beta_world_cell*S_WORLD_log + final_ai_excess_intensity*S_AI_EXCESS_log',
            'formula_simple_return':'EXP(stress_log_return)-1',
            'recommended_client_pnl_formula':'stress_pnl_usd = - signed_market_value_usd * stress_simple_return',
            'margin_usage_formula':'stress_loss_to_margin = max(stress_pnl_usd,0)/client_level_margin_usd',
            'market_cap_overlay_formula':'optional only: loss_usd_adjusted = max(stress_pnl_usd,0)*size_loss_multiplier(holding_market_cap_usd)'
        }
        for _, sc in scenario_params.iterrows():
            s=sc['scenario']
            logret = beta_cell*float(sc['S_WORLD_log']) + final_intensity*float(sc['S_AI_EXCESS_log'])
            rec[f'{s}_stress_log'] = logret
            rec[f'{s}_stress_simple'] = math.exp(logret)-1
            rec[f'{s}_stress_pct'] = 100*(math.exp(logret)-1)
            rec[f'{s}_world_component_log'] = beta_cell*float(sc['S_WORLD_log'])
            rec[f'{s}_ai_excess_component_log'] = final_intensity*float(sc['S_AI_EXCESS_log'])
            rec[f'{s}_valuation_severity_scalar'] = float(sc['valuation_severity_scalar'])
        rows.append(rec)

stress = pd.DataFrame(rows)
# Sort for human readability
stress = stress.sort_values(['country_bucket','client_industry_label']).reset_index(drop=True)
stress.to_csv(DATA/'country_industry_stress_vector_v5.csv', index=False)
long=[]
base_cols=['country_bucket','country_proxy_ticker','country_region_group','client_industry_label','client_industry_normalized','industry_bucket','industry_proxy_ticker','industry_sector_group','model_scope','reliability_flag','beta_world_cell','final_ai_excess_intensity']
for _, r in stress.iterrows():
    common={c:r[c] for c in base_cols}
    for _, sc in scenario_params.iterrows():
        s=sc['scenario']
        rec=common.copy()
        rec.update({'scenario':s,'valuation_severity_scalar':sc['valuation_severity_scalar'],'S_WORLD_log':sc['S_WORLD_log'],'S_AI_EXCESS_log':sc['S_AI_EXCESS_log'],'stress_log':r.get(f'{s}_stress_log',np.nan),'stress_simple':r.get(f'{s}_stress_simple',np.nan),'stress_pct':r.get(f'{s}_stress_pct',np.nan)})
        long.append(rec)
pd.DataFrame(long).to_csv(DATA/'country_industry_stress_vector_v5_long.csv', index=False)

# Coherence diagnostics
coh=[]
for cb, sub in stress[stress.model_scope.eq('equity_factor_stress')].groupby('country_bucket'):
    idx=sub[sub['client_industry_normalized'].eq('index etf')]
    tech=sub[sub['client_industry_normalized'].eq('technology hardware storage peripheral')]
    util=sub[sub['client_industry_normalized'].eq('electric utilities')]
    if len(idx) and len(tech):
        coh.append({'country_bucket':cb,
                    'index_base_stress_pct':float(idx['base_stress_pct'].iloc[0]),
                    'technology_hardware_base_stress_pct':float(tech['base_stress_pct'].iloc[0]),
                    'technology_more_severe_than_index':bool(tech['base_stress_pct'].iloc[0] <= idx['base_stress_pct'].iloc[0]),
                    'index_ai_excess_intensity':float(idx['final_ai_excess_intensity'].iloc[0]),
                    'technology_ai_excess_intensity':float(tech['final_ai_excess_intensity'].iloc[0]),
                    'utilities_base_stress_pct':float(util['base_stress_pct'].iloc[0]) if len(util) else np.nan})
coh=pd.DataFrame(coh).sort_values('technology_hardware_base_stress_pct')
coh.to_csv(DATA/'coherence_diagnostics_v5.csv', index=False)

# Single-stock override recomputation with beta-adjusted intensity.
ss_rows=[]
for _, r in ss_input.iterrows():
    beta=float(r['beta_world_stock'])
    theta=float(r['theta_ai_abs_stock'])
    econ=float(r['economic_ai_intensity'])
    raw_stat, stat=stat_excess_intensity(theta,beta)
    final=WEIGHT_STAT*stat + WEIGHT_ECON*econ
    final=min(MAX_INTENSITY,max(0.0,final))
    rec={
        'ticker':r['ticker'],
        'model_scope':'single_stock_override',
        'beta_world_stock':beta,
        'theta_ai_abs_stock':theta,
        'theta_ai_abs_world_reference':THETA_WORLD,
        'stat_ai_excess_intensity_raw':raw_stat,
        'stat_ai_excess_intensity':stat,
        'economic_ai_intensity':econ,
        'statistical_weight':WEIGHT_STAT,
        'economic_weight':WEIGHT_ECON,
        'final_ai_excess_intensity':final,
        'residual_ai_beta_diagnostic':r.get('residual_ai_beta_diagnostic',np.nan),
        'n_months':r.get('n_months',np.nan),
        'formula_log_return':'beta_world_stock*S_WORLD_log + final_ai_excess_intensity*S_AI_EXCESS_log',
        'recommended_use':'Use this row instead of country-industry row when ticker matches.'
    }
    for _, sc in scenario_params.iterrows():
        s=sc['scenario']
        logret=beta*float(sc['S_WORLD_log']) + final*float(sc['S_AI_EXCESS_log'])
        rec[f'{s}_stress_log']=logret
        rec[f'{s}_stress_simple']=math.exp(logret)-1
        rec[f'{s}_stress_pct']=100*(math.exp(logret)-1)
        rec[f'{s}_world_component_log']=beta*float(sc['S_WORLD_log'])
        rec[f'{s}_ai_excess_component_log']=final*float(sc['S_AI_EXCESS_log'])
        rec[f'{s}_valuation_severity_scalar']=float(sc['valuation_severity_scalar'])
    ss_rows.append(rec)
ss = pd.DataFrame(ss_rows).sort_values('base_stress_pct').reset_index(drop=True)
ss.to_csv(DATA/'single_stock_override_vector_v5.csv', index=False)

# Sample outputs
sample_specs=[
    ('S&P 500 index proxy','United States','index etf'),
    ('US technology hardware','United States','technology hardware storage peripheral'),
    ('US electric utilities','United States','electric utilities'),
    ('US independent power and renewables','United States','independent power renewables'),
    ('US oil and gas','United States','oil gas consumable fuels'),
    ('Korea broad index / ETF','Korea','index etf'),
    ('Korea technology hardware','Korea','technology hardware storage peripheral'),
    ('Korea electric utilities','Korea','electric utilities'),
    ('Taiwan broad index / ETF','Taiwan','index etf'),
    ('Taiwan technology hardware','Taiwan','technology hardware storage peripheral'),
    ('Japan machinery','Japan','mchinery'),
    ('Germany industrial conglomerates','Germany','industrial conlomerates'),
    ('Emerging Asia banks','Emerging Asia Fallback','banks'),
]
sample=[]
for label, cb, ind_norm in sample_specs:
    row=stress[(stress['country_bucket']==cb)&(stress['client_industry_normalized']==ind_norm)]
    if len(row):
        r=row.iloc[0]
        sample.append({'sample_position':label,'country_bucket':cb,'client_industry_label':r['client_industry_label'],'industry_bucket':r['industry_bucket'],'mild_stress_pct':r['mild_stress_pct'],'base_stress_pct':r['base_stress_pct'],'severe_stress_pct':r['severe_stress_pct'],'beta_world_cell':r['beta_world_cell'],'final_ai_excess_intensity':r['final_ai_excess_intensity'],'reliability_flag':r['reliability_flag']})
for t in ['NVDA','AMD','SMCI','PLTR','AVGO','MSFT','GOOGL','AMZN','META']:
    row=ss[ss['ticker'].eq(t)]
    if len(row):
        r=row.iloc[0]
        sample.append({'sample_position':f'{t} single-stock override','country_bucket':'single stock','client_industry_label':'single stock override','industry_bucket':t,'mild_stress_pct':r['mild_stress_pct'],'base_stress_pct':r['base_stress_pct'],'severe_stress_pct':r['severe_stress_pct'],'beta_world_cell':r['beta_world_stock'],'final_ai_excess_intensity':r['final_ai_excess_intensity'],'reliability_flag':'single-stock'})
samples=pd.DataFrame(sample)
samples.to_csv(DATA/'sample_outcomes_v5.csv', index=False)

# Optional market cap overlay policy
mc_policy=pd.DataFrame([
    {'market_cap_bucket':'mega_large_cap','condition':'holding_market_cap_usd >= 10000000000','size_loss_multiplier':1.00,'rationale':'Factor stress is usually sufficient for liquid large-cap equities.'},
    {'market_cap_bucket':'mid_cap','condition':'2000000000 <= holding_market_cap_usd < 10000000000','size_loss_multiplier':1.05,'rationale':'Small liquidity and gap-risk allowance.'},
    {'market_cap_bucket':'small_cap','condition':'300000000 <= holding_market_cap_usd < 2000000000','size_loss_multiplier':1.10,'rationale':'Material liquidity and gap-risk allowance.'},
    {'market_cap_bucket':'micro_cap_or_missing','condition':'holding_market_cap_usd < 300000000 or missing','size_loss_multiplier':1.20,'rationale':'Use only as a conservative add-on after factor P&L, not as part of the return model.'},
])
mc_policy.to_csv(DATA/'optional_market_cap_overlay_policy_v5.csv', index=False)
# Copy mapping templates
country_map.to_csv(DATA/'client_country_mapping_template_v5.csv', index=False)
industry_map.to_csv(DATA/'client_industry_mapping_v5.csv', index=False)

# Summary numbers
in_scope=stress[stress.model_scope.eq('equity_factor_stress')]
summary={
    'model_version':'v5 coherent valuation-calibrated model',
    'theta_world_reference':THETA_WORLD,
    'beta_adjusted_intensity_formula':'I=(theta-beta*theta_world)/(1-theta_world)',
    'lambda_industry_tilt':LAMBDA_INDUSTRY_TILT,
    'statistical_weight':WEIGHT_STAT,
    'economic_weight':WEIGHT_ECON,
    'country_weight_in_economic_cell':COUNTRY_WEIGHT_ECON,
    'industry_weight_in_economic_cell':INDUSTRY_WEIGHT_ECON,
    'base_valuation_severity_scalar':KAPPA_BASE,
    'mild_valuation_severity_scalar':KAPPA_MILD,
    'severe_valuation_severity_scalar':KAPPA_SEVERE,
    'S_WORLD_base_pct':float(scenario_params[scenario_params.scenario.eq('base')]['S_WORLD_pct'].iloc[0]),
    'S_AI_EXCESS_base_pct':float(scenario_params[scenario_params.scenario.eq('base')]['S_AI_EXCESS_pct'].iloc[0]),
    'S_AI_EPICENTER_base_pct':float(scenario_params[scenario_params.scenario.eq('base')]['S_AI_EPICENTER_pct'].iloc[0]),
    'S_AI_EPICENTER_severe_pct':float(scenario_params[scenario_params.scenario.eq('severe')]['S_AI_EPICENTER_pct'].iloc[0]),
    'num_rows':int(len(stress)),
    'num_in_scope_rows':int(len(in_scope)),
    'num_country_buckets':int(stress['country_bucket'].nunique()),
    'num_client_industry_labels':int(stress['client_industry_label'].nunique()),
    'base_min_stress_pct':float(in_scope['base_stress_pct'].min()),
    'base_median_stress_pct':float(in_scope['base_stress_pct'].median()),
    'base_max_stress_pct':float(in_scope['base_stress_pct'].max()),
    'coherence_tech_worse_than_index_share':float(coh['technology_more_severe_than_index'].mean()) if len(coh) else None,
    'nvda_mild_pct':float(ss[ss.ticker.eq('NVDA')]['mild_stress_pct'].iloc[0]),
    'nvda_base_pct':float(ss[ss.ticker.eq('NVDA')]['base_stress_pct'].iloc[0]),
    'nvda_severe_pct':float(ss[ss.ticker.eq('NVDA')]['severe_stress_pct'].iloc[0]),
    'spy_proxy_base_pct':float(stress[(stress.country_bucket.eq('United States'))&(stress.client_industry_normalized.eq('index etf'))]['base_stress_pct'].iloc[0]),
    'korea_index_base_pct':float(stress[(stress.country_bucket.eq('Korea'))&(stress.client_industry_normalized.eq('index etf'))]['base_stress_pct'].iloc[0]),
    'korea_tech_hardware_base_pct':float(stress[(stress.country_bucket.eq('Korea'))&(stress.client_industry_normalized.eq('technology hardware storage peripheral'))]['base_stress_pct'].iloc[0]),
}
Path(DATA/'summary_numbers_v5.json').write_text(json.dumps(summary, indent=2))

# -----------------------------
# Figures
# -----------------------------
plt.rcParams.update({'font.size':9})

def savefig(name):
    plt.tight_layout()
    plt.savefig(FIG/name, dpi=220)
    plt.close()

# 1 model architecture
fig, ax = plt.subplots(figsize=(9,3.6))
ax.axis('off')
boxes=[('Dot-com TMT\nmarket + excess shock',0.05,0.55),('Damodaran valuation\nseverity scalar',0.05,0.15),('Scenario shocks\n$S_W$, $S_{AI}$',0.32,0.35),('Country ETF\n$\\beta_b, \\theta_b$',0.58,0.65),('Industry ETF\n$\\beta_g, \\theta_g$',0.58,0.25),('Cell vector\n$R_{b,g}$',0.82,0.45)]
for txt,x,y in boxes:
    ax.add_patch(plt.Rectangle((x,y),0.18,0.22, fill=False, linewidth=1.2))
    ax.text(x+0.09,y+0.11,txt,ha='center',va='center',fontsize=9)
for x1,y1,x2,y2 in [(0.23,0.66,0.32,0.46),(0.23,0.26,0.32,0.46),(0.50,0.46,0.58,0.76),(0.50,0.46,0.58,0.36),(0.76,0.76,0.82,0.56),(0.76,0.36,0.82,0.56)]:
    ax.annotate('', xy=(x2,y2), xytext=(x1,y1), arrowprops=dict(arrowstyle='->',lw=1.0))
ax.set_title('Model structure: market shock plus valuation-calibrated AI-excess shock')
savefig('01_model_structure.png')

# 2 valuation calibration
fig,ax=plt.subplots(figsize=(7.5,4.2))
vals=[]; labs=[]
for metric in ['forward_pe','current_pe','trailing_pe']:
    row=valuation_inputs[(valuation_inputs.year.eq(2024))&(valuation_inputs.region.eq('US'))&(valuation_inputs.metric.eq(metric))]
    if len(row):
        vals.append(float(row['premium_log'].iloc[0])); labs.append(metric.replace('_',' '))
dot=valuation_summary[valuation_summary.parameter.eq('dotcom_reference_premium_log')]['value'].iloc[0]
vals=[dot]+vals+[float(valuation_summary[valuation_summary.parameter.eq('current_blended_premium_log')]['value'].iloc[0])]
labs=['dot-com ref']+labs+['current blended']
ax.bar(range(len(vals)), vals)
ax.set_xticks(range(len(vals))); ax.set_xticklabels(labs, rotation=20, ha='right')
ax.axhline(dot, linestyle='--', linewidth=1)
ax.set_ylabel('Log AI/TMT premium vs market')
ax.set_title(f'Valuation calibration: base severity scalar = {KAPPA_BASE:.3f}')
for i,v in enumerate(vals):
    ax.text(i,v+0.02,f'{math.exp(v):.2f}x',ha='center',fontsize=8)
savefig('02_valuation_calibration.png')

# 3 scenario decomposition
fig,ax=plt.subplots(figsize=(7.5,4.1))
x=np.arange(len(scenario_params)); width=0.35
ax.bar(x-width/2, scenario_params['S_WORLD_pct'], width, label='World market')
ax.bar(x+width/2, scenario_params['S_AI_EXCESS_pct'], width, label='AI-excess')
ax.set_xticks(x); ax.set_xticklabels(scenario_params['scenario'].str.title())
ax.set_ylabel('Simple return shock (%)')
ax.set_title('Scenario components')
ax.legend()
for i,row in scenario_params.iterrows():
    ax.text(i, row['S_AI_EPICENTER_pct']-3, f'Epicenter\n{row["S_AI_EPICENTER_pct"]:.1f}%', ha='center', va='top', fontsize=8)
savefig('03_scenario_decomposition.png')

# 4 sample outcomes
samp=samples.sort_values('base_stress_pct')
fig,ax=plt.subplots(figsize=(8.5,6.2))
y=np.arange(len(samp))
ax.barh(y, samp['base_stress_pct'])
ax.set_yticks(y); ax.set_yticklabels(samp['sample_position'])
ax.set_xlabel('Base stress return (%)')
ax.set_title('Representative base stress outputs')
ax.axvline(0, linewidth=0.8)
savefig('04_sample_outputs.png')

# 5 selected heatmap
sel_countries=['United States','Taiwan','Korea','Japan','China','Germany','United Kingdom','Emerging Asia Fallback','Emerging Markets Fallback']
sel_buckets=['Index or ETF','Technology','Communication Services','Utilities','Energy','Industrials','Financials','Healthcare','Consumer Discretionary','Real Estate']
unique = stress[stress.model_scope.eq('equity_factor_stress')].groupby(['country_bucket','industry_bucket'])['base_stress_pct'].mean().unstack()
pivot=unique.reindex(sel_countries)[[c for c in sel_buckets if c in unique.columns]]
fig,ax=plt.subplots(figsize=(9.2,5.6))
im=ax.imshow(pivot.values, aspect='auto')
ax.set_xticks(range(len(pivot.columns))); ax.set_xticklabels(pivot.columns, rotation=45, ha='right')
ax.set_yticks(range(len(pivot.index))); ax.set_yticklabels(pivot.index)
for i in range(pivot.shape[0]):
    for j in range(pivot.shape[1]):
        val=pivot.values[i,j]
        if not np.isnan(val): ax.text(j,i,f'{val:.0f}',ha='center',va='center',fontsize=7)
fig.colorbar(im, ax=ax, label='Base stress return (%)')
ax.set_title('Selected country-industry base stress heatmap')
savefig('05_base_heatmap_selected.png')

# 6 coherence: index vs tech
coh_plot=coh[['country_bucket','index_base_stress_pct','technology_hardware_base_stress_pct']].copy().sort_values('technology_hardware_base_stress_pct').head(18)
fig,ax=plt.subplots(figsize=(8.5,5.2))
y=np.arange(len(coh_plot)); h=0.38
ax.barh(y-h/2, coh_plot['index_base_stress_pct'], h, label='Broad index/ETF')
ax.barh(y+h/2, coh_plot['technology_hardware_base_stress_pct'], h, label='Technology hardware')
ax.set_yticks(y); ax.set_yticklabels(coh_plot['country_bucket'])
ax.set_xlabel('Base stress return (%)')
ax.set_title('Coherence check: technology hardware is at least as stressed as broad index')
ax.legend()
savefig('06_coherence_index_vs_tech.png')

# 7 distribution
fig,ax=plt.subplots(figsize=(7.5,4.1))
for scenario in ['mild','base','severe']:
    vals=stress.loc[stress.model_scope.eq('equity_factor_stress'),f'{scenario}_stress_pct'].dropna()
    ax.hist(vals, bins=28, alpha=0.45, label=scenario.title())
ax.set_xlabel('Stress return (%)')
ax.set_ylabel('Number of rows')
ax.set_title('Distribution of stress returns by scenario')
ax.legend()
savefig('07_stress_distribution.png')

# 8 single stock overrides
fig,ax=plt.subplots(figsize=(7.8,4.6))
ssplot=ss.sort_values('base_stress_pct')
y=np.arange(len(ssplot)); h=0.26
ax.barh(y-h, ssplot['mild_stress_pct'], h, label='Mild')
ax.barh(y, ssplot['base_stress_pct'], h, label='Base')
ax.barh(y+h, ssplot['severe_stress_pct'], h, label='Severe')
ax.set_yticks(y); ax.set_yticklabels(ssplot['ticker'])
ax.set_xlabel('Stress return (%)')
ax.set_title('Single-stock override vector')
ax.legend(fontsize=8)
savefig('08_single_stock_overrides.png')

# 9 intensity construction scatter
fig,ax=plt.subplots(figsize=(6.8,4.6))
sub=stress[stress.model_scope.eq('equity_factor_stress')].drop_duplicates(['industry_bucket'])
ax.scatter(sub['cell_stat_ai_excess_intensity'], sub['cell_economic_ai_intensity'])
for _,r in sub.iterrows():
    ax.text(r['cell_stat_ai_excess_intensity']+0.01, r['cell_economic_ai_intensity']+0.01, str(r['industry_bucket'])[:18], fontsize=7)
ax.set_xlabel('Statistical AI-excess intensity')
ax.set_ylabel('Economic AI-excess intensity')
ax.set_title('Statistical and economic intensity inputs')
savefig('09_statistical_vs_economic_intensity.png')

# -----------------------------
# Tables for LaTeX
# -----------------------------
def write_tabular(df, path, cols, headers=None, n=None, float_cols=None):
    float_cols=float_cols or []
    headers=headers or cols
    if n is not None: df=df.head(n)
    with open(path,'w') as f:
        f.write('\\begin{tabular}{'+'l'*len(cols)+'}\n')
        f.write('\\hline\n')
        f.write(' & '.join(safe_tex(h) for h in headers)+' \\\\ \n')
        f.write('\\hline\n')
        for _,r in df.iterrows():
            vals=[]
            for c in cols:
                v=r[c]
                if c in float_cols and pd.notna(v):
                    vals.append(f'{float(v):.1f}')
                elif isinstance(v,(float,np.floating)) and pd.notna(v):
                    vals.append(f'{float(v):.2f}')
                else:
                    vals.append(safe_tex(v))
            f.write(' & '.join(vals)+' \\\\ \n')
        f.write('\\hline\n\\end{tabular}\n')

scenario_table=scenario_params[['scenario','S_WORLD_pct','S_AI_EXCESS_pct','S_AI_EPICENTER_pct','valuation_severity_scalar']].copy()
scenario_table['scenario']=scenario_table['scenario'].str.title()
write_tabular(scenario_table, OUT/'table_scenarios.tex', ['scenario','S_WORLD_pct','S_AI_EXCESS_pct','S_AI_EPICENTER_pct','valuation_severity_scalar'], ['Scenario','World %','AI excess %','AI epicenter %','Kappa'], float_cols=['S_WORLD_pct','S_AI_EXCESS_pct','S_AI_EPICENTER_pct','valuation_severity_scalar'])
write_tabular(samples.sort_values('base_stress_pct')[['sample_position','mild_stress_pct','base_stress_pct','severe_stress_pct','reliability_flag']], OUT/'table_samples.tex', ['sample_position','mild_stress_pct','base_stress_pct','severe_stress_pct','reliability_flag'], ['Position','Mild %','Base %','Severe %','Flag'], n=18, float_cols=['mild_stress_pct','base_stress_pct','severe_stress_pct'])
coh_small=coh[['country_bucket','index_base_stress_pct','technology_hardware_base_stress_pct','utilities_base_stress_pct']].copy().sort_values('technology_hardware_base_stress_pct').head(10)
write_tabular(coh_small, OUT/'table_coherence.tex', ['country_bucket','index_base_stress_pct','technology_hardware_base_stress_pct','utilities_base_stress_pct'], ['Country','Index %','Tech hw %','Utilities %'], float_cols=['index_base_stress_pct','technology_hardware_base_stress_pct','utilities_base_stress_pct'])
ss_tab=ss[['ticker','mild_stress_pct','base_stress_pct','severe_stress_pct','beta_world_stock','final_ai_excess_intensity']].copy().sort_values('base_stress_pct')
write_tabular(ss_tab, OUT/'table_single_stocks.tex', ['ticker','mild_stress_pct','base_stress_pct','severe_stress_pct','beta_world_stock','final_ai_excess_intensity'], ['Ticker','Mild %','Base %','Severe %','Beta','AI int.'], float_cols=['mild_stress_pct','base_stress_pct','severe_stress_pct','beta_world_stock','final_ai_excess_intensity'])

# -----------------------------
# Client application template
# -----------------------------
apply_code = r'''import pandas as pd
import numpy as np
import re

def norm_label(x):
    return re.sub(r'[^a-z0-9]+',' ',str(x).lower()).strip()

def size_loss_multiplier(market_cap_usd):
    try:
        mc = float(market_cap_usd)
    except Exception:
        return 1.20
    if np.isnan(mc) or mc <= 0:
        return 1.20
    if mc >= 10_000_000_000:
        return 1.00
    if mc >= 2_000_000_000:
        return 1.05
    if mc >= 300_000_000:
        return 1.10
    return 1.20

def apply_stress(client_csv,
                 stress_vector_csv='data/country_industry_stress_vector_v5.csv',
                 single_stock_csv='data/single_stock_override_vector_v5.csv',
                 country_mapping_csv='data/client_country_mapping_template_v5.csv',
                 scenario='base',
                 output_csv='client_stress_output_v5.csv',
                 use_single_stock_overrides=True,
                 apply_market_cap_overlay=False):
    client = pd.read_csv(client_csv)
    stress = pd.read_csv(stress_vector_csv)
    single = pd.read_csv(single_stock_csv)
    country_map = pd.read_csv(country_mapping_csv)

    required = ['country','industry','signed_market_value_usd']
    missing = [c for c in required if c not in client.columns]
    if missing:
        raise ValueError(f'Missing required client columns: {missing}')

    client['country_normalized'] = client['country'].map(norm_label)
    client['industry_normalized'] = client['industry'].map(norm_label)
    if 'ticker' in client.columns:
        client['ticker_upper'] = client['ticker'].astype(str).str.upper().str.replace(r'[^A-Z0-9]+','',regex=True)
    else:
        client['ticker_upper'] = ''

    if 'client_country_normalized' not in country_map.columns:
        country_map['client_country_normalized'] = country_map['client_country_label'].map(norm_label)

    client = client.merge(
        country_map[['client_country_normalized','country_bucket','country_proxy_ticker','region_group','reliability_country']],
        left_on='country_normalized', right_on='client_country_normalized', how='left'
    )
    client['country_bucket'] = client['country_bucket'].fillna('World Fallback')

    scenario_cols = [f'{scenario}_stress_simple', f'{scenario}_stress_pct', f'{scenario}_stress_log']
    key_cols = ['country_bucket','client_industry_normalized','model_scope','reliability_flag','industry_bucket','beta_world_cell','final_ai_excess_intensity'] + scenario_cols
    stress_small = stress[key_cols].rename(columns={
        f'{scenario}_stress_simple':'stress_simple',
        f'{scenario}_stress_pct':'stress_pct',
        f'{scenario}_stress_log':'stress_log'
    })
    out = client.merge(stress_small, left_on=['country_bucket','industry_normalized'], right_on=['country_bucket','client_industry_normalized'], how='left')

    if use_single_stock_overrides:
        single_small = single[['ticker',f'{scenario}_stress_simple',f'{scenario}_stress_pct',f'{scenario}_stress_log','beta_world_stock','final_ai_excess_intensity']].rename(columns={
            'ticker':'ticker_upper',
            f'{scenario}_stress_simple':'single_stock_stress_simple',
            f'{scenario}_stress_pct':'single_stock_stress_pct',
            f'{scenario}_stress_log':'single_stock_stress_log'
        })
        out = out.merge(single_small, on='ticker_upper', how='left')
        use_override = out['single_stock_stress_simple'].notna()
        out.loc[use_override,'stress_simple'] = out.loc[use_override,'single_stock_stress_simple']
        out.loc[use_override,'stress_pct'] = out.loc[use_override,'single_stock_stress_pct']
        out.loc[use_override,'stress_log'] = out.loc[use_override,'single_stock_stress_log']
        out.loc[use_override,'model_scope'] = 'single_stock_override'
        out.loc[use_override,'reliability_flag'] = 'single-stock'

    out['stress_pnl_usd'] = -out['signed_market_value_usd'] * out['stress_simple']
    out['adverse_stress_loss_usd'] = out['stress_pnl_usd'].clip(lower=0)

    if apply_market_cap_overlay:
        if 'holding_market_cap_usd' not in out.columns:
            raise ValueError('holding_market_cap_usd is required when apply_market_cap_overlay=True')
        out['size_loss_multiplier'] = out['holding_market_cap_usd'].map(size_loss_multiplier)
    else:
        out['size_loss_multiplier'] = 1.0

    out['adverse_stress_loss_usd_after_size_overlay'] = out['adverse_stress_loss_usd'] * out['size_loss_multiplier']
    if 'client_level_margin_usd' in out.columns:
        out['stress_loss_to_margin'] = out['adverse_stress_loss_usd_after_size_overlay'] / out['client_level_margin_usd']
    out.to_csv(output_csv, index=False)
    return out

if __name__ == '__main__':
    # Example:
    # apply_stress('client_positions.csv', scenario='base', output_csv='client_stress_output_v5.csv')
    pass
'''
(CODE/'apply_stress_to_client_template_v5.py').write_text(apply_code)
# save this build script itself
shutil.copy2(Path(__file__), CODE/'build_ai_country_industry_stress_v5.py')

# README and data dictionary
readme=f'''# AI country-industry stress research v5

This package contains the coherent valuation-calibrated AI unwind stress model.

Main outputs:
- `main.pdf`: presentation-ready report.
- `data/country_industry_stress_vector_v5.csv`: merge-ready country x industry vector.
- `data/single_stock_override_vector_v5.csv`: single-stock override vector for AI epicenter names.
- `data/scenario_parameters_v5.csv`: mild, base, and severe scenario settings.
- `data/coherence_diagnostics_v5.csv`: index-versus-technology hardware checks by country.
- `code/apply_stress_to_client_template_v5.py`: merge template for position-level data.
- `code/build_ai_country_industry_stress_v5.py`: replication code.

Key base outputs:
- Base valuation severity scalar: {KAPPA_BASE:.3f}
- S&P 500 proxy base stress: {summary['spy_proxy_base_pct']:.1f}%
- Korea broad ETF base stress: {summary['korea_index_base_pct']:.1f}%
- Korea technology hardware base stress: {summary['korea_tech_hardware_base_pct']:.1f}%
- NVDA base stress: {summary['nvda_base_pct']:.1f}%
'''
(OUT/'README.md').write_text(readme)

ddict='''# Data dictionary

## country_industry_stress_vector_v5.csv
- `country_bucket`: model country or regional bucket.
- `client_industry_label`: client industry label used for merging.
- `client_industry_normalized`: normalized merge key for industry.
- `industry_bucket`: model industry proxy bucket.
- `beta_world_cell`: cell market beta used in stress formula.
- `final_ai_excess_intensity`: AI-excess intensity after statistical/economic blend and coherence projection.
- `base_stress_simple`: base simple return shock.
- `base_stress_pct`: base return shock in percent.
- `mild_stress_pct`, `severe_stress_pct`: mild and severe scenario shocks.
- `country_index_final_ai_excess_intensity`: AI-excess intensity of the broad country index.
- `cell_stat_ai_excess_intensity_raw`: raw beta-adjusted statistical intensity before clipping.
- `cell_stat_ai_excess_intensity`: clipped statistical intensity.
- `cell_economic_ai_intensity`: economic AI relevance score used in blend.
- `monotonic_constraint_applied`: whether the coherence floor was applied to explicitly AI-linked industries.
- `reliability_flag`: A/B/C/D/X proxy quality flag.

## single_stock_override_vector_v5.csv
- `ticker`: override ticker.
- `beta_world_stock`: stock market beta.
- `theta_ai_abs_stock`: absolute beta to AI raw basket.
- `stat_ai_excess_intensity`: beta-adjusted statistical AI-excess intensity.
- `economic_ai_intensity`: economic AI score.
- `final_ai_excess_intensity`: final override intensity.
- `mild_stress_pct`, `base_stress_pct`, `severe_stress_pct`: scenario shocks.

## Formula
`stress_log_return = beta_world_cell*S_WORLD_log + final_ai_excess_intensity*S_AI_EXCESS_log`

`stress_simple_return = exp(stress_log_return)-1`

`stress_pnl_usd = -signed_market_value_usd * stress_simple_return`
'''
(OUT/'data_dictionary.md').write_text(ddict)

# -----------------------------
# Vanilla LaTeX report
# -----------------------------
def rep(txt, mapping):
    for k,v in mapping.items(): txt=txt.replace('@@'+k+'@@',str(v))
    return txt

report_template = r'''
\documentclass[11pt]{article}
\usepackage{graphicx}
\begin{document}

\title{AI Unwind Stress Framework: Coherent Country-Industry and Single-Stock Vector}
\author{Alex Zhang}
\date{July 2026}
\maketitle

\section*{Executive summary}

This report presents a coherent stress framework for an AI-led equity unwind. The model converts a historical AI/TMT-style boom-unwind analogue into a cross-sectional stress vector across countries, industries, index exposures, and selected single-stock AI epicenter names. The framework is designed around one central distinction:
\[
\hbox{total stress}=\hbox{market de-risking}+\hbox{AI-excess repricing}.
\]
A broad index, a technology hardware stock, a utility, and an energy company should not all receive the same shock. The market component captures the common selloff; the AI-excess component captures theme-specific repricing through hardware, semiconductors, cloud, software, power demand, grid equipment, financing channels, and related supply chains.

The base case uses a valuation-calibrated AI-excess shock. The severe case keeps the full dot-com TMT analogue. The mild case is a scaled version of the base stress. The scenario set is:

\input{table_scenarios.tex}

The base valuation severity scalar is
\[
\kappa_{base}=@@KAPPA_BASE@@.
\]
This means the base case uses @@KAPPA_BASE_PCT@@\% of the dot-com AI/TMT excess repricing channel. The full dot-com analogue is retained as the severe case, not discarded.

Key base results are: S\&P 500 proxy @@SPY_BASE@@\%, Korea broad index/ETF @@KOREA_INDEX@@\%, Korea technology hardware @@KOREA_TECH@@\%, Taiwan technology hardware @@TAIWAN_TECH@@\%, and NVDA single-stock override @@NVDA_BASE@@\%. The vector contains @@N_ROWS@@ rows across @@N_COUNTRIES@@ country or regional buckets and @@N_INDUSTRIES@@ client industry labels. The in-scope base stress range is @@MIN_BASE@@\% to @@MAX_BASE@@\%, with median @@MEDIAN_BASE@@\%.

\section{Model requirements}

The model must satisfy four requirements. First, it must produce a usable stress vector even when individual non-U.S. stock returns are unavailable. Second, it must avoid double-counting the market component of the AI trade. Third, it must produce economically coherent cross-sectional ordering: an explicitly AI-linked technology hardware bucket should not be less stressed than the broad country index under an AI-specific unwind. Fourth, the output must be directly mergeable to position data using country and industry labels.

The model therefore operates at the country-industry level. For a position with country bucket $b$ and industry bucket $g$, the stress return is
\[
\widehat R_{b,g}^{s}
=
\beta_{b,g}^{W}S_W^s+I_{b,g}^{AI}S_{AI}^{s}.
\]
Here $S_W^s$ is the world equity shock, $S_{AI}^s$ is the AI-excess shock, $\beta_{b,g}^{W}$ is the cell market beta, and $I_{b,g}^{AI}$ is the cell AI-excess intensity. This is a stress model, not a point forecast.

\begin{figure}[h]
\centering
\includegraphics[width=0.92\textwidth]{figures/01_model_structure.png}
\caption{The model separates valuation-calibrated AI-excess repricing from broad market de-risking.}
\end{figure}

\section{Shock calibration}

The historical shock anchor comes from the dot-com TMT unwind. The TMT epicenter is represented by the Fama-French technology-related industries: software, hardware, chips, and telecom. The post-peak drawdown is decomposed into a market component and a TMT-excess component. This decomposition avoids treating all of the dot-com decline as AI-specific. The broad market part is applied through $S_W$; the incremental TMT part is applied through $S_{AI}$.

A full dot-com replay is useful as a severe analogue, but it is too strong to impose mechanically as the base case. The base case scales only the AI-excess component using Damodaran industry valuation data. Let $P_{now}^{AI}$ be the current log valuation premium of AI/TMT industries versus the market, and let $P_{2000}^{TMT}$ be the dot-com reference premium. The base severity scalar is
\[
\kappa_{base}=\mathrm{clip}\left({P_{now}^{AI}\over P_{2000}^{TMT}},0.50,1.00\right).
\]
The market component is not scaled by this valuation ratio, because broad market de-risking can occur even if today's AI valuation premium is below dot-com levels.

\begin{figure}[h]
\centering
\includegraphics[width=0.88\textwidth]{figures/02_valuation_calibration.png}
\caption{Valuation calibration using Damodaran industry valuation data. The base case scales the AI-excess component, not the market component.}
\end{figure}

\begin{figure}[h]
\centering
\includegraphics[width=0.88\textwidth]{figures/03_scenario_decomposition.png}
\caption{Mild, base, and severe scenario components.}
\end{figure}

\section{Country-industry exposure model}

For each country or region proxy, monthly returns are used to estimate a market beta $\beta_b^W$ and an absolute AI co-movement beta $\theta_b$. For each industry proxy, monthly returns are used to estimate $\beta_g^W$ and $\theta_g$. The absolute AI beta is not used directly as AI-excess exposure, because the AI basket itself contains ordinary market exposure.

The correction is:
\[
\theta_y \approx \beta_y^W\theta_W + I_y^{AI}(1-\theta_W),
\]
where $\theta_W$ is the world index's absolute beta to the AI basket. Solving gives the statistical AI-excess intensity:
\[
I_y^{stat}=\mathrm{clip}\left({\theta_y-\beta_y^W\theta_W\over 1-\theta_W},0,I_{max}\right).
\]
This is the key identification step. A country or industry can have high absolute co-movement with the AI basket simply because it has high market beta. The beta-adjusted formula isolates the part that is incremental to ordinary market exposure.

The unobserved country-industry cell is built by using the country proxy as the baseline and the global industry proxy as a tilt:
\[
\beta_{b,g}^W=\beta_b^W(\beta_g^W)^{\lambda},
\]
\[
\theta_{b,g}=\theta_b\left({\theta_g\over \theta_W}\right)^{\lambda},
\]
with $\lambda=0.50$. The square-root tilt reduces overfitting because a global industry ETF is only an imperfect proxy for a local industry sleeve.

The final AI-excess intensity blends statistical evidence with economic relevance:
\[
I_{b,g}^{AI}=w_{stat}I_{b,g}^{stat}+w_{econ}I_{b,g}^{econ},
\]
where $w_{stat}=@@W_STAT@@$ and $w_{econ}=@@W_ECON@@$. The economic component is industry-dominant:
\[
I_{b,g}^{econ}=0.35I_b^{econ}+0.65I_g^{econ}.
\]
The reason is that the industry label normally carries more direct information about AI transmission than the country label. The country label still matters because Taiwan, Korea, the United States, China, and Japan have different supply-chain and market-composition exposure.

For broad index and ETF rows, no industry tilt is applied:
\[
\beta_{b,index}^{W}=\beta_b^W,
\qquad
I_{b,index}^{AI}=I_b^{AI}.
\]
This makes index rows interpretable as country-market exposures, not as generic industry exposures.

Finally, the model applies a coherence projection. For industries with explicit AI relevance, the AI-excess intensity must be at least modestly above the broad country index intensity:
\[
I_{b,g}^{AI}\geq I_{b,index}^{AI}+0.05.
\]
This is not a return forecast. It is an internal consistency condition on a proxy-based latent-cell model. It prevents a broad country ETF from being more AI-excess-sensitive than its own explicitly AI-linked technology hardware bucket purely because of proxy arithmetic.

\section{Results}

Representative outputs are shown below. The Korea result illustrates the corrected country-industry ordering: the broad Korea index/ETF row is less negative than Korea technology hardware. Utilities and energy are stressed through the market channel and through a positive AI relevance channel, but they do not receive the same AI-excess intensity as technology hardware.

\input{table_samples.tex}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\textwidth]{figures/04_sample_outputs.png}
\caption{Representative base stress outputs.}
\end{figure}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\textwidth]{figures/05_base_heatmap_selected.png}
\caption{Selected base country-industry stress heatmap. Values are simple return shocks in percent.}
\end{figure}

\section{Coherence diagnostics}

The table below compares each selected country index row with the same country's technology hardware row. In every listed case, technology hardware is at least as stressed as the broad country index. This is a necessary sanity check for an AI-specific unwind scenario.

\input{table_coherence.tex}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\textwidth]{figures/06_coherence_index_vs_tech.png}
\caption{Coherence check: broad country index/ETF versus technology hardware.}
\end{figure}

\section{Single-stock override vector}

The country-industry vector is the default mapping. Selected AI epicenter names receive single-stock overrides because broad buckets cannot capture company-specific concentration. The same formula is used:
\[
\widehat R_i^s=\beta_i^WS_W^s+I_i^{AI}S_{AI}^s.
\]
The stock-level AI-excess intensity uses the same beta-adjusted decomposition:
\[
I_i^{stat}=\mathrm{clip}\left({\theta_i-\beta_i^W\theta_W\over 1-\theta_W},0,I_{max}\right).
\]
This avoids interpreting high beta as pure AI exposure. NVDA remains highly stressed because it has both high market beta and very high AI-excess intensity, but the base case is valuation-adjusted and the full dot-com analogue is reserved for the severe scenario.

\input{table_single_stocks.tex}

\begin{figure}[h]
\centering
\includegraphics[width=0.90\textwidth]{figures/08_single_stock_overrides.png}
\caption{Single-stock override vector under mild, base, and severe scenarios.}
\end{figure}

\section{Implementation}

For a position with signed USD market value $x_i$, the model applies the merged stress return $\widehat R_i^s$ and computes
\[
\widehat L_i^s=-x_i\widehat R_i^s.
\]
For a long position, a negative stress return produces a positive loss. For a short position, a negative stress return produces a gain unless an adverse-only convention is imposed separately.

The provided application template expects at least three columns:
\[
\hbox{country},\quad \hbox{industry},\quad \hbox{signed\_market\_value\_usd}.
\]
If a ticker column is present and the ticker appears in the single-stock override file, the override is used. If client-level margin is present, the template computes loss-to-margin. If holding market capitalization is present, the template can apply an optional liquidity add-on after the factor loss is calculated.

Market capitalization is not used to change the factor return. It is not a valuation metric by itself. It should only be used as a liquidity or gap-risk overlay unless price-to-earnings, enterprise-value-to-sales, or other valuation fundamentals are available.

\section{Limitations}

This framework is a systematic stress vector, not a point forecast. It does not estimate idiosyncratic earnings shocks for every global stock. ETF proxies introduce basis risk, especially for small countries and narrow industries. Damodaran valuation data calibrate industry-level severity, not individual company intrinsic value. Forward earnings can be optimistic, while trailing earnings can be cyclical. The single-stock override vector improves treatment of major AI names, but it remains scenario-based rather than a fundamental valuation model.

These limitations are manageable because the output is intended to provide a consistent cross-sectional stress map. The strength of the framework is not precision at the individual security level; it is coherent ranking, transparent scenario decomposition, and direct applicability to country-industry position data.

\section{References}

Barberis, N., Greenwood, R., Jin, L., and Shleifer, A. (2018). Extrapolation and Bubbles. Journal of Financial Economics, 129(2), 203--227.

Greenwood, R., Shleifer, A., and You, Y. (2019). Bubbles for Fama. Journal of Financial Economics, 131(1), 20--43.

Heston, S. L. and Rouwenhorst, K. G. (1994). Does Industrial Structure Explain the Benefits of International Diversification? Journal of Financial Economics, 36(1), 3--27.

Griffin, J. M. and Karolyi, G. A. (1998). Another Look at the Role of the Industrial Structure of Markets for International Diversification Strategies. Journal of Financial Economics, 50(3), 351--373.

Newey, W. K. and West, K. D. (1987). A Simple, Positive Semi-definite, Heteroskedasticity and Autocorrelation Consistent Covariance Matrix. Econometrica, 55(3), 703--708.

Ofek, E. and Richardson, M. (2003). DotCom Mania: The Rise and Fall of Internet Stock Prices. Journal of Finance, 58(3), 1113--1137.

Damodaran, A. Industry valuation datasets and archives. NYU Stern School of Business.

Amundi Investment Institute. AI Boom or Bubble? Lessons from the Dot-Com Period. 2026.

\end{document}
'''
# grab values for report
get_stress=lambda cb,norm: float(stress[(stress.country_bucket.eq(cb))&(stress.client_industry_normalized.eq(norm))]['base_stress_pct'].iloc[0])
report=rep(report_template, {
    'KAPPA_BASE':f'{KAPPA_BASE:.3f}',
    'KAPPA_BASE_PCT':f'{100*KAPPA_BASE:.1f}',
    'SPY_BASE':f'{summary["spy_proxy_base_pct"]:.1f}',
    'KOREA_INDEX':f'{summary["korea_index_base_pct"]:.1f}',
    'KOREA_TECH':f'{summary["korea_tech_hardware_base_pct"]:.1f}',
    'TAIWAN_TECH':f'{get_stress("Taiwan","technology hardware storage peripheral"):.1f}',
    'NVDA_BASE':f'{summary["nvda_base_pct"]:.1f}',
    'N_ROWS':str(summary['num_rows']),
    'N_COUNTRIES':str(summary['num_country_buckets']),
    'N_INDUSTRIES':str(summary['num_client_industry_labels']),
    'MIN_BASE':f'{summary["base_min_stress_pct"]:.1f}',
    'MAX_BASE':f'{summary["base_max_stress_pct"]:.1f}',
    'MEDIAN_BASE':f'{summary["base_median_stress_pct"]:.1f}',
    'W_STAT':f'{WEIGHT_STAT:.2f}',
    'W_ECON':f'{WEIGHT_ECON:.2f}',
})
(OUT/'main.tex').write_text(report)

# Compile and render
subprocess.run(['pdflatex','-interaction=nonstopmode','main.tex'], cwd=OUT, stdout=open(OUT/'compile1.log','w'), stderr=subprocess.STDOUT, check=False)
subprocess.run(['pdflatex','-interaction=nonstopmode','main.tex'], cwd=OUT, stdout=open(OUT/'compile2.log','w'), stderr=subprocess.STDOUT, check=False)
render_dir=OUT/'render_check'
render_dir.mkdir(exist_ok=True)
subprocess.run(['python','/home/oai/skills/pdfs/scripts/render_pdf.py',str(OUT/'main.pdf'),'--out_dir',str(render_dir),'--dpi','160'], stdout=open(OUT/'render.log','w'), stderr=subprocess.STDOUT, check=False)

# Create a quick montage for visual inspection
try:
    from PIL import Image, ImageDraw
    pages=list(render_dir.glob('page-*.png'))[:6]
    thumbs=[]
    for p in pages:
        im=Image.open(p).convert('RGB')
        im.thumbnail((260,340))
        thumbs.append(im.copy())
    if thumbs:
        W=3*260; H=2*340
        canvas=Image.new('RGB',(W,H),'white')
        for idx,im in enumerate(thumbs):
            x=(idx%3)*260; y=(idx//3)*340
            canvas.paste(im,(x,y))
        canvas.save(OUT/'render_montage.png')
except Exception as e:
    (OUT/'montage_error.txt').write_text(str(e))

# Zip package
zip_path=ROOT/'ai_country_industry_stress_research_v5_outputs.zip'
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in OUT.rglob('*'):
        if p.is_file():
            rel=p.relative_to(OUT)
            if str(rel).startswith('render_check/') or rel.suffix in ['.aux','.log']:
                continue
            z.write(p, arcname=str(Path('ai_country_industry_stress_research_v5')/rel))
print(json.dumps(summary, indent=2))
print('PDF', OUT/'main.pdf')
print('ZIP', zip_path)
