"""Historical shock decomposition, fixed-horizon anchors, and scenario surface."""
from __future__ import annotations
import numpy as np
import pandas as pd

KAPPA_BASE = 0.6707390702673786
SCENARIO_SPEC = {
    "mild":   {"world_scale": 0.50, "kappa": 0.5 * KAPPA_BASE},
    "base":   {"world_scale": 1.00, "kappa": KAPPA_BASE},
    "severe": {"world_scale": 1.00, "kappa": 1.00},
    "extreme":{"world_scale": 1.00, "kappa": 1.50},
    "worst":  {"world_scale": 1.00, "kappa": 2.00},
}
HORIZONS = {"1w": 5, "2w": 10, "1m": 21, "2m": 42}


def log_return_between(price: pd.Series, start_pos: int, end_pos: int):
    p = pd.Series(price, dtype=float).dropna()
    return float(np.log(p.iloc[end_pos] / p.iloc[start_pos]))


def decompose_historical_shock(epicenter_log, world_log):
    """S_X = S_E - S_W so S_E = S_W + S_X exactly in log space."""
    return {
        "S_EPICENTER_log": float(epicenter_log),
        "S_WORLD_log": float(world_log),
        "S_AI_EXCESS_log": float(epicenter_log - world_log),
    }


def peak_anchored_raw_horizons(epicenter_price, world_price, peak_date, horizons=HORIZONS):
    """Measure actual post-peak endpoint shocks rather than linearly scaling terminal loss."""
    e = pd.Series(epicenter_price, copy=True).dropna().sort_index()
    w = pd.Series(world_price, copy=True).dropna().sort_index()
    common = pd.concat([e.rename("epicenter"), w.rename("world")], axis=1).dropna()
    t0 = common.index.get_indexer([pd.Timestamp(peak_date)], method="nearest")[0]
    rows = []
    for label, sessions in horizons.items():
        end = t0 + sessions
        if end >= len(common):
            raise ValueError(f"insufficient history for {label}")
        se = float(np.log(common["epicenter"].iloc[end] / common["epicenter"].iloc[t0]))
        sw = float(np.log(common["world"].iloc[end] / common["world"].iloc[t0]))
        rows.append({
            "horizon": label, "sessions": sessions,
            "peak_date": common.index[t0], "endpoint": common.index[end],
            "S_EPICENTER_raw_log": se, "S_WORLD_raw_log": sw,
            "S_AI_EXCESS_raw_log": se - sw,
        })
    return pd.DataFrame(rows)


def scenario_surface(raw_horizons: pd.DataFrame, scenario_spec=SCENARIO_SPEC):
    """Apply scenario world-scale and kappa to every raw historical horizon."""
    rows = []
    for _, h in raw_horizons.iterrows():
        for scenario, spec in scenario_spec.items():
            sw = float(spec["world_scale"]) * float(h["S_WORLD_raw_log"])
            sx = float(spec["kappa"]) * float(h["S_AI_EXCESS_raw_log"])
            se = sw + sx
            rows.append({
                "horizon": h["horizon"], "scenario": scenario,
                "world_scale": spec["world_scale"], "kappa": spec["kappa"],
                "S_WORLD_log": sw, "S_AI_EXCESS_log": sx,
                "S_AI_EPICENTER_log": se,
                "S_WORLD_simple": np.exp(sw) - 1.0,
                "S_AI_EXCESS_simple": np.exp(sx) - 1.0,
                "S_AI_EPICENTER_simple": np.exp(se) - 1.0,
            })
    return pd.DataFrame(rows)


def terminal_reference_scenarios():
    """Exact terminal factor anchors inherited from the audited calibration."""
    severe_world = -0.2612572967420284
    severe_excess = -0.7576212009788291
    rows = []
    for scenario, spec in SCENARIO_SPEC.items():
        sw = spec["world_scale"] * severe_world
        sx = spec["kappa"] * severe_excess
        se = sw + sx
        rows.append({
            "scenario": scenario, "world_scale": spec["world_scale"],
            "valuation_severity_scalar": spec["kappa"],
            "S_WORLD_log": sw, "S_AI_EXCESS_log": sx,
            "S_AI_EPICENTER_log": se,
            "S_WORLD_simple": np.exp(sw) - 1.0,
            "S_AI_EXCESS_simple": np.exp(sx) - 1.0,
            "S_AI_EPICENTER_simple": np.exp(se) - 1.0,
        })
    return pd.DataFrame(rows)


def stress_log_return(beta_world, ai_intensity, world_shock_log, ai_excess_shock_log):
    return (
        np.asarray(beta_world, dtype=float) * float(world_shock_log)
        + np.asarray(ai_intensity, dtype=float) * float(ai_excess_shock_log)
    )
