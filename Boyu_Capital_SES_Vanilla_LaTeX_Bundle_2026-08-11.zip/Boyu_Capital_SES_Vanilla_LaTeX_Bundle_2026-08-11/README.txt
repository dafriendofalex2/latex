Boyu Capital - Counterparty Overview for Strategic Equity Solutions
Information cut-off: 11 August 2026

VANILLA LATEX BUILD
-------------------
This bundle intentionally uses no external LaTeX packages.

Compile with:
  pdflatex main.tex
  pdflatex main.tex

Files:
  main.tex        - report source
  references.tex  - bibliography using standard thebibliography environment
  main.pdf        - compiled output

No geometry, hyperref, booktabs, longtable, tabularx, xcolor, microtype,
BibTeX, Biber, latexmk, Perl, shell escape, or other add-on packages are required.
