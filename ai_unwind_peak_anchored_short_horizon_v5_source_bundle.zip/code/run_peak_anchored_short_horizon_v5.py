import os, re, math, json, shutil, subprocess, textwrap, zipfile
from pathlib import Path
from datetime import datetime

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path('/mnt/data')
OUT = ROOT / 'ai_unwind_short_horizon_peak_anchored_v5'
DATA = OUT / 'data'
FIG = OUT / 'figures'
CODE = OUT / 'code'
for d in [OUT, DATA, FIG, CODE]:
    d.mkdir(parents=True, exist_ok=True)

# Grounded uploaded paths
PATHS = {
    'ci': ROOT / 'country_industry_stress_vector_v5(1).csv',
    'ss': ROOT / 'single_stock_override_vector_v5(1).csv',
    'scenario': ROOT / 'scenario_parameters_v5.csv',
    'spx': ROOT / 'spx(1).csv',
    'ff49_daily': ROOT / '49_Industry_Portfolios_Daily(1).csv',
    'ff_factors_daily': ROOT / 'F-F_Research_Data_Factors_daily(1).csv',
}
for k,p in PATHS.items():
    if not p.exists():
        raise FileNotFoundError(f'Missing required file {k}: {p}')

# ----------------------------
# Parsers
# ----------------------------
def parse_french_49_daily(path: Path) -> pd.DataFrame:
    with open(path, 'r', errors='replace') as f:
        lines = f.readlines()
    header_idx = None
    for i, line in enumerate(lines):
        if line.strip().startswith(',Agric'):
            header_idx = i
            break
    if header_idx is None:
        raise ValueError('Could not locate FF49 value-weighted daily header')
    header = [x.strip() for x in lines[header_idx].strip().split(',')]
    cols = ['date'] + header[1:]
    rows = []
    for line in lines[header_idx + 1:]:
        if 'Average Equal Weighted Returns' in line or 'Copyright' in line:
            break
        first = line.split(',', 1)[0].strip()
        if not re.match(r'^\d{8}$', first):
            break
        parts = [x.strip() for x in line.rstrip('\n').split(',')]
        if len(parts) >= len(cols):
            rows.append(parts[:len(cols)])
    df = pd.DataFrame(rows, columns=cols)
    df['date'] = pd.to_datetime(df['date'], format='%Y%m%d')
    for c in cols[1:]:
        df[c] = pd.to_numeric(df[c], errors='coerce') / 100.0
        df.loc[df[c] <= -0.99, c] = np.nan
    return df.set_index('date').sort_index()


def parse_french_factors_daily(path: Path) -> pd.DataFrame:
    with open(path, 'r', errors='replace') as f:
        lines = f.readlines()
    header_idx = None
    for i, line in enumerate(lines):
        if line.strip().startswith(',Mkt-RF'):
            header_idx = i
            break
    if header_idx is None:
        raise ValueError('Could not locate FF factor daily header')
    header = [x.strip() for x in lines[header_idx].strip().split(',')]
    cols = ['date'] + header[1:]
    rows = []
    for line in lines[header_idx + 1:]:
        first = line.split(',', 1)[0].strip()
        if not re.match(r'^\d{8}$', first):
            break
        parts = [x.strip() for x in line.rstrip('\n').split(',')]
        if len(parts) >= len(cols):
            rows.append(parts[:len(cols)])
    df = pd.DataFrame(rows, columns=cols)
    df['date'] = pd.to_datetime(df['date'], format='%Y%m%d')
    for c in cols[1:]:
        df[c] = pd.to_numeric(df[c], errors='coerce') / 100.0
    return df.set_index('date').sort_index()


def parse_spx(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    # Expected: date, close. Date example: 02-Jan-86.
    df.columns = [c.strip().lower() for c in df.columns]
    if 'date' not in df.columns or 'close' not in df.columns:
        raise ValueError(f'SPX file must have date and close columns, found {df.columns.tolist()}')
    df['date'] = pd.to_datetime(df['date'], format='%d-%b-%y', errors='coerce')
    if df['date'].isna().any():
        df['date'] = pd.to_datetime(df['date'], errors='coerce')
    df['close'] = pd.to_numeric(df['close'], errors='coerce')
    df = df.dropna(subset=['date','close']).sort_values('date').drop_duplicates('date')
    df = df.set_index('date')
    df['spx_log_ret'] = np.log(df['close']).diff()
    return df

# ----------------------------
# Load data
# ----------------------------
ci = pd.read_csv(PATHS['ci'])
ss = pd.read_csv(PATHS['ss'])
scenario_terminal = pd.read_csv(PATHS['scenario'])
ff49 = parse_french_49_daily(PATHS['ff49_daily'])
ff = parse_french_factors_daily(PATHS['ff_factors_daily'])
spx = parse_spx(PATHS['spx'])

# Required exposure columns
for col in ['beta_world_cell','final_ai_excess_intensity']:
    if col not in ci.columns:
        raise ValueError(f'country-industry vector missing {col}')
for col in ['beta_world_stock','final_ai_excess_intensity']:
    if col not in ss.columns:
        raise ValueError(f'single-stock vector missing {col}')

# Kappa from terminal v5 scenario file
base_kappa = float(scenario_terminal.loc[scenario_terminal['scenario'].str.lower()=='base', 'valuation_severity_scalar'].iloc[0])

# ----------------------------
# Build daily calibration series
# ----------------------------
TMT_COLS = ['Hardw','Softw','Chips','Telcm']
missing_cols = [c for c in TMT_COLS if c not in ff49.columns]
if missing_cols:
    raise ValueError(f'FF49 daily missing TMT columns: {missing_cols}')
original_ff49_cols = [c for c in ff49.columns if c not in ['TMT4_simple','TMT4_log','All49_simple','All49_log']]
ff49['TMT4_simple'] = ff49[TMT_COLS].mean(axis=1, skipna=False)
ff49['TMT4_log'] = np.log1p(ff49['TMT4_simple'])
ff49['All49_simple'] = ff49[original_ff49_cols].mean(axis=1, skipna=True)
ff49['All49_log'] = np.log1p(ff49['All49_simple'])

ff['ff_market_simple'] = ff['Mkt-RF'] + ff['RF']
ff['ff_market_log'] = np.log1p(ff['ff_market_simple'])

# Primary broad leg is SPX because user supplied SPX historical data and it is the standard broad benchmark.
common = ff49[['TMT4_simple','TMT4_log','All49_simple','All49_log']].join(spx[['close','spx_log_ret']], how='inner')
common = common.join(ff[['ff_market_simple','ff_market_log']], how='left')
common = common.dropna(subset=['TMT4_log','spx_log_ret'])

# ----------------------------
# Dot-com peak and horizon drawdown anchor
# ----------------------------
# Peak window deliberately stops at 2000-03-31. That identifies the pre-unwind dot-com TMT peak.
cal = common.loc['1995-01-01':'2002-12-31'].copy()
if cal.empty:
    raise ValueError('No dot-com calibration data after alignment')
cal['tmt_wealth'] = np.exp(cal['TMT4_log'].cumsum())
cal['spx_wealth'] = cal['close'] / cal['close'].iloc[0]
cal['all49_wealth'] = np.exp(cal['All49_log'].cumsum())
peak_date = cal.loc[:'2000-03-31', 'tmt_wealth'].idxmax()
trough_date = cal.loc[peak_date:, 'tmt_wealth'].idxmin()
common_dates = list(common.index)
peak_pos = common_dates.index(peak_date)

# Horizon definitions: margin horizons should use maximum observed loss by the deadline, not the endpoint close only.
# For audit, also store exact end-of-horizon close-to-close results.
def horizon_anchor(h_days: int, label: str) -> dict:
    # dates after peak to h_days ahead inclusive
    if peak_pos + h_days >= len(common_dates):
        raise ValueError('Horizon exceeds data')
    exact_end_date = common_dates[peak_pos + h_days]
    # cumulative log path from peak for TMT and SPX over first h_days trading days
    fwd = common.iloc[peak_pos+1:peak_pos+h_days+1].copy()
    fwd['tmt_cum_log'] = fwd['TMT4_log'].cumsum()
    fwd['spx_cum_log'] = fwd['spx_log_ret'].cumsum()
    fwd['all49_cum_log'] = fwd['All49_log'].cumsum()
    fwd['ff_market_cum_log'] = fwd['ff_market_log'].cumsum()
    # Primary: worst TMT drawdown by the horizon
    anchor_date = fwd['tmt_cum_log'].idxmin()
    trading_days_to_anchor = int(common_dates.index(anchor_date) - peak_pos)
    fwd_to_anchor = common.iloc[peak_pos+1:peak_pos+trading_days_to_anchor+1]
    tmt_log = float(fwd_to_anchor['TMT4_log'].sum())
    spx_log = float(fwd_to_anchor['spx_log_ret'].sum())
    all49_log = float(fwd_to_anchor['All49_log'].sum())
    ff_market_log = float(fwd_to_anchor['ff_market_log'].sum())
    # Exact endpoint audit
    fwd_exact = common.iloc[peak_pos+1:peak_pos+h_days+1]
    tmt_log_exact = float(fwd_exact['TMT4_log'].sum())
    spx_log_exact = float(fwd_exact['spx_log_ret'].sum())
    all49_log_exact = float(fwd_exact['All49_log'].sum())
    ff_market_log_exact = float(fwd_exact['ff_market_log'].sum())
    return {
        'horizon': label,
        'horizon_trading_days': h_days,
        'peak_date': peak_date.strftime('%Y-%m-%d'),
        'anchor_date': anchor_date.strftime('%Y-%m-%d'),
        'trading_days_to_anchor': trading_days_to_anchor,
        'exact_end_date': exact_end_date.strftime('%Y-%m-%d'),
        'S_TMT_log': tmt_log,
        'S_WORLD_log': spx_log,
        'S_AI_EXCESS_log': tmt_log - spx_log,
        'S_ALL49_log_audit': all49_log,
        'S_AI_EXCESS_vs_ALL49_log_audit': tmt_log - all49_log,
        'S_FF_MARKET_log_audit': ff_market_log,
        'S_AI_EXCESS_vs_FF_MARKET_log_audit': tmt_log - ff_market_log,
        'endpoint_S_TMT_log': tmt_log_exact,
        'endpoint_S_WORLD_log': spx_log_exact,
        'endpoint_S_AI_EXCESS_log': tmt_log_exact - spx_log_exact,
        'endpoint_S_ALL49_log_audit': all49_log_exact,
        'endpoint_S_AI_EXCESS_vs_ALL49_log_audit': tmt_log_exact - all49_log_exact,
        'endpoint_S_FF_MARKET_log_audit': ff_market_log_exact,
        'endpoint_S_AI_EXCESS_vs_FF_MARKET_log_audit': tmt_log_exact - ff_market_log_exact,
    }

anchors = [horizon_anchor(10, '2w'), horizon_anchor(21, '1m')]
anchor_df = pd.DataFrame(anchors)
for col in [c for c in anchor_df.columns if c.endswith('_log') or '_log_' in c]:
    anchor_df[col.replace('_log','_simple')] = np.exp(anchor_df[col]) - 1
    anchor_df[col.replace('_log','_pct')] = 100 * (np.exp(anchor_df[col]) - 1)
anchor_df.to_csv(DATA / 'short_horizon_dotcom_anchor_diagnostics.csv', index=False)

# Terminal diagnostic from same daily data: not used directly, but useful to audit difference from v5 terminal model.
term_tmt_log = float(common.loc[peak_date:trough_date,'TMT4_log'].iloc[1:].sum())
term_spx_log = float(common.loc[peak_date:trough_date,'spx_log_ret'].iloc[1:].sum())
terminal_daily_audit = pd.DataFrame([{
    'peak_date': peak_date.strftime('%Y-%m-%d'),
    'trough_date': trough_date.strftime('%Y-%m-%d'),
    'trading_days_to_trough': int(common_dates.index(trough_date)-peak_pos),
    'TMT_peak_to_trough_log': term_tmt_log,
    'TMT_peak_to_trough_pct': 100*(math.exp(term_tmt_log)-1),
    'SPX_same_window_log': term_spx_log,
    'SPX_same_window_pct': 100*(math.exp(term_spx_log)-1),
    'TMT_excess_vs_SPX_log': term_tmt_log - term_spx_log,
    'TMT_excess_vs_SPX_pct_equiv': 100*(math.exp(term_tmt_log - term_spx_log)-1),
}])
terminal_daily_audit.to_csv(DATA / 'terminal_daily_audit_not_used_as_short_horizon_anchor.csv', index=False)

# ----------------------------
# Scenario ladder
# ----------------------------
def scenario_ladder(anchor: dict) -> pd.DataFrame:
    h = anchor['horizon']
    S_W_raw = anchor['S_WORLD_log']
    S_X_raw = anchor['S_AI_EXCESS_log']
    rows = []
    definitions = [
        ('mild', 0.5, 0.5 * base_kappa, 'Half market shock plus half of valuation-adjusted TMT-excess shock.'),
        ('base', 1.0, base_kappa, 'Full market shock plus valuation-adjusted TMT-excess shock.'),
        ('severe', 1.0, 1.0, 'Full dot-com short-horizon market shock plus full TMT-excess shock.'),
    ]
    for scenario, world_scale, ai_scalar, desc in definitions:
        sw = world_scale * S_W_raw
        sx = ai_scalar * S_X_raw
        se = sw + sx
        rows.append({
            'horizon': h,
            'scenario': scenario,
            'horizon_trading_days': anchor['horizon_trading_days'],
            'peak_date': anchor['peak_date'],
            'anchor_date': anchor['anchor_date'],
            'trading_days_to_anchor': anchor['trading_days_to_anchor'],
            'exact_end_date': anchor['exact_end_date'],
            'world_scale': world_scale,
            'valuation_severity_scalar': ai_scalar,
            'S_WORLD_raw_dotcom_log': S_W_raw,
            'S_AI_EXCESS_raw_dotcom_log': S_X_raw,
            'S_WORLD_log': sw,
            'S_AI_EXCESS_log': sx,
            'S_AI_EPICENTER_log': se,
            'S_WORLD_simple': math.exp(sw) - 1,
            'S_WORLD_pct': 100 * (math.exp(sw) - 1),
            'S_AI_EXCESS_simple': math.exp(sx) - 1,
            'S_AI_EXCESS_pct': 100 * (math.exp(sx) - 1),
            'S_AI_EPICENTER_simple': math.exp(se) - 1,
            'S_AI_EPICENTER_pct': 100 * (math.exp(se) - 1),
            'description': desc,
            'anchor_method': 'Peak-anchored maximum TMT drawdown observed by the horizon deadline',
            'broad_market_proxy': 'S&P 500 daily close from uploaded spx file',
            'tmt_proxy': 'Equal-weight daily-rebalanced FF49 Hardw, Softw, Chips, Telcm value-weighted industry returns',
        })
    return pd.DataFrame(rows)

scen = pd.concat([scenario_ladder(a) for a in anchors], ignore_index=True)
scen.to_csv(ROOT / 'ai_unwind_v5_peak_anchored_short_horizon_scenario_parameters.csv', index=False)
scen.to_csv(DATA / 'ai_unwind_v5_peak_anchored_short_horizon_scenario_parameters.csv', index=False)

# ----------------------------
# Apply scenarios to vector and single-stock overrides
# ----------------------------
SCEN_COLS = [
    'mild_stress_log','mild_stress_simple','mild_stress_pct','mild_world_component_log','mild_ai_excess_component_log','mild_valuation_severity_scalar',
    'base_stress_log','base_stress_simple','base_stress_pct','base_world_component_log','base_ai_excess_component_log','base_valuation_severity_scalar',
    'severe_stress_log','severe_stress_simple','severe_stress_pct','severe_world_component_log','severe_ai_excess_component_log','severe_valuation_severity_scalar'
]

def apply_to_df(df: pd.DataFrame, beta_col: str, intensity_col: str, horizon: str, scen_df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for c in SCEN_COLS:
        if c in out.columns:
            out = out.drop(columns=[c])
    out.insert(0, 'short_horizon_anchor_method', 'peak_anchored_max_drawdown_by_margin_horizon')
    out.insert(1, 'short_horizon', horizon)
    ssub = scen_df[scen_df['horizon']==horizon].copy()
    for _, row in ssub.iterrows():
        sc = row['scenario']
        world_comp = out[beta_col].astype(float) * row['S_WORLD_log']
        ai_comp = out[intensity_col].astype(float) * row['S_AI_EXCESS_log']
        stress_log = world_comp + ai_comp
        out[f'{sc}_stress_log'] = stress_log
        out[f'{sc}_stress_simple'] = np.exp(stress_log) - 1
        out[f'{sc}_stress_pct'] = 100 * (np.exp(stress_log) - 1)
        out[f'{sc}_world_component_log'] = world_comp
        out[f'{sc}_ai_excess_component_log'] = ai_comp
        out[f'{sc}_valuation_severity_scalar'] = row['valuation_severity_scalar']
    return out

outputs = {}
for h in ['2w','1m']:
    ci_h = apply_to_df(ci, 'beta_world_cell', 'final_ai_excess_intensity', h, scen)
    ss_h = apply_to_df(ss, 'beta_world_stock', 'final_ai_excess_intensity', h, scen)
    ci_path = ROOT / f'ai_unwind_v5_{h}_peak_anchored_stress_vector.csv'
    ss_path = ROOT / f'ai_unwind_v5_{h}_peak_anchored_single_stock_override.csv'
    ci_h.to_csv(ci_path, index=False)
    ss_h.to_csv(ss_path, index=False)
    ci_h.to_csv(DATA / ci_path.name, index=False)
    ss_h.to_csv(DATA / ss_path.name, index=False)
    outputs[(h,'ci')] = ci_h
    outputs[(h,'ss')] = ss_h

# Summaries
summary_rows=[]
for h in ['2w','1m']:
    ci_h = outputs[(h,'ci')]
    ss_h = outputs[(h,'ss')]
    for sc in ['mild','base','severe']:
        summary_rows.append({
            'horizon':h,
            'dataset':'country_industry',
            'scenario':sc,
            'rows':len(ci_h),
            'min_stress_pct':ci_h[f'{sc}_stress_pct'].min(),
            'p05_stress_pct':ci_h[f'{sc}_stress_pct'].quantile(0.05),
            'median_stress_pct':ci_h[f'{sc}_stress_pct'].median(),
            'p95_stress_pct':ci_h[f'{sc}_stress_pct'].quantile(0.95),
            'max_stress_pct':ci_h[f'{sc}_stress_pct'].max(),
        })
        summary_rows.append({
            'horizon':h,
            'dataset':'single_stock_override',
            'scenario':sc,
            'rows':len(ss_h),
            'min_stress_pct':ss_h[f'{sc}_stress_pct'].min(),
            'p05_stress_pct':ss_h[f'{sc}_stress_pct'].quantile(0.05),
            'median_stress_pct':ss_h[f'{sc}_stress_pct'].median(),
            'p95_stress_pct':ss_h[f'{sc}_stress_pct'].quantile(0.95),
            'max_stress_pct':ss_h[f'{sc}_stress_pct'].max(),
        })
summary = pd.DataFrame(summary_rows)
summary.to_csv(DATA / 'short_horizon_vector_distribution_summary.csv', index=False)

# Representative rows selection
ci1m = outputs[('1m','ci')]
ci2w = outputs[('2w','ci')]
ss1m = outputs[('1m','ss')]
ss2w = outputs[('2w','ss')]

def find_row(df, country=None, industry_contains=None, model_scope=None):
    m = pd.Series(True, index=df.index)
    if country:
        m &= df['country_bucket'].astype(str).str.contains(country, case=False, na=False)
    if industry_contains:
        m &= df['client_industry_label'].astype(str).str.contains(industry_contains, case=False, na=False)
    if model_scope:
        m &= df['model_scope'].astype(str).str.contains(model_scope, case=False, na=False)
    x = df[m]
    return x.iloc[0] if len(x) else None

rep_specs = [
    ('Korea index / ETF', {'country':'Korea', 'industry_contains':'Index|ETF|Broad|Country', 'model_scope':None}),
    ('Korea technology hardware', {'country':'Korea', 'industry_contains':'Technology Hardware'}),
    ('Taiwan technology hardware', {'country':'Taiwan', 'industry_contains':'Technology Hardware'}),
    ('United States technology hardware', {'country':'United States', 'industry_contains':'Technology Hardware'}),
    ('United States index / ETF', {'country':'United States', 'industry_contains':'Index|ETF|Broad|Country'}),
]
# Because labels may differ, fallback searches.
rep_rows=[]
for label, spec in rep_specs:
    r2 = find_row(ci2w, **spec)
    r1 = find_row(ci1m, **spec)
    if r2 is None or r1 is None:
        # fallback: country only + first relevant broad index scope
        if 'index' in label.lower():
            m2 = ci2w['country_bucket'].astype(str).str.contains(spec.get('country',''), case=False, na=False) & ci2w['model_scope'].astype(str).str.contains('index', case=False, na=False)
            m1 = ci1m['country_bucket'].astype(str).str.contains(spec.get('country',''), case=False, na=False) & ci1m['model_scope'].astype(str).str.contains('index', case=False, na=False)
            if m2.any() and m1.any():
                r2, r1 = ci2w[m2].iloc[0], ci1m[m1].iloc[0]
        else:
            m2 = ci2w['country_bucket'].astype(str).str.contains(spec.get('country',''), case=False, na=False) & ci2w['client_industry_label'].astype(str).str.contains('technology|hardware|semiconductor', case=False, na=False)
            m1 = ci1m['country_bucket'].astype(str).str.contains(spec.get('country',''), case=False, na=False) & ci1m['client_industry_label'].astype(str).str.contains('technology|hardware|semiconductor', case=False, na=False)
            if m2.any() and m1.any():
                r2, r1 = ci2w[m2].iloc[0], ci1m[m1].iloc[0]
    if r2 is not None and r1 is not None:
        rep_rows.append({
            'row': label,
            'country_bucket': r2.get('country_bucket',''),
            'client_industry_label': r2.get('client_industry_label',''),
            'beta_world_cell': r2.get('beta_world_cell',np.nan),
            'final_ai_excess_intensity': r2.get('final_ai_excess_intensity',np.nan),
            '2w_base_stress_pct': r2['base_stress_pct'],
            '1m_base_stress_pct': r1['base_stress_pct'],
            '2w_severe_stress_pct': r2['severe_stress_pct'],
            '1m_severe_stress_pct': r1['severe_stress_pct'],
        })
# single stocks
for ticker in ['NVDA','AMD','AVGO','MSFT','GOOGL','META','AMZN','PLTR','SMCI']:
    a = ss2w[ss2w['ticker'].astype(str).str.upper()==ticker]
    b = ss1m[ss1m['ticker'].astype(str).str.upper()==ticker]
    if len(a) and len(b):
        r2=a.iloc[0]; r1=b.iloc[0]
        rep_rows.append({
            'row': f'{ticker} override',
            'country_bucket': '',
            'client_industry_label': '',
            'beta_world_cell': r2.get('beta_world_stock',np.nan),
            'final_ai_excess_intensity': r2.get('final_ai_excess_intensity',np.nan),
            '2w_base_stress_pct': r2['base_stress_pct'],
            '1m_base_stress_pct': r1['base_stress_pct'],
            '2w_severe_stress_pct': r2['severe_stress_pct'],
            '1m_severe_stress_pct': r1['severe_stress_pct'],
        })
rep_df = pd.DataFrame(rep_rows)
rep_df.to_csv(DATA / 'representative_short_horizon_results.csv', index=False)

# Data audit
file_audit = pd.DataFrame([
    {'file':'FF49 daily industry portfolios','path':str(PATHS['ff49_daily']), 'rows':len(ff49), 'date_min':ff49.index.min().strftime('%Y-%m-%d'), 'date_max':ff49.index.max().strftime('%Y-%m-%d'), 'role':'TMT epicenter daily returns'},
    {'file':'Fama-French daily factors','path':str(PATHS['ff_factors_daily']), 'rows':len(ff), 'date_min':ff.index.min().strftime('%Y-%m-%d'), 'date_max':ff.index.max().strftime('%Y-%m-%d'), 'role':'broad-market audit using Mkt-RF + RF'},
    {'file':'S&P 500 daily close','path':str(PATHS['spx']), 'rows':len(spx), 'date_min':spx.index.min().strftime('%Y-%m-%d'), 'date_max':spx.index.max().strftime('%Y-%m-%d'), 'role':'primary broad-market shock leg'},
    {'file':'country_industry_stress_vector_v5','path':str(PATHS['ci']), 'rows':len(ci), 'date_min':'n/a', 'date_max':'n/a', 'role':'v5 exposure matrix'},
    {'file':'single_stock_override_vector_v5','path':str(PATHS['ss']), 'rows':len(ss), 'date_min':'n/a', 'date_max':'n/a', 'role':'single-stock override exposure matrix'},
    {'file':'scenario_parameters_v5','path':str(PATHS['scenario']), 'rows':len(scenario_terminal), 'date_min':'n/a', 'date_max':'n/a', 'role':'base kappa and terminal scenario logic'},
])
file_audit.to_csv(DATA / 'data_audit.csv', index=False)

# ----------------------------
# Figures
# ----------------------------
# Figure 1: path around peak
path_start = pd.Timestamp('2000-03-01')
path_end = pd.Timestamp('2000-04-28')
path = common.loc[path_start:path_end].copy()
# Normalize to 100 at peak_date
base_tmt = np.exp(common.loc[:peak_date,'TMT4_log'].sum())
# Easier: calculate relative wealth from peak by cumulative returns in period
path_rel = pd.DataFrame(index=path.index)
# For relative wealth, set value at peak to 100. Need full returns from peak.
for idx_col, ret_col, label in [('tmt_rel','TMT4_log','FF49 TMT basket'),('spx_rel','spx_log_ret','S&P 500')]:
    rel=[]
    for d in path.index:
        if d == peak_date:
            val=100.0
        elif d > peak_date:
            val=100.0*math.exp(common.loc[peak_date:d, ret_col].iloc[1:].sum())
        else:
            val=100.0*math.exp(-common.loc[d:peak_date, ret_col].iloc[1:].sum())
        rel.append(val)
    path_rel[idx_col]=rel
fig, ax = plt.subplots(figsize=(8.8, 4.8))
ax.plot(path_rel.index, path_rel['tmt_rel'], label='FF49 TMT basket')
ax.plot(path_rel.index, path_rel['spx_rel'], label='S&P 500')
ax.axvline(peak_date, linestyle='--', linewidth=1)
for a in anchors:
    ax.axvline(pd.Timestamp(a['anchor_date']), linestyle=':', linewidth=1)
ax.set_title('Dot-com TMT peak and short-horizon drawdown anchors')
ax.set_ylabel('Index level, TMT peak = 100')
ax.legend(loc='best')
ax.grid(True, alpha=0.3)
fig.autofmt_xdate()
fig.tight_layout()
fig.savefig(FIG/'fig_01_dotcom_peak_anchored_path.png', dpi=200)
plt.close(fig)

# Figure 2: Scenario epicenter shock by horizon/scenario
plot_scen = scen.copy()
plot_scen['label'] = plot_scen['horizon'] + ' ' + plot_scen['scenario']
fig, ax = plt.subplots(figsize=(8.8, 4.8))
ax.bar(plot_scen['label'], plot_scen['S_AI_EPICENTER_pct'])
ax.set_title('Peak-anchored dot-com shock ladder: implied TMT / AI epicenter stress')
ax.set_ylabel('Simple return stress (%)')
ax.axhline(0, linewidth=0.8)
ax.grid(True, axis='y', alpha=0.3)
plt.xticks(rotation=25, ha='right')
fig.tight_layout()
fig.savefig(FIG/'fig_02_scenario_epicenter_ladder.png', dpi=200)
plt.close(fig)

# Figure 3: Component decomposition, base case
base_scen = scen[scen['scenario']=='base'].copy()
fig, ax = plt.subplots(figsize=(7.6, 4.6))
x = np.arange(len(base_scen))
world = base_scen['S_WORLD_pct'].values
excess = base_scen['S_AI_EXCESS_pct'].values
ax.bar(x, world, label='Broad market component')
ax.bar(x, excess, bottom=world, label='Valuation-scaled TMT excess component')
ax.set_xticks(x)
ax.set_xticklabels(base_scen['horizon'])
ax.set_title('Base case shock decomposition')
ax.set_ylabel('Log-component shown as simple-return equivalent (%)')
ax.axhline(0, linewidth=0.8)
ax.legend(loc='best')
ax.grid(True, axis='y', alpha=0.3)
fig.tight_layout()
fig.savefig(FIG/'fig_03_base_decomposition.png', dpi=200)
plt.close(fig)

# Figure 4: Distribution of base row stresses
fig, ax = plt.subplots(figsize=(8.8,4.8))
ax.hist(outputs[('2w','ci')]['base_stress_pct'], bins=45, alpha=0.6, label='2-week base')
ax.hist(outputs[('1m','ci')]['base_stress_pct'], bins=45, alpha=0.6, label='1-month base')
ax.set_title('Distribution of v5 country-industry base stress by horizon')
ax.set_xlabel('Stress (%)')
ax.set_ylabel('Number of country-industry rows')
ax.legend(loc='best')
ax.grid(True, axis='y', alpha=0.3)
fig.tight_layout()
fig.savefig(FIG/'fig_04_base_distribution.png', dpi=200)
plt.close(fig)

# ----------------------------
# LaTeX report (vanilla except graphicx)
# ----------------------------
def pct(x, d=2):
    try: return f'{float(x):.{d}f}\%'
    except: return 'n/a'

def val(x, d=3):
    try: return f'{float(x):.{d}f}'
    except: return 'n/a'

def latex_escape(s):
    s = str(s)
    return (s.replace('\\','\\textbackslash{}')
             .replace('&','\\&').replace('%','\\%').replace('$','\\$')
             .replace('#','\\#').replace('_','\\_').replace('{','\\{').replace('}','\\}')
             .replace('~','\\textasciitilde{}').replace('^','\\textasciicircum{}'))

# Prepare compact tables
anchor_for_tex = []
for _, r in anchor_df.iterrows():
    anchor_for_tex.append([
        r['horizon'], int(r['horizon_trading_days']), r['peak_date'], r['anchor_date'], int(r['trading_days_to_anchor']), r['exact_end_date'],
        pct(r['S_TMT_pct']), pct(r['S_WORLD_pct']), pct(r['S_AI_EXCESS_pct'])
    ])

endpoint_for_tex=[]
for _, r in anchor_df.iterrows():
    endpoint_for_tex.append([r['horizon'], r['exact_end_date'], pct(r['endpoint_S_TMT_pct']), pct(r['endpoint_S_WORLD_pct']), pct(r['endpoint_S_AI_EXCESS_pct'])])

scen_for_tex=[]
for _, r in scen.iterrows():
    scen_for_tex.append([r['horizon'], r['scenario'], pct(r['S_WORLD_pct']), pct(r['S_AI_EXCESS_pct']), pct(r['S_AI_EPICENTER_pct']), val(r['valuation_severity_scalar'],3)])

rep_for_tex=[]
# keep at most 12 rows
for _, r in rep_df.head(12).iterrows():
    rep_for_tex.append([latex_escape(r['row']), pct(r['2w_base_stress_pct']), pct(r['1m_base_stress_pct']), pct(r['2w_severe_stress_pct']), pct(r['1m_severe_stress_pct'])])

summary_for_tex=[]
for _, r in summary[(summary['dataset']=='country_industry') & (summary['scenario']=='base')].iterrows():
    summary_for_tex.append([r['horizon'], int(r['rows']), pct(r['min_stress_pct']), pct(r['p05_stress_pct']), pct(r['median_stress_pct']), pct(r['max_stress_pct'])])

# Helper to build table strings

def make_tabular(headers, rows, align=None):
    if align is None:
        align = 'l' * len(headers)
    out = []
    out.append('\\begin{center}')
    out.append('\\begin{tabular}{' + align + '}')
    out.append('\\hline')
    out.append(' & '.join(headers) + ' \\\\')
    out.append('\\hline')
    for row in rows:
        out.append(' & '.join(map(str,row)) + ' \\\\')
    out.append('\\hline')
    out.append('\\end{tabular}')
    out.append('\\end{center}')
    return '\n'.join(out)

anchor_table = make_tabular(['Horizon','Deadline','Peak','Anchor','Days','Endpoint','TMT','S\&P','TMT excess'], anchor_for_tex, 'llrrrrrrr')
endpoint_table = make_tabular(['Horizon','Endpoint','TMT','S\&P','TMT excess'], endpoint_for_tex, 'lrrrr')
scenario_table = make_tabular(['Horizon','Scenario','World','Excess','Epicenter','Scalar'], scen_for_tex, 'llrrrr')
rep_table = make_tabular(['Row','2w base','1m base','2w severe','1m severe'], rep_for_tex, 'lrrrr')
summary_table = make_tabular(['Horizon','Rows','Min','P5','Median','Max'], summary_for_tex, 'lrrrrr')

# Key numbers for prose
ad = {r['horizon']: r for _, r in anchor_df.iterrows()}
# Date and results strings
peak_s = str(peak_date.date())
trough_s = str(trough_date.date())
terminal_tmt_pct = pct(terminal_daily_audit.iloc[0]['TMT_peak_to_trough_pct'])
terminal_spx_pct = pct(terminal_daily_audit.iloc[0]['SPX_same_window_pct'])

tex = r'''
\documentclass[10pt]{article}
\usepackage{graphicx}
\setlength{\parindent}{0pt}
\setlength{\parskip}{6pt}
\setlength{\textwidth}{6.6in}
\setlength{\oddsidemargin}{0in}
\setlength{\evensidemargin}{0in}
\setlength{\textheight}{9.1in}
\setlength{\topmargin}{-0.55in}
\begin{document}

\begin{center}
{\Large \bf AI Unwind Stress Framework}\
{\large Peak-Anchored Two-Week and One-Month Drawdown Extension}\
{\normalsize Alex Zhang \quad July 2026}
\end{center}

\section*{Executive summary}

This note rebuilds the short-horizon extension of the AI unwind stress framework using the correct historical anchor. The objective is not to compress the terminal peak-to-trough shock into a shorter window. The objective is to measure what the dot-com TMT unwind looked like by an early margin horizon, then apply that short-horizon shock through the same v5 exposure matrix used in the original country-industry stress vector.

The main specification is peak-anchored. First, construct a daily dot-com TMT wealth index from the Fama-French 49 industry portfolios. TMT is defined as the equal-weight daily-rebalanced basket of Hardware, Software, Chips, and Telecom. The pre-unwind TMT peak occurs on __PEAK_DATE__. For each margin horizon, the calibration chooses the worst TMT drawdown observed by the horizon deadline. This is more relevant for margin management than using only the close exactly ten or twenty-one trading days after the peak, because a client can breach margin before the endpoint.

The two-week horizon is defined as ten trading days. The one-month horizon is defined as twenty-one trading days. The broad-market leg is measured using the uploaded S\&P 500 daily close history. The same v5 scenario ladder is then applied: mild uses half the broad-market shock and half the valuation-adjusted TMT-excess shock; base uses the full broad-market shock and the valuation-adjusted TMT-excess shock; severe uses the full broad-market shock and the full dot-com TMT-excess shock.

\section*{1. Data used}

The analysis uses the uploaded final v5 country-industry vector and single-stock override vector. The short-horizon research does not re-estimate row-level AI exposure. It replaces only the historical scenario shock vector. This is why the output remains compatible with the original v5 client P\&L workflow.

\begin{center}
\begin{tabular}{lrrl}
\hline
Dataset & Rows & Date range & Role \\
\hline
FF49 daily industry portfolios & __FF49_ROWS__ & __FF49_RANGE__ & TMT daily returns \\
Fama-French daily factors & __FF_ROWS__ & __FF_RANGE__ & market audit \\
S\&P 500 daily close & __SPX_ROWS__ & __SPX_RANGE__ & primary broad market \\
v5 country-industry vector & __CI_ROWS__ & n/a & exposure matrix \\
v5 single-stock override vector & __SS_ROWS__ & n/a & stock overrides \\
\hline
\end{tabular}
\end{center}

\section*{2. Historical short-horizon anchor}

Let $t$ index trading days. Let $R^{TMT}_t$ be the daily simple return of the TMT basket on day $t$. The basket is
\[
R^{TMT}_t={1\over 4}\left(R^{Hardw}_t+R^{Softw}_t+R^{Chips}_t+R^{Telcm}_t\right),
\]
where $R^{Hardw}_t$ is the daily return of the Fama-French Hardware industry, $R^{Softw}_t$ is Software, $R^{Chips}_t$ is Chips, and $R^{Telcm}_t$ is Telecom.

Let $P^{TMT}_t$ be the cumulative TMT wealth index. The pre-unwind peak is
\[
t_0=\arg\max_{t\leq 2000\hbox{-}03\hbox{-}31}P^{TMT}_t.
\]
In the uploaded daily data, $t_0=$ __PEAK_DATE__.

For each horizon $h$, define the set of trading days after the peak and before the margin deadline:
\[
D_h=\{t_0+1,t_0+2,\ldots,t_0+h\}.
\]
The drawdown anchor is the date at which TMT is lowest inside that margin horizon:
\[
\tau_h=\arg\min_{t\in D_h} P^{TMT}_t.
\]
This definition matters. If the purpose is margin risk, the relevant loss is the worst loss reached by the deadline, not only the end-of-window close.

The raw short-horizon TMT shock is
\[
S_E^h=\log\left({P^{TMT}_{\tau_h}\over P^{TMT}_{t_0}}\right),
\]
where $S_E^h$ means the total epicenter shock at horizon $h$. The broad-market shock is
\[
S_W^h=\log\left({P^{SPX}_{\tau_h}\over P^{SPX}_{t_0}}\right),
\]
where $P^{SPX}_t$ is the S\&P 500 close. The TMT-excess shock is the part of the TMT fall not explained by the broad market:
\[
S_X^h=S_E^h-S_W^h.
\]
Here $S_X^h$ is the direct short-horizon analogue of the terminal AI-excess shock in the original framework.

__ANCHOR_TABLE__

The endpoint-only calculation is shown below as an audit. It is not used as the main margin shock because it can miss an intra-horizon margin breach.

__ENDPOINT_TABLE__

\begin{figure}[h]
\centering
\includegraphics[width=0.94\textwidth]{figures/fig_01_dotcom_peak_anchored_path.png}
\caption{Daily TMT and S\&P 500 path around the dot-com TMT peak. The short-horizon calibration anchors to the worst TMT drawdown reached by each margin deadline.}
\end{figure}

\section*{3. Scenario ladder}

The v5 terminal framework has three scenarios. The same structure is preserved here. The base case uses the terminal valuation severity scalar
\[
\kappa_{base}=__KAPPA__,
\]
which means the base case applies __KAPPA_PCT__ of the full dot-com TMT-excess channel. The severe case keeps the full dot-com short-horizon TMT-excess analogue.

For each horizon $h$, the scenario shock components are:
\[
\begin{array}{lll}
\hbox{Mild:} & S_W^{mild,h}=0.5S_W^h, & S_X^{mild,h}=0.5\kappa_{base}S_X^h,\\
\hbox{Base:} & S_W^{base,h}=S_W^h, & S_X^{base,h}=\kappa_{base}S_X^h,\\
\hbox{Severe:} & S_W^{severe,h}=S_W^h, & S_X^{severe,h}=S_X^h.
\end{array}
\]
The implied AI/TMT epicenter shock is the sum of the market and excess log components:
\[
S_E^{s,h}=S_W^{s,h}+S_X^{s,h}.
\]

__SCENARIO_TABLE__

\begin{figure}[h]
\centering
\includegraphics[width=0.88\textwidth]{figures/fig_02_scenario_epicenter_ladder.png}
\caption{Implied AI/TMT epicenter stress by short-horizon scenario. The one-month stress is larger because the dot-com TMT basket reached a much deeper trough by the one-month margin deadline.}
\end{figure}

\begin{figure}[h]
\centering
\includegraphics[width=0.82\textwidth]{figures/fig_03_base_decomposition.png}
\caption{Base case decomposition. The broad market leg is not valuation-scaled. Only the TMT-excess leg is scaled by the base valuation severity scalar.}
\end{figure}

\section*{4. Applying the shock to the v5 exposure matrix}

For country-industry row $i$, the v5 model keeps two exposure variables. The first is $\beta_i^W$, the row's broad-market beta. In the CSV this is `beta\_world\_cell'. The second is $I_i^{AI}$, the row's final AI-excess intensity. In the CSV this is `final\_ai\_excess\_intensity'.

The short-horizon stress for scenario $s$ and horizon $h$ is
\[
\widehat R_i^{s,h}=\beta_i^W S_W^{s,h}+I_i^{AI}S_X^{s,h}.
\]
Here $\widehat R_i^{s,h}$ is a log-return stress. The reported simple-return stress is
\[
\widehat r_i^{s,h}=\exp\left(\widehat R_i^{s,h}\right)-1.
\]
This is exactly the same application layer as the terminal v5 model. The exposure matrix is not rebuilt. The only change is that $S_W$ and $S_X$ now come from the dot-com two-week and one-month drawdown anchors rather than the terminal peak-to-trough anchor.

For single-stock override row $q$, the equation is the same, with the stock-level beta $\beta_q^W$ replacing the country-industry beta:
\[
\widehat R_q^{s,h}=\beta_q^W S_W^{s,h}+I_q^{AI}S_X^{s,h}.
\]

\section*{5. Output distribution and representative results}

The table below summarizes the base-case country-industry distribution in the generated short-horizon vectors.

__SUMMARY_TABLE__

\begin{figure}[h]
\centering
\includegraphics[width=0.90\textwidth]{figures/fig_04_base_distribution.png}
\caption{Distribution of v5 country-industry base stress across the 1,917-row vector. The one-month distribution shifts left because the dot-com TMT peak-anchored one-month drawdown is materially larger than the two-week drawdown.}
\end{figure}

Representative rows are shown below. These are illustrative checks only; the delivered CSV files contain the full 1,917-row country-industry vector and the single-stock override vector.

__REP_TABLE__

\section*{6. Why this version is the correct short-horizon replication}

The earlier approach that scaled the terminal peak-to-trough shock into a shorter horizon was not the right replication for this use case. It assumed that the terminal stress arrived according to an estimated arrival fraction. That can make two-week and one-month shocks look artificially similar.

This version instead estimates the historical shock directly at the requested margin horizon. The historical sequence is:
\[
\hbox{dot-com TMT peak} \quad \rightarrow \quad \hbox{worst TMT loss by 10 trading days or 21 trading days}.
\]
Then it decomposes that loss into:
\[
\hbox{broad market shock} + \hbox{TMT-excess shock}.
\]
Finally it applies the same v5 exposure matrix:
\[
\widehat R_i^{s,h}=\beta_i^W S_W^{s,h}+I_i^{AI}S_X^{s,h}.
\]
This preserves the original framework while making the outputs usable for short-horizon margin management.

\section*{7. Data limitations and controls}

The key input needed for a rigorous short-horizon replication is now present: daily Fama-French industry returns and daily S\&P 500 data for the dot-com period. No blocking data gaps remain for the requested two-week and one-month research.

There are still methodological choices. The main output uses S\&P 500 as the broad-market leg because it is a transparent broad equity benchmark and was explicitly supplied. The Fama-French market factor and the all-49-industry average are retained as audit checks in the diagnostic CSV. The main TMT basket uses the four industries most directly aligned with the original TMT analogue: Hardware, Software, Chips, and Telecom.

The daily peak-to-trough diagnostic in the same data gives a TMT peak-to-trough move of __TERM_TMT__ and an S\&P 500 move of __TERM_SPX__ from __PEAK_DATE__ to __TROUGH_DATE__. This diagnostic is not used to overwrite the terminal v5 calibration. It is included only to confirm that the daily TMT series is identifying the same historical dot-com unwind episode.

\section*{8. Delivered files}

The generated deliverables are:

\begin{itemize}
\item `ai\_unwind\_v5\_2w\_peak\_anchored\_stress\_vector.csv' -- full country-industry vector for the two-week horizon.
\item `ai\_unwind\_v5\_1m\_peak\_anchored\_stress\_vector.csv' -- full country-industry vector for the one-month horizon.
\item `ai\_unwind\_v5\_2w\_peak\_anchored\_single\_stock\_override.csv' -- single-stock override vector for the two-week horizon.
\item `ai\_unwind\_v5\_1m\_peak\_anchored\_single\_stock\_override.csv' -- single-stock override vector for the one-month horizon.
\item `ai\_unwind\_v5\_peak\_anchored\_short\_horizon\_scenario\_parameters.csv' -- scenario shock parameters and calibration dates.
\end{itemize}

\end{document}
'''

repls = {
    '__PEAK_DATE__': peak_s,
    '__TROUGH_DATE__': trough_s,
    '__FF49_ROWS__': str(len(ff49)),
    '__FF49_RANGE__': f"{ff49.index.min().date()} to {ff49.index.max().date()}",
    '__FF_ROWS__': str(len(ff)),
    '__FF_RANGE__': f"{ff.index.min().date()} to {ff.index.max().date()}",
    '__SPX_ROWS__': str(len(spx)),
    '__SPX_RANGE__': f"{spx.index.min().date()} to {spx.index.max().date()}",
    '__CI_ROWS__': str(len(ci)),
    '__SS_ROWS__': str(len(ss)),
    '__KAPPA__': f'{base_kappa:.6f}',
    '__KAPPA_PCT__': f'{100*base_kappa:.1f} percent',
    '__ANCHOR_TABLE__': anchor_table,
    '__ENDPOINT_TABLE__': endpoint_table,
    '__SCENARIO_TABLE__': scenario_table,
    '__SUMMARY_TABLE__': summary_table,
    '__REP_TABLE__': rep_table,
    '__TERM_TMT__': terminal_tmt_pct,
    '__TERM_SPX__': terminal_spx_pct,
}
for k,v in repls.items():
    tex = tex.replace(k,v)
tex_path = OUT / 'ai_unwind_peak_anchored_short_horizon_v5_report.tex'
tex_path.write_text(tex)
shutil.copy(tex_path, ROOT / 'ai_unwind_peak_anchored_short_horizon_v5_report.tex')

# Copy code and build artifacts
shutil.copy(Path(__file__), CODE / Path(__file__).name)
# Compile LaTeX twice
cwd = os.getcwd()
os.chdir(OUT)
for i in range(2):
    subprocess.run(['pdflatex','-interaction=nonstopmode', tex_path.name], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
os.chdir(cwd)
pdf_path = OUT / 'ai_unwind_peak_anchored_short_horizon_v5_report.pdf'
if not pdf_path.exists():
    raise RuntimeError('PDF compilation failed')
shutil.copy(pdf_path, ROOT / 'ai_unwind_peak_anchored_short_horizon_v5_report.pdf')

# Run summary JSON
run_summary = {
    'generated_at': datetime.utcnow().isoformat() + 'Z',
    'peak_date': peak_s,
    'trough_date': trough_s,
    'base_kappa': base_kappa,
    'anchors': anchors,
    'outputs': {
        '2w_country_industry': '/mnt/data/ai_unwind_v5_2w_peak_anchored_stress_vector.csv',
        '1m_country_industry': '/mnt/data/ai_unwind_v5_1m_peak_anchored_stress_vector.csv',
        '2w_single_stock': '/mnt/data/ai_unwind_v5_2w_peak_anchored_single_stock_override.csv',
        '1m_single_stock': '/mnt/data/ai_unwind_v5_1m_peak_anchored_single_stock_override.csv',
        'scenario_parameters': '/mnt/data/ai_unwind_v5_peak_anchored_short_horizon_scenario_parameters.csv',
        'report_pdf': '/mnt/data/ai_unwind_peak_anchored_short_horizon_v5_report.pdf',
        'latex': '/mnt/data/ai_unwind_peak_anchored_short_horizon_v5_report.tex',
    }
}
(OUT/'run_summary.json').write_text(json.dumps(run_summary, indent=2))
shutil.copy(OUT/'run_summary.json', ROOT / 'ai_unwind_peak_anchored_short_horizon_v5_run_summary.json')

# Zip source bundle
bundle = ROOT / 'ai_unwind_peak_anchored_short_horizon_v5_source_bundle.zip'
if bundle.exists():
    bundle.unlink()
with zipfile.ZipFile(bundle, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for path in OUT.rglob('*'):
        if path.is_file():
            z.write(path, arcname=str(path.relative_to(OUT)))
    # include root csvs/latex/pdf names for convenience
    for p in [
        ROOT / 'ai_unwind_v5_2w_peak_anchored_stress_vector.csv',
        ROOT / 'ai_unwind_v5_1m_peak_anchored_stress_vector.csv',
        ROOT / 'ai_unwind_v5_2w_peak_anchored_single_stock_override.csv',
        ROOT / 'ai_unwind_v5_1m_peak_anchored_single_stock_override.csv',
        ROOT / 'ai_unwind_v5_peak_anchored_short_horizon_scenario_parameters.csv',
        ROOT / 'ai_unwind_peak_anchored_short_horizon_v5_report.tex',
        ROOT / 'ai_unwind_peak_anchored_short_horizon_v5_report.pdf',
    ]:
        if p.exists():
            z.write(p, arcname=p.name)

print(json.dumps(run_summary, indent=2))
print('PDF', pdf_path, pdf_path.stat().st_size)
print('Bundle', bundle, bundle.stat().st_size)
