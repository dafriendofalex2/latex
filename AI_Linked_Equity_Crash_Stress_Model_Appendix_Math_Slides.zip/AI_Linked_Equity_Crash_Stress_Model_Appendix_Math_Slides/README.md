Appendix mathematics slide deck for the AI-linked equity crash stress model.

Contents:
- Appendix_Math_Slides.pdf: compiled 20-slide appendix deck
- Appendix_Math_Slides.tex: LaTeX Beamer source

Scope:
- return construction and log-return arithmetic
- market beta estimation
- AI proxy orthogonalization and first-order condition
- raw AI slope theta_i^abs derivation
- beta-adjusted AI exposure score
- country-industry exposure surface
- dot-com shock decomposition
- valuation severity scalar
- scenario and horizon mechanics
- market-cap penalty
- ticker overrides and portfolio P&L
- conditional scenario-probability model
