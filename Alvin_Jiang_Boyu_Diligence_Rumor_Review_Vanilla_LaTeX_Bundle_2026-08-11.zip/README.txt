Alvin Jiang / Boyu Capital - Senior Person Diligence Note
Information cut-off: 11 August 2026

VANILLA LATEX BUILD
-------------------
No external packages are used.

Compile with:
  pdflatex main.tex
  pdflatex main.tex

No geometry, hyperref, xcolor, booktabs, bibtex/biber, latexmk, Perl or shell escape is required.
