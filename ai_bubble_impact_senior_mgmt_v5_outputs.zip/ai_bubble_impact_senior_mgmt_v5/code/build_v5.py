import os, re, math, zipfile, shutil, subprocess, textwrap
from pathlib import Path
from datetime import datetime
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

BASE = Path('/mnt/data')
OUT = BASE/'ai_bubble_impact_senior_mgmt_v5'
FIG = OUT/'figures'
DATA = OUT/'data'
CODE = OUT/'code'
for p in [OUT, FIG, DATA, CODE]:
    p.mkdir(parents=True, exist_ok=True)

# ------------------------------
# Helpers
# ------------------------------
def month_end_from_yyyymm(x):
    x = str(int(x)).strip()
    y, m = int(x[:4]), int(x[4:6])
    return pd.Period(f'{y}-{m:02d}', freq='M').to_timestamp('M')

def parse_ff_csv(path, section='monthly'):
    # Reads French files whose first data rows are YYYYMM, then annual YYYY rows later.
    lines = Path(path).read_text(errors='ignore').splitlines()
    header_idx = None
    for i, line in enumerate(lines):
        if line.startswith(',') and ('Mkt-RF' in line or 'Agric' in line):
            header_idx = i
            break
    if header_idx is None:
        raise ValueError('header not found')
    header = [h.strip() for h in lines[header_idx].split(',')]
    rows = []
    for line in lines[header_idx+1:]:
        if not line.strip():
            if rows:
                break
            continue
        first = line.split(',')[0].strip()
        if not re.match(r'^\d{6}$', first):
            if rows:
                break
            continue
        parts = [p.strip() for p in line.split(',')]
        if len(parts) < len(header):
            continue
        rows.append(parts[:len(header)])
    df = pd.DataFrame(rows, columns=['date']+header[1:])
    df['date'] = df['date'].astype(int).apply(month_end_from_yyyymm)
    for c in df.columns[1:]:
        df[c] = pd.to_numeric(df[c], errors='coerce')/100.0
    df = df.set_index('date').sort_index()
    df = df.replace([-0.9999, -9.99, -99.99, -999.0], np.nan)
    return df

def parse_ff_factors(zip_path):
    with zipfile.ZipFile(zip_path) as z:
        name = z.namelist()[0]
        text = z.read(name).decode('latin1')
    tmp = OUT/'ff_factors_raw.csv'
    tmp.write_text(text)
    return parse_ff_csv(tmp)

def read_stooq(ticker):
    for suffix in ['.us.txt', '.us(1).txt']:
        path = BASE/f'{ticker.lower()}{suffix}'
        if path.exists():
            df = pd.read_csv(path)
            df['date'] = pd.to_datetime(df['<DATE>'].astype(str), format='%Y%m%d')
            df = df.rename(columns={'<CLOSE>':'close','<VOL>':'volume','<OPEN>':'open','<HIGH>':'high','<LOW>':'low'})
            return df[['date','open','high','low','close','volume']].sort_values('date').set_index('date')
    raise FileNotFoundError(ticker)

def monthly_returns_from_daily(df):
    m = df['close'].resample('M').last().dropna()
    return m.pct_change().dropna(), m

def norm_series(s, base_date=None, value=100.0):
    s = s.dropna().copy()
    if base_date is not None:
        s = s[s.index >= pd.Timestamp(base_date)]
    if len(s)==0:
        return s
    return s / s.iloc[0] * value

def weighted_signal(returns, theta=0.85, K=12):
    vals = []
    idx = []
    r = returns.dropna()
    for i in range(K, len(r)+1):
        window = r.iloc[i-K:i].values[::-1]  # latest first
        weights = np.array([(1-theta)*(theta**k) for k in range(K)])
        weights = weights/weights.sum()
        vals.append(float(np.dot(weights, window)))
        idx.append(r.index[i-1])
    return pd.Series(vals, index=idx)

def cumulative_return(returns):
    return (1+returns).cumprod()

def max_drawdown_future(rel_returns, H=24):
    # future relative drawdown over next H months from each t, cumulative simple returns.
    r = rel_returns.dropna()
    out = pd.Series(index=r.index, dtype=float)
    for i in range(len(r)-H):
        fwd = r.iloc[i+1:i+H+1]
        cr = (1+fwd).cumprod()-1
        out.iloc[i] = cr.min()
    return out

def ols_beta(y, X):
    df = pd.concat([y, X], axis=1).dropna()
    if len(df) < 12:
        return np.nan, np.nan, len(df)
    yy = df.iloc[:,0].values
    XX = df.iloc[:,1:].values
    XX = np.column_stack([np.ones(len(XX)), XX])
    try:
        coef = np.linalg.lstsq(XX, yy, rcond=None)[0]
        yhat = XX@coef
        ssr = ((yy-yhat)**2).sum()
        sst = ((yy-yy.mean())**2).sum()
        r2 = 1-ssr/sst if sst>0 else np.nan
        return coef, r2, len(df)
    except Exception:
        return np.nan, np.nan, len(df)

def date_add_months(ts, n):
    return (pd.Timestamp(ts) + pd.DateOffset(months=n)).to_pydatetime()

# ------------------------------
# Load data
# ------------------------------
ff49 = parse_ff_csv(BASE/'49_Industry_Portfolios.csv')
ff3 = parse_ff_factors(BASE/'F-F_Research_Data_Factors_CSV (1).zip')
ff3['MKT'] = ff3['Mkt-RF'] + ff3['RF']

# Shiller S&P monthly price (broad S&P-like actual path)
shiller_xlsx = BASE/'tmp_convert'/'ie_data.xlsx'
if not shiller_xlsx.exists():
    (BASE/'tmp_convert').mkdir(exist_ok=True)
    subprocess.run(['libreoffice','--headless','--convert-to','xlsx','--outdir',str(BASE/'tmp_convert'),str(BASE/'ie_data.xls')], check=False)
sh = pd.read_excel(shiller_xlsx, sheet_name='Data', header=None)
sh = sh.iloc[8:, [0,1]].copy()
sh.columns=['date_code','sp_price']
sh['date_code'] = pd.to_numeric(sh['date_code'], errors='coerce')
sh['sp_price'] = pd.to_numeric(sh['sp_price'], errors='coerce')
sh = sh.dropna()
def shiller_date(x):
    y = int(math.floor(x))
    m = int(round((x-y)*100))
    if m<1 or m>12:
        m=1
    return pd.Period(f'{y}-{m:02d}', freq='M').to_timestamp('M')
sh['date'] = sh['date_code'].apply(shiller_date)
sh = sh.set_index('date').sort_index()
sp_monthly_price = sh['sp_price']
sp_monthly_returns = sp_monthly_price.pct_change().dropna()

# NASDAQ daily and monthly
nas = pd.read_excel(BASE/'NASDAQCOM.xlsx', sheet_name='Daily, Close')
nas.columns = ['date','nasdaq']
nas['date'] = pd.to_datetime(nas['date'])
nas['nasdaq'] = pd.to_numeric(nas['nasdaq'], errors='coerce')
nas = nas.dropna().set_index('date').sort_index()
nas_m_px = nas['nasdaq'].resample('M').last().dropna()
nas_m_ret = nas_m_px.pct_change().dropna()

# AI stock data
ai_tickers = ['NVDA','AMD','AVGO','MSFT','GOOGL','AMZN','META','SMCI','PLTR']
stock_daily = {t: read_stooq(t) for t in ai_tickers}
stock_monthly_returns = {}
stock_monthly_prices = {}
for t, df in stock_daily.items():
    r, p = monthly_returns_from_daily(df)
    stock_monthly_returns[t] = r
    stock_monthly_prices[t] = p
stock_mret = pd.DataFrame(stock_monthly_returns)
stock_mpx = pd.DataFrame(stock_monthly_prices)

# Current period data. Use ChatGPT launch / AI era.
ai_start = pd.Timestamp('2022-11-30')
current_start = pd.Timestamp('2023-01-31')
latest_daily = min([df.index.max() for df in stock_daily.values()])
latest_month = stock_mpx.dropna(how='all').index.max()

# Daily AI basket equal-weight path
all_closes = pd.concat({t: df['close'] for t,df in stock_daily.items()}, axis=1).dropna(how='all')
# Use available securities each day, equal-weight over available values normalized from AI start.
daily_norms = []
for t in ai_tickers:
    s = stock_daily[t]['close'].copy()
    s = s[s.index >= ai_start]
    if len(s)>0:
        daily_norms.append((s/s.iloc[0]).rename(t))
daily_norm_df = pd.concat(daily_norms, axis=1)
ai_daily_index = daily_norm_df.mean(axis=1).dropna()*100

# Monthly AI returns equal-weight over available names.
ai_mret_raw = stock_mret[stock_mret.index >= current_start][ai_tickers].mean(axis=1).dropna()
# Market factor monthly for regression overlap.
mkt_mret = ff3['MKT']
common = ai_mret_raw.index.intersection(mkt_mret.index)
ai_mret_common = ai_mret_raw.loc[common]
mkt_common = mkt_mret.loc[common]
# AI relative factor for current calculation.
ai_rel = (ai_mret_common - mkt_common).dropna()

# Dot-com TMT factor
core_tmt = ['Softw','Hardw','Chips','Telcm']
ext_tmt = ['Softw','Hardw','Chips','Telcm','LabEq','BusSv','ElcEq']
tmt_cols = [c for c in core_tmt if c in ff49.columns]
ret_tmt = ff49[tmt_cols].mean(axis=1).dropna()
ret_mkt = ff3['MKT'].reindex(ret_tmt.index).dropna()
ret_tmt = ret_tmt.reindex(ret_mkt.index).dropna()
rel_tmt = (ret_tmt - ret_mkt).dropna()
# dot-com window
dot_window = rel_tmt.loc['1995-01-31':'2003-12-31']
dot_cum = (1+dot_window).cumprod()
dot_peak = dot_cum.loc[:'2001-06-30'].idxmax()
H=24
post_dates = pd.date_range(dot_peak + pd.offsets.MonthEnd(1), periods=H, freq='M')
# actual dates from rel_tmt after peak
post_rel = rel_tmt.loc[rel_tmt.index > dot_peak].iloc[:H]
post_mkt = ff3['MKT'].reindex(post_rel.index).dropna().iloc[:H]
# align same length
nH = min(H, len(post_rel), len(post_mkt))
post_rel = post_rel.iloc[:nH]
post_mkt = post_mkt.iloc[:nH]
H = nH
base_ai_rel_total = (1+post_rel).prod()-1
base_mkt_total = (1+post_mkt).prod()-1
# dot-com path normalized at peak
prepost_rel = rel_tmt.loc[dot_peak - pd.DateOffset(months=36): dot_peak + pd.DateOffset(months=36)]
# construct wealth with peak = 100: cum from start then rescale peak to 100
prepost_cum = (1+prepost_rel).cumprod()
prepost_cum = prepost_cum/prepost_cum.loc[dot_peak]*100
prepost_event_months = prepost_cum.index.to_period('M').asi8 - dot_peak.to_period('M').ordinal

# Current AI relative event overlay
current_rel = (ai_mret_raw.reindex(mkt_mret.index).dropna() - mkt_mret.reindex(ai_mret_raw.index).dropna()).dropna()
cur_cum = (1+current_rel).cumprod()*100
if len(cur_cum)>0:
    cur_peak = cur_cum.idxmax()
    cur_event = cur_cum.loc[cur_peak - pd.DateOffset(months=36): cur_peak + pd.DateOffset(months=36)]
    cur_event = cur_event/cur_event.loc[cur_peak]*100
    cur_event_months = cur_event.index.to_period('M').asi8 - cur_peak.to_period('M').ordinal
else:
    cur_peak = None

# Extrapolation and stretch signals for current AI and history.
X_ai = weighted_signal(current_rel, theta=0.85, K=12)
Z_ai = current_rel.cumsum()
V_ai = Z_ai - Z_ai.rolling(24, min_periods=12).mean()
ai_signal_raw = (X_ai.reindex(V_ai.index) + V_ai.reindex(X_ai.index)).dropna()

# Historical signals on FF49 industries
hist_rows = []
for col in ff49.columns:
    r = ff49[col].reindex(mkt_mret.index).dropna()
    if len(r) < 80 or col=='Other':
        continue
    rel = (r - mkt_mret.reindex(r.index)).dropna()
    X = weighted_signal(rel, 0.85, 12)
    Z = rel.cumsum()
    V = Z - Z.rolling(24, min_periods=12).mean()
    sig = (X.reindex(V.index) + V.reindex(X.index)).dropna()
    fut = max_drawdown_future(rel, H=24)
    df = pd.concat([sig.rename('signal'), fut.rename('future_dd')], axis=1).dropna()
    df['industry'] = col
    hist_rows.append(df)
hist_signal = pd.concat(hist_rows).dropna()
hist_signal = hist_signal.replace([np.inf,-np.inf], np.nan).dropna()
# standardize signal for presentation
sig_mean, sig_std = hist_signal['signal'].mean(), hist_signal['signal'].std()
hist_signal['signal_z'] = (hist_signal['signal']-sig_mean)/sig_std
if len(ai_signal_raw)>0:
    ai_signal_z = (ai_signal_raw - sig_mean)/sig_std
    current_ai_signal_z = ai_signal_z.iloc[-1]
    peak_ai_signal_z = ai_signal_z.max()
    peak_ai_signal_date = ai_signal_z.idxmax()
    current_ai_signal_percentile = (hist_signal['signal_z'] <= current_ai_signal_z).mean()
    peak_ai_signal_percentile = (hist_signal['signal_z'] <= peak_ai_signal_z).mean()
else:
    current_ai_signal_z = peak_ai_signal_z = current_ai_signal_percentile = peak_ai_signal_percentile = np.nan
    peak_ai_signal_date = pd.NaT

# Regress future drawdown on signal, diagnostic only.
coefs, r2_hist, n_hist = ols_beta(hist_signal['future_dd'], hist_signal[['signal_z']])
if not isinstance(coefs, float):
    hist_intercept, hist_slope = coefs[0], coefs[1]
else:
    hist_intercept = hist_slope = np.nan

# Estimate betas and final hybrid exposure multipliers
# Monthly returns aligned to current era and FF market.
beta_rows=[]
# AI factor excluding own name. Use current_start onward, monthly.
for t in ai_tickers:
    y = stock_mret[t].loc[current_start:].dropna()
    # excluding t basket
    excl = [x for x in ai_tickers if x!=t]
    ai_excl = stock_mret[excl].loc[current_start:].mean(axis=1).dropna()
    common_idx = y.index.intersection(ai_excl.index).intersection(mkt_mret.index)
    y2 = y.reindex(common_idx)
    m2 = mkt_mret.reindex(common_idx)
    ai_rel_excl = (ai_excl.reindex(common_idx) - m2)
    coef, r2, n = ols_beta(y2, pd.DataFrame({'mkt':m2, 'ai_rel_excl':ai_rel_excl}))
    if isinstance(coef, np.ndarray):
        b_mkt, b_ai = coef[1], coef[2]
    else:
        b_mkt, b_ai = np.nan, np.nan
    # market beta over longer 2020+ when possible
    common2 = stock_mret[t].dropna().index.intersection(mkt_mret.index)
    common2 = common2[common2 >= pd.Timestamp('2020-01-31')]
    coef2, r22, n2 = ols_beta(stock_mret[t].reindex(common2), pd.DataFrame({'mkt':mkt_mret.reindex(common2)}))
    b_mkt_long = coef2[1] if isinstance(coef2, np.ndarray) else np.nan
    beta_rows.append({'ticker':t,'beta_mkt_reg':b_mkt,'beta_ai_reg':b_ai,'r2_ai_reg':r2,'n_ai_reg':n,'beta_mkt_long':b_mkt_long,'r2_mkt_long':r22,'n_mkt_long':n2})
betas = pd.DataFrame(beta_rows).set_index('ticker')
# overlays based on economic AI exposure. No zeros for platform names.
overlay = pd.Series({
    'NVDA':1.45, 'SMCI':1.35, 'AMD':1.15, 'AVGO':1.05, 'PLTR':1.00,
    'MSFT':0.75, 'GOOGL':0.75, 'AMZN':0.60, 'META':0.60
})
# clipped statistical beta contribution
stat = betas['beta_ai_reg'].replace([np.inf,-np.inf],np.nan).fillna(0.0)
stat_clipped = stat.clip(lower=0.15, upper=2.25)
# if regression really too noisy, overlay dominates. final lambda combines both.
lambda_final = (0.70*overlay + 0.30*stat_clipped).reindex(ai_tickers)
# reasonable caps
lambda_final = lambda_final.clip(lower=0.40, upper=1.60)
# market beta use long, clipped reasonable.
beta_mkt = betas['beta_mkt_long'].fillna(betas['beta_mkt_reg']).fillna(1.0).clip(lower=0.5, upper=2.4)
exposure_table = betas.copy()
exposure_table['economic_overlay'] = overlay
exposure_table['lambda_final'] = lambda_final
exposure_table['beta_mkt_final'] = beta_mkt

# SPY holdings
hold = pd.read_excel(BASE/'holdings-daily-us-en-spy.xlsx', sheet_name='holdings', header=4)
hold = hold.rename(columns=lambda x: str(x).strip())
hold['Ticker'] = hold['Ticker'].astype(str).str.strip()
hold['Weight'] = pd.to_numeric(hold['Weight'], errors='coerce')/100.0
hold = hold.dropna(subset=['Ticker','Weight'])
# Covered AI mapping; use GOOGL proxy for GOOG as economic same Alphabet exposure.
proxy_map = {'GOOG':'GOOGL'}
hold['proxy'] = hold['Ticker'].replace(proxy_map)
hold_ai = hold[hold['proxy'].isin(ai_tickers)].copy()
weight_by_proxy = hold_ai.groupby('proxy')['Weight'].sum().reindex(ai_tickers).fillna(0.0)
covered_ai_weight = float(weight_by_proxy.sum())
# weights of likely omitted AI candidates visible in holdings but no price data
candidate_omitted = ['AAPL','ORCL','CRM','NOW','ADBE','TSM','ASML','MU','ANET','DELL','VRT']
omitted = hold[hold['Ticker'].isin(candidate_omitted)][['Ticker','Weight']].copy().sort_values('Weight',ascending=False)
omitted_weight = float(omitted['Weight'].sum())

# Projection returns by scenario.
scales = {'mild':0.50,'base':1.00,'severe':1.25}
scenario_stock_returns = {}
scenario_stock_paths = {}
scenario_ai_path = {}
scenario_spy_path = {}
scenario_nasdaq_path = {}
# Estimate Nasdaq projection betas: monthly Nasdaq returns on mkt and current AI relative.
common_n = nas_m_ret.index.intersection(mkt_mret.index).intersection(current_rel.index)
common_n = common_n[common_n >= current_start]
coef_n, r2_n, n_n = ols_beta(nas_m_ret.reindex(common_n), pd.DataFrame({'mkt':mkt_mret.reindex(common_n), 'ai_rel':current_rel.reindex(common_n)}))
if isinstance(coef_n, np.ndarray):
    beta_n_mkt, beta_n_ai = coef_n[1], coef_n[2]
else:
    beta_n_mkt, beta_n_ai = 1.2, 0.8
beta_n_mkt = float(np.clip(beta_n_mkt,0.5,2.5))
beta_n_ai = float(np.clip(beta_n_ai,0.0,3.0))

# monthly projection dates from last actual daily date
proj_dates = [pd.Timestamp(latest_daily)] + [pd.Timestamp(latest_daily) + pd.DateOffset(months=i) for i in range(1,H+1)]
for scen, scale in scales.items():
    r_m = (post_mkt * scale).values
    r_rel = (post_rel * scale).values
    stock_rets = {}
    stock_path = {}
    for t in ai_tickers:
        monthly = beta_mkt[t]*r_m + lambda_final[t]*r_rel
        monthly = np.clip(monthly, -0.85, 0.85)
        total = np.prod(1+monthly)-1
        stock_rets[t]=total
        stock_path[t] = np.concatenate([[1.0], np.cumprod(1+monthly)])
    scenario_stock_returns[scen] = pd.Series(stock_rets)
    scenario_stock_paths[scen] = pd.DataFrame(stock_path, index=proj_dates)
    # AI basket equal-weight projected path
    scenario_ai_path[scen] = scenario_stock_paths[scen][ai_tickers].mean(axis=1)
    # SPY path by weights: non-covered gets broad mkt; covered gets stock projected returns.
    spy_monthly = (1-covered_ai_weight)*r_m.copy()
    for t in ai_tickers:
        monthly = beta_mkt[t]*r_m + lambda_final[t]*r_rel
        monthly = np.clip(monthly, -0.85, 0.85)
        spy_monthly += weight_by_proxy[t]*monthly
    scenario_spy_path[scen] = pd.Series(np.concatenate([[1.0], np.cumprod(1+spy_monthly)]), index=proj_dates)
    # Nasdaq proxy path
    nas_monthly = beta_n_mkt*r_m + beta_n_ai*r_rel
    nas_monthly = np.clip(nas_monthly, -0.85, 0.85)
    scenario_nasdaq_path[scen] = pd.Series(np.concatenate([[1.0], np.cumprod(1+nas_monthly)]), index=proj_dates)

# Base contributions for SPY
base_stock_total = scenario_stock_returns['base']
contrib = (weight_by_proxy * base_stock_total).sort_values()
noncovered_return = (scenario_spy_path['base'].iloc[-1]-1 - contrib.sum())/(1-covered_ai_weight) if covered_ai_weight < 1 else np.nan
spy_total = scenario_spy_path['base'].iloc[-1]-1
nas_total = scenario_nasdaq_path['base'].iloc[-1]-1
ai_basket_total = scenario_ai_path['base'].iloc[-1]-1

# CSV outputs
exposure_table.to_csv(DATA/'exposure_multipliers.csv')
pd.DataFrame(scenario_stock_returns).to_csv(DATA/'stress_vector_ai_stocks_total_return.csv')
weight_by_proxy.rename('spy_weight').to_csv(DATA/'spy_ai_weights.csv')
contrib.rename('base_spy_contribution').to_csv(DATA/'base_spy_contributions.csv')
pd.DataFrame({s:scenario_spy_path[s] for s in scenarios if False}).to_csv(DATA/'empty.csv') if False else None
pd.DataFrame({s:scenario_ai_path[s] for s in scales}).to_csv(DATA/'projected_ai_basket_paths.csv')
pd.DataFrame({s:scenario_spy_path[s] for s in scales}).to_csv(DATA/'projected_spy_paths.csv')
pd.DataFrame({s:scenario_nasdaq_path[s] for s in scales}).to_csv(DATA/'projected_nasdaq_paths.csv')
hist_signal.sample(min(5000,len(hist_signal)), random_state=1).to_csv(DATA/'historical_signal_future_drawdown_sample.csv')
omitted.to_csv(DATA/'omitted_candidate_ai_weights.csv', index=False)

# ------------------------------
# Figures
# ------------------------------
plt.rcParams.update({'figure.dpi': 160, 'savefig.dpi': 200, 'font.size': 9})

def savefig(name):
    plt.tight_layout()
    path = FIG/name
    plt.savefig(path, bbox_inches='tight')
    plt.close()
    return path

# Fig 1 event time overlay current AI vs dotcom TMT
plt.figure(figsize=(8.5,4.8))
plt.plot(prepost_event_months, prepost_cum.values, label='Dot-com TMT relative wealth')
if cur_peak is not None:
    plt.plot(cur_event_months, cur_event.values, label='Current AI relative wealth')
plt.axvline(0, linestyle='--', linewidth=1)
plt.axhline(100, linestyle=':', linewidth=1)
plt.title('Peak-normalized event-time overlay: current AI vs dot-com TMT')
plt.xlabel('Months from relative peak')
plt.ylabel('Relative wealth, peak = 100')
plt.legend()
plt.grid(True, alpha=0.3)
savefig('fig01_event_overlay.png')

# Fig 2 dotcom replay from current date: projected AI vs historical TMT post-peak normalized
plt.figure(figsize=(8.5,4.8))
# dotcom post peak normalized path to 100 at peak; include t=0
post_tmt_path = pd.Series(np.concatenate([[1.0], np.cumprod(1+post_rel.values)]), index=range(0,H+1))*100
plt.plot(post_tmt_path.index, post_tmt_path.values, label='Dot-com TMT post-peak relative path')
plt.plot(range(0,H+1), scenario_ai_path['base'].values*100, label='Current AI projected replay (base)')
plt.plot(range(0,H+1), scenario_ai_path['mild'].values*100, label='Current AI projected replay (mild)')
plt.plot(range(0,H+1), scenario_ai_path['severe'].values*100, label='Current AI projected replay (severe)')
plt.axhline(100, linestyle=':', linewidth=1)
plt.title('Normalized projected AI replay versus dot-com post-peak path')
plt.xlabel('Projection month')
plt.ylabel('Index, projection start / dot-com peak = 100')
plt.legend()
plt.grid(True, alpha=0.3)
savefig('fig02_projection_vs_dotcom.png')

# Fig 3 actual and projected aggregate paths connected
plt.figure(figsize=(9,5))
# AI actual daily normalized at AI start; projection starts at latest with last actual value
ai_actual = ai_daily_index[ai_daily_index.index >= ai_start]
plt.plot(ai_actual.index, ai_actual.values, label='AI basket actual')
last_ai = ai_actual.iloc[-1]
for scen in ['mild','base','severe']:
    proj = scenario_ai_path[scen]*last_ai
    plt.plot(proj.index, proj.values, linestyle='--', label=f'AI basket projected {scen}')
# S&P actual monthly normalized at 100 on AI start
sp_act = sp_monthly_price[sp_monthly_price.index >= ai_start]
sp_norm = sp_act/sp_act.iloc[0]*100
plt.plot(sp_norm.index, sp_norm.values, label='S&P price index actual')
sp_last = sp_norm.iloc[-1]
for scen in ['base']:
    proj = scenario_spy_path[scen]*sp_last
    plt.plot(proj.index, proj.values, linestyle='--', label=f'S&P/SPY weighted projected {scen}')
plt.axvline(pd.Timestamp(latest_daily), linestyle=':', linewidth=1)
plt.title('Actual paths and connected projected unwind paths')
plt.xlabel('Date')
plt.ylabel('Index level, normalized to 100 at AI start')
plt.legend(ncol=2)
plt.grid(True, alpha=0.3)
savefig('fig03_actual_projection_aggregate.png')

# Fig 4 Nasdaq actual and projected connected, plus dotcom NASDAQ history normalized
plt.figure(figsize=(9,5))
nas_actual = nas['nasdaq'][nas.index >= ai_start]
nas_norm = nas_actual/nas_actual.iloc[0]*100
plt.plot(nas_norm.index, nas_norm.values, label='NASDAQ Composite actual')
nas_last = nas_norm.iloc[-1]
for scen in ['mild','base','severe']:
    plt.plot(scenario_nasdaq_path[scen].index, scenario_nasdaq_path[scen].values*nas_last, linestyle='--', label=f'NASDAQ projected {scen}')
plt.axvline(pd.Timestamp(latest_daily), linestyle=':', linewidth=1)
plt.title('NASDAQ actual path with connected AI-unwind projection')
plt.xlabel('Date')
plt.ylabel('Index level, normalized to 100 at AI start')
plt.legend(ncol=2)
plt.grid(True, alpha=0.3)
savefig('fig04_nasdaq_projection.png')

# Fig 5 platform stocks actual + projected
platform = ['MSFT','GOOGL','AMZN','META']
plt.figure(figsize=(9,5))
for t in platform:
    s = stock_daily[t]['close']; s = s[s.index>=ai_start]
    if len(s)==0: continue
    actual = s/s.iloc[0]*100
    plt.plot(actual.index, actual.values, label=f'{t} actual')
    last = actual.iloc[-1]
    proj = scenario_stock_paths['base'][t]*last
    plt.plot(proj.index, proj.values, linestyle='--', label=f'{t} projected')
plt.axvline(pd.Timestamp(latest_daily), linestyle=':', linewidth=1)
plt.title('Platform megacaps: actual paths connected to base projected unwind')
plt.xlabel('Date')
plt.ylabel('Index level, normalized to 100 at AI start')
plt.legend(ncol=2)
plt.grid(True, alpha=0.3)
savefig('fig05_platform_projection.png')

# Fig 6 infra/high beta stocks actual + projected
infra = ['NVDA','AMD','AVGO','SMCI','PLTR']
plt.figure(figsize=(9,5))
for t in infra:
    s = stock_daily[t]['close']; s = s[s.index>=ai_start]
    if len(s)==0: continue
    actual = s/s.iloc[0]*100
    plt.plot(actual.index, actual.values, label=f'{t} actual')
    last = actual.iloc[-1]
    proj = scenario_stock_paths['base'][t]*last
    plt.plot(proj.index, proj.values, linestyle='--', label=f'{t} projected')
plt.axvline(pd.Timestamp(latest_daily), linestyle=':', linewidth=1)
plt.title('AI infrastructure and high-beta names: actual paths connected to base projection')
plt.xlabel('Date')
plt.ylabel('Index level, normalized to 100 at AI start')
plt.legend(ncol=2)
plt.grid(True, alpha=0.3)
savefig('fig06_infra_projection.png')

# Fig 7 SPY contribution bars
plt.figure(figsize=(8,5))
c = contrib.sort_values()
plt.barh(c.index, c.values*100)
plt.axvline(0, linewidth=1)
plt.title('Base SPY contribution from covered AI names')
plt.xlabel('Contribution to SPY return, percentage points')
plt.ylabel('Stock proxy')
plt.grid(True, axis='x', alpha=0.3)
savefig('fig07_spy_contributions.png')

# Fig 8 exposure multiplier compare
plt.figure(figsize=(8,5))
order = lambda_final.sort_values(ascending=True).index
x = np.arange(len(order))
plt.barh(order, exposure_table.loc[order,'economic_overlay'], label='Economic overlay')
plt.scatter(exposure_table.loc[order,'beta_ai_reg'].clip(-1,3), order, marker='o', label='Regression AI beta')
plt.scatter(exposure_table.loc[order,'lambda_final'], order, marker='x', label='Final stress multiplier')
plt.axvline(0, linewidth=1)
plt.title('AI exposure construction: regression evidence plus economic overlay')
plt.xlabel('Multiplier / beta')
plt.legend()
plt.grid(True, axis='x', alpha=0.3)
savefig('fig08_exposure_multipliers.png')

# Fig 9 Scenario paths SPY
plt.figure(figsize=(8.5,4.8))
for scen in ['mild','base','severe']:
    plt.plot(range(0,H+1), scenario_spy_path[scen].values*100, label=scen)
plt.axhline(100, linestyle=':', linewidth=1)
plt.title('SPY weighted index-impact scenario paths')
plt.xlabel('Projection month')
plt.ylabel('Index, projection start = 100')
plt.legend()
plt.grid(True, alpha=0.3)
savefig('fig09_spy_scenarios.png')

# Fig 10 Heatmap sensitivity final SPY return to market scale and AI scale.
market_scales = np.linspace(0.5,1.5,9)
ai_scales = np.linspace(0.5,1.5,9)
Z = np.zeros((len(ai_scales), len(market_scales)))
for ia, ascale in enumerate(ai_scales):
    for im, mscale in enumerate(market_scales):
        r_m = post_mkt.values * mscale
        r_rel = post_rel.values * ascale
        spy_monthly = (1-covered_ai_weight)*r_m.copy()
        for t in ai_tickers:
            monthly = beta_mkt[t]*r_m + lambda_final[t]*r_rel
            monthly = np.clip(monthly,-0.85,0.85)
            spy_monthly += weight_by_proxy[t]*monthly
        Z[ia,im] = (np.prod(1+spy_monthly)-1)*100
plt.figure(figsize=(7.5,5.8))
im=plt.imshow(Z, origin='lower', aspect='auto', extent=[market_scales[0],market_scales[-1],ai_scales[0],ai_scales[-1]])
plt.colorbar(im, label='Projected SPY return (%)')
plt.title('Sensitivity of SPY impact to market and AI shock scaling')
plt.xlabel('Market shock scale')
plt.ylabel('AI relative shock scale')
savefig('fig10_sensitivity_heatmap.png')

# Fig 11 historical signal vs future drawdown scatter
sample = hist_signal.sample(min(4000,len(hist_signal)), random_state=2)
plt.figure(figsize=(8,5))
plt.scatter(sample['signal_z'], sample['future_dd']*100, s=8, alpha=0.35)
xs = np.linspace(sample['signal_z'].min(), sample['signal_z'].max(), 100)
plt.plot(xs, (hist_intercept + hist_slope*xs)*100, label='Historical linear fit')
if not np.isnan(current_ai_signal_z):
    plt.axvline(current_ai_signal_z, linestyle='--', linewidth=1, label='Latest current AI signal')
    plt.axvline(peak_ai_signal_z, linestyle=':', linewidth=1, label='Peak current AI signal')
plt.title('Historical FF49 signal versus subsequent 24-month drawdown')
plt.xlabel('Extrapolation/stretch signal, z-score')
plt.ylabel('Future 24-month worst relative drawdown (%)')
plt.legend()
plt.grid(True, alpha=0.3)
savefig('fig11_signal_drawdown.png')

# Fig 12 historical distribution of future drawdowns at high signal states
hi = hist_signal[hist_signal['signal_z'] >= hist_signal['signal_z'].quantile(0.90)]['future_dd']*100
all_dd = hist_signal['future_dd']*100
plt.figure(figsize=(8,5))
plt.hist(all_dd, bins=60, alpha=0.45, label='All industry-months')
plt.hist(hi, bins=40, alpha=0.65, label='Top decile signal')
plt.axvline(base_ai_rel_total*100, linestyle='--', linewidth=1, label='Dot-com TMT relative shock')
plt.title('Historical drawdown distribution and dot-com calibration')
plt.xlabel('Future 24-month worst relative drawdown (%)')
plt.ylabel('Count')
plt.legend()
plt.grid(True, alpha=0.3)
savefig('fig12_drawdown_distribution.png')

# Fig 13 Correlation matrix current AI stocks monthly returns
corr = stock_mret[ai_tickers].loc[current_start:].corr()
plt.figure(figsize=(6.8,5.8))
im=plt.imshow(corr.values, vmin=-1, vmax=1)
plt.xticks(range(len(ai_tickers)), ai_tickers, rotation=45, ha='right')
plt.yticks(range(len(ai_tickers)), ai_tickers)
plt.colorbar(im, label='Correlation')
plt.title('Current AI basket monthly return correlation')
for i in range(len(ai_tickers)):
    for j in range(len(ai_tickers)):
        plt.text(j,i,f'{corr.values[i,j]:.1f}',ha='center',va='center',fontsize=6)
savefig('fig13_correlation_matrix.png')

# Fig 14 Final stock stress vector bar
plt.figure(figsize=(8,5))
vec = scenario_stock_returns['base'].sort_values()
plt.barh(vec.index, vec.values*100)
plt.axvline(0, linewidth=1)
plt.title('Base stock-level stress vector')
plt.xlabel('Total projected return over 24 months (%)')
plt.ylabel('Stock')
plt.grid(True, axis='x', alpha=0.3)
savefig('fig14_stock_vector.png')

# ------------------------------
# Text report with vanilla-ish LaTeX
# ------------------------------
# Small table strings
summary_rows = [
    ('Dot-com peak used', dot_peak.strftime('%Y-%m')),
    ('Dot-com TMT 24m relative shock', f'{base_ai_rel_total*100:.1f}\%'),
    ('Dot-com market 24m shock', f'{base_mkt_total*100:.1f}\%'),
    ('Covered AI weight in SPY', f'{covered_ai_weight*100:.1f}\%'),
    ('Omitted candidate AI weight in SPY', f'{omitted_weight*100:.1f}\%'),
    ('Base AI basket projected return', f'{ai_basket_total*100:.1f}\%'),
    ('Base SPY weighted impact', f'{spy_total*100:.1f}\%'),
    ('Base NASDAQ proxy impact', f'{nas_total*100:.1f}\%'),
    ('Historical signal regression R-squared', f'{r2_hist:.3f}'),
]
stock_rows = []
for t in scenario_stock_returns['base'].sort_values().index:
    stock_rows.append((t, f'{beta_mkt[t]:.2f}', f'{exposure_table.loc[t,"beta_ai_reg"]:.2f}', f'{overlay[t]:.2f}', f'{lambda_final[t]:.2f}', f'{scenario_stock_returns["base"][t]*100:.1f}\%'))
contrib_rows = []
for t, v in contrib.sort_values().items():
    contrib_rows.append((t, f'{weight_by_proxy[t]*100:.2f}\%', f'{scenario_stock_returns["base"][t]*100:.1f}\%', f'{v*100:.2f} pp'))
# Escape helpers
def latex_table(rows, headers):
    s = []
    s.append('\\begin{center}')
    s.append('\\begin{tabular}{' + 'l' * len(headers) + '}')
    s.append('\\hline')
    s.append(' & '.join(headers) + ' \\\\')
    s.append('\\hline')
    for r in rows:
        s.append(' & '.join(map(str,r)) + ' \\\\')
    s.append('\\hline')
    s.append('\\end{tabular}')
    s.append('\\end{center}')
    return '\n'.join(s)

tex = r'''
\documentclass{article}
\usepackage{graphicx}

\title{AI Bubble Unwind Impact Model: Corrected Analysis and Visualization Package}
\author{}
\date{}

\begin{document}
\maketitle

\section{Scope of this version}

This version fixes the main issues in the previous package. The projected paths now start exactly at the last actual observation, so there is no visual gap between history and scenario. The report also includes a peak-normalized event-time overlay of the current AI path against the dot-com TMT path, and a separate normalized projection chart that compares the model-implied AI replay against the historical dot-com post-peak drawdown. The stock-level exposure construction has also been corrected: platform names such as GOOGL are not assigned zero AI exposure simply because a short noisy regression happens to produce a weak coefficient.

The goal is not to predict the timing or probability of an AI crash. The goal is to construct a conditional stress vector. The object is
\[
R^s=(R_1^s,\ldots,R_N^s)',
\]
where each component is the projected return of a stock, sector, or index under scenario \(s\). The output is designed to be used later in portfolio stress testing.

\section{Model specification}

The empirical model has three components. First, the dot-com TMT episode is used to define a market path and a technology-theme relative path. Second, the current AI basket is mapped onto that historical path through stock-level market beta and AI-specific exposure. Third, the SPY impact is decomposed into covered AI concentration and the remaining market component.

Let \(r_t^M\) be the market return during the dot-com replay window and let \(r_t^T-r_t^M\) be the TMT relative return. For stock \(i\), the projected monthly return under the base scenario is
\[
r_{i,t}^{base}=\beta_i^M r_t^M+\lambda_i^{AI}(r_t^T-r_t^M).
\]
The first term captures broad market beta. The second term captures AI-specific sensitivity. The 24-month projected return is
\[
R_i^{base}=\prod_{t=1}^{24}(1+r_{i,t}^{base})-1.
\]

For scenario scaling, the monthly market and AI-relative shocks are multiplied by a scenario coefficient \(c_s\):
\[
r_{i,t}^{s}=\beta_i^M c_s r_t^M+\lambda_i^{AI}c_s(r_t^T-r_t^M),
\]
where \(c_s=0.5\) for mild, \(c_s=1.0\) for base, and \(c_s=1.25\) for severe.

The SPY-level impact is computed by applying current SPY weights to the covered AI names and assigning the remaining index weight to the broad market replay:
\[
r_{SPY,t}^{s}=\left(1-\sum_{i\in A}w_i\right)c_s r_t^M+\sum_{i\in A}w_i r_{i,t}^{s}.
\]
This is deliberately transparent. It avoids pretending that we have full current S\&P 500 constituent price histories when we do not.

\section{Exposure construction}

A pure regression-only approach can generate economically nonsensical results because the current AI period is short, the basket names are highly correlated, and the factor is noisy. This was the source of the prior issue where a platform name could appear to have zero AI exposure. The corrected version uses a hybrid exposure multiplier:
\[
\lambda_i^{AI}=0.70\lambda_i^{econ}+0.30\max(0.15,\hat{\lambda}_i^{reg}),
\]
with caps to avoid extreme statistical artifacts. The economic overlay reflects whether the firm is an AI infrastructure supplier, a platform/hyperscaler, or a more speculative AI-exposed name. The regression term is still shown as a diagnostic, but it is not allowed to mechanically erase obvious economic exposure.

This is a management stress framework rather than a causal model. The hybrid exposure is an assumption set that should be debated, adjusted, and approved before production use.

\section{Key numbers}
'''
tex += latex_table(summary_rows, ['Quantity','Value'])
tex += r'''

\section{Dot-com and current AI comparison}

Figure 1 is the key visual sanity check. It aligns the current AI factor and the historical dot-com TMT factor by their own relative peaks. Both are normalized to 100 at peak. This answers the question: if the current AI theme is viewed as a bubble-like technology trade, where does its actual path sit relative to the dot-com pattern?

\begin{center}
\includegraphics[width=0.95\linewidth]{figures/fig01_event_overlay.png}
\end{center}

The chart should not be interpreted as proof that AI must follow dot-com. It is a historical template comparison. If the current AI line is already below its peak, that means the theme has partly cooled before the scenario projection starts. This is important because a stress scenario should begin from the current level, not from a hypothetical peak.

Figure 2 then asks a different question: starting from today, what does a dot-com-style replay imply for the AI basket? The projected AI series is normalized to 100 at the projection start and shown against the actual dot-com TMT post-peak path. This directly addresses the previous missing visualization.

\begin{center}
\includegraphics[width=0.95\linewidth]{figures/fig02_projection_vs_dotcom.png}
\end{center}

\section{Actual paths connected to projections}

The following figures fix the gap problem in the earlier version. The dashed projection begins at exactly the last observed actual value. Therefore the projection is not a separate floating line; it is a continuation of the observed time series under the stress scenario.

\begin{center}
\includegraphics[width=0.95\linewidth]{figures/fig03_actual_projection_aggregate.png}
\end{center}

Figure 3 shows the aggregate AI basket and the S\&P price index proxy. The S\&P price history comes from the Shiller data, while the SPY impact uses current SPY holdings. This is not ideal, but it is transparent: the price history is a broad S\&P proxy and the contribution calculation uses SPY weights.

\begin{center}
\includegraphics[width=0.95\linewidth]{figures/fig04_nasdaq_projection.png}
\end{center}

Figure 4 shows the NASDAQ Composite. Because QQQ holdings were not available, the NASDAQ projection is estimated from its historical sensitivity to the current AI factor and the market factor. This is a proxy, not a holdings-level NASDAQ-100 decomposition.

\section{Stock-level projected paths}

Figures 5 and 6 show actual stock paths connected to the base projected unwind. The stocks are separated into platform megacaps and AI infrastructure/high-beta names because their economics are different. Platform names have more diversified businesses and lower AI-specific multipliers. Infrastructure names have larger direct sensitivity to an AI capex or AI demand disappointment.

\begin{center}
\includegraphics[width=0.95\linewidth]{figures/fig05_platform_projection.png}
\end{center}

\begin{center}
\includegraphics[width=0.95\linewidth]{figures/fig06_infra_projection.png}
\end{center}

The important point is not the exact final price. The useful output is the stress shape and ranking. The model says that high-beta AI infrastructure names should suffer larger drawdowns than diversified platform names under the same AI-relative shock.

\section{Final stock vector}

The base stock-level vector is shown below. The beta columns are included so that the result is auditable. If management disagrees with the economic overlay, the stress vector can be regenerated by changing \(\lambda_i^{econ}\).
'''
tex += latex_table(stock_rows, ['Ticker','Mkt beta','Reg AI beta','Econ AI','Final AI','Base return'])
tex += r'''

\begin{center}
\includegraphics[width=0.95\linewidth]{figures/fig14_stock_vector.png}
\end{center}

\section{SPY concentration impact}

The next chart decomposes the base SPY impact into contributions from covered AI names. A contribution is weight times projected return:
\[
Contribution_i=w_i R_i^{base}.
\]
Alphabet Class C is proxied by GOOGL because a separate GOOG price file was not available. This is reasonable for stress purposes but should be replaced with actual GOOG history in a production version.

\begin{center}
\includegraphics[width=0.95\linewidth]{figures/fig07_spy_contributions.png}
\end{center}
'''
tex += latex_table(contrib_rows, ['Ticker proxy','SPY weight','Base return','SPY contrib'])
tex += r'''

Figure 8 shows the exposure construction itself. It is included to make the model debuggable. A black-box vector would not be appropriate for senior management; the stress multiplier must be visible and challengeable.

\begin{center}
\includegraphics[width=0.95\linewidth]{figures/fig08_exposure_multipliers.png}
\end{center}

\section{Scenario paths and sensitivity}

Figure 9 shows the SPY weighted index impact under mild, base, and severe assumptions. The difference between the lines is the scale applied to both the broad market replay and the AI-relative replay.

\begin{center}
\includegraphics[width=0.95\linewidth]{figures/fig09_spy_scenarios.png}
\end{center}

Figure 10 is a sensitivity heatmap. It separates uncertainty in the market shock from uncertainty in the AI-relative shock. This matters because the two risks are conceptually different. A pure AI unwind can be severe for the basket but moderate for the index if market spillover is contained. A combined AI unwind plus broad risk-off market shock produces a much larger index loss.

\begin{center}
\includegraphics[width=0.85\linewidth]{figures/fig10_sensitivity_heatmap.png}
\end{center}

\section{Historical evaluation of the signal}

The project also tests whether the extrapolation/stretch signal has predictive content historically using Fama-French 49 industries. The result is intentionally sobering. The fitted relationship has low explanatory power. This means the signal is not a reliable crash predictor. It is still useful for stress construction, but it should not be sold as a forecast model.

\begin{center}
\includegraphics[width=0.95\linewidth]{figures/fig11_signal_drawdown.png}
\end{center}

\begin{center}
\includegraphics[width=0.95\linewidth]{figures/fig12_drawdown_distribution.png}
\end{center}

The distribution chart shows why the dot-com shock is a stress calibration rather than a normal expectation. Dot-com is a severe historical technology-theme event, not the mean outcome of high-signal states.

\section{Correlation and crowding within the AI basket}

The model assumes that the AI basket behaves like a linked theme rather than a set of unrelated stocks. Figure 13 checks this assumption by showing the current-period monthly return correlation matrix. High correlations support treating the group as a common factor. Lower correlations would argue for a more granular sub-basket model.

\begin{center}
\includegraphics[width=0.80\linewidth]{figures/fig13_correlation_matrix.png}
\end{center}

\section{Known problems and what remains to make this deliverable}

There are several real limitations. They should be stated directly rather than hidden.

First, the SPY calculation uses SPY holdings, but the actual S\&P price path in the report uses the Shiller S\&P price series because a clean SPY price history was not available in the uploaded files. This is acceptable for illustration, but the next version should download SPY total return or adjusted close history.

Second, the AI stock basket is incomplete. ORCL, AAPL, GOOG as a separate share class, and other AI-adjacent names are not fully covered with their own price histories. The report proxies GOOG using GOOGL and excludes other missing names. The omitted candidate AI weights file lists visible SPY weights that could matter.

Third, there is no full S\&P 500 constituent price history. Therefore the non-AI spillover is approximated through the broad market component, not estimated stock by stock. A production-quality version should download daily or monthly price histories for all current SPY constituents and estimate stock-level AI betas.

Fourth, the sector ETF data are missing. Without XLK, XLC, XLY, SMH, SOXX, IGV, and other sector ETFs, the sector-level presentation is weaker than it should be. The current package uses Fama-French industries for historical calibration, but a management presentation should include ETF-level sector shock paths.

Fifth, the exposure multipliers are partly judgmental. This is intentional, because regression-only estimates are unstable and can create obviously wrong outputs. However, the overlay should be converted into a formally approved scenario grid: low, base, and high AI exposure by name.

Sixth, the model still does not include valuation, earnings, capex, or options-implied data. To make the project more deliverable, the next step should add valuation-compression scenarios and AI capex-payback scenarios. That would allow the model to distinguish between a momentum unwind and a fundamental monetization disappointment.

\section{Recommended next work}

To make this useful for senior management, the next version should focus on data completeness and validation rather than adding more theory. The concrete priorities are:

\begin{enumerate}
\item Download SPY and QQQ adjusted price histories so the index path charts use actual ETF data rather than proxies.
\item Download QQQ holdings so the NASDAQ-100 impact can be decomposed by constituent weights rather than estimated by regression.
\item Download daily or monthly prices for all current SPY constituents. This enables a true stock-level vector for the entire index.
\item Download sector ETF histories, especially XLK, XLC, XLY, SMH, SOXX, IGV, and SKYY. This enables clean sector-level shock paths.
\item Add missing AI and AI-adjacent names: ORCL, AAPL, GOOG, TSM, ASML, MU, ANET, DELL, and VRT.
\item Add market capitalization and valuation data so the AI factor can be value-weighted and the stress can include valuation compression.
\item Backtest the methodology on dot-com by pretending to stand at the dot-com peak, estimating exposures using only prior data, and comparing projected versus realized paths.
\item Turn the final output into a dashboard-style package: stock vector, sector vector, index impact, scenario slider, and contribution decomposition.
\end{enumerate}

\section{Bottom line}

This version should be interpreted as a corrected stress-analysis prototype. It is not a final prediction model. The useful result is the translation of a dot-com-style AI-relative shock into connected stock paths, index paths, contribution tables, and stress vectors. The model is transparent enough to challenge and adjust, which is more valuable for risk work than a precise-looking but unjustified forecast.

\end{document}
'''
(OUT/'main.tex').write_text(tex)

# README and dictionary
readme = f"""# AI Bubble Impact Senior Management v5

This package rebuilds the analysis with corrected connected projections and richer visualization.

Key outputs:
- Base AI relative shock from dot-com TMT replay: {base_ai_rel_total*100:.1f}%
- Base market shock over same replay window: {base_mkt_total*100:.1f}%
- Base projected AI basket return: {ai_basket_total*100:.1f}%
- Base projected SPY weighted impact: {spy_total*100:.1f}%
- Covered AI weight in SPY: {covered_ai_weight*100:.1f}%

Main files:
- main.pdf: compiled report
- main.tex: vanilla LaTeX source using only graphicx
- figures/: all visualizations
- data/: output vectors and diagnostics
- code/build_v5.py: script used to build the package

Important limitations are stated in the report. This is a stress prototype, not a forecast model.
"""
(OUT/'README.md').write_text(readme)

dd = """# Data dictionary

- exposure_multipliers.csv: regression diagnostics, economic overlay, and final AI stress multipliers.
- stress_vector_ai_stocks_total_return.csv: mild/base/severe total projected returns by AI stock over 24 months.
- spy_ai_weights.csv: covered AI weights in SPY holdings, with GOOG proxied by GOOGL.
- base_spy_contributions.csv: base case weight-times-return contributions to SPY.
- projected_ai_basket_paths.csv: normalized projected AI basket path by scenario.
- projected_spy_paths.csv: normalized projected SPY weighted path by scenario.
- projected_nasdaq_paths.csv: normalized projected NASDAQ proxy path by scenario.
- historical_signal_future_drawdown_sample.csv: sample of FF49 historical signal and future drawdown observations.
- omitted_candidate_ai_weights.csv: visible SPY weights for candidate AI/AI-adjacent names not fully covered.
"""
(OUT/'data_dictionary.md').write_text(dd)
shutil.copyfile('/mnt/data/build_v5.py', CODE/'build_v5.py')

# Compile LaTeX
subprocess.run(['pdflatex','-interaction=nonstopmode','main.tex'], cwd=OUT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
subprocess.run(['pdflatex','-interaction=nonstopmode','main.tex'], cwd=OUT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

# Zip
zip_path = BASE/'ai_bubble_impact_senior_mgmt_v5_outputs.zip'
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(OUT):
        for f in files:
            if f.endswith(('.aux','.log')): continue
            path = Path(root)/f
            z.write(path, path.relative_to(OUT.parent))
print('WROTE', zip_path)
print('PDF', OUT/'main.pdf')
print('Summary:', base_ai_rel_total, base_mkt_total, covered_ai_weight, spy_total, ai_basket_total, nas_total)
