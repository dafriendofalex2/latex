"""Dot-com path-similarity diagnostic.  This is evidence for analogue choice, not timing."""
from __future__ import annotations
import numpy as np
import pandas as pd


def normalize_log_path(price):
    p = pd.Series(price, dtype=float).dropna()
    if (p <= 0).any():
        raise ValueError("price must be positive")
    lp = np.log(p)
    return lp - lp.iloc[0]


def rolling_smooth(values, window=20):
    s = pd.Series(np.asarray(values, dtype=float))
    return s.rolling(window, min_periods=1).mean().to_numpy()


def path_score(current_path, historical_path):
    a = np.asarray(current_path, dtype=float)
    b = np.asarray(historical_path, dtype=float)
    n = min(len(a), len(b))
    if n < 20:
        raise ValueError("paths are too short")
    a, b = a[-n:], b[-n:]
    return {
        "rmse": float(np.sqrt(np.mean((a - b) ** 2))),
        "mae": float(np.mean(np.abs(a - b))),
        "correlation": float(np.corrcoef(a, b)[0, 1]),
    }


def fit_lead(current_price, reference_price, max_lead=150, n=252, smooth_window=20):
    """Search historical segments ending 0..max_lead days before reference peak."""
    current = pd.Series(current_price, dtype=float).dropna().iloc[-n:]
    reference = pd.Series(reference_price, dtype=float).dropna()
    x = rolling_smooth(normalize_log_path(current).to_numpy(), smooth_window)
    peak = int(np.nanargmax(reference.to_numpy()))
    rows = []
    for lead in range(max_lead + 1):
        end = peak - lead
        start = end - n + 1
        if start < 0:
            continue
        ref = reference.iloc[start:end + 1]
        y = rolling_smooth(normalize_log_path(ref).to_numpy(), smooth_window)
        score = path_score(x, y)
        rows.append({"lead_trading_days": lead, **score, "start_index": start, "end_index": end})
    if not rows:
        raise ValueError("reference series is too short for requested search")
    table = pd.DataFrame(rows).sort_values("lead_trading_days")
    best = table.loc[table["rmse"].idxmin()].to_dict()
    return best, table
