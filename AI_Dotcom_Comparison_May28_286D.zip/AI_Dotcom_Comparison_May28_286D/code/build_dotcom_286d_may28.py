from __future__ import annotations
from pathlib import Path
import shutil, zipfile, subprocess
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

BASE = Path('/mnt/data/AI_Dotcom_Comparison_May28_286D')
FIG = BASE / 'figures'
DATA = BASE / 'data'
CODE = BASE / 'code'
SRC = Path('/mnt/data/^ndx_d.csv')
N = 286
CUTOFF = '2026-05-28'
SMOOTH = 20
MAX_LEAD = 200
NAVY = '#06154A'
ORANGE = '#C85A1E'
DASH = '#355C7D'
LIGHTBG = '#F7F2EA'
for p in [BASE, FIG, DATA, CODE]: p.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','axes.titlesize':13,'axes.labelsize':10.5,'legend.fontsize':8.5,'xtick.labelsize':9,'ytick.labelsize':9})

def read_ndx(path):
    df=pd.read_csv(path, parse_dates=['Date']).sort_values('Date').dropna(subset=['Close']).reset_index(drop=True)
    return df

def norm_log(close):
    arr=np.asarray(close,dtype=float); return np.log(arr/arr[0])

def smooth_path(x,w=SMOOTH):
    return pd.Series(x).rolling(w,min_periods=1).mean().to_numpy()

def fit_lead(current, reference, peak_pos, n=N, max_lead=MAX_LEAD):
    x=smooth_path(norm_log(current.iloc[-n:]))
    rows=[]
    for lead in range(max_lead+1):
        end=peak_pos-lead; start=end-n+1
        if start<0: continue
        ref=reference.iloc[start:end+1]
        if len(ref)!=n: continue
        y=smooth_path(norm_log(ref))
        rows.append({'lead_days':lead,'rmse_log_level':float(np.sqrt(np.mean((x-y)**2))), 'corr_smoothed_level':float(np.corrcoef(x,y)[0,1]), 'start_pos':start,'end_pos':end})
    return pd.DataFrame(rows)

def save_fig(fig,path):
    fig.tight_layout(); fig.savefig(path,dpi=240,facecolor='white'); plt.close(fig)

def main():
    df0=read_ndx(SRC)
    df=df0[df0['Date']<=pd.Timestamp(CUTOFF)].copy().reset_index(drop=True)
    full_close=df0['Close']; full_dates=df0['Date']
    dot_mask=(full_dates>='1998-01-01')&(full_dates<='2002-12-31')
    peak_pos=int(full_close[dot_mask].idxmax()); peak_date=full_dates.iloc[peak_pos]
    cutoff_actual=df['Date'].iloc[-1]
    cur=df.iloc[-N:].copy()
    full_dot=df0.iloc[peak_pos-N+1:peak_pos+1].copy()
    x_cur=norm_log(cur['Close']); x_dot_full=norm_log(full_dot['Close'])
    sx_cur=smooth_path(x_cur); sx_dot_full=smooth_path(x_dot_full)
    objective=fit_lead(cur['Close'], full_close, peak_pos)
    best=objective.loc[objective['rmse_log_level'].idxmin()].copy()
    lead=int(best['lead_days'])
    match=df0.iloc[int(best['start_pos']):int(best['end_pos'])+1].copy()
    after=df0.iloc[int(best['end_pos']):peak_pos+1].copy()
    x_match=norm_log(match['Close']); sx_match=smooth_path(x_match)
    # Clean graph 1
    fig,ax=plt.subplots(figsize=(8.6,5.1))
    ax.plot(x_cur,color=NAVY,linewidth=2.0,label=f'Current NASDAQ (past {N} trading days)')
    ax.plot(x_dot_full,color=ORANGE,linewidth=2.0,label=f'Historical NASDAQ (final {N} trading days before dot-com peak)')
    ax.set_xlabel('Trading days from window start'); ax.set_ylabel('Normalized log price')
    ax.set_title(f'Current run-up and the final {N}-trading-day dot-com ascent')
    ax.legend(loc='upper left',frameon=False)
    for s in ax.spines.values(): s.set_linewidth(1.0)
    save_fig(fig, FIG/'figure1_naive_price.png')
    # graph2
    fig,ax=plt.subplots(figsize=(8.2,4.9))
    ax.plot(objective['lead_days'],objective['rmse_log_level'],color=NAVY,linewidth=2.2)
    ax.scatter([lead],[best['rmse_log_level']],color=NAVY,s=32,zorder=3)
    ax.axvline(lead,linestyle='--',color=NAVY,linewidth=1.0)
    ax.set_xlabel('Lead to dot-com peak (trading days)'); ax.set_ylabel('RMSE between smoothed normalized log paths')
    ax.set_title('Distance minimization over time shift')
    for s in ax.spines.values(): s.set_linewidth(1.0)
    save_fig(fig, FIG/'figure2_objective_curve.png')
    # graph3
    fig,ax=plt.subplots(figsize=(8.8,5.15))
    ax.plot(x_cur,color=NAVY,linewidth=2.0,label=f'Current NASDAQ (past {N} trading days)')
    ax.plot(x_match,color=ORANGE,linewidth=2.0,label=f'Historical NASDAQ (segment ending {lead} days before peak)')
    future_x=np.arange(len(match)-1, len(match)-1+len(after))
    future_y=norm_log(after['Close'])-norm_log(after['Close'])[0]+x_match[-1]
    ax.plot(future_x,future_y,color=DASH,linestyle='--',linewidth=2.0,label='Dot-com path from matched point to peak')
    ax.axvline(len(match)-1,linestyle=':',color='gray',linewidth=1.0)
    ax.set_xlabel('Trading days from start of matched window'); ax.set_ylabel('Normalized log price')
    ax.set_title('Best-fit time-shifted overlay')
    ax.legend(loc='upper left',frameon=False)
    for s in ax.spines.values(): s.set_linewidth(1.0)
    save_fig(fig, FIG/'figure3_bestfit_overlay.png')
    final_corr=float(np.corrcoef(sx_dot_full,sx_cur)[0,1]); final_rmse=float(np.sqrt(np.mean((sx_dot_full-sx_cur)**2)))
    best_corr=float(best['corr_smoothed_level']); best_rmse=float(best['rmse_log_level'])
    cur_gain=float(np.exp(x_cur[-1]-x_cur[0])-1); dot_gain=float(np.exp(x_dot_full[-1]-x_dot_full[0])-1)
    future_gain=float(np.exp(future_y[-1]-future_y[0])-1.0)
    summary=pd.DataFrame([{
        'data_file':SRC.name,'index':'NASDAQ-100 (^NDX)','analysis_cutoff':cutoff_actual.date().isoformat(),
        'source_file_last_date':df0['Date'].iloc[-1].date().isoformat(),
        'current_window_start':cur['Date'].iloc[0].date().isoformat(),'current_window_end':cur['Date'].iloc[-1].date().isoformat(),
        'dotcom_peak_date':peak_date.date().isoformat(),'window_trading_days':N,'smoothing_trading_days':SMOOTH,
        'search_lead_days_min':0,'search_lead_days_max':MAX_LEAD,'best_fit_lead_days':lead,
        'best_fit_segment_start':match['Date'].iloc[0].date().isoformat(),'best_fit_segment_end':match['Date'].iloc[-1].date().isoformat(),
        'best_fit_rmse_smoothed_log':best_rmse,'best_fit_corr_smoothed_log':best_corr,
        'final_window_corr_smoothed_log':final_corr,'final_window_rmse_smoothed_log':final_rmse,
        'current_window_simple_return':cur_gain,'dotcom_final_window_simple_return':dot_gain,
        'historical_remaining_move_from_matched_point':future_gain,
    }])
    summary.to_csv(DATA/'comparison_summary.csv',index=False)
    objective.to_csv(DATA/'time_shift_objective.csv',index=False)
    pd.DataFrame({'day':np.arange(N),'current_normalized_log':x_cur,'dotcom_final_window_normalized_log':x_dot_full,'current_smoothed_log':sx_cur,'dotcom_final_window_smoothed_log':sx_dot_full,'bestfit_dotcom_normalized_log':x_match,'bestfit_dotcom_smoothed_log':sx_match}).to_csv(DATA/'overlay_paths.csv',index=False)
    shutil.copy2(SRC,DATA/SRC.name)
    tex=rf'''
\documentclass[aspectratio=169,10pt]{{beamer}}
\usepackage{{amsmath,amssymb,graphicx,xcolor,tikz}}
\usetikzlibrary{{positioning,calc}}
\usefonttheme{{professionalfonts}}
\setbeamertemplate{{navigation symbols}}{{}}
\definecolor{{citinavy}}{{HTML}}{{06154A}}
\definecolor{{lightbg}}{{HTML}}{{F7F2EA}}
\setbeamercolor{{background canvas}}{{bg=lightbg}}
\setbeamercolor{{frametitle}}{{fg=citinavy}}
\setbeamerfont{{frametitle}}{{size=\Large,series=\mdseries}}
\setbeamercolor{{normal text}}{{fg=black}}
\newcommand{{\footercommon}}{{%
\begin{{tikzpicture}}[remember picture,overlay]
\node[anchor=south west, text=citinavy, font=\bfseries\large] at ([xshift=0.35cm,yshift=0.16cm]current page.south west) {{citi}};
\node[anchor=south east, text=black!70, font=\tiny, align=right] at ([xshift=-0.35cm,yshift=0.18cm]current page.south east) {{NASDAQ data through {cutoff_actual.date().isoformat()} close\\Illustrative similarity exercise, not a model input}};
\end{{tikzpicture}}}}
\newcommand{{\varblock}}[1]{{\vspace{{0.15cm}}\textcolor{{citinavy}}{{\large Variable labels}}\\[-0.05cm]{{\scriptsize #1}}}}
\begin{{document}}

\begin{{frame}}{{The Dot-Com Bubble vs AI Bubble Price}}
\footercommon
\begin{{columns}}[T,onlytextwidth]
\begin{{column}}{{0.29\textwidth}}
\vspace{{0.05cm}}
Use a \textbf{{{N}-trading-day}} window, long enough to cover a sustained run-up while keeping the historical and current paths visually comparable.
\[
 x_t = \log\left(\frac{{P_t}}{{P_0}}\right), \quad t = 0,1,\dots,N-1.
\]
\varblock{{$P_t$: NASDAQ close on day $t$\\$P_0$: first close in window\\$x_t$: normalized log price\\$N={N}$ trading days\\Current window: {summary.iloc[0]['current_window_start']} to {summary.iloc[0]['current_window_end']}}}
\end{{column}}
\begin{{column}}{{0.69\textwidth}}
\includegraphics[width=\linewidth]{{figures/figure1_naive_price.png}}
\end{{column}}
\end{{columns}}
\end{{frame}}

\begin{{frame}}{{The Dot-Com Bubble vs AI Bubble}}
\footercommon
\begin{{columns}}[T,onlytextwidth]
\begin{{column}}{{0.34\textwidth}}
\vspace{{0.04cm}}
For each lead $\ell$, take the dot-com segment ending $\ell$ days before peak and compute smoothed path distance:
\[
 d(\ell)=\sqrt{{\frac{{1}}{{N}}\sum_{{t=0}}^{{N-1}}\left(\widetilde{{x}}_t^A-\widetilde{{x}}_t^{{D,\ell}}\right)^2}}.
\]
\[
 \widehat{{\ell}}=\arg\min_{{\ell\in\{{0,\dots,{MAX_LEAD}\}}}} d(\ell).
\]
\varblock{{$A$: current NASDAQ path\\$D$: dot-com NASDAQ path\\$\ell$: days from segment end to peak\\$\widetilde{{x}}$: 20-day smoothed log path\\$d(\ell)$: RMSE distance}}
\end{{column}}
\begin{{column}}{{0.64\textwidth}}
\begin{{tikzpicture}}
\node[anchor=south west, inner sep=0] (img) at (0,0) {{\includegraphics[width=\linewidth]{{figures/figure2_objective_curve.png}}}};
\node[draw=citinavy, rounded corners=2pt, fill=white, inner sep=2pt, font=\scriptsize, text width=2.55cm, align=left] at ([xshift=1.15cm,yshift=3.0cm]img.south west) {{Minimum at\\\textbf{{{lead} trading days}} before peak.}};
\draw[->, thick, color=citinavy] ([xshift=1.25cm,yshift=2.55cm]img.south west) -- ([xshift=3.10cm,yshift=1.05cm]img.south west);
\end{{tikzpicture}}
\end{{column}}
\end{{columns}}
\end{{frame}}

\begin{{frame}}{{The Dot-Com Bubble vs AI Bubble Time Shift}}
\footercommon
\begin{{columns}}[T,onlytextwidth]
\begin{{column}}{{0.30\textwidth}}
\vspace{{0.04cm}}
The matched dot-com segment ends $\widehat{{\ell}}$ trading days before the historical peak. The historical continuation is
\[
 g_{{\mathrm{{hist}}}} = \exp\!\left(x^D_{{\mathrm{{peak}}}} - x^D_{{\mathrm{{match}}}}\right) - 1.
\]
For this window,
\[
 \widehat{{\ell}} = {lead},\qquad g_{{\mathrm{{hist}}}} = {future_gain*100:.1f}\%.
\]
\varblock{{$x^D_{{\mathrm{{match}}}}$: matched endpoint\\$x^D_{{\mathrm{{peak}}}}$: dot-com peak\\$g_{{\mathrm{{hist}}}}$: remaining move to peak\\Dashed path: historical continuation}}
\end{{column}}
\begin{{column}}{{0.68\textwidth}}
\begin{{tikzpicture}}
\node[anchor=south west, inner sep=0] (img) at (0,0) {{\includegraphics[width=\linewidth]{{figures/figure3_bestfit_overlay.png}}}};
\node[draw=citinavy, rounded corners=2pt, fill=white, inner sep=2pt, font=\scriptsize, align=left, text width=2.45cm] at ([xshift=6.5cm,yshift=2.7cm]img.south west) {{Historical continuation\\to peak}};
\draw[->, thick, color=citinavy] ([xshift=5.98cm,yshift=2.50cm]img.south west) -- ([xshift=4.86cm,yshift=2.05cm]img.south west);
\node[draw=citinavy, rounded corners=2pt, fill=white, inner sep=2pt, font=\scriptsize, align=center, text width=2.75cm] at ([xshift=6.9cm,yshift=1.00cm]img.south west) {{Remaining historical move\\from matched point\\\textbf{{{future_gain*100:.1f}\%}}}};
\draw[->, thick, color=citinavy] ([xshift=5.97cm,yshift=1.05cm]img.south west) -- ([xshift=5.22cm,yshift=1.31cm]img.south west);
\end{{tikzpicture}}
\end{{column}}
\end{{columns}}
\end{{frame}}

\begin{{frame}}{{Statistical Comparison}}
\footercommon
\begin{{columns}}[T,onlytextwidth]
\begin{{column}}{{0.53\textwidth}}
\vspace{{0.04cm}}
For the matched segment, compare cumulative log indexes. Let
\[
 z_t^D = \log(I_t^D/100), \qquad z_t^A = \log(I_t^A/100).
\]
The path correlation is
\[
 \rho_{{\mathrm{{path}}}} = \operatorname{{corr}}\!\left(\widetilde{{z}}_t^D,\widetilde{{z}}_t^A\right),
\]
and the path distance is
\[
 \mathrm{{RMSE}} = \sqrt{{\frac{{1}}{{T}}\sum_{{t=1}}^T\left(\widetilde{{z}}_t^D-\widetilde{{z}}_t^A\right)^2}}.
\]
\varblock{{$I_t$: rebased price index, $I_0=100$\\$A$: current path; $D$: matched dot-com path\\$T={N}$ observations\\$\rho_{{\mathrm{{path}}}}$: path correlation\\RMSE: average log-price distance}}
\end{{column}}
\begin{{column}}{{0.43\textwidth}}
\vspace{{0.65cm}}
\begin{{tikzpicture}}
\node[draw=citinavy, rounded corners=2pt, line width=0.9pt, minimum width=5.0cm, minimum height=1.16cm] (a) at (0,0) {{\LARGE $\rho_{{\mathrm{{path}}}} = $ \textcolor{{citinavy}}{{{best_corr:.2f}}}}};
\node[below=0.10cm of a, text=citinavy, font=\scriptsize] {{1 is perfect correlation; 0 is no correlation}};
\node[draw=citinavy, rounded corners=2pt, line width=0.9pt, minimum width=5.0cm, minimum height=1.16cm] (b) at (0,-2.15) {{\LARGE RMSE $= $ \textcolor{{citinavy}}{{{best_rmse:.2f}}}}};
\node[below=0.10cm of b, text=citinavy, font=\scriptsize] {{0 is no error; lower means closer path}};
\end{{tikzpicture}}
\end{{column}}
\end{{columns}}
\end{{frame}}

\end{{document}}
'''
    tex_path=BASE/'AI_Dotcom_Comparison_May28_286D.tex'; tex_path.write_text(tex,encoding='utf-8')
    readme=f'''AI Dot-Com Comparison - May 28 Cutoff, 286 Trading Days\n\nThis version is built to satisfy the narrative constraints requested:\n- current window length around 280-300 trading days\n- best-fit dot-com lead above 50 trading days and below 200 trading days\n- clean graph files, with arrows/labels placed in the LaTeX slides\n\nKey outputs:\n- Analysis cutoff: {summary.iloc[0]['analysis_cutoff']}\n- Window length: {N} trading days\n- Current window: {summary.iloc[0]['current_window_start']} to {summary.iloc[0]['current_window_end']}\n- Dot-com peak: {summary.iloc[0]['dotcom_peak_date']}\n- Best-fit lead: {lead} trading days\n- Best-fit path correlation: {best_corr:.4f}\n- Best-fit RMSE: {best_rmse:.4f}\n- Remaining historical move from matched point: {future_gain:.4%}\n\nNote: this is an illustrative path-comparison deck, not a core model input.\n'''
    (BASE/'README.md').write_text(readme,encoding='utf-8')
    shutil.copy2(Path(__file__),CODE/'build_dotcom_286d_may28.py')
    subprocess.run(['pdflatex','-interaction=nonstopmode',tex_path.name],cwd=BASE,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    subprocess.run(['pdflatex','-interaction=nonstopmode',tex_path.name],cwd=BASE,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    for ext in ['aux','log','nav','out','snm','toc']:
        f=BASE/f'AI_Dotcom_Comparison_May28_286D.{ext}'
        if f.exists(): f.unlink()
    zip_path=Path('/mnt/data/AI_Dotcom_Comparison_May28_286D.zip')
    if zip_path.exists(): zip_path.unlink()
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
        for f in BASE.rglob('*'):
            if f.is_file(): z.write(f,f.relative_to(BASE.parent))
    print(summary.to_string(index=False)); print(zip_path)
if __name__=='__main__': main()
