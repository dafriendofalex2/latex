"""Burst-conditional five-case severity probability model.

The object estimated here is P(S=s | B=1), where B=1 denotes a qualifying
bubble crash with maximum drawdown of at least 40%.  This module DOES NOT
estimate P(B=1), the probability or timing of a burst.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pandas as pd
from scipy import stats

BURST_THRESHOLD = 0.40
BOOTSTRAP_REPLICATIONS = 5000
RANDOM_SEED = 20260805
SCENARIO_ORDER = ["mild", "base", "severe", "extreme", "worst"]
DEFAULT_ANCHORS = np.array([
    0.31935317408616015,
    0.5367198983734149,
    0.6390004249225980,
    0.7528325157387598,
    0.8307705341123137,
])


def positive_log_loss(drawdown):
    d = np.asarray(drawdown, dtype=float)
    if np.any((d < 0) | (d >= 1)):
        raise ValueError("drawdown must lie in [0,1)")
    return -np.log1p(-d)


def drawdown_from_log_loss(log_loss):
    return 1.0 - np.exp(-np.asarray(log_loss, dtype=float))


def scenario_cells(anchors=DEFAULT_ANCHORS, burst_threshold=BURST_THRESHOLD):
    """Nearest-representative Voronoi cells in positive log-loss space."""
    d = np.asarray(anchors, dtype=float)
    if len(d) != 5 or not np.all(np.diff(d) > 0):
        raise ValueError("five strictly increasing scenario anchors are required")
    L = positive_log_loss(d)
    mid_L = 0.5 * (L[:-1] + L[1:])
    mid_D = drawdown_from_log_loss(mid_L)
    return pd.DataFrame({
        "scenario": SCENARIO_ORDER,
        "representative_drawdown": d,
        "representative_log_loss": L,
        "cell_lower_drawdown": np.array([burst_threshold, *mid_D]),
        "cell_upper_drawdown": np.array([*mid_D, 1.0]),
        "cell_lower_logloss": positive_log_loss(np.array([burst_threshold, *mid_D])),
        "cell_upper_logloss": np.array([*mid_L, np.inf]),
    })


def aicc(log_likelihood: float, parameter_count: int, sample_size: int) -> float:
    """Small-sample corrected Akaike information criterion."""
    k, n = float(parameter_count), float(sample_size)
    if n <= k + 1:
        return np.inf
    return float(2*k - 2*log_likelihood + 2*k*(k+1)/(n-k-1))


def fit_models(drawdowns, burst_threshold=BURST_THRESHOLD):
    """Fit Beta, Gamma, Weibull and Lognormal conditional severity families.

    Beta is fitted to z=(D-u)/(1-u).  The other three are fitted to excess
    positive log loss T=log((1-u)/(1-D)).  All log likelihoods are evaluated
    on the common D scale, including the appropriate Jacobian, so AICc is
    comparable across parameterizations.
    """
    D = np.asarray(drawdowns, dtype=float)
    if np.any(D < burst_threshold) or np.any(D >= 1):
        raise ValueError("conditional drawdowns must satisfy u <= D < 1")
    n = len(D)
    u = float(burst_threshold)
    z = np.clip((D - u) / (1.0 - u), 1e-12, 1.0 - 1e-12)
    T = np.maximum(np.log((1.0 - u) / (1.0 - D)), 1e-12)
    fitted = []

    beta_par = stats.beta.fit(z, floc=0, fscale=1)
    beta_ll = float(np.sum(stats.beta.logpdf(z, *beta_par) - np.log(1.0 - u)))
    def beta_cdf(d, par=beta_par):
        d = np.asarray(d, dtype=float)
        scaled = np.clip((d-u)/(1-u), 0.0, 1.0)
        value = stats.beta.cdf(scaled, *par)
        return np.where(d <= u, 0.0, np.where(d >= 1.0, 1.0, value))
    fitted.append({"name":"Beta on normalized drawdown", "family":"Beta",
                   "params":beta_par, "loglik":beta_ll, "k":2,
                   "aicc":aicc(beta_ll,2,n), "cdf":beta_cdf})

    for name, dist in [
        ("Gamma on excess log-loss", stats.gamma),
        ("Weibull on excess log-loss", stats.weibull_min),
        ("Lognormal on excess log-loss", stats.lognorm),
    ]:
        par = dist.fit(T, floc=0)
        # T(D)=log((1-u)/(1-D)); dT/dD = 1/(1-D).
        ll_D = float(np.sum(dist.logpdf(T, *par) - np.log(1.0 - D)))
        def make_cdf(distribution, parameters):
            def _cdf(d):
                d = np.asarray(d, dtype=float)
                clipped = np.minimum(d, 1.0 - 1e-12)
                t = np.log((1.0-u)/(1.0-clipped))
                value = distribution.cdf(np.maximum(t,0.0), *parameters)
                return np.where(d <= u, 0.0, np.where(d >= 1.0, 1.0, value))
            return _cdf
        fitted.append({"name":name, "family":name.split()[0], "params":par,
                       "loglik":ll_D, "k":2, "aicc":aicc(ll_D,2,n),
                       "cdf":make_cdf(dist, par)})
    return fitted


def model_average_probabilities(drawdowns, cells=None):
    """Fit candidates, compute AICc weights, and integrate probability by cell."""
    cells = scenario_cells() if cells is None else cells.copy()
    fits = fit_models(drawdowns)
    scores = np.array([f["aicc"] for f in fits], dtype=float)
    raw = np.exp(-0.5 * (scores - scores.min()))
    weights = raw / raw.sum()
    lo = cells["cell_lower_drawdown"].to_numpy(float)
    hi = cells["cell_upper_drawdown"].to_numpy(float)
    per_model = []
    for fit, weight in zip(fits, weights):
        cdf = fit["cdf"]
        p = np.array([float(cdf(hi[i]) - cdf(lo[i])) for i in range(5)])
        p = np.maximum(p, 0.0)
        p = p / p.sum()
        fit["weight"] = float(weight)
        fit["probabilities"] = p
        per_model.append(p)
    averaged = np.sum(np.asarray(per_model) * weights[:, None], axis=0)
    averaged = averaged / averaged.sum()
    return fits, averaged


def bootstrap_probabilities(
    drawdowns, cells=None, replications=BOOTSTRAP_REPLICATIONS,
    seed=RANDOM_SEED,
):
    """Episode-level nonparametric bootstrap with the full ensemble re-fitted."""
    cells = scenario_cells() if cells is None else cells.copy()
    observed = np.asarray(drawdowns, dtype=float)
    rng = np.random.default_rng(seed)
    accepted = []
    attempts = 0
    max_attempts = max(4*replications, replications+1000)
    while len(accepted) < replications and attempts < max_attempts:
        attempts += 1
        sample = rng.choice(observed, size=len(observed), replace=True)
        try:
            _, p = model_average_probabilities(sample, cells)
            if np.all(np.isfinite(p)) and abs(float(p.sum()) - 1.0) < 1e-8:
                accepted.append(p)
        except Exception:
            continue
    if len(accepted) < replications:
        raise RuntimeError(f"only {len(accepted)} valid bootstrap replications")
    return np.vstack(accepted)


def dirichlet_crosscheck(drawdowns, cells=None):
    """Jeffreys-prior Dirichlet posterior mean for observed scenario-bin counts."""
    cells = scenario_cells() if cells is None else cells.copy()
    D = np.asarray(drawdowns, dtype=float)
    lo = cells["cell_lower_drawdown"].to_numpy(float)
    hi = cells["cell_upper_drawdown"].to_numpy(float)
    counts = np.array([
        np.sum((D >= lo[i]) & (D < hi[i])) if i < 4 else np.sum((D >= lo[i]) & (D <= hi[i]))
        for i in range(5)
    ], dtype=float)
    posterior_alpha = counts + 0.5
    return counts.astype(int), posterior_alpha / posterior_alpha.sum()


def gpd_diagnostic(drawdowns, burst_threshold=BURST_THRESHOLD):
    """Unconstrained small-sample GPD diagnostic; not the production probability model."""
    D = np.asarray(drawdowns, dtype=float)
    uL = -np.log(1.0 - burst_threshold)
    excess = -np.log(1.0 - D) - uL
    shape, loc, scale = stats.genpareto.fit(excess, floc=0)
    endpoint_log = np.inf if shape >= 0 else uL - scale / shape
    endpoint_D = 1.0 if not np.isfinite(endpoint_log) else 1.0 - np.exp(-endpoint_log)
    return {"shape":float(shape), "scale":float(scale), "finite_endpoint_drawdown":float(endpoint_D)}


def estimate(drawdowns, bootstrap=True):
    """Return central estimates, model comparison, and optional bootstrap intervals."""
    cells = scenario_cells()
    fits, p = model_average_probabilities(drawdowns, cells)
    result = cells.copy()
    result["probability"] = p
    counts, dmean = dirichlet_crosscheck(drawdowns, cells)
    result["historical_count"] = counts
    result["dirichlet_jeffreys_posterior_mean"] = dmean
    if bootstrap:
        boot = bootstrap_probabilities(drawdowns, cells)
        q05, q50, q95 = np.quantile(boot, [0.05, 0.50, 0.95], axis=0)
        result["bootstrap_p05"] = q05
        result["bootstrap_median"] = q50
        result["bootstrap_p95"] = q95
    model_table = pd.DataFrame([{
        "model": f["name"], "log_likelihood_D_space": f["loglik"],
        "AICc": f["aicc"], "AICc_weight": f["weight"],
        **{f"P_{SCENARIO_ORDER[i]}": f["probabilities"][i] for i in range(5)}
    } for f in fits])
    return result, model_table


def conditional_weighted_metric(values_by_scenario, probabilities):
    """E[Y | B=1] = sum_s p_s Y_s; weight completed scenario outcomes, not log shocks."""
    y = np.asarray(values_by_scenario, dtype=float)
    p = np.asarray(probabilities, dtype=float)
    if len(y) != 5 or len(p) != 5 or abs(p.sum()-1.0) > 1e-8:
        raise ValueError("five outcomes and probabilities summing to one are required")
    return float(p @ y)
