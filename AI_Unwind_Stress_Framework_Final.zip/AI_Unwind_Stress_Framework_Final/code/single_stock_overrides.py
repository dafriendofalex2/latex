"""Ticker-level override estimation using the same factor specification.

A ticker override is a precision hierarchy: if an approved stock-specific row
exists, it replaces the generic country-industry factor row. It is never added
on top of the generic row.
"""
from __future__ import annotations

from pathlib import Path
from typing import Mapping

import numpy as np
import pandas as pd

from factor_estimation import month_end_log_returns, estimate_proxy_exposure
from exposure_intensity import blend_ai_intensity, statistical_ai_excess_intensity
from scenario_engine import add_stress_columns


def build_ai_factor(
    component_prices: Mapping[str, pd.Series],
    world_price: pd.Series,
) -> pd.DataFrame:
    """Build aligned monthly world and equal-weight AI thematic returns."""
    world = month_end_log_returns(world_price).rename("world")
    components = {
        name: month_end_log_returns(series).rename(name)
        for name, series in component_prices.items()
    }
    if not components:
        raise ValueError("at least one AI thematic component is required")
    comp = pd.concat(components.values(), axis=1).dropna()
    ai = comp.mean(axis=1).rename("ai")
    return pd.concat([world, ai], axis=1).dropna()


def estimate_stock_override(
    ticker: str,
    stock_price: pd.Series,
    factors: pd.DataFrame,
    economic_ai_intensity: float,
) -> dict:
    """Estimate a stock's market loading and final AI-excess vulnerability."""
    stock = month_end_log_returns(stock_price).rename("stock")
    aligned = pd.concat([stock, factors[["world", "ai"]]], axis=1).dropna()
    exp = estimate_proxy_exposure(aligned["stock"], aligned["world"], aligned["ai"])
    stat_raw, stat = statistical_ai_excess_intensity(
        exp["theta_ai_abs_raw"],
        exp["beta_world_raw"],
        exp["theta_ai_abs_world_reference"],
    )
    final = float(blend_ai_intensity(stat, float(economic_ai_intensity)))
    return {
        "ticker": str(ticker).upper(),
        "beta_world_stock": exp["beta_world_raw"],
        "theta_ai_abs_stock": exp["theta_ai_abs_raw"],
        "theta_ai_abs_world_reference": exp["theta_ai_abs_world_reference"],
        "stat_ai_excess_intensity_raw": float(stat_raw),
        "stat_ai_excess_intensity": float(stat),
        "economic_ai_intensity": float(economic_ai_intensity),
        "statistical_weight": 0.60,
        "economic_weight": 0.40,
        "final_ai_excess_intensity": final,
        "residual_ai_beta_diagnostic": exp["residual_ai_beta_diagnostic"],
        "n_months": exp["n_months"],
    }


def recompute_approved_override_table(approved_exposures: pd.DataFrame) -> pd.DataFrame:
    """Apply the canonical 60/40 blend to an audited exposure-component table."""
    required = [
        "ticker", "beta_world_stock", "stat_ai_excess_intensity",
        "economic_ai_intensity"
    ]
    missing = [c for c in required if c not in approved_exposures.columns]
    if missing:
        raise ValueError(f"missing columns: {missing}")
    out = approved_exposures.copy()
    out["statistical_weight"] = 0.60
    out["economic_weight"] = 0.40
    out["final_ai_excess_intensity"] = blend_ai_intensity(
        out["stat_ai_excess_intensity"], out["economic_ai_intensity"]
    )
    return out


def materialize_stock_scenarios(
    stock_exposures: pd.DataFrame,
    scenario_df: pd.DataFrame,
) -> pd.DataFrame:
    return add_stress_columns(
        stock_exposures,
        scenario_df,
        beta_col="beta_world_stock",
        ai_col="final_ai_excess_intensity",
    )
