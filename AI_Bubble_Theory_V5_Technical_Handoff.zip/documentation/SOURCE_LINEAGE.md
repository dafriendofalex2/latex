# Source lineage and fidelity notes

## Original V5 core

The authoritative original project file is `build_ai_country_industry_stress_v5.py` (July 8, 2026). The project File Library exposes its model-generating sections and confirms the full file, but does not provide a direct byte-copy API into the active sandbox. The bundle therefore includes `code/original_v5/build_ai_country_industry_stress_v5_model_core.py`, a faithful extraction of the model-generating logic: V5 governance constants, scenario construction, beta-adjusted AI-excess intensity, country-industry latent cells, economic blending, coherence projection, row stresses, and original single-stock overrides. Presentation-only code (charts, LaTeX table generation, render checks, packaging) is intentionally excluded from that recovered core.

`code/original_v5/apply_stress_to_client_template_v5.py` is reproduced directly from the original standalone V5 application script found in the File Library.

## Upstream return estimation

Original V5 consumes audited V4 country and industry coefficient tables rather than rerunning raw regressions. `code/research_reference/v5_factor_estimation_reference.py` is an implementation-equivalent research reference for the theory: market beta, raw AI co-movement, AI-factor residualization, residual-beta diagnostic, shrinkage-to-prior operator, and beta-adjusted statistical intensity. It is not represented as a byte-identical copy of the V4 estimator.

## Later V5 extensions

Files under `code/extensions/` are clean, executable implementations of the mechanisms added after the original terminal V5 build: verified peak-anchored short horizons, broader stock overrides, empirical market-cap fragility, five-case conditional severity probabilities, and dot-com path-similarity diagnostics. The report clearly labels these as extensions, not original July 8 V5 mechanics.

## Important version distinction

The later August 2026 canonical refactor experimented with / adopted a 60% statistical / 40% economic final blend. That is not the original V5 specification. The original V5 core in this bundle remains 45% statistical / 55% economic.
