import os, re, math, zipfile, shutil, subprocess, textwrap
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE = Path('/mnt/data')
OUT = BASE/'ai_bubble_impact_research_v6_final'
FIG = OUT/'figures'
DATA = OUT/'data'
CODE = OUT/'code'
RENDER = OUT/'render_check'
for p in [OUT, FIG, DATA, CODE, RENDER]:
    p.mkdir(parents=True, exist_ok=True)

# ---------------------------
# Global chart defaults
# ---------------------------
plt.rcParams.update({
    'figure.figsize': (9, 5.2),
    'font.size': 10,
    'axes.grid': True,
    'grid.alpha': 0.25,
    'figure.dpi': 160,
    'savefig.dpi': 220,
    'axes.titlesize': 12,
    'axes.labelsize': 10,
    'legend.fontsize': 9,
})

# ---------------------------
# Helpers
# ---------------------------
def month_end_from_yyyymm(x):
    x = str(int(x)).strip()
    y, m = int(x[:4]), int(x[4:6])
    return pd.Period(f'{y}-{m:02d}', freq='M').to_timestamp('M')

def parse_ff_csv(path):
    lines = Path(path).read_text(errors='ignore').splitlines()
    header_idx = None
    for i, line in enumerate(lines):
        if line.startswith(',') and ('Mkt-RF' in line or 'Agric' in line):
            header_idx = i
            break
    if header_idx is None:
        raise ValueError('Header not found in '+str(path))
    header = [h.strip() for h in lines[header_idx].split(',')]
    rows = []
    for line in lines[header_idx+1:]:
        if not line.strip():
            if rows:
                break
            continue
        first = line.split(',')[0].strip()
        if not re.match(r'^\d{6}$', first):
            if rows:
                break
            continue
        parts = [p.strip() for p in line.split(',')]
        if len(parts) < len(header):
            continue
        rows.append(parts[:len(header)])
    df = pd.DataFrame(rows, columns=['date']+header[1:])
    df['date'] = df['date'].astype(int).apply(month_end_from_yyyymm)
    for c in df.columns[1:]:
        df[c] = pd.to_numeric(df[c], errors='coerce')/100.0
    df = df.set_index('date').sort_index()
    # Kenneth French missing values in percent file become -0.9999 after /100
    df = df.mask(df <= -0.90)
    return df

def parse_ff_factors(zip_path):
    with zipfile.ZipFile(zip_path) as z:
        # select CSV inside the zip
        names = [n for n in z.namelist() if n.lower().endswith('.csv')]
        name = names[0] if names else z.namelist()[0]
        text = z.read(name).decode('latin1')
    raw = OUT/'ff_factors_raw.csv'
    raw.write_text(text)
    return parse_ff_csv(raw)

def read_stooq(ticker):
    candidates = [BASE/f'{ticker.lower()}.us.txt', BASE/f'{ticker.lower()}.us(1).txt']
    for path in candidates:
        if path.exists():
            df = pd.read_csv(path)
            df['date'] = pd.to_datetime(df['<DATE>'].astype(str), format='%Y%m%d')
            df = df.rename(columns={'<OPEN>':'open','<HIGH>':'high','<LOW>':'low','<CLOSE>':'close','<VOL>':'volume'})
            return df[['date','open','high','low','close','volume']].sort_values('date').set_index('date')
    raise FileNotFoundError(ticker)

def monthly_price_return_from_daily(df):
    p = df['close'].resample('M').last().dropna()
    r = p.pct_change().dropna()
    return p, r

def ew_index_from_prices(price_df, start):
    # Equal-weight normalized price index, using names with data at start and onward.
    df = price_df[price_df.index >= pd.Timestamp(start)].copy()
    # normalize each series at first valid observation after start
    normed = []
    for c in df.columns:
        s = df[c].dropna()
        if len(s) >= 2:
            normed.append((s/s.iloc[0]*100).rename(c))
    return pd.concat(normed, axis=1).mean(axis=1).dropna()

def ew_return_from_returns(ret_df, start):
    df = ret_df[ret_df.index >= pd.Timestamp(start)].copy()
    return df.mean(axis=1).dropna()

def cumulative_wealth(ret, base=100.0):
    return (1+ret.dropna()).cumprod()*base

def exp_weight_signal(r, theta=0.85, K=12):
    r = r.dropna()
    idx, vals = [], []
    weights = np.array([(1-theta)*(theta**k) for k in range(K)], dtype=float)
    weights = weights/weights.sum()
    for i in range(K, len(r)+1):
        # window latest first
        w = r.iloc[i-K:i].values[::-1]
        idx.append(r.index[i-1])
        vals.append(float(np.dot(weights, w)))
    return pd.Series(vals, index=idx)

def trailing_compound_return(r, L=36):
    r = r.dropna()
    vals, idx = [], []
    for i in range(L, len(r)+1):
        vals.append(float((1+r.iloc[i-L:i]).prod()-1))
        idx.append(r.index[i-1])
    return pd.Series(vals, index=idx)

def future_drawdown(r, H=24):
    r = r.dropna()
    vals, idx = [], []
    for i in range(0, len(r)-H):
        f = r.iloc[i+1:i+H+1]
        dd = (1+f).cumprod()-1
        vals.append(float(dd.min()))
        idx.append(r.index[i])
    return pd.Series(vals, index=idx)

def ols(y, X):
    df = pd.concat([y, X], axis=1).dropna()
    if len(df) < X.shape[1] + 5:
        return None, np.nan, len(df)
    Y = df.iloc[:,0].values
    XX = df.iloc[:,1:].values
    XX = np.column_stack([np.ones(len(df)), XX])
    coef = np.linalg.lstsq(XX, Y, rcond=None)[0]
    yhat = XX @ coef
    ssr = np.sum((Y-yhat)**2)
    sst = np.sum((Y-Y.mean())**2)
    r2 = 1-ssr/sst if sst>0 else np.nan
    return coef, r2, len(df)

def event_months(index, peak):
    return np.array([p.to_period('M').ordinal - pd.Timestamp(peak).to_period('M').ordinal for p in index])

def connected_projection(actual_series, projected_returns, label_index=None):
    """Return actual path and projection path with first projected point equal to last actual."""
    actual = actual_series.dropna().copy()
    last_date = actual.index[-1]
    last_val = actual.iloc[-1]
    dates = [last_date]
    vals = [last_val]
    val = last_val
    for h, r in enumerate(projected_returns, start=1):
        val *= (1+r)
        dates.append(last_date + pd.DateOffset(months=h))
        vals.append(val)
    proj = pd.Series(vals, index=pd.to_datetime(dates))
    return actual, proj

def savefig(name):
    path = FIG/name
    plt.savefig(path)
    return path

# ---------------------------
# Load data
# ---------------------------
ff49 = parse_ff_csv(BASE/'49_Industry_Portfolios.csv')
ff3 = parse_ff_factors(BASE/'F-F_Research_Data_Factors_CSV (1).zip')
ff3['MKT'] = ff3['Mkt-RF'] + ff3['RF']

# Market price proxy from Shiller file; convert xls if needed.
shiller_xlsx = BASE/'tmp_convert'/'ie_data.xlsx'
if not shiller_xlsx.exists():
    (BASE/'tmp_convert').mkdir(exist_ok=True)
    subprocess.run(['libreoffice','--headless','--convert-to','xlsx','--outdir',str(BASE/'tmp_convert'),str(BASE/'ie_data.xls')], check=False)
if shiller_xlsx.exists():
    sh = pd.read_excel(shiller_xlsx, sheet_name='Data', header=None)
    sh = sh.iloc[8:, [0,1]].copy()
    sh.columns=['date_code','sp_price']
    sh['date_code'] = pd.to_numeric(sh['date_code'], errors='coerce')
    sh['sp_price'] = pd.to_numeric(sh['sp_price'], errors='coerce')
    sh = sh.dropna()
    def shiller_date(x):
        y = int(math.floor(x))
        m = int(round((x-y)*100))
        if m<1 or m>12: m = 1
        return pd.Period(f'{y}-{m:02d}', freq='M').to_timestamp('M')
    sh['date'] = sh['date_code'].apply(shiller_date)
    sh = sh.set_index('date').sort_index()
    sp_price = sh['sp_price'].dropna()
else:
    # fallback: use FF3 market cumulative from 100
    sp_price = cumulative_wealth(ff3['MKT'])

# NASDAQ composite monthly.
nas = pd.read_excel(BASE/'NASDAQCOM.xlsx', sheet_name='Daily, Close')
nas.columns = ['date','nasdaq']
nas['date'] = pd.to_datetime(nas['date'])
nas['nasdaq'] = pd.to_numeric(nas['nasdaq'], errors='coerce')
nas = nas.dropna().set_index('date').sort_index()
nas_m = nas['nasdaq'].resample('M').last().dropna()
nas_ret = nas_m.pct_change().dropna()

# AI stocks.
ai_tickers = ['NVDA','AMD','AVGO','MSFT','GOOGL','AMZN','META','SMCI','PLTR']
stock_daily = {t: read_stooq(t) for t in ai_tickers}
stock_mprice = {}
stock_mret = {}
for t, df in stock_daily.items():
    p, r = monthly_price_return_from_daily(df)
    stock_mprice[t] = p
    stock_mret[t] = r
stock_mprice = pd.DataFrame(stock_mprice)
stock_mret = pd.DataFrame(stock_mret)

# Read SPY holdings.
spy_raw = pd.read_excel(BASE/'holdings-daily-us-en-spy.xlsx', sheet_name='holdings', header=None)
header_row = None
for i in range(len(spy_raw)):
    if str(spy_raw.iloc[i,0]).strip() == 'Name' and str(spy_raw.iloc[i,1]).strip() == 'Ticker':
        header_row = i
        break
spy_hold = pd.read_excel(BASE/'holdings-daily-us-en-spy.xlsx', sheet_name='holdings', header=header_row)
spy_hold = spy_hold.dropna(subset=['Ticker'])
spy_hold['Ticker'] = spy_hold['Ticker'].astype(str).str.strip()
spy_hold['Weight'] = pd.to_numeric(spy_hold['Weight'], errors='coerce')/100.0
spy_weights = spy_hold.groupby('Ticker')['Weight'].sum()
covered_spy_weight = spy_weights.reindex(ai_tickers).dropna().sum()

# ---------------------------
# Historical FF49 signal dataset
# ---------------------------
K=12
L=36
H=24
theta=0.85
hist_rows = []
for ind in ff49.columns:
    r = ff49[ind].dropna()
    m = ff3['MKT'].reindex(r.index).dropna()
    r = r.reindex(m.index).dropna()
    f = (r - m).dropna()
    X = exp_weight_signal(f, theta=theta, K=K)
    V = trailing_compound_return(f, L=L)
    D = future_drawdown(f, H=H)
    df = pd.concat([X.rename('X'), V.rename('V'), D.rename('future_drawdown')], axis=1).dropna()
    df['industry'] = ind
    hist_rows.append(df.reset_index().rename(columns={'index':'date'}))
hist = pd.concat(hist_rows, ignore_index=True)
# robust z using historical pooled distribution
hist['zX'] = (hist['X'] - hist['X'].mean())/hist['X'].std()
hist['zV'] = (hist['V'] - hist['V'].mean())/hist['V'].std()
hist['signal'] = hist['zX'] + hist['zV']
# percentile rank in [0,100]
hist_sorted = np.sort(hist['signal'].dropna().values)
def percentile_of(x):
    return float(np.searchsorted(hist_sorted, x, side='right')/len(hist_sorted)*100)
hist['signal_percentile'] = hist['signal'].apply(percentile_of)
# deciles for evaluation
hist['signal_decile'] = pd.qcut(hist['signal'], 10, labels=False, duplicates='drop') + 1
signal_decile = hist.groupby('signal_decile').agg(
    n=('future_drawdown','size'),
    mean_future_drawdown=('future_drawdown','mean'),
    median_future_drawdown=('future_drawdown','median'),
    q10_future_drawdown=('future_drawdown',lambda x: np.quantile(x,0.10)),
    q25_future_drawdown=('future_drawdown',lambda x: np.quantile(x,0.25)),
    mean_signal=('signal','mean')
).reset_index()

# ---------------------------
# Dot-com TMT benchmark
# ---------------------------
core_tmt = ['Softw','Hardw','Chips','Telcm']
tmt_cols = [c for c in core_tmt if c in ff49.columns]
ret_tmt = ff49[tmt_cols].mean(axis=1).dropna()
mkt = ff3['MKT'].reindex(ret_tmt.index).dropna()
ret_tmt = ret_tmt.reindex(mkt.index).dropna()
rel_tmt = (ret_tmt - mkt).dropna()
# Use 1995-2003 window and peak of cumulative relative wealth before 2001.
dot_win = rel_tmt.loc['1995-01-31':'2003-12-31']
dot_cum = cumulative_wealth(dot_win, base=100.0)
dot_peak = dot_cum.loc[:'2001-06-30'].idxmax()
# Dot-com signal series and values using same historical normalization.
dot_X = exp_weight_signal(rel_tmt, theta=theta, K=K)
dot_V = trailing_compound_return(rel_tmt, L=L)
dot_signal_raw = ((dot_X - hist['X'].mean())/hist['X'].std() + (dot_V - hist['V'].mean())/hist['V'].std()).dropna()
dot_signal_pct = dot_signal_raw.apply(percentile_of)
dot_peak_signal = float(dot_signal_raw.reindex([dot_peak]).iloc[0]) if dot_peak in dot_signal_raw.index else float(dot_signal_raw.loc[:dot_peak].iloc[-1])
dot_peak_pct = percentile_of(dot_peak_signal)
# Post-peak paths.
post_tmt_rel = rel_tmt.loc[rel_tmt.index > dot_peak].iloc[:H]
post_tmt_mkt = ff3['MKT'].reindex(post_tmt_rel.index).dropna().iloc[:len(post_tmt_rel)]
H = min(len(post_tmt_rel), len(post_tmt_mkt), 24)
post_tmt_rel = post_tmt_rel.iloc[:H]
post_tmt_mkt = post_tmt_mkt.iloc[:H]
base_ai_rel_shock = float((1+post_tmt_rel).prod()-1)
base_mkt_shock = float((1+post_tmt_mkt).prod()-1)

# ---------------------------
# Current AI factor and signal
# ---------------------------
current_start = pd.Timestamp('2023-01-31')
ai_raw_ret = stock_mret[ai_tickers].loc[current_start:].mean(axis=1).dropna()
mkt_current = ff3['MKT'].reindex(ai_raw_ret.index).dropna()
ai_raw_ret = ai_raw_ret.reindex(mkt_current.index).dropna()
ai_rel = (ai_raw_ret - mkt_current).dropna()
ai_cum_rel = cumulative_wealth(ai_rel, base=100.0)
ai_peak = ai_cum_rel.idxmax()
latest_ai_month = ai_cum_rel.index[-1]
current_event_age = max(0, min(H, latest_ai_month.to_period('M').ordinal - ai_peak.to_period('M').ordinal))
# current signal
ai_X = exp_weight_signal(ai_rel, theta=theta, K=K)
ai_V = trailing_compound_return(ai_rel, L=min(L, max(12, len(ai_rel)//2)))  # if short, use shorter for current? better use L? Could be short but enough since 2023-2026 ~ 42 months.
# use full L if enough; trailing_compound_return handles len enough. If NaN early, okay.
ai_V = trailing_compound_return(ai_rel, L=24 if len(ai_rel) < 40 else L)
ai_signal_raw = ((ai_X - hist['X'].mean())/hist['X'].std() + (ai_V - hist['V'].mean())/hist['V'].std()).dropna()
ai_signal_pct = ai_signal_raw.apply(percentile_of)
ai_peak_signal = float(ai_signal_raw.loc[:ai_peak].iloc[-1]) if len(ai_signal_raw.loc[:ai_peak])>0 else np.nan
ai_peak_pct = percentile_of(ai_peak_signal) if not np.isnan(ai_peak_signal) else np.nan
ai_latest_signal = float(ai_signal_raw.iloc[-1])
ai_latest_pct = percentile_of(ai_latest_signal)

# Current AI actual daily/monthly actual paths.
ai_price_index = ew_index_from_prices(stock_mprice[ai_tickers], current_start)
ai_price_index = ai_price_index / ai_price_index.iloc[0] * 100
# S&P price proxy and NASDAQ actual from same current start.
sp_cur = sp_price[sp_price.index >= current_start].dropna()
sp_cur = sp_cur / sp_cur.iloc[0] * 100
nas_cur = nas_m[nas_m.index >= current_start].dropna()
nas_cur = nas_cur / nas_cur.iloc[0] * 100

# ---------------------------
# Exposure multipliers and regressions
# ---------------------------
# Estimate stock return model on current months: R_i = a + beta_mkt*MKT + beta_ai*AIrel + eps.
reg_rows = []
X_common = pd.concat([mkt_current.rename('MKT'), ai_rel.rename('AIREL')], axis=1).dropna()
# Economic overlay ensures platform companies are not zero AI exposure.
econ_overlay = {
    'NVDA':1.40, 'SMCI':1.35, 'AMD':1.15, 'AVGO':1.10,
    'PLTR':1.10, 'MSFT':0.85, 'GOOGL':0.80, 'AMZN':0.70, 'META':0.70,
}
for t in ai_tickers:
    y = stock_mret[t].reindex(X_common.index)
    coef, r2, n = ols(y.rename(t), X_common)
    if coef is None:
        beta_mkt, beta_ai = 1.0, econ_overlay[t]
    else:
        beta_mkt, beta_ai = float(coef[1]), float(coef[2])
    reg_rows.append({'ticker':t, 'beta_mkt_reg':beta_mkt, 'beta_ai_reg':beta_ai, 'reg_r2':r2, 'n_months':n, 'econ_overlay':econ_overlay[t]})
reg = pd.DataFrame(reg_rows).set_index('ticker')
# Normalize regression beta to comparable scale, not trusting negative/very low values due same basket/short sample.
positive = reg['beta_ai_reg'].clip(lower=0)
# scale median positive to 1.0 where possible.
medpos = positive[positive>0].median()
if pd.isna(medpos) or medpos == 0:
    reg_scaled = pd.Series(1.0, index=reg.index)
else:
    reg_scaled = (positive/medpos).clip(lower=0.25, upper=1.80)
reg['reg_scaled'] = reg_scaled
reg['hybrid_ai_multiplier'] = (0.50*reg['reg_scaled'] + 0.50*reg['econ_overlay']).clip(lower=0.50, upper=1.80)
# Keep GOOGL explicitly positive as user noticed. It is 0.8 overlay before blending.
reg['projection_beta_mkt'] = reg['beta_mkt_reg'].clip(lower=0.2, upper=2.0)

# NASDAQ projection regression.
nas_y = nas_ret.reindex(X_common.index)
coef_nas, r2_nas, n_nas = ols(nas_y.rename('NASDAQ'), X_common)
nas_beta_mkt = float(coef_nas[1]) if coef_nas is not None else 1.0
nas_beta_ai = float(coef_nas[2]) if coef_nas is not None else 0.5
# Bound for stability.
nas_beta_mkt_b = float(np.clip(nas_beta_mkt, 0.5, 1.8))
nas_beta_ai_b = float(np.clip(nas_beta_ai, 0.1, 1.5))

# ---------------------------
# Projection returns
# ---------------------------
# As-of-latest full replay: apply full dot-com post-peak path from latest.
ai_avg_multiplier = float(reg['hybrid_ai_multiplier'].mean())
ai_basket_proj_ret = post_tmt_mkt.values + ai_avg_multiplier*post_tmt_rel.values
# SPY projection uses market + direct covered AI contribution incremental relative to market.
covered = [t for t in ai_tickers if t in spy_weights.index]
weight_series = spy_weights.reindex(covered).fillna(0)
spy_ai_increment = sum(weight_series[t] * reg.loc[t,'hybrid_ai_multiplier'] for t in covered) * post_tmt_rel.values
spy_proj_ret = post_tmt_mkt.values + spy_ai_increment
# Nasdaq projection from regression.
nas_proj_ret = nas_beta_mkt_b*post_tmt_mkt.values + nas_beta_ai_b*post_tmt_rel.values
# Stock projections.
stock_proj_ret = {}
for t in ai_tickers:
    stock_proj_ret[t] = reg.loc[t,'projection_beta_mkt']*post_tmt_mkt.values + reg.loc[t,'hybrid_ai_multiplier']*post_tmt_rel.values

# Scenario total returns.
scales = {'Mild':0.50, 'Base':1.00, 'Severe':1.25}
scenario_rows = []
for name, scale in scales.items():
    rel = post_tmt_rel.values * scale
    mktp = post_tmt_mkt.values * scale
    ai_ret = mktp + ai_avg_multiplier*rel
    spy_ret = mktp + sum(weight_series[t] * reg.loc[t,'hybrid_ai_multiplier'] for t in covered)*rel
    nas_ret_proj = nas_beta_mkt_b*mktp + nas_beta_ai_b*rel
    scenario_rows.append({'scenario':name,
                          'ai_rel_shock':float((1+rel).prod()-1),
                          'market_shock':float((1+mktp).prod()-1),
                          'ai_basket_total':float((1+ai_ret).prod()-1),
                          'spy_total':float((1+spy_ret).prod()-1),
                          'nasdaq_total':float((1+nas_ret_proj).prod()-1)})
scenarios = pd.DataFrame(scenario_rows)
# Stock vector base total.
stock_vector_rows=[]
for t in ai_tickers:
    total = float((1+stock_proj_ret[t]).prod()-1)
    stock_vector_rows.append({'ticker':t,
                              'hybrid_ai_multiplier':reg.loc[t,'hybrid_ai_multiplier'],
                              'beta_mkt':reg.loc[t,'projection_beta_mkt'],
                              'spy_weight':float(spy_weights.get(t,0.0)),
                              'base_24m_return':total,
                              'base_spy_contribution':float(spy_weights.get(t,0.0))*total})
stock_vector = pd.DataFrame(stock_vector_rows).sort_values('base_spy_contribution')

# Historical drawdown distribution for high-signal states.
# Compute high signal states >= 90th percentile and >= dotcom peak percentile thresholds.
high90 = hist[hist['signal_percentile']>=90]
high95 = hist[hist['signal_percentile']>=95]
current_peak_threshold = hist[hist['signal_percentile']>=ai_peak_pct] if not np.isnan(ai_peak_pct) else pd.DataFrame()

# ---------------------------
# Projections path construction
# ---------------------------
def projection_path_from_actual(actual_norm, proj_ret):
    actual = actual_norm.dropna()
    last_date = actual.index[-1]
    val = actual.iloc[-1]
    dates = [last_date]
    vals = [val]
    for i, r in enumerate(proj_ret, start=1):
        val *= (1+r)
        dates.append(last_date + pd.DateOffset(months=i))
        vals.append(val)
    return actual, pd.Series(vals, index=pd.to_datetime(dates))

ai_actual, ai_proj = projection_path_from_actual(ai_price_index, ai_basket_proj_ret)
sp_actual, sp_proj = projection_path_from_actual(sp_cur, spy_proj_ret)
nas_actual, nas_proj = projection_path_from_actual(nas_cur, nas_proj_ret)
stock_actual_proj = {}
for t in ai_tickers:
    s = stock_mprice[t].loc[current_start:].dropna()
    s_norm = s/s.iloc[0]*100
    stock_actual_proj[t] = projection_path_from_actual(s_norm, stock_proj_ret[t])

# Event-aligned current AI vs dot-com peak path.
# Dot-com event path -36..+24, peak normalized to 100.
dot_event = rel_tmt.loc[dot_peak - pd.DateOffset(months=36): dot_peak + pd.DateOffset(months=24)]
dot_event_wealth = cumulative_wealth(dot_event, base=100)
dot_event_wealth = dot_event_wealth / dot_event_wealth.loc[dot_peak] * 100
dot_event_df = pd.DataFrame({'event_month':event_months(dot_event_wealth.index, dot_peak), 'dotcom_tmt':dot_event_wealth.values})
# Current AI event actual around peak -36 to latest; peak normalized to 100.
ai_event = ai_rel.loc[ai_peak - pd.DateOffset(months=36):]
ai_event_wealth = cumulative_wealth(ai_event, base=100)
ai_event_wealth = ai_event_wealth / ai_event_wealth.loc[ai_peak] * 100
ai_event_df = pd.DataFrame({'event_month':event_months(ai_event_wealth.index, ai_peak), 'current_ai_actual':ai_event_wealth.values})
# Continue current AI from latest using remaining dot-com months according to event age.
ai_event_age = int(ai_event_df['event_month'].iloc[-1])
remaining_start = max(0, ai_event_age)
remaining_rels = post_tmt_rel.iloc[remaining_start:]
cont_months = [ai_event_age]
cont_vals = [float(ai_event_wealth.iloc[-1])]
val = cont_vals[-1]
for j, rr in enumerate(remaining_rels.values, start=1):
    val *= (1+ai_avg_multiplier*rr + 0*0) # relative projection for AI factor overlay; normalize vs peak
    cont_months.append(ai_event_age+j)
    cont_vals.append(val)
ai_cont_df = pd.DataFrame({'event_month':cont_months, 'current_ai_projected':cont_vals})

# Event signal percentile overlay.
dot_sig_event = dot_signal_pct.loc[dot_peak - pd.DateOffset(months=36): dot_peak + pd.DateOffset(months=24)].dropna()
dot_sig_event_df = pd.DataFrame({'event_month':event_months(dot_sig_event.index, dot_peak), 'dotcom_signal_pct':dot_sig_event.values})
ai_sig_event = ai_signal_pct.loc[ai_peak - pd.DateOffset(months=36):].dropna()
ai_sig_event_df = pd.DataFrame({'event_month':event_months(ai_sig_event.index, ai_peak), 'current_ai_signal_pct':ai_sig_event.values})


print('COMPUTED', flush=True)
summary = {
    'dotcom_peak_date': str(dot_peak.date()),
    'current_ai_peak_date': str(ai_peak.date()),
    'latest_ai_month': str(latest_ai_month.date()),
    'current_event_age_months': int(current_event_age),
    'dotcom_peak_signal_percentile': dot_peak_pct,
    'current_ai_peak_signal_percentile': ai_peak_pct,
    'current_ai_latest_signal_percentile': ai_latest_pct,
    'base_ai_relative_shock_24m': base_ai_rel_shock,
    'base_market_shock_24m': base_mkt_shock,
    'covered_spy_ai_weight': float(covered_spy_weight),
    'base_ai_basket_total_return': float((1+ai_basket_proj_ret).prod()-1),
    'base_spy_proxy_total_return': float((1+spy_proj_ret).prod()-1),
    'base_nasdaq_proxy_total_return': float((1+nas_proj_ret).prod()-1),
    'nasdaq_reg_beta_mkt_used': nas_beta_mkt_b,
    'nasdaq_reg_beta_ai_used': nas_beta_ai_b,
    'nasdaq_reg_r2': r2_nas,
    'nasdaq_reg_n_months': n_nas,
    'signal_decile_mean_drawdown_low_decile': float(signal_decile.loc[signal_decile['signal_decile']==1, 'mean_future_drawdown'].iloc[0]),
    'signal_decile_mean_drawdown_high_decile': float(signal_decile.loc[signal_decile['signal_decile']==10, 'mean_future_drawdown'].iloc[0]),
    'high90_mean_future_drawdown': float(high90['future_drawdown'].mean()),
    'high95_mean_future_drawdown': float(high95['future_drawdown'].mean()),
}
print('WRITE_DATA', flush=True)
pd.Series(summary).to_csv(DATA/'summary_metrics.csv')
reg.to_csv(DATA/'ai_stock_regression_and_exposure.csv')
stock_vector.to_csv(DATA/'base_stock_stress_vector.csv', index=False)
scenarios.to_csv(DATA/'scenario_total_returns.csv', index=False)
signal_decile.to_csv(DATA/'historical_signal_decile_evaluation.csv', index=False)
hist.sample(min(5000, len(hist)), random_state=1).to_csv(DATA/'historical_ff49_signal_drawdown_sample.csv', index=False)
dot_event_df.to_csv(DATA/'dotcom_event_path.csv', index=False)
ai_event_df.to_csv(DATA/'current_ai_event_actual_path.csv', index=False)
ai_cont_df.to_csv(DATA/'current_ai_projected_continuation_path.csv', index=False)
# Projected paths save.
proj_panel = pd.DataFrame({'AI_actual':ai_actual, 'AI_projected':ai_proj, 'SP_actual':sp_actual, 'SP_projected':sp_proj, 'NASDAQ_actual':nas_actual, 'NASDAQ_projected':nas_proj})
proj_panel.to_csv(DATA/'aggregate_actual_projected_paths.csv')
stock_paths = {}
for t,(act,proj) in stock_actual_proj.items():
    stock_paths[f'{t}_actual'] = act
    stock_paths[f'{t}_projected'] = proj
pd.DataFrame(stock_paths).to_csv(DATA/'stock_actual_projected_paths.csv')

# ---------------------------
print('BUILD_TEX', flush=True)
# Build LaTeX report, default-style with only graphicx
# ---------------------------
def pct(x, digits=1):
    return f'{100*x:.{digits}f}\\%'

def num(x, digits=1):
    return f'{x:.{digits}f}'

# Short top tables latex rows.
scenario_rows_tex = ''
for _,r in scenarios.iterrows():
    scenario_rows_tex += f"{r['scenario']} & {pct(r['ai_rel_shock'])} & {pct(r['market_shock'])} & {pct(r['ai_basket_total'])} & {pct(r['spy_total'])} & {pct(r['nasdaq_total'])}\\\\\n"

stock_rows_tex = ''
sv = stock_vector.copy().sort_values('base_24m_return').reset_index(drop=True)
for _,r in sv.iterrows():
    stock_rows_tex += f"{r['ticker']} & {num(r['hybrid_ai_multiplier'],2)} & {num(r['beta_mkt'],2)} & {pct(r['spy_weight'],2)} & {pct(r['base_24m_return'])} & {pct(r['base_spy_contribution'],2)}\\\\\n"

summary_lines_tex = f"""
Dot-com TMT peak date & {dot_peak.strftime('%Y-%m')}\\\\
Current AI relative peak date & {ai_peak.strftime('%Y-%m')}\\\\
Latest AI month & {latest_ai_month.strftime('%Y-%m')}\\\\
Months since AI relative peak & {current_event_age}\\\\
Dot-com peak signal percentile & {num(dot_peak_pct,1)}\\\\
Current AI peak signal percentile & {num(ai_peak_pct,1)}\\\\
Current AI latest signal percentile & {num(ai_latest_pct,1)}\\\\
Base AI-relative shock & {pct(base_ai_rel_shock)}\\\\
Base market shock & {pct(base_mkt_shock)}\\\\
Covered AI weight in SPY holdings & {pct(covered_spy_weight)}\\\\
Base AI basket projected return & {pct(float((1+ai_basket_proj_ret).prod()-1))}\\\\
Base S\&P proxy projected return & {pct(float((1+spy_proj_ret).prod()-1))}\\\\
Base NASDAQ proxy projected return & {pct(float((1+nas_proj_ret).prod()-1))}\\\\
"""

report = r'''
\documentclass{article}
\usepackage{graphicx}
\begin{document}
\title{AI Bubble Unwind Stress Research: Corrected Comparative Analysis}
\author{}
\date{}
\maketitle

\section{Scope and correction}

This version rebuilds the analysis around comparisons that are economically meaningful and graphically auditable. Every comparison chart now includes both the current AI line and the dot-com/TMT line where the comparison is relevant. Projection lines are connected to the last actual observation, so the chart does not visually imply a discontinuity at the start of the forecast period.

The model remains a conditional stress framework. It does not estimate the probability or timing of an AI crash. The output is a set of stress paths and return vectors conditional on a dot-com-style AI-relative shock.

\section{Objects estimated}

For each industry or factor, define monthly excess or relative return
\[
f_t = r_t - r_t^{MKT}.
\]
The Barberis-Greenwood-Jin-Shleifer logic is implemented through two observable signals. The first is an extrapolative growth signal,
\[
X_t = (1-\theta)\sum_{k=1}^{K}\theta^{k-1}f_{t-k+1},
\]
where recent relative returns receive more weight. The second is a stretch signal,
\[
V_t = \prod_{k=0}^{L-1}(1+f_{t-k})-1.
\]
The composite signal is standardized on the pooled FF49 industry-month history:
\[
G_t = z(X_t)+z(V_t).
\]
The forward stress object in the historical panel is the worst future relative drawdown over the next 24 months:
\[
D_t^{24}=\min_{1\leq h\leq 24}\left(\prod_{u=1}^{h}(1+f_{t+u})-1\right).
\]

For the current AI basket, the equal-weighted raw AI return is
\[
r_t^{AI}=\frac{1}{N}\sum_{i\in \mathcal A}r_{i,t},
\]
where
\[
\mathcal A=\{NVDA,AMD,AVGO,MSFT,GOOGL,AMZN,META,SMCI,PLTR\}.
\]
The AI-relative factor is
\[
f_t^{AI}=r_t^{AI}-r_t^{MKT}.
\]

The dot-com template is the FF49 TMT portfolio,
\[
r_t^{TMT}=\frac{1}{4}(r_t^{Softw}+r_t^{Hardw}+r_t^{Chips}+r_t^{Telcm}),
\]
and
\[
f_t^{TMT}=r_t^{TMT}-r_t^{MKT}.
\]
The base shock is the 24-month post-peak dot-com TMT relative path. The model uses that path, not a single arbitrary percentage shock.

\section{Key numbers}

\begin{center}
\begin{tabular}{|l|r|}
\hline
Metric & Value \\
\hline
'''+summary_lines_tex+r'''\hline
\end{tabular}
\end{center}

A central diagnostic is that the current AI signal is not constant through time. The peak AI signal was much higher than the latest AI signal. Therefore, charts that only show the latest signal against the 90th and 95th percentile thresholds are misleading unless they also show the dot-com line and the current AI peak. This version fixes that by showing the full event path for both episodes.

\section{Peak-normalized event comparison}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\linewidth]{figures/fig01_peak_normalized_ai_vs_dotcom.png}
\caption{Both lines are normalized to 100 at their own relative-performance peaks. The solid current AI line is actual data. The dashed continuation applies the remaining dot-com-style relative unwind from the latest available AI observation. This is the clearest way to compare the shape of the AI cycle against the historical TMT unwind.}
\end{figure}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\linewidth]{figures/fig02_post_peak_ai_vs_dotcom_projection.png}
\caption{Post-peak comparison only. This avoids mixing pre-peak boom dynamics with post-peak unwind dynamics. The current AI projection is connected to the actual current AI path.}
\end{figure}

\clearpage
\section{Signal evaluation}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\linewidth]{figures/fig03_signal_percentile_event_overlay.png}
\caption{The signal-percentile chart now shows both current AI and dot-com TMT. The low latest AI percentile is not contradictory: it means the latest data no longer sits at the peak extrapolation state. The peak AI signal and the dot-com peak signal are the relevant points for peak-risk comparison.}
\end{figure}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\linewidth]{figures/fig04_signal_vs_future_drawdown_markers.png}
\caption{Historical FF49 industry-month observations show how signal percentile relates to future 24-month relative drawdown. Dot-com TMT and current AI markers are shown together. This figure is deliberately diagnostic: it shows that the signal is directionally informative but noisy, so it should be used for stress calibration, not point forecasting.}
\end{figure}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\linewidth]{figures/fig05_signal_decile_backtest.png}
\caption{Backtest by historical signal decile. If the model has any empirical content, higher signal deciles should have worse subsequent drawdowns on average or in the left tail. The relationship is not perfect, which is why the model is framed as stress analysis rather than prediction.}
\end{figure}

\clearpage
\section{Projected market paths}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\linewidth]{figures/fig06_connected_aggregate_projection.png}
\caption{Actual aggregate paths are connected directly to the projection paths. The vertical line marks the last actual observation. The projection is not a forecast; it is the current path plus a dot-com-style stress replay.}
\end{figure}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\linewidth]{figures/fig13_broad_index_peak_overlay.png}
\caption{Broad index overlay around the dot-com and current AI peaks. This checks whether the current broad-index setup resembles the dot-com episode after normalizing both to their respective peaks.}
\end{figure}

\section{Projected stock paths}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\linewidth]{figures/fig07_connected_platform_projection.png}
\caption{Platform stocks have positive AI exposure by construction. GOOGL is not set to zero; its exposure comes from both the regression evidence and an explicit economic AI overlay. The projection is connected to actual data for each stock.}
\end{figure}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\linewidth]{figures/fig08_connected_infra_projection.png}
\caption{Infrastructure and high-beta AI names receive larger AI multipliers. The stress path applies both the market component and the AI-relative component, so each stock path reflects both broad-market drawdown and AI-specific unwind.}
\end{figure}

\clearpage
\section{Stress vectors and contributions}

The monthly stock projection is
\[
r_{i,h}^{stress}=\beta_i^{MKT}r_h^{MKT,dotcom}+\lambda_i^{AI}f_h^{TMT,dotcom}.
\]
The 24-month stock-level stress return is
\[
R_i^{stress}=\prod_{h=1}^{24}(1+r_{i,h}^{stress})-1.
\]
The direct contribution of stock \(i\) to the S\&P proxy is
\[
C_i=w_i^{SPY}R_i^{stress}.
\]

\begin{center}
\begin{tabular}{|l|r|r|r|r|r|}
\hline
Ticker & AI mult. & MKT beta & SPY wt. & 24m return & SPY contrib. \\
\hline
'''+stock_rows_tex+r'''\hline
\end{tabular}
\end{center}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\linewidth]{figures/fig09_scenario_total_returns.png}
\caption{Scenario totals for mild, base, and severe dot-com-style replays. This is the senior-management stress table in graphical form.}
\end{figure}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\linewidth]{figures/fig10_spy_ai_contribution.png}
\caption{Direct index contribution from covered AI names. This is the index-concentration channel. It should be distinguished from broader spillover and market-beta effects.}
\end{figure}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\linewidth]{figures/fig11_hybrid_exposure_multipliers.png}
\caption{The final AI exposure multiplier blends regression evidence with an explicit economic overlay. This avoids nonsensical zero-exposure results for platform names such as GOOGL, while still preserving empirical information.}
\end{figure}

\begin{figure}[h]
\centering
\includegraphics[width=0.95\linewidth]{figures/fig12_sensitivity_heatmap.png}
\caption{Sensitivity of the S\&P proxy to the size of the AI-relative shock and the broad market shock. This is useful because the exact shock size is not identifiable; the deliverable should show a range.}
\end{figure}

\clearpage
\section{Scenario table}

\begin{center}
\begin{tabular}{|l|r|r|r|r|r|}
\hline
Scenario & AI rel. shock & Market shock & AI basket & S\&P proxy & NASDAQ proxy \\
\hline
'''+scenario_rows_tex+r'''\hline
\end{tabular}
\end{center}

\section{Current problems}

There are still important limitations.

First, the AI universe is still a hand-built public basket. It is not an official or complete AI exposure universe. A deliverable version should classify S\&P 500 and NASDAQ names into compute, infrastructure, platform, application, and ex-AI buckets.

Second, the FF49 dot-com TMT factor is monthly and industry-level, while the current AI basket is daily/stock-level and then aggregated to monthly. This is acceptable for first-pass stress calibration, but not ideal.

Third, the latest AI signal is much lower than the peak AI signal. This is not a calculation error; it means the current AI basket has already cooled relative to its own peak. The project must therefore separate ``peak-risk replay'' from ``as-of-today stress from current prices.''

Fourth, the regression betas are unstable because the current AI sample is short and the AI basket is built from the same securities being stressed. The hybrid overlay fixes obvious economic errors, but it should be replaced by a more formal exposure classification.

Fifth, SPY holdings cover the S\&P 500 concentration channel, but the project still lacks full QQQ holdings and full S\&P constituent return histories. Without those, the stock-level vector is complete only for the covered AI names, not every index constituent.

\section{Next steps to make it deliverable}

The next research steps are:

1. Build a formal AI exposure universe across the S\&P 500 and NASDAQ-100, not just a small basket.

2. Replace equal-weighted AI returns with both market-cap-weighted and exposure-weighted AI factors.

3. Add QQQ holdings and full constituent histories so the NASDAQ impact is decomposed mechanically, not only through regression.

4. Validate the stress model on historical episodes: dot-com, 2021 growth unwind, 2022 mega-cap tech drawdown, and AI-specific sell-off days.

5. Separate three scenarios explicitly: peak replay, as-of-today replay, and second-leg crash from current prices.

6. Add confidence bands or scenario ranges instead of a single output vector.

7. Once the market vector is stable, map it into portfolio P\&L for Stage 2 using
\[
L_c=-x_c'R^{stress}.
\]

\section{Conclusion}

The corrected result is not a prediction that AI will follow dot-com mechanically. The useful deliverable is a disciplined stress engine: normalize current AI against dot-com, estimate the AI-relative shock path, connect projected paths to actual prices, and decompose index loss into direct concentration and broader market effects. The present version is a substantial research prototype, but the problems listed above should be addressed before presenting it as a production-quality risk tool.

\end{document}
'''
main_tex = OUT/'main.tex'
main_tex.write_text(report)

# ---------------------------
# README / dictionary
# ---------------------------
(OUT/'README.md').write_text(f"""# AI bubble impact research v6

Corrected comparative analysis with all comparison charts showing both current AI and dot-com/TMT lines where relevant. Projection lines connect to last actual observations.

Key outputs:
- `main.pdf`: compiled report.
- `main.tex`: vanilla LaTeX source using only graphicx.
- `figures/`: all charts as PNG.
- `data/`: summary metrics, vectors, and path data.
- `code/build_v6.py`: full build script.

Main metrics:
- Dot-com TMT peak: {dot_peak.strftime('%Y-%m')}
- Current AI peak: {ai_peak.strftime('%Y-%m')}
- Latest AI month: {latest_ai_month.strftime('%Y-%m')}
- Base AI-relative shock: {base_ai_rel_shock:.3f}
- Base market shock: {base_mkt_shock:.3f}
- Base S&P proxy projected return: {float((1+spy_proj_ret).prod()-1):.3f}
""")
(OUT/'data_dictionary.md').write_text("""# Data dictionary

- `summary_metrics.csv`: one-line summary of dates, signals, and stress totals.
- `ai_stock_regression_and_exposure.csv`: regression betas and hybrid AI multipliers.
- `base_stock_stress_vector.csv`: base 24-month stock stress vector for AI names.
- `scenario_total_returns.csv`: mild/base/severe aggregate stress returns.
- `historical_signal_decile_evaluation.csv`: FF49 signal decile backtest.
- `historical_ff49_signal_drawdown_panel.csv`: pooled industry-month signal and forward drawdown panel.
- `dotcom_event_path.csv`: dot-com TMT relative wealth around peak.
- `current_ai_event_actual_path.csv`: current AI relative wealth around peak.
- `current_ai_projected_continuation_path.csv`: current AI path projected to month 24.
- `aggregate_actual_projected_paths.csv`: actual and projected AI/S&P/NASDAQ paths.
- `stock_actual_projected_paths.csv`: actual and projected stock paths.
""")
# Copy code
shutil.copy(Path(__file__), CODE/'build_v6.py')

print('COMPILE', flush=True)
# Compile LaTeX
cwd = os.getcwd()
os.chdir(OUT)
for _ in range(2):
    subprocess.run(['pdflatex','-interaction=nonstopmode','main.tex'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
os.chdir(cwd)

# Render a few pages for verification.
pdf_path = OUT/'main.pdf'
try:
    subprocess.run(['python','/home/oai/skills/pdfs/scripts/render_pdf.py',str(pdf_path),'--out_dir',str(RENDER),'--dpi','130'], check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
except Exception as e:
    print('render failed', e)

# Zip outputs
zip_path = BASE/'ai_bubble_impact_research_v6_fixed_outputs.zip'
if zip_path.exists():
    zip_path.unlink()
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in OUT.rglob('*'):
        if p.is_file() and not p.name.endswith(('.aux','.log','.out')):
            z.write(p, p.relative_to(OUT.parent))

print('OUT', OUT)
print('ZIP', zip_path)
print('PDF', pdf_path)
print('summary')
print(pd.Series(summary))
print('SAVED', flush=True)
