import os, re, glob, math, json, shutil, zipfile, subprocess, textwrap
from pathlib import Path
from xml.etree import ElementTree as ET
from datetime import datetime
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path('/mnt/data')
V3 = ROOT/'ai_country_industry_stress_research_v3'
OUT = ROOT/'ai_country_industry_stress_research_v4'
FIG = OUT/'figures'
DATA = OUT/'data'
CODE = OUT/'code'
RAW = OUT/'raw_inputs'
for p in [OUT]:
    if p.exists(): shutil.rmtree(p)
for d in [OUT, FIG, DATA, CODE, RAW]: d.mkdir(parents=True, exist_ok=True)

# ---------- small helpers ----------
def safe_tex(s):
    s=str(s)
    repl={'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}
    for a,b in repl.items(): s=s.replace(a,b)
    return s

def pct(x): return 100*(math.exp(x)-1)

def format_pct(x):
    return '' if pd.isna(x) else f'{x:.1f}\\%'

def norm(s): return re.sub(r'[^a-z0-9]+',' ',str(s).lower()).strip()

def is_financial(ind):
    n=norm(ind)
    return any(x in n for x in ['bank','insurance','financial','reit','real estate','thrift','broker','capital markets','investment'])

def is_ai_tmt(ind):
    n=norm(ind)
    keys=['internet','software','computer','peripheral','semiconductor','telecom equipment','telecom equip','information services','computer services']
    bad=['telecom services','foreign telecom']
    return any(k in n for k in keys) and not any(b in n for b in bad)

def to_num(x):
    if x is None: return np.nan
    if isinstance(x, str):
        s=x.strip()
        if s.upper() in ['NA','N/A','NM','N.M.','']:
            return np.nan
        s=s.replace('%','').replace(',','')
    else:
        s=x
    try: return float(s)
    except Exception: return np.nan

# ---------- xlsx parser for converted Damodaran workbooks ----------
def col_to_num(col):
    n=0
    for c in col:
        n=n*26+ord(c)-64
    return n-1

def read_xlsx_sheet(path, sheet_name=None):
    z=zipfile.ZipFile(path)
    ns={'a':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
    ss=[]
    if 'xl/sharedStrings.xml' in z.namelist():
        root=ET.fromstring(z.read('xl/sharedStrings.xml'))
        for si in root.findall('a:si',ns):
            ss.append(''.join((t.text or '') for t in si.iter('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t')))
    wb=ET.fromstring(z.read('xl/workbook.xml'))
    sheets=[]
    for s in wb.find('a:sheets',ns):
        sheets.append((s.attrib['name'],s.attrib['{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id']))
    rels=ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
    rid_to_target={r.attrib['Id']:r.attrib['Target'] for r in rels}
    if sheet_name is None: sheet_name=sheets[0][0]
    rid=[rid for name,rid in sheets if name==sheet_name][0]
    target=rid_to_target[rid]
    if not target.startswith('worksheets/'):
        target='worksheets/'+target.split('/')[-1]
    root=ET.fromstring(z.read('xl/'+target))
    cells={}; maxr=0; maxc=0
    for c in root.iter('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c'):
        ref=c.attrib.get('r','')
        m=re.match(r'([A-Z]+)(\d+)',ref)
        if not m: continue
        col=col_to_num(m.group(1)); row=int(m.group(2))-1
        typ=c.attrib.get('t')
        v=c.find('a:v',ns)
        val=None
        if v is not None and v.text is not None:
            txt=v.text
            if typ=='s':
                val=ss[int(txt)] if int(txt)<len(ss) else txt
            elif typ=='b':
                val=bool(int(txt))
            else:
                try: val=float(txt) if any(ch in txt for ch in '.eE') else int(txt)
                except Exception: val=txt
        else:
            isel=c.find('a:is',ns)
            if isel is not None:
                val=''.join((t.text or '') for t in isel.iter('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t'))
        cells[(row,col)]=val; maxr=max(maxr,row+1); maxc=max(maxc,col+1)
    return [[cells.get((r,c)) for c in range(maxc)] for r in range(maxr)]

def xlsx_to_table(path, sheet):
    rows=read_xlsx_sheet(path, sheet)
    start=None
    for i,r in enumerate(rows):
        if len(r)>0 and str(r[0]).strip()=='Industry Name':
            start=i; break
    if start is None:
        raise ValueError(f'Industry table not found in {path} {sheet}')
    headers=[str(x).strip() if x is not None else '' for x in rows[start]]
    out=[]
    for r in rows[start+1:]:
        if not r or r[0] is None: continue
        rec={headers[j]: (r[j] if j<len(r) else None) for j in range(len(headers))}
        out.append(rec)
    return pd.DataFrame(out)

def ensure_xlsx_inputs():
    # Keep converted workbooks inside v4 for auditability. Convert only if the user-supplied XLS files are present.
    srcs=['pedata98.xls','pedata99.xls','pedata00.xls','pedata01.xls','pedata02.xls','pedata03.xls','pedata24.xls','peGlobal24.xls','peEurope24.xls','peemerg24.xls','histgr04.xls']
    xdir=RAW/'damodaran_converted_xlsx'
    xdir.mkdir(exist_ok=True, parents=True)
    for s in srcs:
        p=ROOT/s
        if p.exists():
            shutil.copy2(p, RAW/s)
    # Use existing xlsx conversion if already available; otherwise convert with LibreOffice.
    existing=Path('/mnt/data/xls_xlsx')
    if existing.exists() and (existing/'pedata24.xlsx').exists():
        for p in existing.glob('*.xlsx'):
            shutil.copy2(p, xdir/p.name)
    else:
        cmd=['libreoffice','--headless','--convert-to','xlsx','--outdir',str(xdir)] + [str(ROOT/s) for s in srcs if (ROOT/s).exists()]
        subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return xdir

XDIR=ensure_xlsx_inputs()

# ---------- valuation calibration ----------
def table_for_year(year, region='US'):
    if year==2024:
        if region=='US': return xlsx_to_table(XDIR/'pedata24.xlsx','Industry Averages')
        if region=='Global': return xlsx_to_table(XDIR/'peGlobal24.xlsx','Industry Averages')
        if region=='Europe': return xlsx_to_table(XDIR/'peEurope24.xlsx','Industry Averages')
        if region=='Emerging': return xlsx_to_table(XDIR/'peemerg24.xlsx','Industry Averages')
    else:
        return xlsx_to_table(XDIR/f'pedata{str(year)[-2:]}.xlsx','Sheet1')
    raise ValueError((year,region))

def column_present(df, options, min_non_na=10):
    for c in options:
        if c in df.columns and df[c].apply(to_num).notna().sum() >= min_non_na:
            return c
    return None

def firms_col(df):
    return 'Number of firms' if 'Number of firms' in df.columns else 'Number of Firms'

def valuation_snapshot(year, region='US'):
    df=table_for_year(year, region=region).copy()
    pe_cols=[]
    for label, opts in [('current_pe',['Current PE','Price/Current EPS']),('trailing_pe',['Trailing PE','Price/Trailing EPS']),('forward_pe',['Forward PE','Price/Forward PE'])]:
        c=column_present(df, opts, min_non_na=10)
        if c is not None:
            df[label]=df[c].apply(to_num); pe_cols.append(label)
        else:
            df[label]=np.nan
    gc=column_present(df, ['Expected growth - next 5 years','Expected Growth','EPS Growth','EPS growth'], min_non_na=10)
    df['expected_growth']=df[gc].apply(to_num) if gc else np.nan
    fc=firms_col(df)
    df['n_firms']=df[fc].apply(to_num) if fc in df.columns else 1.0
    df['is_financial']=df['Industry Name'].apply(is_financial)
    df['is_ai_tmt']=df['Industry Name'].apply(is_ai_tmt)
    df['year']=year; df['region']=region
    return df

def premium_for_metric(df, metric):
    work=df[(df[metric].notna()) & (df[metric] > 0) & (df[metric] < 1000)].copy()
    ai=work[work['is_ai_tmt']]
    if len(ai)==0: return np.nan, np.nan, np.nan, []
    w=ai['n_firms'].fillna(1).clip(lower=1)
    ai_level=float(np.exp(np.average(np.log(ai[metric].astype(float)), weights=w)))
    mkt_rows=work[work['Industry Name'].astype(str).str.contains('Total Market', case=False, na=False)]
    if len(mkt_rows)>0:
        # Use Total Market if available because Damodaran provides it in the 2024 files.
        mkt_level=float(mkt_rows[metric].iloc[0])
    else:
        mkt_level=float(np.exp(np.median(np.log(work.loc[~work['is_financial'],metric].astype(float)))))
    premium_log=math.log(ai_level/mkt_level)
    return premium_log, ai_level, mkt_level, ai['Industry Name'].tolist()

valuation_rows=[]
for year in [1998,1999,2000,2001,2002,2003]:
    df=valuation_snapshot(year,'US')
    for metric in ['current_pe','trailing_pe','forward_pe']:
        if df[metric].notna().sum()>10:
            prem, ai_level, mkt_level, names=premium_for_metric(df, metric)
            if pd.notna(prem):
                valuation_rows.append({'year':year,'region':'US','metric':metric,'ai_level':ai_level,'market_level':mkt_level,'premium_log':prem,'premium_ratio':math.exp(prem),'industries_used':'; '.join(names)})
for region in ['US','Global','Europe','Emerging']:
    df=valuation_snapshot(2024,region)
    for metric in ['current_pe','trailing_pe','forward_pe']:
        if df[metric].notna().sum()>10:
            prem, ai_level, mkt_level, names=premium_for_metric(df, metric)
            if pd.notna(prem):
                valuation_rows.append({'year':2024,'region':region,'metric':metric,'ai_level':ai_level,'market_level':mkt_level,'premium_log':prem,'premium_ratio':math.exp(prem),'industries_used':'; '.join(names)})
valuation_premiums=pd.DataFrame(valuation_rows)
valuation_premiums.to_csv(DATA/'valuation_premium_calibration_inputs.csv', index=False)

# Dot-com benchmark: use Jan 1999 and Jan 2000 current-PE premium to reflect the pre-crash peak without relying on post-crash accounting noise.
dot_ref=valuation_premiums[(valuation_premiums.region=='US') & (valuation_premiums.year.isin([1999,2000])) & (valuation_premiums.metric=='current_pe')]
dotcom_premium_log=float(dot_ref['premium_log'].mean())
# Current US blended premium: 50% forward, 25% current, 25% trailing. Forward is weighted highest because stress should not ignore expected earnings, but current/trailing prevent excessive reliance on optimistic forecasts.
cur=valuation_premiums[(valuation_premiums.region=='US') & (valuation_premiums.year==2024)].set_index('metric')
cur_forward=float(cur.loc['forward_pe','premium_log'])
cur_current=float(cur.loc['current_pe','premium_log'])
cur_trailing=float(cur.loc['trailing_pe','premium_log'])
current_blended_premium_log=0.50*cur_forward+0.25*cur_current+0.25*cur_trailing
kappa_raw=current_blended_premium_log/dotcom_premium_log if dotcom_premium_log>0 else 1.0
# Floors/caps are explicit governance choices: they prevent a single PE dataset from converting a stress scenario into a valuation forecast.
kappa_base=float(np.clip(kappa_raw,0.50,1.00))
kappa_mild=0.5*kappa_base
kappa_severe=1.0
calib_summary=pd.DataFrame([
    {'parameter':'dotcom_reference_premium_log','value':dotcom_premium_log,'description':'Mean log AI/TMT PE premium versus market in Jan 1999 and Jan 2000.'},
    {'parameter':'current_forward_premium_log','value':cur_forward,'description':'Current US AI/TMT forward PE premium versus market.'},
    {'parameter':'current_current_premium_log','value':cur_current,'description':'Current US AI/TMT current PE premium versus market.'},
    {'parameter':'current_trailing_premium_log','value':cur_trailing,'description':'Current US AI/TMT trailing PE premium versus market.'},
    {'parameter':'current_blended_premium_log','value':current_blended_premium_log,'description':'0.50 forward + 0.25 current + 0.25 trailing earnings multiple premium.'},
    {'parameter':'raw_valuation_severity_scalar','value':kappa_raw,'description':'Current blended premium divided by dot-com reference premium.'},
    {'parameter':'base_valuation_severity_scalar_kappa','value':kappa_base,'description':'Production base multiplier applied to AI-excess shock.'},
    {'parameter':'severe_valuation_severity_scalar_kappa','value':kappa_severe,'description':'Full dot-com analogue multiplier.'},
])
calib_summary.to_csv(DATA/'valuation_severity_calibration_summary.csv', index=False)

# ---------- read v3 return model estimates and adjust scenario severity ----------
ci=pd.read_csv(V3/'data/country_industry_stress_vector_v3.csv')
ss=pd.read_csv(V3/'data/single_stock_override_vector_v3.csv')
scenario_v3=pd.read_csv(V3/'data/scenario_parameters_v3.csv')
base_v3=scenario_v3[scenario_v3.scenario=='base'].iloc[0]
S_WORLD=float(base_v3['S_WORLD_log'])
S_AI_EXCESS_DOTCOM=float(base_v3['S_AI_EXCESS_log'])
S_EPICENTER_DOTCOM=S_WORLD+S_AI_EXCESS_DOTCOM
scenarios=pd.DataFrame([
    {'scenario':'mild','world_scale':0.50,'valuation_severity_scalar':kappa_mild,'S_WORLD_log':0.50*S_WORLD,'S_AI_EXCESS_log':kappa_mild*S_AI_EXCESS_DOTCOM},
    {'scenario':'base','world_scale':1.00,'valuation_severity_scalar':kappa_base,'S_WORLD_log':S_WORLD,'S_AI_EXCESS_log':kappa_base*S_AI_EXCESS_DOTCOM},
    {'scenario':'severe','world_scale':1.00,'valuation_severity_scalar':kappa_severe,'S_WORLD_log':S_WORLD,'S_AI_EXCESS_log':kappa_severe*S_AI_EXCESS_DOTCOM},
])
scenarios['S_AI_EPICENTER_log']=scenarios['S_WORLD_log']+scenarios['S_AI_EXCESS_log']
for c in ['S_WORLD_log','S_AI_EXCESS_log','S_AI_EPICENTER_log']:
    scenarios[c.replace('_log','_simple')]=np.exp(scenarios[c])-1
scenarios['calibration_note']=['Half-world move and half of valuation-adjusted AI-excess move','Valuation-adjusted AI-excess move; full dot-com world move','Full dot-com AI-excess analogue; full dot-com world move']
scenarios.to_csv(DATA/'scenario_parameters_v4.csv', index=False)

# Copy key diagnostics from v3 into v4 for auditability.
for fn in ['country_factor_estimates_v3.csv','industry_factor_estimates_v3.csv','factor_correlation_diagnostics.csv','ff49_validation_summary_v3.csv','ff49_dotcom_validation_v3.csv','client_industry_mapping_v3.csv','client_country_mapping_template_v3.csv','optional_market_cap_overlay_policy_v3.csv','economic_exposure_assumptions_v3.csv']:
    src=V3/'data'/fn
    if src.exists(): shutil.copy2(src, DATA/fn.replace('_v3','_v4_return_model_input'))

# Create v4 country-industry vector
out=ci.copy()
# Rename base prevaluation columns to preserve provenance; drop old scenario columns later.
old_scenario_cols=[c for c in out.columns if re.match(r'^(mild|base|severe)_', c)]
for c in old_scenario_cols:
    out=out.drop(columns=[c])
out['valuation_severity_scalar_base']=kappa_base
out['valuation_severity_scalar_mild']=kappa_mild
out['valuation_severity_scalar_severe']=kappa_severe
out['ai_excess_shock_source']='Dot-com TMT excess drawdown scaled by Damodaran PE-premium calibration'
out['stress_model_version']='v4 valuation-calibrated country-industry model'
out['formula_log_return']='beta_world_cell*S_WORLD_log + final_ai_excess_intensity*valuation_severity_scalar*S_AI_EXCESS_DOTCOM_log'
out['formula_simple_return']='EXP(stress_log_return)-1'
out['recommended_client_pnl_formula']='stress_pnl_usd = - signed_market_value_usd * stress_simple_return'
out['margin_usage_formula']='stress_loss_to_margin = max(stress_pnl_usd,0)/client_level_margin_usd'
out['market_cap_overlay_formula']='optional only: loss_usd_adjusted = max(stress_pnl_usd,0) * size_loss_multiplier(holding_market_cap_usd)'
for _,r in scenarios.iterrows():
    s=r['scenario']
    mask=out['model_scope'].eq('equity_factor_stress')
    log=np.where(mask, out['beta_world_cell']*r['S_WORLD_log'] + out['final_ai_excess_intensity']*r['S_AI_EXCESS_log'], np.nan)
    out[f'{s}_stress_log']=log
    out[f'{s}_stress_simple']=np.exp(log)-1
    out[f'{s}_stress_pct']=100*out[f'{s}_stress_simple']
    out[f'{s}_world_component_log']=np.where(mask, out['beta_world_cell']*r['S_WORLD_log'], np.nan)
    out[f'{s}_ai_excess_component_log']=np.where(mask, out['final_ai_excess_intensity']*r['S_AI_EXCESS_log'], np.nan)
    out[f'{s}_valuation_severity_scalar']=r['valuation_severity_scalar']
# Reorder important columns
front=['country_bucket','country_proxy_ticker','country_region_group','client_industry_label','client_industry_normalized','industry_bucket','industry_proxy_ticker','industry_sector_group','model_scope','reliability_flag','beta_world_cell','final_ai_excess_intensity','valuation_severity_scalar_base','valuation_severity_scalar_severe','formula_log_return','formula_simple_return','recommended_client_pnl_formula','margin_usage_formula','market_cap_overlay_formula']
cols=front+[c for c in out.columns if c not in front]
out=out[cols]
out.to_csv(DATA/'country_industry_stress_vector_v4.csv', index=False)
# long scenario format
long_rows=[]
for _,row in out.iterrows():
    base={k:row[k] for k in ['country_bucket','country_proxy_ticker','country_region_group','client_industry_label','client_industry_normalized','industry_bucket','industry_proxy_ticker','industry_sector_group','model_scope','reliability_flag','beta_world_cell','final_ai_excess_intensity']}
    for _,sc in scenarios.iterrows():
        s=sc['scenario']
        rec=base.copy(); rec.update({'scenario':s,'valuation_severity_scalar':sc['valuation_severity_scalar'],'S_WORLD_log':sc['S_WORLD_log'],'S_AI_EXCESS_log':sc['S_AI_EXCESS_log'],'stress_log':row.get(f'{s}_stress_log',np.nan),'stress_simple':row.get(f'{s}_stress_simple',np.nan),'stress_pct':row.get(f'{s}_stress_pct',np.nan)})
        long_rows.append(rec)
pd.DataFrame(long_rows).to_csv(DATA/'country_industry_stress_vector_v4_long.csv', index=False)

# Single-stock overrides
ss4=ss.copy()
old=[c for c in ss4.columns if re.match(r'^(mild|base|severe)_', c)]
ss4=ss4.drop(columns=old)
ss4['valuation_severity_scalar_base']=kappa_base
ss4['stress_model_version']='v4 valuation-calibrated single-stock override'
ss4['formula_log_return']='beta_world_stock*S_WORLD_log + final_ai_excess_intensity*valuation_severity_scalar*S_AI_EXCESS_DOTCOM_log'
for _,r in scenarios.iterrows():
    s=r['scenario']
    log=ss4['beta_world_stock']*r['S_WORLD_log'] + ss4['final_ai_excess_intensity']*r['S_AI_EXCESS_log']
    ss4[f'{s}_stress_log']=log
    ss4[f'{s}_stress_simple']=np.exp(log)-1
    ss4[f'{s}_stress_pct']=100*ss4[f'{s}_stress_simple']
    ss4[f'{s}_world_component_log']=ss4['beta_world_stock']*r['S_WORLD_log']
    ss4[f'{s}_ai_excess_component_log']=ss4['final_ai_excess_intensity']*r['S_AI_EXCESS_log']
    ss4[f'{s}_valuation_severity_scalar']=r['valuation_severity_scalar']
ss4.to_csv(DATA/'single_stock_override_vector_v4.csv', index=False)

# Market cap overlay policy
mc_policy=pd.DataFrame([
    {'market_cap_bucket':'mega_large_cap','condition':'holding_market_cap_usd >= 10000000000','size_loss_multiplier':1.00,'rationale':'Factor stress is usually sufficient for liquid large-cap equities.'},
    {'market_cap_bucket':'mid_cap','condition':'2000000000 <= holding_market_cap_usd < 10000000000','size_loss_multiplier':1.05,'rationale':'Small liquidity/concentration allowance.'},
    {'market_cap_bucket':'small_cap','condition':'300000000 <= holding_market_cap_usd < 2000000000','size_loss_multiplier':1.10,'rationale':'Material liquidity and gap-risk allowance.'},
    {'market_cap_bucket':'micro_cap_or_missing','condition':'holding_market_cap_usd < 300000000 or missing','size_loss_multiplier':1.20,'rationale':'Use only as a conservative add-on, not as part of the factor return.'},
])
mc_policy.to_csv(DATA/'optional_market_cap_overlay_policy_v4.csv', index=False)

# Sample outcomes
sample_specs=[
    ('S&P 500 index proxy','United States','index & ETF'),
    ('US technology hardware','United States','technology hardware & storage &peripheral'),
    ('Taiwan technology hardware','Taiwan','technology hardware & storage &peripheral'),
    ('Korea technology hardware','Korea','technology hardware & storage &peripheral'),
    ('US electric utilities','United States','electric utilities'),
    ('US independent power / renewables','United States','independent power & renewables'),
    ('US oil and gas','United States','oil gas & consumable fuels'),
    ('Japan machinery','Japan','Mchinery'),
    ('Europe banks fallback','Developed Europe Fallback','banks'),
    ('Emerging Asia software/services proxy','Emerging Asia Fallback','IT services')
]
sample_rows=[]
for label,cty,ind in sample_specs:
    sub=out[(out['country_bucket']==cty) & (out['client_industry_label'].str.lower()==ind.lower())]
    if len(sub)==0:
        sub=out[(out['country_bucket']==cty) & (out['client_industry_normalized']==norm(ind))]
    if len(sub)>0:
        r=sub.iloc[0]
        sample_rows.append({'sample_position':label,'country_bucket':r['country_bucket'],'client_industry_label':r['client_industry_label'],'industry_bucket':r['industry_bucket'],'mild_stress_pct':r['mild_stress_pct'],'base_stress_pct':r['base_stress_pct'],'severe_stress_pct':r['severe_stress_pct'],'beta_world_cell':r['beta_world_cell'],'final_ai_excess_intensity':r['final_ai_excess_intensity'],'reliability_flag':r['reliability_flag']})
# Add single stock outcomes
for t in ['NVDA','AMD','AVGO','MSFT','GOOGL','AMZN','META','SMCI','PLTR']:
    sub=ss4[ss4['ticker']==t]
    if len(sub):
        r=sub.iloc[0]
        sample_rows.append({'sample_position':f'{t} single-stock override','country_bucket':'single stock','client_industry_label':'single stock override','industry_bucket':t,'mild_stress_pct':r['mild_stress_pct'],'base_stress_pct':r['base_stress_pct'],'severe_stress_pct':r['severe_stress_pct'],'beta_world_cell':r['beta_world_stock'],'final_ai_excess_intensity':r['final_ai_excess_intensity'],'reliability_flag':'single-stock'})
samples=pd.DataFrame(sample_rows)
samples.to_csv(DATA/'sample_outcomes_v4.csv', index=False)

# Summary numbers
summary={
    'dotcom_reference_premium_log':dotcom_premium_log,
    'current_forward_premium_log':cur_forward,
    'current_current_premium_log':cur_current,
    'current_trailing_premium_log':cur_trailing,
    'current_blended_premium_log':current_blended_premium_log,
    'raw_kappa':kappa_raw,
    'base_kappa':kappa_base,
    'S_WORLD_base_simple_pct':100*(math.exp(S_WORLD)-1),
    'S_AI_EXCESS_dotcom_simple_pct':100*(math.exp(S_AI_EXCESS_DOTCOM)-1),
    'S_AI_EXCESS_base_simple_pct':100*(math.exp(kappa_base*S_AI_EXCESS_DOTCOM)-1),
    'S_AI_EPICENTER_base_simple_pct':100*(math.exp(S_WORLD+kappa_base*S_AI_EXCESS_DOTCOM)-1),
    'S_AI_EPICENTER_severe_simple_pct':100*(math.exp(S_WORLD+S_AI_EXCESS_DOTCOM)-1),
    'num_country_industry_rows':len(out),
    'num_equity_rows':int((out['model_scope']=='equity_factor_stress').sum()),
    'num_countries':int(out['country_bucket'].nunique()),
    'num_client_industries':int(out['client_industry_label'].nunique()),
    'base_min_stress_pct':float(out['base_stress_pct'].min()),
    'base_median_stress_pct':float(out.loc[out['model_scope']=='equity_factor_stress','base_stress_pct'].median()),
    'base_max_stress_pct':float(out['base_stress_pct'].max()),
    'single_stock_nvda_base_pct':float(ss4.loc[ss4.ticker=='NVDA','base_stress_pct'].iloc[0]) if (ss4.ticker=='NVDA').any() else None,
    'single_stock_nvda_severe_pct':float(ss4.loc[ss4.ticker=='NVDA','severe_stress_pct'].iloc[0]) if (ss4.ticker=='NVDA').any() else None,
}
Path(DATA/'summary_numbers_v4.json').write_text(json.dumps(summary,indent=2))

# ---------- figures ----------
plt.rcParams.update({'font.size':9})
# 1 Valuation premiums
fig,ax=plt.subplots(figsize=(7.4,4.2))
vals=[dotcom_premium_log, cur_forward, cur_current, cur_trailing, current_blended_premium_log]
labs=['Dot-com\n1999-2000','Current\nforward PE','Current\ncurrent PE','Current\ntrailing PE','Current\nblended']
ax.bar(labs, vals)
ax.axhline(dotcom_premium_log, linestyle='--', linewidth=1)
ax.set_ylabel('Log premium vs market')
ax.set_title('AI/TMT valuation premium: current data versus dot-com reference')
for i,v in enumerate(vals): ax.text(i, v+0.02, f'{math.exp(v):.2f}x', ha='center', va='bottom', fontsize=8)
ax.set_ylim(0, max(vals)*1.22)
ax.text(0.02,0.86,f'Base valuation severity scalar = {kappa_base:.2f}', transform=ax.transAxes, va='top', fontsize=8)
fig.tight_layout(); fig.savefig(FIG/'01_valuation_calibration.png',dpi=220); plt.close(fig)
# 2 Scenario shocks
fig,ax=plt.subplots(figsize=(7.2,4.0))
x=np.arange(len(scenarios)); width=0.35
ax.bar(x-width/2, 100*scenarios['S_WORLD_simple'], width, label='World market shock')
ax.bar(x+width/2, 100*scenarios['S_AI_EXCESS_simple'], width, label='AI-excess shock')
ax.set_xticks(x); ax.set_xticklabels(scenarios['scenario'].str.title())
ax.set_ylabel('Simple return shock (%)')
ax.set_title('Scenario decomposition after valuation calibration')
ax.legend()
for i,row in scenarios.iterrows():
    ax.text(i, 100*row['S_AI_EPICENTER_simple']-4, f'Epicenter\n{100*row["S_AI_EPICENTER_simple"]:.1f}%', ha='center', va='top', fontsize=8)
fig.tight_layout(); fig.savefig(FIG/'02_scenario_decomposition.png',dpi=220); plt.close(fig)
# 3 Sample outcomes
samp=samples.copy().sort_values('base_stress_pct')
fig,ax=plt.subplots(figsize=(8.2,5.6))
y=np.arange(len(samp))
ax.barh(y, samp['base_stress_pct'])
ax.set_yticks(y); ax.set_yticklabels(samp['sample_position'])
ax.set_xlabel('Base stress return (%)')
ax.set_title('Representative base stress outputs')
ax.axvline(0, linewidth=0.8)
fig.tight_layout(); fig.savefig(FIG/'03_sample_outcomes.png',dpi=220); plt.close(fig)
# 4 Heatmap subset: selected countries and industry buckets
sel_countries=['United States','Taiwan','Korea','Japan','China','Germany','United Kingdom','Emerging Asia Fallback','Emerging Markets Fallback']
sel_inds=['Technology','Aerospace and Defense','Utilities','Energy','Industrials','Financials','Healthcare','Consumer Discretionary','Consumer Staples','Real Estate']
heat=out[(out.model_scope=='equity_factor_stress') & (out.country_bucket.isin(sel_countries))].copy()
# one row per country x industry_bucket, average duplicated client labels in same bucket
pivot=heat.groupby(['country_bucket','industry_bucket'])['base_stress_pct'].mean().unstack()
pivot=pivot.reindex(sel_countries)[[c for c in sel_inds if c in pivot.columns]]
fig,ax=plt.subplots(figsize=(8.2,5.2))
im=ax.imshow(pivot.values, aspect='auto')
ax.set_xticks(range(len(pivot.columns))); ax.set_xticklabels(pivot.columns, rotation=45, ha='right')
ax.set_yticks(range(len(pivot.index))); ax.set_yticklabels(pivot.index)
for i in range(pivot.shape[0]):
    for j in range(pivot.shape[1]):
        val=pivot.values[i,j]
        if pd.notna(val): ax.text(j,i,f'{val:.0f}',ha='center',va='center',fontsize=7)
fig.colorbar(im, ax=ax, label='Base stress return (%)')
ax.set_title('Base stress heatmap, selected country and industry buckets')
fig.tight_layout(); fig.savefig(FIG/'04_base_heatmap_selected.png',dpi=220); plt.close(fig)
# 5 Distribution
fig,ax=plt.subplots(figsize=(7.2,4.0))
base_vals=out.loc[out.model_scope=='equity_factor_stress','base_stress_pct'].dropna()
sev_vals=out.loc[out.model_scope=='equity_factor_stress','severe_stress_pct'].dropna()
ax.hist(base_vals, bins=30, alpha=0.65, label='Base')
ax.hist(sev_vals, bins=30, alpha=0.45, label='Severe/full dot-com')
ax.set_xlabel('Stress return (%)')
ax.set_ylabel('Number of country-industry rows')
ax.set_title('Distribution of country-industry stress returns')
ax.legend(); fig.tight_layout(); fig.savefig(FIG/'05_stress_distribution.png',dpi=220); plt.close(fig)
# 6 Single stock overrides comparison base/severe
fig,ax=plt.subplots(figsize=(7.6,4.4))
ss_plot=ss4.sort_values('base_stress_pct')
y=np.arange(len(ss_plot)); h=0.38
ax.barh(y-h/2, ss_plot['base_stress_pct'], h, label='Base valuation-adjusted')
ax.barh(y+h/2, ss_plot['severe_stress_pct'], h, label='Severe full dot-com')
ax.set_yticks(y); ax.set_yticklabels(ss_plot['ticker'])
ax.set_xlabel('Stress return (%)')
ax.set_title('Single-stock override vector')
ax.legend(); fig.tight_layout(); fig.savefig(FIG/'06_single_stock_overrides.png',dpi=220); plt.close(fig)
# 7 Return model validation copied from v3 if available
if (V3/'figures/09_ff49_validation.png').exists(): shutil.copy2(V3/'figures/09_ff49_validation.png', FIG/'07_ff49_validation.png')
if (V3/'figures/11_stat_vs_economic_intensity.png').exists(): shutil.copy2(V3/'figures/11_stat_vs_economic_intensity.png', FIG/'08_stat_vs_economic_intensity.png')

# Tables for LaTeX
def write_tabular(df, path, cols, headers=None, n=10, float_cols=None):
    float_cols=float_cols or []
    headers=headers or cols
    with open(path,'w') as f:
        f.write('\\begin{tabular}{' + 'l'*len(cols) + '}\n')
        f.write('\\hline\n')
        f.write(' & '.join(safe_tex(h) for h in headers) + ' \\\\ \n')
        f.write('\\hline\n')
        for _,r in df.head(n).iterrows():
            vals=[]
            for c in cols:
                v=r[c]
                if c in float_cols and pd.notna(v): vals.append(f'{float(v):.1f}')
                elif isinstance(v,(float,np.floating)) and pd.notna(v): vals.append(f'{float(v):.2f}')
                else: vals.append(safe_tex(v))
            f.write(' & '.join(vals) + ' \\\\ \n')
        f.write('\\hline\n\\end{tabular}\n')

write_tabular(samples[['sample_position','base_stress_pct','severe_stress_pct','reliability_flag']].sort_values('base_stress_pct'), OUT/'table_samples.tex', ['sample_position','base_stress_pct','severe_stress_pct','reliability_flag'], ['Position','Base %','Severe %','Flag'], n=12, float_cols=['base_stress_pct','severe_stress_pct'])
worst=out[out.model_scope=='equity_factor_stress'].sort_values('base_stress_pct')[['country_bucket','client_industry_label','industry_bucket','base_stress_pct','severe_stress_pct','reliability_flag']].copy()
def short_label(x):
    x=str(x)
    repl={
        'technology hardware & storage &peripheral':'tech hardware',
        'electronic equipment & instrument':'electronic equipment',
        'communication equipment':'communications equip.',
        'index & ETF':'index/ETF',
        'index futures':'index futures'
    }
    return repl.get(x, x[:26] + ('...' if len(x)>26 else ''))
worst['client_industry_label']=worst['client_industry_label'].map(short_label)
write_tabular(worst, OUT/'table_worst.tex', ['country_bucket','client_industry_label','industry_bucket','base_stress_pct','reliability_flag'], ['Country','Client industry','Model bucket','Base %','Flag'], n=12, float_cols=['base_stress_pct'])
valtab=valuation_premiums[(valuation_premiums.year.isin([1999,2000,2024])) & (valuation_premiums.region=='US') & (valuation_premiums.metric.isin(['current_pe','trailing_pe','forward_pe']))].copy()
valtab['premium_ratio_str']=valtab['premium_ratio'].map(lambda x:f'{x:.2f}x')
write_tabular(valtab[['year','metric','premium_ratio_str','premium_log']].sort_values(['year','metric']), OUT/'table_valuation.tex', ['year','metric','premium_ratio_str','premium_log'], ['Year','Metric','AI/TMT premium','Log premium'], n=12, float_cols=['premium_log'])

# Client application template
apply_code = r'''import pandas as pd
import numpy as np
import re
from pathlib import Path

def norm_label(x):
    return re.sub(r'[^a-z0-9]+',' ',str(x).lower()).strip()

def size_loss_multiplier(market_cap_usd):
    try:
        mc = float(market_cap_usd)
    except Exception:
        return 1.20
    if np.isnan(mc) or mc <= 0:
        return 1.20
    if mc >= 10_000_000_000:
        return 1.00
    if mc >= 2_000_000_000:
        return 1.05
    if mc >= 300_000_000:
        return 1.10
    return 1.20

def apply_stress(client_csv,
                 stress_vector_csv='data/country_industry_stress_vector_v4.csv',
                 single_stock_csv='data/single_stock_override_vector_v4.csv',
                 country_mapping_csv='data/client_country_mapping_template_v4_return_model_input.csv',
                 scenario='base',
                 output_csv='client_stress_output_v4.csv',
                 use_single_stock_overrides=True,
                 apply_market_cap_overlay=False):
    client = pd.read_csv(client_csv)
    stress = pd.read_csv(stress_vector_csv)
    single = pd.read_csv(single_stock_csv)
    country_map = pd.read_csv(country_mapping_csv)

    required = ['country','industry','signed_market_value_usd']
    miss = [c for c in required if c not in client.columns]
    if miss:
        raise ValueError(f'Missing required client columns: {miss}')

    client['country_normalized'] = client['country'].map(norm_label)
    client['industry_normalized'] = client['industry'].map(norm_label)
    if 'ticker' in client.columns:
        client['ticker_upper'] = client['ticker'].astype(str).str.upper().str.replace(r'[^A-Z0-9]+','',regex=True)
    else:
        client['ticker_upper'] = ''

    # Country mapping template columns: client_country_label, client_country_normalized, country_bucket, country_proxy_ticker, region_group, reliability_country
    if 'client_country_normalized' not in country_map.columns:
        country_map['client_country_normalized'] = country_map['client_country_label'].map(norm_label)
    client = client.merge(country_map[['client_country_normalized','country_bucket','country_proxy_ticker','region_group','reliability_country']], left_on='country_normalized', right_on='client_country_normalized', how='left')
    client['country_bucket'] = client['country_bucket'].fillna('World Fallback')

    key_cols = ['country_bucket','client_industry_normalized',f'{scenario}_stress_simple',f'{scenario}_stress_pct',f'{scenario}_stress_log','model_scope','reliability_flag','industry_bucket','beta_world_cell','final_ai_excess_intensity']
    stress_small = stress[key_cols].rename(columns={f'{scenario}_stress_simple':'stress_simple',f'{scenario}_stress_pct':'stress_pct',f'{scenario}_stress_log':'stress_log'})
    out = client.merge(stress_small, left_on=['country_bucket','industry_normalized'], right_on=['country_bucket','client_industry_normalized'], how='left')

    if use_single_stock_overrides and 'ticker_upper' in out.columns:
        single_small = single[['ticker',f'{scenario}_stress_simple',f'{scenario}_stress_pct',f'{scenario}_stress_log','beta_world_stock','final_ai_excess_intensity']].rename(columns={'ticker':'ticker_upper',f'{scenario}_stress_simple':'single_stock_stress_simple',f'{scenario}_stress_pct':'single_stock_stress_pct',f'{scenario}_stress_log':'single_stock_stress_log'})
        out = out.merge(single_small, on='ticker_upper', how='left')
        use_ss = out['single_stock_stress_simple'].notna()
        out.loc[use_ss,'stress_simple'] = out.loc[use_ss,'single_stock_stress_simple']
        out.loc[use_ss,'stress_pct'] = out.loc[use_ss,'single_stock_stress_pct']
        out.loc[use_ss,'stress_log'] = out.loc[use_ss,'single_stock_stress_log']
        out.loc[use_ss,'model_scope'] = 'single_stock_override'
        out.loc[use_ss,'reliability_flag'] = 'single-stock'

    out['stress_pnl_usd'] = -out['signed_market_value_usd'] * out['stress_simple']
    out['adverse_stress_loss_usd'] = out['stress_pnl_usd'].clip(lower=0)
    if apply_market_cap_overlay:
        if 'holding_market_cap_usd' not in out.columns:
            raise ValueError('holding_market_cap_usd is required when apply_market_cap_overlay=True')
        out['size_loss_multiplier'] = out['holding_market_cap_usd'].map(size_loss_multiplier)
    else:
        out['size_loss_multiplier'] = 1.0
    out['adverse_stress_loss_usd_after_size_overlay'] = out['adverse_stress_loss_usd'] * out['size_loss_multiplier']
    if 'client_level_margin_usd' in out.columns:
        out['stress_loss_to_margin'] = out['adverse_stress_loss_usd_after_size_overlay'] / out['client_level_margin_usd']
    out.to_csv(output_csv, index=False)
    return out

if __name__ == '__main__':
    # Example:
    # apply_stress('client_positions.csv', scenario='base', output_csv='client_stress_output_v4.csv')
    pass
'''
(CODE/'apply_stress_to_client_template_v4.py').write_text(apply_code)
# Replication script: copy this script
shutil.copy2(Path(__file__), CODE/'build_ai_country_industry_stress_v4.py')

# README and data dictionary
readme = f'''# AI country-industry stress research v4

This package contains the final valuation-calibrated country-industry stress vector, single-stock override vector, report source, figures, and replication code.

Main files:
- `main.pdf`: report.
- `data/country_industry_stress_vector_v4.csv`: merge-ready country-industry stress vector.
- `data/single_stock_override_vector_v4.csv`: single-stock override vector for AI epicenter names.
- `data/scenario_parameters_v4.csv`: mild/base/severe shock assumptions.
- `data/valuation_severity_calibration_summary.csv`: Damodaran valuation calibration.
- `code/apply_stress_to_client_template_v4.py`: template for applying the vector to position data.
- `code/build_ai_country_industry_stress_v4.py`: replication script.

Base valuation severity scalar: {kappa_base:.3f}.
'''
(OUT/'README.md').write_text(readme)

ddict = '''# Data dictionary

`country_industry_stress_vector_v4.csv` key columns:
- `country_bucket`: model country or region bucket.
- `client_industry_label`: original client industry label supplied for the mapping table.
- `industry_bucket`: model industry proxy bucket.
- `beta_world_cell`: market-beta component used in the stress formula.
- `final_ai_excess_intensity`: AI-excess intensity before valuation scaling.
- `valuation_severity_scalar_base`: base valuation severity scalar applied to the AI-excess shock.
- `base_stress_simple`: base simple return shock.
- `base_stress_pct`: base return shock in percentage points.
- `severe_stress_simple`: full dot-com analogue simple return shock.
- `reliability_flag`: A/B/C/D/X mapping quality flag.

`single_stock_override_vector_v4.csv` key columns:
- `ticker`: override ticker.
- `beta_world_stock`: stock market-beta component.
- `final_ai_excess_intensity`: AI-excess intensity before valuation scaling.
- `base_stress_pct`: valuation-adjusted base shock.
- `severe_stress_pct`: full dot-com analogue shock.

`valuation_premium_calibration_inputs.csv`:
- `premium_log`: log AI/TMT valuation premium versus market.
- `premium_ratio`: exp(premium_log).
'''
(OUT/'data_dictionary.md').write_text(ddict)


# LaTeX report
# Use a plain raw template with explicit placeholders. Do not use Python f-strings here because LaTeX braces are meaningful.
def repl_report(txt, mapping):
    for k,v in mapping.items():
        txt = txt.replace('@@'+k+'@@', str(v))
    return txt

report_template = r'''
\documentclass[11pt]{article}
\usepackage{graphicx}
\begin{document}

\title{AI Unwind Stress Framework: Valuation-Calibrated Country-Industry and Single-Stock Vector}
\author{Alex Zhang}
\date{July 2026}
\maketitle

\section*{Executive summary}

This report presents a valuation-calibrated stress framework for an AI-led equity unwind. The framework separates the shock into two economically distinct pieces: a broad equity-market drawdown and an incremental AI-excess repricing channel. This separation is important because an AI unwind would not be a pure single-theme event. It would likely combine market-wide de-risking, factor rotation, semiconductor and cloud repricing, data-center capex reassessment, and second-order stress in power, grid, industrial infrastructure, financing, and communication services.

The central revision in this version is severity calibration. A full dot-com TMT replay remains a useful severe analogue, but it should not be mechanically treated as the base case. The base case now scales the AI-excess component using Damodaran industry valuation data. The result is a cleaner framework: dot-com determines the historical tail shape, while current valuation evidence determines how much of that excess shock is used in the base case.

The base valuation severity scalar is
\[
\kappa_{base}=@@KAPPA_BASE@@.
\]
This means the base case applies @@KAPPA_BASE_PCT@@\% of the dot-com AI/TMT excess drawdown, while the severe case keeps the unadjusted dot-com analogue. The broad market component is not scaled away in the base case; an AI bubble unwind is assumed to create a full market de-risking event.

The main calibrated shocks are
\[
S_W=@@S_WORLD_BASE@@\%, \qquad
S_{AI,excess}^{dotcom}=@@S_AI_EXCESS_DOTCOM@@\%,
\]
\[
S_{AI,excess}^{base}=@@S_AI_EXCESS_BASE@@\%, \qquad
S_{AI,epicenter}^{base}=@@S_EPICENTER_BASE@@\%.
\]
The final vector covers @@N_ROWS@@ country-industry rows across @@N_COUNTRIES@@ country or region buckets and @@N_INDUSTRIES@@ client industry labels. The median base stress across in-scope equity rows is @@MEDIAN_BASE@@\%. The NVDA single-stock override is @@NVDA_BASE@@\% in the valuation-adjusted base case and @@NVDA_SEVERE@@\% in the full-dot-com severe case.

\section{Core model}

The model is a scenario-based factor stress model. It is not a point forecast and it is not a stock-by-stock valuation model. For a country-industry cell $(b,g)$, the stress return under scenario $s$ is
\[
\widehat R_{b,g}^s
=
\beta_{b,g}^W S_W^s
+
I_{b,g}^{AI}\kappa_s S_{AI,excess}^{dotcom}.
\]
Here $\beta_{b,g}^W$ is the market-beta component, $S_W^s$ is the global equity shock, $I_{b,g}^{AI}$ is the AI-excess intensity, $\kappa_s$ is the valuation severity scalar, and $S_{AI,excess}^{dotcom}$ is the dot-com TMT excess drawdown relative to the market. The same formula is used for selected single-stock overrides:
\[
\widehat R_i^s
=
\beta_i^W S_W^s
+
I_i^{AI}\kappa_s S_{AI,excess}^{dotcom}.
\]

The logic is deliberately modular. Return data and economic mapping determine exposure. Valuation data calibrate severity. The model therefore does not use a high P/E ratio to decide whether a country or industry is AI-exposed. Instead, the valuation premium only answers one question: should the base AI-excess shock use the full dot-com analogue, or only a scaled version of it?

\section{Why the previous approach needed refinement}

A world-neutral residual AI factor is useful for relative-performance diagnostics. It answers a question such as: after controlling for the market, which countries and industries behave like AI winners versus AI laggards? It is not sufficient as the production crash factor. A negative residual beta can mean that a sector tends to outperform AI after controlling for the market; it does not mean the sector should rise in an absolute equity selloff.

The production stress therefore uses an absolute decomposition: market shock plus AI-excess intensity. Residual AI beta is retained in the data files for audit and interpretation, but it is not the main crash mechanism. This avoids the earlier problem where defensive sectors appeared to benefit mechanically from an AI crash. It also avoids the opposite error of simply deleting negative betas. The residual estimates remain visible, but the stress mechanism is now aligned with the economic event being tested.

The second refinement is valuation severity. A full dot-com replay is too blunt as a base case. Some AI leaders have real revenues, margins, and cash flow that many dot-com-era internet firms did not have. At the same time, the AI trade still embeds fragile assumptions about data-center capex, semiconductor demand durability, cloud monetization, power availability, margin sustainability, and the pace of enterprise AI adoption. The valuation layer is intended to reflect this difference without replacing the factor model.

\section{Valuation calibration}

Damodaran industry valuation files are used to compare the current AI/TMT valuation premium with the late-1990s and early-2000s TMT premium. For each year and valuation metric, define
\[
P_t^m
=
\log M_{AI,t}^m-\log M_{MKT,t}^m,
\]
where $M_{AI,t}^m$ is the firm-count-weighted geometric mean multiple for AI/TMT industries and $M_{MKT,t}^m$ is the market benchmark. The dot-com reference is
\[
P_{dotcom}=\frac{1}{2}\left(P_{1999}^{current}+P_{2000}^{current}\right).
\]
For the current period, the base premium combines forward, current, and trailing PE:
\[
P_{now}=0.50P_{now}^{forward}+0.25P_{now}^{current}+0.25P_{now}^{trailing}.
\]
Forward PE receives the highest weight because the AI debate is mainly about future earnings power. Current and trailing PE remain in the blend because forward estimates can embed optimistic sell-side expectations.

The raw severity scalar is
\[
\kappa_{raw}=\frac{P_{now}}{P_{dotcom}}=@@KAPPA_RAW@@.
\]
The production base scalar is clipped to a transparent governance range:
\[
\kappa_{base}=\min\{1,\max\{0.5,\kappa_{raw}\}\}=@@KAPPA_BASE@@.
\]
The lower bound prevents a single valuation dataset from eliminating stress. The upper bound prevents the base case from becoming more severe than the full dot-com analogue.

\begin{figure}[h]
\centering
\includegraphics[width=0.92\textwidth]{figures/01_valuation_calibration.png}
\caption{AI/TMT valuation premium today compared with the dot-com reference. Labels show the AI/TMT multiple relative to the market.}
\end{figure}

\input{table_valuation.tex}

\section{Scenario definition}

The dot-com anchor is built from Fama-French 49 industry portfolios. TMT is defined as software, hardware, chips, and telecom. The 24-month post-peak move is decomposed into a broad market component and a TMT excess component. The scenarios are
\[
\begin{array}{lll}
\mathrm{Mild} &:& 0.5S_W,\quad 0.5\kappa_{base}S_{AI,excess}^{dotcom},\\
\mathrm{Base} &:& S_W,\quad \kappa_{base}S_{AI,excess}^{dotcom},\\
\mathrm{Severe} &:& S_W,\quad S_{AI,excess}^{dotcom}.
\end{array}
\]
The severe case is therefore the full historical analogue. The base case is the same historical analogue after valuation calibration.

\begin{figure}[h]
\centering
\includegraphics[width=0.90\textwidth]{figures/02_scenario_decomposition.png}
\caption{World-market and AI-excess shock components after valuation calibration.}
\end{figure}

\section{Country-industry vector}

Each row is mapped into a country or region bucket and an industry bucket. Country and industry ETF proxies provide the return history used to estimate market beta and AI co-movement. Because public data are imperfect and many client industries are more granular than available ETF proxies, the model uses a reliability flag for each row. Direct country and direct granular industry mappings receive higher confidence; regional fallbacks and broad-sector fallbacks receive lower confidence.

The final AI-excess intensity combines observed absolute AI co-movement with explicit economic relevance. This is necessary because the current AI episode is recent. A purely statistical estimate would be unstable, while a purely hand-scored mapping would be arbitrary. The blended approach is auditable: the data files retain the statistical estimate, economic score, final intensity, and residual-beta diagnostic.

The final country-industry vector is delivered as the main v4 CSV. It contains mild, base, and severe stress returns, stress formulas, country bucket, industry bucket, proxy tickers, reliability flag, beta, AI intensity, valuation scalar, and application fields.

\begin{figure}[h]
\centering
\includegraphics[width=0.92\textwidth]{figures/04_base_heatmap_selected.png}
\caption{Base stress heatmap for selected country and industry buckets. Values are simple return shocks in percent.}
\end{figure}

\section{Representative outputs}

The valuation-adjusted base case remains severe for high-AI, high-beta buckets, but it is no longer mechanically equal to the full dot-com analogue. Taiwan and Korea technology hardware remain among the most exposed country-industry combinations. U.S. utilities and power-related industries receive a larger AI channel than generic defensives because data-center buildout creates a direct electricity and grid-demand channel. Energy receives a smaller but positive AI channel. Staples, tobacco, and many non-AI consumer buckets remain dominated by the broad market component.

\input{table_samples.tex}

\begin{figure}[h]
\centering
\includegraphics[width=0.94\textwidth]{figures/03_sample_outcomes.png}
\caption{Representative base stress outputs.}
\end{figure}

The most negative base rows are concentrated in high-beta Asia technology, technology hardware, semiconductors, AI infrastructure, and selected cyclical industries. These rows are not extreme merely because of geography or volatility; they combine high market beta with high AI-excess intensity.

\input{table_worst.tex}

\begin{figure}[h]
\centering
\includegraphics[width=0.90\textwidth]{figures/05_stress_distribution.png}
\caption{Distribution of base and severe stress returns across in-scope country-industry rows.}
\end{figure}

\section{Single-stock override vector}

The country-industry vector is the default mapping. Selected AI epicenter names receive single-stock overrides because broad industry buckets cannot capture their concentrated exposure. The override vector is delivered as a separate single-stock CSV.

The single-stock result for NVDA is now valuation-adjusted in the base case. The severe case remains the full-dot-com analogue. This means a result near a 70\% drawdown is no longer presented as the central case unless the severe scenario is selected.

\begin{figure}[h]
\centering
\includegraphics[width=0.90\textwidth]{figures/06_single_stock_overrides.png}
\caption{Base and severe single-stock override shocks.}
\end{figure}

\section{Application and risk interpretation}

For each equity position, normalize the country label and industry label, merge to the country-industry vector, and use the selected scenario return. If the security ticker appears in the single-stock override file, use the override row. For signed USD market value $x_i$, stress P\&L is
\[
\widehat L_i^s=-x_i\widehat R_i^s.
\]
For a long position, a negative stress return produces a positive loss. For a short position, a negative stress return produces a gain unless an adverse-only convention is imposed.

Margin usage can be measured as
\[
\mathrm{loss\mbox{-}to\mbox{-}margin}_i^s
=\frac{\max\{\widehat L_i^s,0\}}{\mathrm{margin}}.
\]
If holding-level market capitalization is available, it should be used only as an optional liquidity overlay. Market capitalization by itself is not valuation; it should not alter the factor return unless the goal is to add a liquidity or concentration loss multiplier.

\section{Validation and controls}

The framework has four controls. First, the shock is decomposed into market and AI-excess components, reducing double counting. Second, valuation calibration is applied only to the AI-excess component, preserving the exposure model. Third, residual AI betas are retained as diagnostics but are not mistaken for absolute crash returns. Fourth, reliability flags and fallback mappings identify where the proxy quality is weaker.

Historical validation against Fama-French 49 industry portfolios should be interpreted as rank validation. The return-model layer produced a dot-com validation rank correlation of approximately 0.36 between predicted and realized industry drawdowns. That is useful for ranking vulnerability, but it is not strong enough to justify precise point forecasts without scenario judgement.

\begin{figure}[h]
\centering
\includegraphics[width=0.82\textwidth]{figures/07_ff49_validation.png}
\caption{Historical FF49 validation from the return-model layer. The model is useful for ranking vulnerability rather than exact drawdown forecasting.}
\end{figure}

\section{Limitations}

The model is a systematic stress model built from public return and valuation proxies. It does not estimate idiosyncratic stock gaps for every global security. It does not model options convexity, issuer-specific earnings surprises, borrow recalls, forced liquidation impact, or second-order financing stress. Country and industry proxies are ETF-based, so small countries and obscure industries carry basis risk. P/E data are imperfect because earnings can be cyclically high or low, loss-making firms distort industry averages, and forward estimates can embed optimistic expectations.

The output should therefore be interpreted as a consistent scenario vector, not a precise forecast. The main strength is cross-sectional discipline: the same shock logic is applied across countries, industries, ETFs, index exposures, and AI epicenter single names.

\section{References}

Barberis, N., Greenwood, R., Jin, L., and Shleifer, A. (2018). Extrapolation and Bubbles. Journal of Financial Economics, 129(2), 203--227.

Greenwood, R., Shleifer, A., and You, Y. (2019). Bubbles for Fama. Journal of Financial Economics, 131(1), 20--43.

Heston, S. L. and Rouwenhorst, K. G. (1994). Does Industrial Structure Explain the Benefits of International Diversification? Journal of Financial Economics, 36(1), 3--27.

Griffin, J. M. and Karolyi, G. A. (1998). Another Look at the Role of the Industrial Structure of Markets for International Diversification Strategies. Journal of Financial Economics, 50(3), 351--373.

Newey, W. K. and West, K. D. (1987). A Simple, Positive Semi-definite, Heteroskedasticity and Autocorrelation Consistent Covariance Matrix. Econometrica, 55(3), 703--708.

Ofek, E. and Richardson, M. (2003). DotCom Mania: The Rise and Fall of Internet Stock Prices. Journal of Finance, 58(3), 1113--1137.

Damodaran, A. Industry valuation datasets and archives. NYU Stern School of Business.

Amundi Investment Institute. AI Boom or Bubble? Lessons from the Dot-Com Period. 2026.

\end{document}
'''

report = repl_report(report_template, {
    'KAPPA_BASE': f'{kappa_base:.3f}',
    'KAPPA_BASE_PCT': f'{100*kappa_base:.1f}',
    'KAPPA_RAW': f'{kappa_raw:.3f}',
    'S_WORLD_BASE': f'{100*(math.exp(S_WORLD)-1):.1f}',
    'S_AI_EXCESS_DOTCOM': f'{100*(math.exp(S_AI_EXCESS_DOTCOM)-1):.1f}',
    'S_AI_EXCESS_BASE': f'{summary["S_AI_EXCESS_base_simple_pct"]:.1f}',
    'S_EPICENTER_BASE': f'{summary["S_AI_EPICENTER_base_simple_pct"]:.1f}',
    'N_ROWS': str(summary['num_country_industry_rows']),
    'N_COUNTRIES': str(summary['num_countries']),
    'N_INDUSTRIES': str(summary['num_client_industries']),
    'MEDIAN_BASE': f'{summary["base_median_stress_pct"]:.1f}',
    'NVDA_BASE': f'{summary["single_stock_nvda_base_pct"]:.1f}',
    'NVDA_SEVERE': f'{summary["single_stock_nvda_severe_pct"]:.1f}',
})
(OUT/'main.tex').write_text(report)

# Compile LaTeX
subprocess.run(['pdflatex','-interaction=nonstopmode','main.tex'], cwd=OUT, stdout=open(OUT/'compile1.log','w'), stderr=subprocess.STDOUT, check=False)
subprocess.run(['pdflatex','-interaction=nonstopmode','main.tex'], cwd=OUT, stdout=open(OUT/'compile2.log','w'), stderr=subprocess.STDOUT, check=False)

# Render verification
render_dir=OUT/'render_check'
render_dir.mkdir(exist_ok=True)
try:
    subprocess.run(['python','/home/oai/skills/pdfs/scripts/render_pdf.py',str(OUT/'main.pdf'),'--out_dir',str(render_dir),'--dpi','160'], stdout=open(OUT/'render.log','w'), stderr=subprocess.STDOUT, check=False)
except Exception as e:
    (OUT/'render_error.txt').write_text(str(e))

# Zip package, excluding noisy aux/render details. Include report, data, code, figures, readme.
zip_path=ROOT/'ai_country_industry_stress_research_v4_outputs.zip'
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in OUT.rglob('*'):
        if p.is_file():
            rel=p.relative_to(OUT)
            if str(rel).startswith('render_check/') or rel.suffix in ['.aux','.log']:
                continue
            z.write(p, arcname=str(Path('ai_country_industry_stress_research_v4')/rel))
print(json.dumps(summary,indent=2))
print('OUTPUT', OUT)
print('ZIP', zip_path)
