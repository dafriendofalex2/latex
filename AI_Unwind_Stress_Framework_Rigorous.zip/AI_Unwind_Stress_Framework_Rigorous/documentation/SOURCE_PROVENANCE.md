# Source Provenance and Reconstruction Notes

## What was recovered from the prior project

The prior File Library contains the original monolithic country-industry stress builder (`build_ai_country_industry_stress_v5.py`), the prior valuation/calibration builder (`build_ai_country_industry_stress_v4.py`), the detailed orthogonalization methodology, the fixed-horizon and market-cap research files, the conditional probability theory/code, and the historical burst-severity sample.

Those source files were inspected directly when preparing this bundle. The recovered original logic includes the beta-adjusted statistical AI-intensity formula, the 0.50 latent industry tilt, the 35/65 country-industry economic score, the 1.50 intensity cap, the 0.05 coherence margin, the valuation-calibrated scenario construction, ticker replacement logic, fixed-horizon historical anchors, empirical size overlay, and the complete conditional probability methodology.

## Final 60/40 specification

The early monolithic builder used a 45% statistical / 55% economic blend. This bundle intentionally does **not** preserve that legacy weighting. The final requested and documented specification is 60% statistical / 40% economic, and that weighting is applied consistently in the executable modules and paper.

This is a deliberate model specification change, not an accidental discrepancy. All formulas and examples in the final paper are written against the 60/40 specification.

## Byte-for-byte source limitation

File Library results can be inspected and searched in this runtime, but the historical File Library objects are not automatically mounted as raw files in the active `/mnt/data` filesystem. Therefore the standalone modules in `code/` are clean executable reconstructions of the recovered model algorithms, organized by statistical role. They should not be represented as byte-identical copies of every historical monolithic script.

The mathematical operations themselves were recovered from the prior source and reproduced explicitly. In particular, the probability model, historical 21-event sample, terminal anchors, scenario cell geometry, AICc ensemble, 5,000-replication bootstrap procedure, Jeffreys-Dirichlet cross-check, and GPD endpoint diagnostic are all reproduced from the prior project methodology and validated numerically.

## Data redistribution boundary

The bundle includes the exact 21-event historical severity sample and the reproduced scenario/probability outputs needed to audit the probability section. It does not redistribute every raw third-party market-price or valuation workbook used in earlier research. The refresh code is written so those raw inputs can be supplied to the relevant module when a full data refresh is required.

## Why the code is modular rather than monolithic

The prior research builders combined data ingestion, estimation, model construction, figure generation, LaTeX writing, and ZIP packaging in large scripts. The final bundle separates the model into executable modules so that the code shown next to each theory section is exactly the code responsible for that transformation, rather than report-generation glue.
