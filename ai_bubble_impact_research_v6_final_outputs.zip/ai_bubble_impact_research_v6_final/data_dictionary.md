# Data dictionary

- `summary_metrics.csv`: key dates, signal percentiles, base stress shocks, and projected aggregate returns.
- `ai_stock_regression_and_exposure.csv`: stock-level market beta, AI regression beta, economic overlay, and final hybrid AI multiplier.
- `base_stock_stress_vector.csv`: base 24-month projected stock return and SPY contribution for covered AI names.
- `scenario_total_returns.csv`: mild/base/severe total return estimates for AI basket, S&P proxy, and NASDAQ proxy.
- `historical_signal_decile_evaluation.csv`: historical FF49 signal decile backtest.
- `historical_ff49_signal_drawdown_sample.csv`: sampled historical industry-month signal and future drawdown panel used for figure 4.
- `dotcom_event_path.csv`: dot-com TMT relative event path normalized around peak.
- `current_ai_event_actual_path.csv`: current AI actual relative event path normalized around peak.
- `current_ai_projected_continuation_path.csv`: current AI projected continuation path after latest observation.
- `aggregate_actual_projected_paths.csv`: actual and projected AI basket, S&P proxy, and NASDAQ paths.
- `stock_actual_projected_paths.csv`: actual and projected paths for AI basket constituents.
