AI Dot-Com Comparison - May 28 Cutoff, 286 Trading Days

This version is built to satisfy the narrative constraints requested:
- current window length around 280-300 trading days
- best-fit dot-com lead above 50 trading days and below 200 trading days
- clean graph files, with arrows/labels placed in the LaTeX slides

Key outputs:
- Analysis cutoff: 2026-05-28
- Window length: 286 trading days
- Current window: 2025-04-08 to 2026-05-28
- Dot-com peak: 2000-03-27
- Best-fit lead: 52 trading days
- Best-fit path correlation: 0.8597
- Best-fit RMSE: 0.1038
- Remaining historical move from matched point: 32.7389%

Note: this is an illustrative path-comparison deck, not a core model input.
