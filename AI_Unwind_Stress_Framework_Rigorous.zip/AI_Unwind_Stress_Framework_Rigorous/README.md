# AI-Led Equity Unwind Stress Framework

This bundle contains the final methodology paper and the executable Python modules that implement every material transformation described in the paper.

## Main deliverables

- `AI_Unwind_Stress_Framework.pdf` - compiled 40-page methodology paper.
- `AI_Unwind_Stress_Framework.tex` - LaTeX source.
- `code/` - standalone Python modules for return estimation, orthogonalization, AI-exposure construction, country-industry lifting, analogue diagnostics, valuation calibration, scenario/horizon construction, single-stock overrides, market-cap overlays, portfolio application, probability estimation, and validation.
- `data/` - exact historical severity sample and reproduced scenario/probability outputs used by the paper.
- `figures/` - figures generated from the model inputs and reproduced calculations.
- `documentation/` - source provenance, code coverage, validation results, parameters, and SHA-256 manifest.

## Final production specification

The AI-excess intensity uses a 60% statistical / 40% economic blend. Country-industry economic relevance uses 35% country / 65% industry. The latent industry tilt is 0.50, AI intensity is bounded to [0, 1.50], the high-AI coherence threshold is 0.50 with a 0.05 margin, and the audited Base valuation severity scalar is 0.6707390702673786.

The five terminal severity anchors are Mild, Base, Severe, Extreme, and Worst. The probability module estimates only `P(S=s | B=1)`, conditional on a qualifying burst with drawdown of at least 40%. It does not estimate the probability or timing of the burst itself.

## Code-to-paper design

There is no separate code appendix. Each core source module is inserted directly in the body of the paper immediately after the theory it implements. The standalone `.py` files are the executable versions of those listings.

See `documentation/CODE_COVERAGE.md` for the one-to-one section mapping.

## Reproduction

Create an environment with Python 3.11+ and install:

```bash
pip install -r requirements.txt
```

The modules are intentionally decomposed by statistical role rather than combined into one monolithic script. Project-specific refresh workflows should provide the raw market/valuation data files to the relevant module. The paper and `documentation/SOURCE_PROVENANCE.md` distinguish reproduced canonical algorithms from third-party/raw source datasets that are not redistributed in this bundle.
