import pandas as pd, numpy as np, math, os, json, textwrap, zipfile, shutil
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE = Path('/mnt/data')
OUTDIR = BASE / 'ai_unwind_single_stock_override_all20_bundle'
OUTDIR.mkdir(exist_ok=True)

# ---------- Helpers ----------

def read_stooq(path):
    df = pd.read_csv(path)
    df['Date'] = pd.to_datetime(df['Date'])
    df = df.sort_values('Date')
    return df[['Date','Close']].rename(columns={'Close':'close'})

def read_investing_like(path, dayfirst=False):
    df = pd.read_csv(path)
    date_col = 'Date'
    df[date_col] = pd.to_datetime(df[date_col], dayfirst=dayfirst)
    # normalize price strings with commas
    price_col = 'Price'
    df[price_col] = (df[price_col].astype(str)
                     .str.replace(',', '', regex=False)
                     .str.replace('K','e3', regex=False)
                     .str.replace('M','e6', regex=False)
                     .str.replace('B','e9', regex=False))
    # handle possible unicode minus? not needed
    def conv(x):
        try:
            return float(eval(str(x))) if any(s in str(x) for s in ['e3','e6','e9']) else float(x)
        except Exception:
            return np.nan
    df[price_col] = df[price_col].map(conv)
    df = df.sort_values(date_col)
    return df[[date_col, price_col]].rename(columns={date_col:'Date', price_col:'close'})

def month_log_returns(price_df, end_date='2026-06-30'):
    s = price_df.set_index('Date')['close'].astype(float)
    s = s[s.index <= pd.Timestamp(end_date)]
    m = s.resample('ME').last().dropna()
    r = np.log(m / m.shift(1)).dropna()
    return r

def ols_slope(y, x):
    x = np.asarray(x)
    y = np.asarray(y)
    xm = x.mean(); ym = y.mean()
    den = ((x-xm)**2).sum()
    if den == 0 or len(x) < 3:
        return np.nan
    return ((x-xm)*(y-ym)).sum() / den

def parse_ff49_daily(path):
    lines = Path(path).read_text(encoding='latin1').splitlines()
    start = None
    for i,l in enumerate(lines):
        if 'Average Value Weighted Returns -- Daily' in l:
            start = i+1
            break
    header = lines[start].split(',')
    data = []
    for l in lines[start+1:]:
        if not l.strip():
            break
        parts = [p.strip() for p in l.split(',')]
        if len(parts) != len(header):
            # if extra commas due truncation, skip
            continue
        data.append(parts)
    df = pd.DataFrame(data, columns=header)
    df.rename(columns={df.columns[0]:'date'}, inplace=True)
    df['date'] = pd.to_datetime(df['date'], format='%Y%m%d')
    for c in df.columns[1:]:
        df[c] = pd.to_numeric(df[c], errors='coerce')
    # convert from percent to decimal simple returns, missing -99.99/-999 to nan
    df = df.replace({-99.99:np.nan, -999:np.nan})
    for c in df.columns[1:]:
        df[c] = df[c] / 100.0
    return df

def parse_spx_daily(path):
    df = pd.read_csv(path)
    if 'date' in df.columns:
        df['Date'] = pd.to_datetime(df['date'], format='%d-%b-%y')
        df['close'] = pd.to_numeric(df['close'], errors='coerce')
    else:
        # fallback maybe SP500 (1).csv or other formats
        datecol = [c for c in df.columns if c.lower().startswith('date')][0]
        closecol = [c for c in df.columns if c.lower() in ('close','price','close*','close/last')][0]
        df['Date'] = pd.to_datetime(df[datecol])
        df['close'] = pd.to_numeric(df[closecol], errors='coerce')
    return df[['Date','close']].sort_values('Date').dropna()

def compute_index_from_simple(returns):
    logp = np.log1p(returns).cumsum()
    idx = np.exp(logp)
    return idx, logp

# ---------- Load existing v5 info ----------
existing = pd.read_csv(BASE / 'single_stock_override_vector_v5(1).csv')
# use v5 theta world reference and kappa from official files
THETA_WORLD = float(existing['theta_ai_abs_world_reference'].iloc[0])
scenario_v5 = pd.read_csv(BASE / 'scenario_parameters_v5.csv')
BASE_KAPPA = float(scenario_v5.loc[scenario_v5['scenario']=='base','valuation_severity_scalar'].iloc[0])
MILD_KAPPA = BASE_KAPPA / 2.0

# ---------- Monthly world & AI basket ----------
world = month_log_returns(read_stooq(BASE / 'spy_us_d (1).csv'))
ai_components = {
    'SMH': month_log_returns(read_stooq(BASE / 'smh_us_d(3).csv')),
    'SOXX': month_log_returns(read_stooq(BASE / 'soxx_us_d(2).csv')),
    'IGV': month_log_returns(read_stooq(BASE / 'igv_us_d(1).csv')),
    'SKYY': month_log_returns(read_stooq(BASE / 'skyy_us_d(1).csv')),
    'AIQ': month_log_returns(read_stooq(BASE / 'aiq_us_d(1).csv')),
}
ai_df = pd.concat(ai_components, axis=1).dropna()
ai_basket = ai_df.mean(axis=1)
# align world and AI
factor_df = pd.concat([world.rename('world'), ai_basket.rename('ai')], axis=1).dropna()
# residual AI factor diagnostic baseline
b_ai_on_world = ols_slope(factor_df['ai'], factor_df['world'])
ai_resid = factor_df['ai'] - b_ai_on_world * factor_df['world']

# ---------- Define 20 override rows ----------
new_specs = [
    ('005930.KS','Samsung Electronics','/mnt/data/Samsung Electronics Co Stock Price History (1).csv','investing',False,0.90),
    ('2330.TW','Taiwan Semiconductor (TW)','/mnt/data/Taiwan Semiconductor Stock Price History (1).csv','investing',False,1.00),
    ('SKSQUARE.KS','SK Square','/mnt/data/SK Square Stock Price History (1).csv','investing',False,0.75),
    ('NBIUS_NV','Nebius NV (history file)','/mnt/data/Nebius NV Stock Price History (1).csv','investing',False,0.85),
    ('TSM','Taiwan Semiconductor ADR','/mnt/data/tsm_us_d.csv','stooq',False,1.00),
    ('SNDK','Sandisk','/mnt/data/sndk_us_d.csv','stooq',False,0.80),
    ('NBIS','Nebius Group NV','/mnt/data/nbis_us_d.csv','stooq',False,0.85),
    ('AAPL','Apple','/mnt/data/aapl_us_d.csv','stooq',False,0.55),
    ('ASML','ASML','/mnt/data/asml_us_d.csv','stooq',False,0.95),
    ('MU','Micron','/mnt/data/mu_us_d.csv','stooq',False,0.90),
    ('000660.KS','SK Hynix','/mnt/data/000660 Historical Data (1).csv','investing',True,1.00),
]

rows = []
# existing rows (9)
name_map = {
    'AMD':'Advanced Micro Devices', 'NVDA':'NVIDIA', 'SMCI':'Super Micro Computer', 'PLTR':'Palantir',
    'AVGO':'Broadcom', 'AMZN':'Amazon', 'META':'Meta Platforms', 'GOOGL':'Alphabet', 'MSFT':'Microsoft'
}
for _,r in existing.iterrows():
    rr = r.to_dict()
    rr['security_name'] = name_map.get(rr['ticker'], rr['ticker'])
    rr['source_file'] = 'existing_v5_override'
    rr['is_legacy_v5_row'] = True
    rows.append(rr)

for ticker, secname, path, kind, dayfirst, econ in new_specs:
    p = Path(path)
    pdf = read_stooq(p) if kind=='stooq' else read_investing_like(p, dayfirst=dayfirst)
    stock = month_log_returns(pdf)
    aligned = pd.concat([stock.rename('stock'), factor_df], axis=1).dropna()
    beta_world = ols_slope(aligned['stock'], aligned['world'])
    theta_ai = ols_slope(aligned['stock'], aligned['ai'])
    # residual ai beta diagnostic using factor_df residual on stock common sample
    ai_resid_aligned = pd.concat([aligned['stock'], ai_resid.rename('ai_resid')], axis=1).dropna()
    resid_beta = ols_slope(ai_resid_aligned['stock'], ai_resid_aligned['ai_resid'])
    stat_raw = (theta_ai - beta_world * THETA_WORLD) / (1.0 - THETA_WORLD)
    stat_clip = min(1.5, max(0.0, stat_raw))
    final_intensity = 0.45 * stat_clip + 0.55 * econ
    rows.append({
        'ticker': ticker,
        'model_scope': 'single_stock_override',
        'beta_world_stock': beta_world,
        'theta_ai_abs_stock': theta_ai,
        'theta_ai_abs_world_reference': THETA_WORLD,
        'stat_ai_excess_intensity_raw': stat_raw,
        'stat_ai_excess_intensity': stat_clip,
        'economic_ai_intensity': econ,
        'statistical_weight': 0.45,
        'economic_weight': 0.55,
        'final_ai_excess_intensity': final_intensity,
        'residual_ai_beta_diagnostic': resid_beta,
        'n_months': len(aligned),
        'formula_log_return': 'beta_world_stock * S_WORLD_log + final_ai_excess_intensity * S_AI_EXCESS_log',
        'recommended_use': 'Use as single-stock override when ticker matches.',
        'security_name': secname,
        'source_file': p.name,
        'is_legacy_v5_row': False,
    })

all20 = pd.DataFrame(rows)
# ensure exactly 20
assert len(all20) == 20, len(all20)

# ---------- Apply terminal scenarios ----------
terminal = all20.copy()
for scen in ['mild','base','severe']:
    row = scenario_v5.loc[scenario_v5['scenario']==scen].iloc[0]
    S_W = float(row['S_WORLD_log'])
    S_X = float(row['S_AI_EXCESS_log'])
    terminal[f'{scen}_stress_log'] = terminal['beta_world_stock'] * S_W + terminal['final_ai_excess_intensity'] * S_X
    terminal[f'{scen}_stress_simple'] = np.exp(terminal[f'{scen}_stress_log']) - 1.0
    terminal[f'{scen}_stress_pct'] = 100 * terminal[f'{scen}_stress_simple']
    terminal[f'{scen}_world_component_log'] = terminal['beta_world_stock'] * S_W
    terminal[f'{scen}_ai_excess_component_log'] = terminal['final_ai_excess_intensity'] * S_X
    terminal[f'{scen}_valuation_severity_scalar'] = float(row['valuation_severity_scalar'])

# ---------- Short-horizon anchor construction ----------
ff49 = parse_ff49_daily(BASE / '49_Industry_Portfolios_Daily.csv')
# If duplicate better file exists, use (1)? but same.
# Build TMT basket: equal-weight value-weighted returns of Hardw, Softw, Chips, Telcm
needed_cols = ['Hardw','Softw','Chips','Telcm']
for c in needed_cols:
    if c not in ff49.columns:
        raise RuntimeError(f'Missing {c} in FF49 daily file')
ff49['tmt_simple'] = ff49[needed_cols].mean(axis=1, skipna=False)
ff49['tmt_log'] = np.log1p(ff49['tmt_simple'])

spx = parse_spx_daily(BASE / 'spx.csv')
spx['spx_log'] = np.log(spx['close'] / spx['close'].shift(1))
spx = spx.dropna()

# align common daily dates
common = pd.merge(ff49[['date','tmt_log','tmt_simple']], spx[['Date','spx_log','close']], left_on='date', right_on='Date', how='inner').drop(columns=['Date'])
common = common.sort_values('date').reset_index(drop=True)
# focus dot-com window for peak determination
common['tmt_log_level'] = common['tmt_log'].cumsum()
window = common[(common['date']>=pd.Timestamp('1998-01-01')) & (common['date']<=pd.Timestamp('2002-12-31'))].copy().reset_index(drop=True)
peak_idx = window['tmt_log_level'].idxmax()
peak_date = window.loc[peak_idx, 'date']
# locate in common
peak_global_idx = common.index[common['date']==peak_date][0]

horizons = {'1w':5, '2w':10, '1m':21}
scen_rows = []
short_outputs = {}
for hname, hdays in horizons.items():
    end_idx = peak_global_idx + hdays
    if end_idx >= len(common):
        raise RuntimeError('Horizon exceeds common series length')
    peak_level_tmt = common.loc[peak_global_idx, 'tmt_log_level']
    end_level_tmt = common.loc[end_idx, 'tmt_log_level']
    S_E_severe = float(end_level_tmt - peak_level_tmt)
    # world using price ratio from peak close to end close
    spx_peak = float(common.loc[peak_global_idx, 'close'])
    spx_end = float(common.loc[end_idx, 'close'])
    S_W_severe = math.log(spx_end / spx_peak)
    S_X_severe = S_E_severe - S_W_severe
    end_date = common.loc[end_idx, 'date']
    cfg = {
        'mild': {'world_scale':0.5, 'kappa':MILD_KAPPA},
        'base': {'world_scale':1.0, 'kappa':BASE_KAPPA},
        'severe': {'world_scale':1.0, 'kappa':1.0},
    }
    scen_df_rows=[]
    for scen, pars in cfg.items():
        S_W = pars['world_scale'] * S_W_severe
        S_X = pars['kappa'] * S_X_severe
        S_E = S_W + S_X
        scen_rows.append({
            'horizon': hname,
            'scenario': scen,
            'horizon_trading_days': hdays,
            'peak_date': peak_date.date().isoformat(),
            'anchor_date': end_date.date().isoformat(),
            'trading_days_to_anchor': hdays,
            'exact_end_date': end_date.date().isoformat(),
            'world_scale': pars['world_scale'],
            'valuation_severity_scalar': pars['kappa'],
            'S_WORLD_raw_dotcom_log': S_W_severe,
            'S_AI_EXCESS_raw_dotcom_log': S_X_severe,
            'S_WORLD_log': S_W,
            'S_AI_EXCESS_log': S_X,
            'S_AI_EPICENTER_log': S_E,
            'S_WORLD_simple': math.exp(S_W)-1.0,
            'S_WORLD_pct': 100*(math.exp(S_W)-1.0),
            'S_AI_EXCESS_simple': math.exp(S_X)-1.0,
            'S_AI_EXCESS_pct': 100*(math.exp(S_X)-1.0),
            'S_AI_EPICENTER_simple': math.exp(S_E)-1.0,
            'S_AI_EPICENTER_pct': 100*(math.exp(S_E)-1.0),
            'description': f'{hname} peak-anchored dot-com short-horizon shock',
            'anchor_method': 'peak_anchored_fixed_horizon_from_ff49_tmt_peak',
            'broad_market_proxy': 'S&P 500 daily close (uploaded spx.csv)',
            'tmt_proxy': 'Equal-weight FF49 Hardw, Softw, Chips, Telcm',
        })
        scen_df_rows.append((scen, S_W, S_X, pars['kappa']))
    # build output dataframe for this horizon
    out = all20.copy()
    out.insert(0, 'short_horizon_anchor_method', 'peak_anchored_fixed_horizon_from_ff49_tmt_peak')
    out.insert(1, 'short_horizon', hname)
    for scen, S_W, S_X, kval in scen_df_rows:
        out[f'{scen}_stress_log'] = out['beta_world_stock'] * S_W + out['final_ai_excess_intensity'] * S_X
        out[f'{scen}_stress_simple'] = np.exp(out[f'{scen}_stress_log']) - 1.0
        out[f'{scen}_stress_pct'] = 100 * out[f'{scen}_stress_simple']
        out[f'{scen}_world_component_log'] = out['beta_world_stock'] * S_W
        out[f'{scen}_ai_excess_component_log'] = out['final_ai_excess_intensity'] * S_X
        out[f'{scen}_valuation_severity_scalar'] = kval
    short_outputs[hname] = out

scenario_short = pd.DataFrame(scen_rows)

# ---------- Save CSVs ----------
terminal_path = BASE / 'single_stock_override_vector_v5_all20.csv'
terminal.to_csv(terminal_path, index=False)
short_paths = {}
for hname, df in short_outputs.items():
    p = BASE / f'ai_unwind_v5_{hname}_all20_single_stock_override.csv'
    df.to_csv(p, index=False)
    short_paths[hname]=p
scenario_path = BASE / 'ai_unwind_v5_all20_single_stock_short_horizon_scenarios.csv'
scenario_short.to_csv(scenario_path, index=False)
combined_summary = []
for hname, df in short_outputs.items():
    for scen in ['mild','base','severe']:
        tmp = df[['ticker','security_name',f'{scen}_stress_pct']].copy()
        tmp['horizon']=hname; tmp['scenario']=scen; tmp.rename(columns={f'{scen}_stress_pct':'stress_pct'}, inplace=True)
        combined_summary.append(tmp)
summary_long = pd.concat(combined_summary, ignore_index=True)
summary_long.to_csv(BASE/'ai_unwind_v5_all20_single_stock_summary_long.csv', index=False)

# ---------- Figures ----------
# sort by 1m base severity
order = short_outputs['1m'].sort_values('base_stress_pct')['ticker'].tolist()

def ordered_vals(df, col):
    return df.set_index('ticker').loc[order, col]

# 1. Base shocks by horizon
plt.figure(figsize=(10,8))
y = np.arange(len(order))
barh = 0.24
for i,hname in enumerate(['1w','2w','1m']):
    vals = ordered_vals(short_outputs[hname], 'base_stress_pct')
    plt.barh(y + (i-1)*barh, vals, height=barh, label=hname)
plt.yticks(y, order)
plt.xlabel('Base stress (%)')
plt.title('All 20 override stocks: base short-horizon stress')
plt.legend()
plt.tight_layout()
fig1 = OUTDIR/'fig_all20_base_by_horizon.png'; plt.savefig(fig1,dpi=180); plt.close()

# 2. Severe shocks by horizon
plt.figure(figsize=(10,8))
for i,hname in enumerate(['1w','2w','1m']):
    vals = ordered_vals(short_outputs[hname], 'severe_stress_pct')
    plt.barh(y + (i-1)*barh, vals, height=barh, label=hname)
plt.yticks(y, order)
plt.xlabel('Severe stress (%)')
plt.title('All 20 override stocks: severe short-horizon stress')
plt.legend()
plt.tight_layout()
fig2 = OUTDIR/'fig_all20_severe_by_horizon.png'; plt.savefig(fig2,dpi=180); plt.close()

# 3. Scatter beta vs AI intensity
plotdf = all20.copy()
plt.figure(figsize=(9,7))
plt.scatter(plotdf['beta_world_stock'], plotdf['final_ai_excess_intensity'])
for _,r in plotdf.iterrows():
    plt.text(r['beta_world_stock']+0.01, r['final_ai_excess_intensity']+0.01, r['ticker'], fontsize=7)
plt.xlabel('World beta')
plt.ylabel('Final AI-excess intensity')
plt.title('Override stock exposures: world beta vs AI-excess intensity')
plt.tight_layout()
fig3 = OUTDIR/'fig_beta_ai_scatter.png'; plt.savefig(fig3,dpi=180); plt.close()

# 4. Heatmap of base stress by horizon
heat = pd.DataFrame({h: short_outputs[h].set_index('ticker')['base_stress_pct'] for h in ['1w','2w','1m']}).loc[order]
plt.figure(figsize=(7,10))
plt.imshow(heat.values, aspect='auto')
plt.xticks(range(heat.shape[1]), heat.columns)
plt.yticks(range(heat.shape[0]), heat.index)
for i in range(heat.shape[0]):
    for j in range(heat.shape[1]):
        plt.text(j, i, f"{heat.values[i,j]:.1f}", ha='center', va='center', fontsize=7)
plt.colorbar(label='Base stress (%)')
plt.title('Base stress heatmap: 20 override stocks')
plt.tight_layout()
fig4 = OUTDIR/'fig_base_heatmap.png'; plt.savefig(fig4,dpi=180); plt.close()

# 5. Scenario anchor chart
anchor_plot = scenario_short.pivot(index='horizon', columns='scenario', values='S_AI_EPICENTER_pct').loc[['1w','2w','1m'], ['mild','base','severe']]
plt.figure(figsize=(7,5))
x = np.arange(len(anchor_plot.index)); width=0.25
for i,scen in enumerate(['mild','base','severe']):
    plt.bar(x+(i-1)*width, anchor_plot[scen], width=width, label=scen)
plt.xticks(x, anchor_plot.index)
plt.ylabel('AI epicenter shock (%)')
plt.title('Dot-com peak-anchored short-horizon shock ladder')
plt.legend()
plt.tight_layout()
fig5 = OUTDIR/'fig_scenario_anchor.png'; plt.savefig(fig5,dpi=180); plt.close()

# ---------- Report tables ----------
# build top table by 1m base
rep = short_outputs['1m'][['ticker','security_name','beta_world_stock','final_ai_excess_intensity','base_stress_pct','severe_stress_pct']].copy()
rep = rep.sort_values('base_stress_pct')
# write simple latex report with only graphicx
report_tex = BASE/'ai_unwind_all20_single_stock_override_report.tex'
report_pdf = BASE/'ai_unwind_all20_single_stock_override_report.pdf'

# small helper table rows

def latex_escape(s):
    return str(s).replace('&','\\&').replace('%','\\%').replace('_','\\_')

anchor_rows = []
for hname in ['1w','2w','1m']:
    sub = scenario_short[scenario_short['horizon']==hname].set_index('scenario')
    anchor_rows.append(f"{hname} & {sub.loc['mild','S_WORLD_pct']:.2f} & {sub.loc['mild','S_AI_EXCESS_pct']:.2f} & {sub.loc['base','S_WORLD_pct']:.2f} & {sub.loc['base','S_AI_EXCESS_pct']:.2f} & {sub.loc['severe','S_WORLD_pct']:.2f} & {sub.loc['severe','S_AI_EXCESS_pct']:.2f} \\")

# summary by stock table (20 rows)
stock_rows = []
summary = short_outputs['1m'][['ticker','security_name','beta_world_stock','final_ai_excess_intensity']].copy()
summary = summary.set_index('ticker')
summary['1w_base'] = short_outputs['1w'].set_index('ticker')['base_stress_pct']
summary['2w_base'] = short_outputs['2w'].set_index('ticker')['base_stress_pct']
summary['1m_base'] = short_outputs['1m'].set_index('ticker')['base_stress_pct']
summary = summary.loc[order].reset_index()
for _,r in summary.iterrows():
    stock_rows.append(f"{latex_escape(r['ticker'])} & {latex_escape(r['security_name'])} & {r['beta_world_stock']:.2f} & {r['final_ai_excess_intensity']:.2f} & {r['1w_base']:.1f} & {r['2w_base']:.1f} & {r['1m_base']:.1f} \\")

report_text = rf'''
\documentclass[10pt]{{article}}
\usepackage{{graphicx}}
\setlength{{\parindent}}{{0pt}}
\begin{{document}}
\title{{AI Unwind Stress Framework: All-20 Single-Stock Override Extension}}
\author{{Alex Zhang}}
\date{{July 2026}}
\maketitle

\section*{{Executive summary}}
This note extends the single-stock override layer of the AI unwind stress framework from the original 9 legacy override names to a 20-row override universe. The extension retains the same modeling structure used in the main framework. For each stock $i$, the stressed log return is
\[
\widehat R_i^{{s,h}} = \beta_i^W S_W^{{s,h}} + I_i^{{AI}} S_X^{{s,h}},
\]
where $\beta_i^W$ is the stock's world beta, $I_i^{{AI}}$ is the final AI-excess intensity, $S_W^{{s,h}}$ is the broad-market shock for scenario $s$ and horizon $h$, and $S_X^{{s,h}}$ is the AI/TMT excess shock over the market. Horizons are 1 week (5 trading days), 2 weeks (10 trading days), and 1 month (21 trading days). Mild, base, and severe are defined in the same way as before: mild uses one-half of the world shock and one-half of the base valuation severity scalar, base uses the full world shock and the v5 base severity scalar, and severe uses the full world shock and the full dot-com excess shock.

The 20 override rows consist of the 9 original U.S. epicenter names plus 11 newly added names or listings supplied in the current research update. The broad-market leg for the short-horizon anchor uses the uploaded daily S\&P 500 history. The technology epicenter leg uses a daily equal-weight basket of Fama--French 49 industry returns for hardware, software, chips, and telecom. The peak date of the TMT basket in the dot-com boom is used as the common anchor date, and the 1w, 2w, and 1m drawdowns are measured directly from that peak rather than being inferred by scaling the peak-to-trough shock.

\section*{{Data and methodology}}
The monthly exposure estimation step uses monthly log returns from the uploaded daily stock files, the SPY world proxy, and the AI basket proxy defined as the equal-weight average of SMH, SOXX, IGV, SKYY, and AIQ monthly log returns through June 2026. The original v5 world-reference AI beta, $\theta_W^{{AI}}={THETA_WORLD:.6f}$, is retained to keep the extension consistent with the existing override vector. For the newly added names, the raw statistical AI-excess intensity is
\[
I_{{i,raw}}^{{stat}} = \frac{{\theta_i^{{AI}} - \beta_i^W \theta_W^{{AI}}}}{{1-\theta_W^{{AI}}}},
\]
with the same $[0,1.5]$ clipping convention as the original override layer. The final AI-excess intensity is then
\[
I_i^{{AI}} = 0.45 I_i^{{stat}} + 0.55 I_i^{{econ}},
\]
where $I_i^{{econ}}$ is the stock-specific economic AI relevance score.

For the short-horizon scenario anchor, let $t_0$ be the peak date of the daily dot-com TMT basket. For each horizon $h \in \{{5,10,21\}}$, let $t_h$ be the trading date exactly $h$ trading sessions after $t_0$. The severe shocks are then measured directly as
\[
S_E^h = \log \left( \frac{{P_E(t_h)}}{{P_E(t_0)}} \right), \qquad
S_W^h = \log \left( \frac{{P_W(t_h)}}{{P_W(t_0)}} \right), \qquad
S_X^h = S_E^h - S_W^h,
\]
where $P_E$ is the TMT epicenter index and $P_W$ is the broad-market S\&P 500 index. Base and mild are scaled from the severe excess shock using the same v5 valuation-severity logic.

\section*{{Scenario anchor results}}
\begin{{center}}
\begin{{tabular}}{{lrrrrrr}}
Horizon & Mild $S_W$ & Mild $S_X$ & Base $S_W$ & Base $S_X$ & Severe $S_W$ & Severe $S_X$ \\
\hline
{chr(10).join(anchor_rows)}
\hline
\end{{tabular}}
\end{{center}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.78\textwidth]{{{fig5.as_posix()}}}
\caption{{Peak-anchored dot-com short-horizon shock ladder.}}
\end{{figure}}

\section*{{Cross-sectional results for all 20 override rows}}
\begin{{figure}}[h!]
\centering
\includegraphics[width=0.95\textwidth]{{{fig1.as_posix()}}}
\caption{{Base short-horizon stress for all 20 override rows.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.95\textwidth]{{{fig2.as_posix()}}}
\caption{{Severe short-horizon stress for all 20 override rows.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.75\textwidth]{{{fig3.as_posix()}}}
\caption{{Override stock exposures: world beta versus final AI-excess intensity.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.58\textwidth]{{{fig4.as_posix()}}}
\caption{{Base-stress heatmap across 1w, 2w, and 1m horizons.}}
\end{{figure}}

\clearpage
\section*{{All-20 summary table}}
\begin{{center}}
\small
\begin{{tabular}}{{llrrrrr}}
Ticker & Security & $\beta^W$ & $I^{{AI}}$ & 1w base & 2w base & 1m base \\
\hline
{chr(10).join(stock_rows)}
\hline
\end{{tabular}}
\end{{center}}

\section*{{Delivered files}}
The main output files are: \texttt{{single\_stock\_override\_vector\_v5\_all20.csv}} for the peak-to-trough override extension, \texttt{{ai\_unwind\_v5\_1w\_all20\_single\_stock\_override.csv}}, \texttt{{ai\_unwind\_v5\_2w\_all20\_single\_stock\_override.csv}}, and \texttt{{ai\_unwind\_v5\_1m\_all20\_single\_stock\_override.csv}} for the short horizons, plus \texttt{{ai\_unwind\_v5\_all20\_single\_stock\_short\_horizon\_scenarios.csv}} for the underlying scenario parameters.

\end{{document}}
'''
report_tex.write_text(report_text)

# copy figures to base for easy bundling and tex relative paths absolute already; compile should work.
# Compile latex
os.chdir(BASE)
os.system(f'pdflatex -interaction=nonstopmode {report_tex.name} > /tmp/latex_all20.log 2>&1')
os.system(f'pdflatex -interaction=nonstopmode {report_tex.name} >> /tmp/latex_all20.log 2>&1')

# ---------- Bundle ----------
# copy source assets into outdir
for f in [terminal_path, scenario_path, BASE/'ai_unwind_v5_all20_single_stock_summary_long.csv', report_tex, report_pdf] + list(short_paths.values()) + [fig1,fig2,fig3,fig4,fig5, BASE/'build_all20_override.py']:
    fp=Path(f)
    if fp.exists():
        dst = OUTDIR / fp.name
        if fp.resolve() != dst.resolve():
            shutil.copy2(fp, dst)
zip_path = BASE/'ai_unwind_all20_single_stock_override_bundle.zip'
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in OUTDIR.iterdir():
        z.write(p, arcname=p.name)

# print brief summary
print('Built files:')
for p in [terminal_path, *short_paths.values(), scenario_path, report_pdf, report_tex, zip_path]:
    print(p, p.exists())
print('Peak date', peak_date, 'THETA_WORLD', THETA_WORLD, 'BASE_KAPPA', BASE_KAPPA)
print(summary.head())
