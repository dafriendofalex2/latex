# Vanilla LaTeX build

This version is intentionally built with default LaTeX only.

`main.tex` uses only:

```tex
\documentclass[11pt]{article}
\usepackage{graphicx}
```

No `geometry`, `booktabs`, `longtable`, `natbib`, `biblatex`, `fontspec`, `hyperref`, `enumitem`, `setspace`, `xcolor`, `caption`, or `subcaption` packages are required.

To compile on MiKTeX/TeX Live, run:

```bash
pdflatex main.tex
pdflatex main.tex
```

On Windows, double-click or run:

```bat
compile_vanilla.bat
```

No Perl/latexmk is needed.
