AI Dot-Com Comparison - Jul. 14 cutoff, 300 trading day window

This bundle uses a fixed Jul. 14, 2026 cutoff and a 300-trading-day window, as requested.

Key outputs
- Window length: 300 trading days
- Current window: 2025-05-02 to 2026-07-14
- Dot-com peak: 2000-03-27
- Best-fit lead: 300 trading days
- Final-window path correlation: 0.8371
- Final-window RMSE: 0.1672
- Best-fit RMSE: 0.0690
- Best-fit correlation: 0.9384
- Remaining historical move from matched point: 131.3373%

Note
With a Jul. 14, 2026 cutoff and a window around 300 days, the best-fit lead sits near the boundary. This bundle keeps the requested specification but should be interpreted as a narrative similarity deck rather than a strict timing exercise.
