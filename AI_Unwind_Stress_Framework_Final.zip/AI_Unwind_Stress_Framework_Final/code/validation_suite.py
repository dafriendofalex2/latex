"""Model validation invariants and reproducibility checks."""
from __future__ import annotations

import numpy as np
import pandas as pd


def check_probability_vector(probabilities, tolerance: float = 1e-10):
    p = np.asarray(probabilities, dtype=float)
    return {
        "nonnegative": bool(np.all(p >= -tolerance)),
        "sums_to_one": bool(abs(p.sum() - 1.0) <= tolerance),
        "sum": float(p.sum()),
    }


def check_scenario_order(scenario_df: pd.DataFrame):
    order = ["mild", "base", "severe", "extreme", "worst"]
    d = scenario_df.set_index("scenario")["S_AI_EPICENTER_log"].reindex(order).to_numpy(float)
    # More severe scenario means a weakly more negative log shock.
    return {"ordered": bool(np.all(np.diff(d) <= 1e-12)), "values": d.tolist()}


def check_log_simple_identity(log_return, simple_return, tolerance: float = 1e-12):
    lhs = np.exp(np.asarray(log_return, dtype=float)) - 1.0
    rhs = np.asarray(simple_return, dtype=float)
    err = np.nanmax(np.abs(lhs - rhs))
    return {"max_abs_error": float(err), "pass": bool(err <= tolerance)}


def check_component_identity(total_log, market_log, ai_log, size_log=0.0, tolerance: float = 1e-12):
    err = np.nanmax(np.abs(
        np.asarray(total_log, dtype=float)
        - np.asarray(market_log, dtype=float)
        - np.asarray(ai_log, dtype=float)
        - np.asarray(size_log, dtype=float)
    ))
    return {"max_abs_error": float(err), "pass": bool(err <= tolerance)}


def check_ai_intensity_bounds(values, lower=0.0, upper=1.5, tolerance=1e-12):
    x = np.asarray(values, dtype=float)
    return {
        "minimum": float(np.nanmin(x)),
        "maximum": float(np.nanmax(x)),
        "pass": bool(np.nanmin(x) >= lower - tolerance and np.nanmax(x) <= upper + tolerance),
    }


def check_large_cap_zero_overlay(size_overlay: pd.DataFrame, reference_bucket="large_mega", tolerance=1e-12):
    x = size_overlay[size_overlay["cap_bucket"] == reference_bucket]["size_overlay_log"].to_numpy(float)
    err = float(np.max(np.abs(x))) if len(x) else np.inf
    return {"max_abs_overlay": err, "pass": bool(err <= tolerance)}
