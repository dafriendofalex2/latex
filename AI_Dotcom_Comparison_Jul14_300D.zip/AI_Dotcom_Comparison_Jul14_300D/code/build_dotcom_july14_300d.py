from __future__ import annotations
from pathlib import Path
import shutil, zipfile, subprocess

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

BASE = Path('/mnt/data/AI_Dotcom_Comparison_Jul14_300D')
FIG = BASE / 'figures'
DATA = BASE / 'data'
CODE = BASE / 'code'
SRC = Path('/mnt/data/^ndx_d.csv')
N = 300
SMOOTH = 20
MAX_LEAD = 300
CUTOFF = pd.Timestamp('2026-07-14')

NAVY = '#06154A'
ORANGE = '#C85A1E'
DASH = '#355C7D'
LIGHTBG = '#F7F2EA'

for p in [BASE, FIG, DATA, CODE]:
    p.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'axes.titlesize': 13,
    'axes.labelsize': 10.5,
    'legend.fontsize': 8.5,
    'xtick.labelsize': 9,
    'ytick.labelsize': 9,
})


def read_ndx(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path, parse_dates=['Date'])
    return df.sort_values('Date').dropna(subset=['Close']).reset_index(drop=True)


def norm_log(close) -> np.ndarray:
    arr = np.asarray(close, dtype=float)
    return np.log(arr / arr[0])


def smooth_path(x: np.ndarray, w: int = SMOOTH) -> np.ndarray:
    return pd.Series(x).rolling(w, min_periods=1).mean().to_numpy()


def fit_lead(current: pd.Series, reference: pd.Series, peak_pos: int,
             n: int = N, max_lead: int = MAX_LEAD) -> pd.DataFrame:
    x = smooth_path(norm_log(current.iloc[-n:]))
    rows = []
    for lead in range(max_lead + 1):
        end = peak_pos - lead
        start = end - n + 1
        if start < 0:
            continue
        ref = reference.iloc[start:end + 1]
        if len(ref) != n:
            continue
        y = smooth_path(norm_log(ref))
        rows.append({
            'lead_days': lead,
            'rmse_log_level': float(np.sqrt(np.mean((x - y) ** 2))),
            'corr_smoothed_level': float(np.corrcoef(x, y)[0, 1]),
            'start_pos': start,
            'end_pos': end,
        })
    return pd.DataFrame(rows)


def save_fig(fig, path: Path):
    fig.tight_layout()
    fig.savefig(path, dpi=240, facecolor='white')
    plt.close(fig)


def main():
    df_all = read_ndx(SRC)
    df_cur_all = df_all[df_all['Date'] <= CUTOFF].reset_index(drop=True)
    close_all = df_all['Close']
    dates_all = df_all['Date']
    dot_mask = (dates_all >= pd.Timestamp('1998-01-01')) & (dates_all <= pd.Timestamp('2002-12-31'))
    peak_pos = int(close_all[dot_mask].idxmax())
    peak_date = dates_all.iloc[peak_pos]

    cur = df_cur_all.iloc[-N:].copy()
    full_dot = df_all.iloc[peak_pos - N + 1:peak_pos + 1].copy()

    x_cur = norm_log(cur['Close'])
    x_dot_full = norm_log(full_dot['Close'])
    sx_cur = smooth_path(x_cur)
    sx_dot_full = smooth_path(x_dot_full)

    objective = fit_lead(cur['Close'], close_all, peak_pos)
    best = objective.loc[objective['rmse_log_level'].idxmin()].copy()
    lead = int(best['lead_days'])
    match = df_all.iloc[int(best['start_pos']):int(best['end_pos']) + 1].copy()
    after = df_all.iloc[int(best['end_pos']):peak_pos + 1].copy()
    x_match = norm_log(match['Close'])
    sx_match = smooth_path(x_match)

    fig, ax = plt.subplots(figsize=(8.6, 5.1))
    ax.plot(x_cur, color=NAVY, linewidth=2.0, label=f'Current NASDAQ (past {N} trading days, ending Jul. 14, 2026)')
    ax.plot(x_dot_full, color=ORANGE, linewidth=2.0, label=f'Historical NASDAQ (final {N} trading days before dot-com peak)')
    ax.set_xlabel('Trading days from window start')
    ax.set_ylabel('Normalized log price')
    ax.set_title(f'Current run-up and the final {N}-trading-day dot-com ascent')
    ax.legend(loc='upper left', frameon=False)
    for s in ax.spines.values():
        s.set_linewidth(1.0)
    save_fig(fig, FIG / 'figure1_naive_price.png')

    fig, ax = plt.subplots(figsize=(8.2, 4.9))
    ax.plot(objective['lead_days'], objective['rmse_log_level'], color=NAVY, linewidth=2.2)
    ax.scatter([lead], [best['rmse_log_level']], color=NAVY, s=32, zorder=3)
    ax.axvline(lead, linestyle='--', color=NAVY, linewidth=1.0)
    ax.set_xlabel('Lead to dot-com peak (trading days)')
    ax.set_ylabel('RMSE between smoothed normalized log paths')
    ax.set_title('Distance minimization over time shift')
    for s in ax.spines.values():
        s.set_linewidth(1.0)
    save_fig(fig, FIG / 'figure2_objective_curve.png')

    fig, ax = plt.subplots(figsize=(8.8, 5.15))
    ax.plot(x_cur, color=NAVY, linewidth=2.0, label=f'Current NASDAQ (past {N} trading days, ending Jul. 14, 2026)')
    ax.plot(x_match, color=ORANGE, linewidth=2.0, label=f'Historical NASDAQ (segment ending {lead} days before peak)')
    future_x = np.arange(len(match) - 1, len(match) - 1 + len(after))
    future_y = norm_log(after['Close']) - norm_log(after['Close'])[0] + x_match[-1]
    ax.plot(future_x, future_y, color=DASH, linestyle='--', linewidth=2.0, label='Dot-com path from matched point to peak')
    ax.axvline(len(match) - 1, linestyle=':', color='gray', linewidth=1.0)
    ax.set_xlabel('Trading days from start of matched window')
    ax.set_ylabel('Normalized log price')
    ax.set_title('Best-fit time-shifted overlay')
    ax.legend(loc='upper left', frameon=False)
    for s in ax.spines.values():
        s.set_linewidth(1.0)
    save_fig(fig, FIG / 'figure3_bestfit_overlay.png')

    final_corr = float(np.corrcoef(sx_dot_full, sx_cur)[0, 1])
    final_rmse = float(np.sqrt(np.mean((sx_dot_full - sx_cur) ** 2)))
    best_corr = float(best['corr_smoothed_level'])
    best_rmse = float(best['rmse_log_level'])
    cur_gain = float(np.exp(x_cur[-1] - x_cur[0]) - 1)
    dot_gain = float(np.exp(x_dot_full[-1] - x_dot_full[0]) - 1)
    future_gain = float(np.exp(future_y[-1] - future_y[0]) - 1.0)

    summary = pd.DataFrame([{
        'data_file': SRC.name,
        'index': 'NASDAQ-100 (^NDX)',
        'current_window_start': cur['Date'].iloc[0].date().isoformat(),
        'current_window_end': cur['Date'].iloc[-1].date().isoformat(),
        'available_data_end_in_file': df_all['Date'].iloc[-1].date().isoformat(),
        'chosen_sample_cutoff': df_cur_all['Date'].iloc[-1].date().isoformat(),
        'dotcom_peak_date': peak_date.date().isoformat(),
        'window_trading_days': N,
        'smoothing_trading_days': SMOOTH,
        'lead_search_min_days': 0,
        'lead_search_max_days': MAX_LEAD,
        'best_fit_lead_days': lead,
        'best_fit_segment_start': match['Date'].iloc[0].date().isoformat(),
        'best_fit_segment_end': match['Date'].iloc[-1].date().isoformat(),
        'best_fit_rmse_smoothed_log': best_rmse,
        'best_fit_corr_smoothed_log': best_corr,
        'final_window_corr_smoothed_log': final_corr,
        'final_window_rmse_smoothed_log': final_rmse,
        'current_window_simple_return': cur_gain,
        'dotcom_final_window_simple_return': dot_gain,
        'historical_remaining_move_from_matched_point': future_gain,
    }])
    summary.to_csv(DATA / 'comparison_summary.csv', index=False)
    objective.to_csv(DATA / 'time_shift_objective.csv', index=False)
    pd.DataFrame({
        'day': np.arange(N),
        'current_normalized_log': x_cur,
        'dotcom_final_window_normalized_log': x_dot_full,
        'current_smoothed_log': sx_cur,
        'dotcom_final_window_smoothed_log': sx_dot_full,
        'bestfit_dotcom_normalized_log': x_match,
        'bestfit_dotcom_smoothed_log': sx_match,
    }).to_csv(DATA / 'overlay_paths.csv', index=False)
    shutil.copy2(SRC, DATA / SRC.name)

    tex = rf'''
\documentclass[aspectratio=169,10pt]{{beamer}}
\usepackage{{amsmath,amssymb,graphicx,xcolor,tikz}}
\usetikzlibrary{{positioning,calc}}
\usefonttheme{{professionalfonts}}
\setbeamertemplate{{navigation symbols}}{{}}
\definecolor{{citinavy}}{{HTML}}{{06154A}}
\definecolor{{lightbg}}{{HTML}}{{F7F2EA}}
\setbeamercolor{{background canvas}}{{bg=lightbg}}
\setbeamercolor{{frametitle}}{{fg=citinavy}}
\setbeamerfont{{frametitle}}{{size=\Large,series=\mdseries}}
\setbeamercolor{{normal text}}{{fg=black}}
\newcommand{{\footercommon}}{{%
\begin{{tikzpicture}}[remember picture,overlay]
\node[anchor=south west, text=citinavy, font=\bfseries\large] at ([xshift=0.35cm,yshift=0.16cm]current page.south west) {{citi}};
\node[anchor=south east, text=black!70, font=\tiny, align=right] at ([xshift=-0.35cm,yshift=0.18cm]current page.south east) {{NASDAQ data through Jul. 14, 2026 close\\Illustrative similarity exercise, not a model input}};
\end{{tikzpicture}}}}
\newcommand{{\varblock}}[1]{{\begin{{block}}{{Variable labels}}\scriptsize #1\end{{block}}}}
\begin{{document}}

\begin{{frame}}{{The Dot-Com Bubble vs AI Bubble Price}}
\footercommon
\begin{{columns}}[T,onlytextwidth]
\begin{{column}}{{0.28\textwidth}}
\vspace{{0.1cm}}
For narrative illustration, use a \textbf{{{N}-trading-day}} window ending on Jul. 14, 2026. This keeps the comparison focused on the run-up itself rather than the later pullback and rebound.
\[
 x_t = \log\left(\frac{{P_t}}{{P_0}}\right), \qquad t = 0,1,\dots,N-1.
\]
\varblock{{
$P_t$: NASDAQ close on day $t$\\
$P_0$: first close in the window\\
$x_t$: normalized log price\\
$N$: {N} trading days\\
Current window: {summary.iloc[0]['current_window_start']} to {summary.iloc[0]['current_window_end']}\\
Dot-com peak date: {summary.iloc[0]['dotcom_peak_date']}}}
\end{{column}}
\begin{{column}}{{0.70\textwidth}}
\begin{{tikzpicture}}
\node[anchor=south west, inner sep=0] (img) at (0,0) {{\includegraphics[width=\linewidth]{{figures/figure1_naive_price.png}}}};
\node[draw=citinavy, rounded corners=2pt, fill=white, inner sep=2pt, font=\scriptsize, text width=2.55cm, align=left] at ([xshift=6.8cm,yshift=3.4cm]img.south west) {{Similar rising shape\\through the run-up}};
\draw[->, thick, color=citinavy] ([xshift=6.15cm,yshift=3.12cm]img.south west) -- ([xshift=4.75cm,yshift=2.10cm]img.south west);
\end{{tikzpicture}}
\end{{column}}
\end{{columns}}
\end{{frame}}

\begin{{frame}}{{The Dot-Com Bubble vs AI Bubble}}
\footercommon
\begin{{columns}}[T,onlytextwidth]
\begin{{column}}{{0.33\textwidth}}
\vspace{{0.08cm}}
For each candidate lead $\ell$ to the dot-com peak, extract the historical segment that ends $\ell$ trading days before the peak and compute the smoothed path distance
\[
 d(\ell)=\sqrt{{\frac{{1}}{{N}}\sum_{{t=0}}^{{N-1}}\left(\widetilde{{x}}_t^A-\widetilde{{x}}_t^{{D,\ell}}\right)^2 }}.
\]
The best alignment is
\[
 \widehat{{\ell}}=\arg\min_{{\ell\in\{{0,\dots,{MAX_LEAD}\}}}} d(\ell).
\]
\varblock{{
$A$: current NASDAQ period\\
$D$: dot-com NASDAQ reference\\
$\ell$: days from segment end to dot-com peak\\
$\widetilde{{x}}$: 20-day smoothed normalized log path\\
$d(\ell)$: RMSE path distance\\
$\widehat{{\ell}}$: best-fit lead}}
\end{{column}}
\begin{{column}}{{0.65\textwidth}}
\begin{{tikzpicture}}
\node[anchor=south west, inner sep=0] (img) at (0,0) {{\includegraphics[width=\linewidth]{{figures/figure2_objective_curve.png}}}};
\node[draw=citinavy, rounded corners=2pt, fill=white, inner sep=2pt, font=\scriptsize, text width=2.8cm, align=left] at ([xshift=1.1cm,yshift=3.0cm]img.south west) {{Best fit occurs at\\\textbf{{{lead} trading days}} before the peak.}};
\draw[->, thick, color=citinavy] ([xshift=1.15cm,yshift=2.55cm]img.south west) -- ([xshift=6.9cm,yshift=0.90cm]img.south west);
\end{{tikzpicture}}
\end{{column}}
\end{{columns}}
\end{{frame}}

\begin{{frame}}{{The Dot-Com Bubble vs AI Bubble Time Shift}}
\footercommon
\begin{{columns}}[T,onlytextwidth]
\begin{{column}}{{0.30\textwidth}}
\vspace{{0.08cm}}
The matched dot-com segment ends $\widehat{{\ell}}$ trading days before the historical peak. The remaining historical move from the matched point to the peak is
\[
 g_{{\mathrm{{hist}}}} = \exp\!\left(x^D_{{\mathrm{{peak}}}} - x^D_{{\mathrm{{match}}}}\right) - 1.
\]
For the {N}-day comparison window,
\[
 \widehat{{\ell}} = {lead}, \qquad g_{{\mathrm{{hist}}}} = {future_gain*100:.1f}\%.
\]
\varblock{{
$x^D_{{\mathrm{{match}}}}$: matched dot-com endpoint\\
$x^D_{{\mathrm{{peak}}}}$: historical dot-com peak\\
$g_{{\mathrm{{hist}}}}$: remaining move from matched point to peak\\
Dashed segment: historical continuation to the peak}}
\end{{column}}
\begin{{column}}{{0.68\textwidth}}
\begin{{tikzpicture}}
\node[anchor=south west, inner sep=0] (img) at (0,0) {{\includegraphics[width=\linewidth]{{figures/figure3_bestfit_overlay.png}}}};
\node[draw=citinavy, rounded corners=2pt, fill=white, inner sep=2pt, font=\scriptsize, align=left, text width=2.55cm] at ([xshift=6.6cm,yshift=2.7cm]img.south west) {{Historical continuation\\to peak}};
\draw[->, thick, color=citinavy] ([xshift=6.0cm,yshift=2.55cm]img.south west) -- ([xshift=5.15cm,yshift=2.05cm]img.south west);
\node[draw=citinavy, rounded corners=2pt, fill=white, inner sep=2pt, font=\scriptsize, align=center, text width=2.85cm] at ([xshift=6.95cm,yshift=1.0cm]img.south west) {{Remaining historical move\\from matched point\\\textbf{{{future_gain*100:.1f}\%}}}};
\draw[->, thick, color=citinavy] ([xshift=6.0cm,yshift=1.08cm]img.south west) -- ([xshift=5.35cm,yshift=1.34cm]img.south west);
\end{{tikzpicture}}
\end{{column}}
\end{{columns}}
\end{{frame}}

\begin{{frame}}{{Statistical Comparison}}
\footercommon
\begin{{columns}}[T,onlytextwidth]
\begin{{column}}{{0.54\textwidth}}
\vspace{{0.05cm}}
To summarize shape similarity, align the two main paths by months-to-end and compare cumulative log indexes. Let
\[
 z_t^D = \log(I_t^D/100), \qquad z_t^A = \log(I_t^A/100).
\]
The path correlation is
\[
 \rho_{{\mathrm{{path}}}} = \operatorname{{corr}}\!\left(\widetilde{{z}}_t^D,\widetilde{{z}}_t^A\right),
\]
and the path distance is
\[
 \mathrm{{RMSE}} = \sqrt{{\frac{{1}}{{T}}\sum_{{t=1}}^T\left(\widetilde{{z}}_t^D-\widetilde{{z}}_t^A\right)^2}}.
\]
\varblock{{
$I_t$: rebased price index with $I_0=100$\\
$A$: current path; $D$: final pre-peak dot-com path\\
$T={N}$ observations\\
$\rho_{{\mathrm{{path}}}}$: shape correlation\\
RMSE: average cumulative log-price distance}}
\end{{column}}
\begin{{column}}{{0.42\textwidth}}
\vspace{{0.65cm}}
\begin{{tikzpicture}}
\node[draw=citinavy, rounded corners=2pt, line width=0.9pt, minimum width=5.2cm, minimum height=1.2cm] (a) at (0,0) {{\LARGE $\rho_{{\mathrm{{path}}}} = $ \textcolor{{citinavy}}{{{final_corr:.2f}}}}};
\node[below=0.10cm of a, text=citinavy, font=\scriptsize] {{Where 1 is perfect correlation, and 0 is no correlation}};
\node[draw=citinavy, rounded corners=2pt, line width=0.9pt, minimum width=5.2cm, minimum height=1.2cm] (b) at (0,-2.2) {{\LARGE RMSE $= $ \textcolor{{citinavy}}{{{final_rmse:.2f}}}}};
\node[below=0.10cm of b, text=citinavy, font=\scriptsize] {{Where 0 is no error, and larger values mean greater distance}};
\end{{tikzpicture}}
\end{{column}}
\end{{columns}}
\end{{frame}}

\end{{document}}
'''
    tex_path = BASE / 'AI_Dotcom_Comparison_Jul14_300D.tex'
    tex_path.write_text(tex, encoding='utf-8')

    readme = f'''AI Dot-Com Comparison - Jul. 14 cutoff, 300 trading day window\n\nThis bundle uses a fixed Jul. 14, 2026 cutoff and a 300-trading-day window, as requested.\n\nKey outputs\n- Window length: {N} trading days\n- Current window: {summary.iloc[0]['current_window_start']} to {summary.iloc[0]['current_window_end']}\n- Dot-com peak: {summary.iloc[0]['dotcom_peak_date']}\n- Best-fit lead: {lead} trading days\n- Final-window path correlation: {final_corr:.4f}\n- Final-window RMSE: {final_rmse:.4f}\n- Best-fit RMSE: {best_rmse:.4f}\n- Best-fit correlation: {best_corr:.4f}\n- Remaining historical move from matched point: {future_gain:.4%}\n\nNote\nWith a Jul. 14, 2026 cutoff and a window around 300 days, the best-fit lead sits near the boundary. This bundle keeps the requested specification but should be interpreted as a narrative similarity deck rather than a strict timing exercise.\n'''
    (BASE / 'README.md').write_text(readme, encoding='utf-8')
    shutil.copy2(Path(__file__), CODE / 'build_dotcom_july14_300d.py')

    subprocess.run(['pdflatex', '-interaction=nonstopmode', tex_path.name], cwd=BASE, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    subprocess.run(['pdflatex', '-interaction=nonstopmode', tex_path.name], cwd=BASE, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    for ext in ['aux','log','nav','out','snm','toc']:
        f = BASE / f'AI_Dotcom_Comparison_Jul14_300D.{ext}'
        if f.exists():
            f.unlink()

    zip_path = Path('/mnt/data/AI_Dotcom_Comparison_Jul14_300D.zip')
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in BASE.rglob('*'):
            if f.is_file():
                z.write(f, f.relative_to(BASE.parent))
    print(summary.to_string(index=False))
    print(zip_path)

if __name__ == '__main__':
    main()
