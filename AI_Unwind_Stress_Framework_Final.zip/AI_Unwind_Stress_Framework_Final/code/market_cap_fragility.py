"""Empirical market-cap fragility overlay.

Size is intentionally separate from AI exposure. The overlay captures generic
liquidity, funding, forced-selling and balance-sheet fragility observed in
smaller capitalization portfolios during broad-market stress windows.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

HORIZONS = {"1w": 5, "2w": 10, "1m": 21, "2m": 42}
SCENARIO_QUANTILES = {
    "mild": 0.50,
    "base": 0.25,
    "severe": 0.10,
    "extreme": 0.05,
    "worst": None,  # historical minimum
}


def rolling_log_return(simple_returns: pd.Series, window: int) -> pd.Series:
    r = pd.Series(simple_returns, copy=True).astype(float)
    return np.log1p(r).rolling(window).sum()


def calibrate_size_overlay(
    size_portfolios: pd.DataFrame,
    broad_market_return: pd.Series,
    top_bucket_col: str,
    start_date: str = "1986-01-01",
    stress_quantile: float = 0.10,
    horizons: dict = HORIZONS,
) -> pd.DataFrame:
    """Estimate adverse relative size outcomes conditional on market stress.

    Inputs are daily simple returns. The conditioning set for horizon h is the
    bottom decile (by default) of broad-market rolling h-day log returns since
    start_date. Each smaller size portfolio is measured relative to the top
    market-cap quintile over the same windows.
    """
    size = size_portfolios.copy().sort_index()
    market = pd.Series(broad_market_return, copy=True).sort_index().astype(float)
    if not isinstance(size.index, pd.DatetimeIndex) or not isinstance(market.index, pd.DatetimeIndex):
        raise TypeError("size and market returns must use DatetimeIndex")
    size = size.loc[size.index >= pd.Timestamp(start_date)]
    market = market.loc[market.index >= pd.Timestamp(start_date)]
    if top_bucket_col not in size.columns:
        raise KeyError(f"top bucket {top_bucket_col!r} not present")

    rows = []
    for h_label, h_days in horizons.items():
        market_h = rolling_log_return(market, h_days)
        size_h = pd.DataFrame({
            c: rolling_log_return(size[c], h_days) for c in size.columns
        })
        aligned = pd.concat([market_h.rename("market"), size_h], axis=1).dropna()
        cutoff = aligned["market"].quantile(stress_quantile)
        stress = aligned[aligned["market"] <= cutoff]
        ref = stress[top_bucket_col]

        for bucket in size.columns:
            rel = stress[bucket] - ref
            for scenario, q in SCENARIO_QUANTILES.items():
                raw = float(rel.min()) if q is None else float(rel.quantile(q))
                overlay = min(raw, 0.0)
                rows.append({
                    "horizon": h_label,
                    "scenario": scenario,
                    "cap_bucket": bucket,
                    "size_overlay_log": overlay,
                    "size_overlay_simple": np.exp(overlay) - 1.0,
                    "size_overlay_pct": 100.0 * (np.exp(overlay) - 1.0),
                    "stress_window_cutoff_log_return": float(cutoff),
                    "n_stress_windows": int(len(stress)),
                    "conditional_quantile": "minimum" if q is None else q,
                    "reference_bucket": top_bucket_col,
                })
    return pd.DataFrame(rows)


def apply_size_overlay(base_stress_log, size_overlay_log):
    """Add the separately calibrated fragility term in log-return space."""
    return np.asarray(base_stress_log, dtype=float) + np.asarray(size_overlay_log, dtype=float)


def assign_cap_bucket(
    market_cap_usd,
    breakpoints_usd=(1.15e9, 3.37e9, 7.56e9, 24.73e9),
):
    """Map current market cap to refreshable quintile-style production buckets."""
    x = np.asarray(market_cap_usd, dtype=float)
    labels = np.array(["micro", "small", "mid", "upper_mid", "large_mega"], dtype=object)
    idx = np.digitize(x, np.asarray(breakpoints_usd, dtype=float), right=False)
    return labels[idx]
