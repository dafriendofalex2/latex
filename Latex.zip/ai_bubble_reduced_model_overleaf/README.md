# AI Bubble Unwind Reduced Model Proposal

This Overleaf-ready project contains a manager-facing proposal for a reduced AI bubble-unwind stress model.

## Files

- `main.tex`: proposal text and mathematical model.
- `references.bib`: BibTeX references.
- `data_required.md`: detailed data inventory and download checklist.
- `main.pdf`: compiled PDF preview.

## Project framing

The model does not forecast whether or when AI crashes. It estimates the conditional market impact given an AI-theme unwind scenario.

Core output:

`Index impact = direct AI concentration + spillover impact`

The proposal also includes a historical calibration module using past Fama-French 49 industry data, especially dot-com TMT and broader historical sector unwind episodes.
