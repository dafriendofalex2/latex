# Data dictionary

## Scenario files

- `scenario_definitions.csv`: mild/base/severe AI factor shocks. Shocks are in log-return units and simple-return equivalents.
- `dotcom_tmt_relative_drawdowns.csv`: historical TMT relative drawdowns versus the Fama-French market return.
- `historical_drawdown_quantiles.csv`: empirical drawdown distributions for all and high-signal historical FF49 states.
- `historical_signal_drawdown_regression.csv`: OLS diagnostics of future drawdown on growth and stretch signals.

## Vector files

- `stress_vector_ai_stocks.csv`: stock-level vector for modelled AI names. Key fields are `lambda_AI_factor`, `mild_simple_return`, `base_simple_return`, and `severe_simple_return`.
- `stress_vector_ff49_industries.csv`: FF49 industry-level vector. Key field is `beta_AI_spillover`.
- `stress_vector_combined.csv`: stock and industry vectors in one file.

## Index impact files

- `spy_ai_holdings_direct_impacts.csv`: current SPY AI holdings and direct impact by name.
- `spy_direct_index_impact_summary.csv`: total direct impact by scenario.

## Factor files

- `current_ai_monthly_factor.csv`: AI raw basket, market return, and orthogonal AI factor.
- `current_ai_signal_summary.csv`: current X, V, and B signals.
- `ff3_monthly_factors_decimal.csv`: parsed Fama-French factors in decimal return units.
- `ff49_value_weighted_monthly_returns_decimal.csv`: parsed Fama-French 49 industry returns in decimal return units.
