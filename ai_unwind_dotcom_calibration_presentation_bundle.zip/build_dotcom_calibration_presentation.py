import os, math, shutil, zipfile, textwrap
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch

BASE = Path('/mnt/data')
OUT = BASE / 'ai_unwind_dotcom_calibration_presentation_bundle'
OUT.mkdir(exist_ok=True)
FIGDIR = OUT / 'figures'
FIGDIR.mkdir(exist_ok=True)

plt.rcParams['figure.dpi'] = 170
plt.rcParams['font.size'] = 10
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['axes.labelsize'] = 10
plt.rcParams['legend.fontsize'] = 8.5

# ---------- helpers ----------
def parse_ff49_daily(path):
    lines = Path(path).read_text(encoding='latin1').splitlines()
    start = None
    for i, l in enumerate(lines):
        if 'Average Value Weighted Returns -- Daily' in l:
            start = i + 1
            break
    if start is None:
        raise RuntimeError('could not find FF49 table')
    header = [h.strip() for h in lines[start].split(',')]
    rows = []
    for l in lines[start+1:]:
        if not l.strip():
            break
        parts = [p.strip() for p in l.split(',')]
        if len(parts) == len(header):
            rows.append(parts)
    df = pd.DataFrame(rows, columns=header)
    df.rename(columns={df.columns[0]: 'date'}, inplace=True)
    df['date'] = pd.to_datetime(df['date'], format='%Y%m%d')
    for c in df.columns[1:]:
        df[c] = pd.to_numeric(df[c], errors='coerce')/100.0
    df = df.replace({-0.9999:np.nan, -9.99:np.nan})
    return df

def load_spx(path1=BASE/'spx.csv', path2=BASE/'SP500 (1).csv'):
    spx_old = pd.read_csv(path1)
    spx_old['date'] = pd.to_datetime(spx_old['date'], format='%d-%b-%y')
    spx_old['close'] = pd.to_numeric(spx_old['close'], errors='coerce')
    spx_old = spx_old[['date','close']]
    if path2.exists():
        spx_new = pd.read_csv(path2)
        spx_new['date'] = pd.to_datetime(spx_new['observation_date'])
        spx_new['close'] = pd.to_numeric(spx_new['SP500'], errors='coerce')
        spx_new = spx_new[['date','close']]
        spx = pd.concat([spx_old, spx_new], ignore_index=True)
    else:
        spx = spx_old
    return spx.dropna().drop_duplicates('date', keep='last').sort_values('date')

def pctfmt(x):
    return f"{x:.1f}%"

def savefig(name):
    p = FIGDIR / name
    plt.tight_layout()
    plt.savefig(p, bbox_inches='tight')
    plt.close()
    return p

def esc(s):
    return str(s).replace('&','\\&').replace('%','\\%').replace('_','\\_').replace('$','\\$')

# ---------- load model data ----------
ff49 = parse_ff49_daily(BASE/'49_Industry_Portfolios_Daily.csv')
spx_df = load_spx()
sc = pd.read_csv(BASE/'ai_unwind_v5_revised_kappa_short_horizon_scenario_parameters.csv')
val = pd.read_csv(BASE/'valuation_severity_calibration_summary(1).csv')
val_inputs = pd.read_csv(BASE/'valuation_premium_calibration_inputs.csv')
sample = pd.read_csv(BASE/'ai_unwind_sample_index_etf_shocks_for_theory_presentation.csv')
ci = pd.read_csv(BASE/'country_industry_stress_vector_v5(1).csv')

# build TMT epicenter index
ff = ff49.copy()
ff['tmt_ret'] = ff[['Hardw','Softw','Chips','Telcm']].mean(axis=1)
ff['tmt_idx'] = (1+ff['tmt_ret']).cumprod()
spx = spx_df.set_index('date')['close'].copy()
tmt = ff.set_index('date')['tmt_idx'].copy()
# restrict dotcom window for peak search
search = tmt[(tmt.index >= '1997-01-01') & (tmt.index <= '2002-12-31')]
# Use the production peak date from the scenario table so the figures match the actual calibration.
peak_date = pd.to_datetime(sc['peak_date'].dropna().iloc[0])
peak_pos = tmt.index.get_loc(peak_date)
# actual horizon anchors from scenario parameter file
horizons = ['1w','2w','1m','2m']
scen_order = ['mild','base','severe','extreme','worst']

# Calculate raw horizon table directly from paths
raw_rows=[]
for h in horizons:
    hd=int(sc[(sc['horizon']==h)].iloc[0]['horizon_trading_days'])
    anchor=pd.to_datetime(sc[(sc['horizon']==h)].iloc[0]['anchor_date'])
    # align spx anchor/peak; scenario params already exact, but record from file
    row=sc[(sc['horizon']==h)&(sc['scenario']=='severe')].iloc[0]
    raw_rows.append({
        'horizon':h,
        'days':hd,
        'anchor_date':anchor.date().isoformat(),
        'S_WORLD_raw_log':row['S_WORLD_raw_dotcom_log'],
        'S_AI_EXCESS_raw_log':row['S_AI_EXCESS_raw_dotcom_log'],
        'S_EPICENTER_raw_log':row['S_AI_EPICENTER_raw_dotcom_log'],
        'S_WORLD_raw_pct':(math.exp(row['S_WORLD_raw_dotcom_log'])-1)*100,
        'S_AI_EXCESS_raw_pct':(math.exp(row['S_AI_EXCESS_raw_dotcom_log'])-1)*100,
        'S_EPICENTER_raw_pct':(math.exp(row['S_AI_EPICENTER_raw_dotcom_log'])-1)*100,
    })
raw = pd.DataFrame(raw_rows)

# kappa values
kappa_base = float(val.loc[val['parameter']=='base_valuation_severity_scalar_kappa','value'].iloc[0])
# Extract dotcom/current premia
vsummary = {r['parameter']:r['value'] for _,r in val.iterrows()}

# ---------- charts ----------
figs={}
# 1 workflow diagram
fig, ax = plt.subplots(figsize=(10.5,4.7))
ax.axis('off'); ax.set_xlim(0,10); ax.set_ylim(0,4.6)
boxes=[(0.3,2.7,1.7,0.8,'Pick historical\nanalogue'),(2.35,2.7,1.9,0.8,'Find TMT peak\n2000-03-27'),(4.65,2.7,2.0,0.8,'Measure short\nhorizon shocks'),(7.1,2.7,2.3,0.8,'Scale AI-excess\nby scenario'),(4.65,1.0,2.0,0.8,'Separate market\nfrom excess'),(7.1,1.0,2.3,0.8,'Apply by beta\nand AI intensity')]
for x,y,w,h,t in boxes:
    ax.add_patch(Rectangle((x,y),w,h,fill=False,linewidth=1.5))
    ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=11)
for x1,y1,x2,y2 in [(2.0,3.1,2.35,3.1),(4.25,3.1,4.65,3.1),(6.65,3.1,7.1,3.1),(5.65,2.7,5.65,1.8),(6.65,1.4,7.1,1.4)]:
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='->',mutation_scale=12,linewidth=1.2))
ax.text(5,4.25,'Dot-com calibration: from historical tape to production shocks',ha='center',fontsize=15,weight='bold')
figs['workflow']=savefig('fig_01_workflow.png')

# 2 TMT and S&P normalized full bubble window
start='1997-01-01'; end='2002-12-31'
tmt_win=tmt[(tmt.index>=start)&(tmt.index<=end)]
spx_win=spx[(spx.index>=start)&(spx.index<=end)]
fig, ax=plt.subplots(figsize=(9,5.2))
ax.plot(tmt_win.index, 100*tmt_win/tmt_win.iloc[0], label='Dot-com TMT proxy: FF49 Hardw/Softw/Chips/Telcm')
ax.plot(spx_win.index, 100*spx_win/spx_win.iloc[0], label='S&P 500 broad market')
ax.axvline(peak_date, linestyle='--', linewidth=1)
ax.annotate('TMT peak\n2000-03-27', xy=(peak_date, 100*tmt.loc[peak_date]/tmt_win.iloc[0]), xytext=(pd.Timestamp('2000-10-01'), 310), arrowprops=dict(arrowstyle='->',lw=1), fontsize=9)
ax.set_title('Dot-com episode: the AI analogue is the TMT epicenter, not the whole market')
ax.set_ylabel('Index level, Jan 1997 = 100')
ax.legend(loc='upper left')
figs['full_path']=savefig('fig_02_dotcom_full_path.png')

# 3 zoom around peak with horizon markers
post_tmt=tmt[tmt.index>=peak_date].iloc[:64]
post_spx=spx[spx.index>=peak_date].iloc[:64]
fig, ax=plt.subplots(figsize=(9,5.2))
ax.plot(range(len(post_tmt)), 100*post_tmt/post_tmt.iloc[0], label='TMT epicenter')
ax.plot(range(len(post_spx)), 100*post_spx/post_spx.iloc[0], label='S&P 500')
for h in horizons:
    days=int(sc[(sc.horizon==h)].iloc[0]['horizon_trading_days'])
    ax.axvline(days, linestyle='--', linewidth=1)
    ax.text(days, ax.get_ylim()[0]+1, h, ha='center', va='bottom', fontsize=9)
ax.set_title('Calibration window: fixed horizons after the TMT peak')
ax.set_xlabel('Trading days after 2000-03-27 TMT peak')
ax.set_ylabel('Index level, peak = 100')
ax.legend()
figs['peak_zoom']=savefig('fig_03_peak_horizon_markers.png')

# 4 drawdown path after peak longer
post_n=252
tmt_post=tmt[tmt.index>=peak_date].iloc[:post_n]
spx_post=spx[spx.index>=peak_date].iloc[:post_n]
tmt_dd=100*(tmt_post/tmt_post.iloc[0]-1)
spx_dd=100*(spx_post/spx_post.iloc[0]-1)
fig, ax=plt.subplots(figsize=(9,5.2))
ax.plot(range(len(tmt_dd)), tmt_dd, label='TMT epicenter drawdown')
ax.plot(range(len(spx_dd)), spx_dd, label='S&P 500 drawdown')
for days in [5,10,21,42]:
    ax.axvline(days, linestyle=':', linewidth=0.9)
ax.set_title('The epicenter sold off faster and deeper than the broad market')
ax.set_xlabel('Trading days after peak')
ax.set_ylabel('Return from peak (%)')
ax.legend()
figs['drawdown']=savefig('fig_04_post_peak_drawdown.png')

# 5 raw shock decomposition by horizon
fig, ax=plt.subplots(figsize=(8.5,5.0))
x=np.arange(len(raw)); width=0.25
ax.bar(x-width, raw['S_WORLD_raw_pct'], width, label='Broad-market shock')
ax.bar(x, raw['S_AI_EXCESS_raw_pct'], width, label='AI/TMT-excess shock')
ax.bar(x+width, raw['S_EPICENTER_raw_pct'], width, label='Epicenter total shock')
ax.set_xticks(x); ax.set_xticklabels(raw['horizon'])
ax.set_ylabel('Raw dot-com shock (%)')
ax.set_title('Raw dot-com calibration inputs by horizon')
ax.legend()
figs['raw_decomp']=savefig('fig_05_raw_shock_decomposition.png')

# 6 decomposition stacked bars of raw total (log components) in simple percent approximations maybe log*100
fig, ax=plt.subplots(figsize=(8.5,5.0))
world=100*raw['S_WORLD_raw_log'].values
excess=100*raw['S_AI_EXCESS_raw_log'].values
ax.bar(raw['horizon'], world, label='Market leg (log points)')
ax.bar(raw['horizon'], excess, bottom=world, label='Excess AI/TMT leg (log points)')
ax.set_title('Epicenter log shock equals market leg plus excess leg')
ax.set_ylabel('Log return contribution (percentage points)')
ax.legend()
figs['log_stack']=savefig('fig_06_raw_log_stack.png')

# 7 kappa ladder
kdf=sc[['scenario','ai_excess_severity_scalar','world_scale']].drop_duplicates().set_index('scenario').loc[scen_order].reset_index()
fig, ax=plt.subplots(figsize=(8.2,4.8))
ax.bar(kdf['scenario'], kdf['ai_excess_severity_scalar'])
ax.axhline(1.0, linestyle='--', linewidth=1)
ax.set_ylabel('AI/TMT-excess severity multiplier')
ax.set_title('Scenario ladder: kappa scales only the excess AI/TMT leg')
for i,r in kdf.iterrows():
    ax.text(i, r['ai_excess_severity_scalar']+0.04, f"{r['ai_excess_severity_scalar']:.2f}", ha='center', fontsize=9)
figs['kappa_ladder']=savefig('fig_07_kappa_ladder.png')

# 8 valuation kappa derivation chart
vals = pd.DataFrame({
    'metric':['Dot-com reference premium','Current blended premium','Base kappa'],
    'value':[vsummary['dotcom_reference_premium_log'], vsummary['current_blended_premium_log'], vsummary['base_valuation_severity_scalar_kappa']]
})
fig, ax=plt.subplots(figsize=(8,4.7))
ax.bar(vals['metric'], vals['value'])
ax.set_ylabel('Log premium or ratio')
ax.set_title('Base kappa is a valuation-severity ratio')
for i,r in vals.iterrows():
    ax.text(i, r['value']+0.025, f"{r['value']:.3f}", ha='center')
figs['valuation_kappa']=savefig('fig_08_base_kappa_valuation.png')

# 9 scenario epicenter heatmap
heat=sc.pivot(index='scenario', columns='horizon', values='S_AI_EPICENTER_pct').loc[scen_order,horizons]
fig, ax=plt.subplots(figsize=(7.6,4.6))
im=ax.imshow(heat.values, aspect='auto')
ax.set_xticks(np.arange(len(horizons))); ax.set_xticklabels(horizons)
ax.set_yticks(np.arange(len(scen_order))); ax.set_yticklabels(scen_order)
ax.set_title('Epicenter stress: horizon x scenario')
for i in range(len(scen_order)):
    for j in range(len(horizons)):
        ax.text(j,i,f"{heat.values[i,j]:.1f}%",ha='center',va='center',fontsize=9)
fig.colorbar(im, ax=ax, shrink=0.8, label='Shock (%)')
figs['heat_epicenter']=savefig('fig_09_epicenter_heatmap.png')

# 10 scenario decomposition by each horizon for world/excess at worst and base maybe line
fig, ax=plt.subplots(figsize=(9,5.2))
for scen in ['base','severe','extreme','worst']:
    sub=sc[sc.scenario==scen].set_index('horizon').loc[horizons]
    ax.plot(horizons, sub['S_AI_EPICENTER_pct'], marker='o', label=scen)
ax.set_title('Scenario severity increases with kappa and horizon')
ax.set_ylabel('AI epicenter shock (%)')
ax.legend(ncol=4)
figs['epicenter_lines']=savefig('fig_10_epicenter_lines.png')

# 11 components by scenario for 2m
sub=sc[sc.horizon=='2m'].set_index('scenario').loc[scen_order]
fig, ax=plt.subplots(figsize=(8.5,5.0))
world=sub['S_WORLD_pct'].values
excess=sub['S_AI_EXCESS_pct'].values
ax.bar(scen_order, world, label='Broad-market component')
ax.bar(scen_order, excess, bottom=world, label='AI/TMT-excess component')
ax.set_title('2-month scenario decomposition')
ax.set_ylabel('Contribution to epicenter shock (%)')
ax.legend()
figs['decomp_2m']=savefig('fig_11_2m_decomposition.png')

# 12 kappa sensitivity curves for each horizon (kappa from 0 to 2.25)
ks=np.linspace(0,2.25,100)
fig, ax=plt.subplots(figsize=(8.5,5.2))
for h in horizons:
    r=raw[raw.horizon==h].iloc[0]
    # world full shock + kappa*excess log, convert to pct
    y=100*(np.exp(r['S_WORLD_raw_log'] + ks*r['S_AI_EXCESS_raw_log'])-1)
    ax.plot(ks,y,label=h)
for k in [kappa_base,1,1.5,2]:
    ax.axvline(k, linestyle=':', linewidth=0.8)
ax.set_title('Kappa sensitivity: same historical excess path, different severities')
ax.set_xlabel('AI/TMT-excess severity multiplier kappa')
ax.set_ylabel('Epicenter stress (%)')
ax.legend(title='Horizon')
figs['kappa_sens']=savefig('fig_12_kappa_sensitivity.png')

# 13 sample proxies 2m scenario comparison
sample_order=['World ETF / broad market','S&P 500 / U.S. broad ETF','NASDAQ / AI epicenter proxy','Japan / Nikkei-type ETF','Korea ETF','Taiwan ETF','China ETF','Developed Europe ETF']
short_label={
    'World ETF / broad market':'World', 'S&P 500 / U.S. broad ETF':'S&P 500', 'NASDAQ / AI epicenter proxy':'NASDAQ/AI',
    'Japan / Nikkei-type ETF':'Japan', 'Korea ETF':'Korea', 'Taiwan ETF':'Taiwan', 'China ETF':'China', 'Developed Europe ETF':'Europe'
}
fig, ax=plt.subplots(figsize=(9.5,5.2))
sub=sample[(sample.short_horizon=='2m') & (sample.scenario.isin(['base','severe','extreme','worst']))].copy()
x=np.arange(len(sample_order)); width=0.18
for i,scen in enumerate(['base','severe','extreme','worst']):
    vals=[]
    for sp in sample_order:
        vals.append(float(sub[(sub.sample_proxy==sp)&(sub.scenario==scen)]['stress_pct'].iloc[0]))
    ax.bar(x+(i-1.5)*width, vals, width, label=scen)
ax.set_xticks(x); ax.set_xticklabels([short_label[s] for s in sample_order], rotation=25, ha='right')
ax.set_ylabel('2-month stress (%)')
ax.set_title('Sample index/ETF shocks produced by the dot-com calibration')
ax.legend(ncol=4)
figs['sample_2m']=savefig('fig_13_sample_2m_shocks.png')

# 14 sample proxies heatmap worst by horizon
hs=sample[(sample.scenario=='worst')].copy()
heat2=pd.DataFrame(index=[short_label[s] for s in sample_order], columns=horizons)
for sp in sample_order:
    for h in horizons:
        heat2.loc[short_label[sp],h]=float(hs[(hs.sample_proxy==sp)&(hs.short_horizon==h)]['stress_pct'].iloc[0])
heat2=heat2.astype(float)
fig, ax=plt.subplots(figsize=(7.3,5.2))
im=ax.imshow(heat2.values, aspect='auto')
ax.set_xticks(range(len(horizons))); ax.set_xticklabels(horizons)
ax.set_yticks(range(len(heat2.index))); ax.set_yticklabels(heat2.index)
ax.set_title('Worst-case sample shocks by horizon')
for i in range(len(heat2.index)):
    for j in range(len(horizons)):
        ax.text(j,i,f"{heat2.values[i,j]:.1f}%",ha='center',va='center',fontsize=8)
fig.colorbar(im, ax=ax, shrink=0.8, label='Shock (%)')
figs['sample_worst_heat']=savefig('fig_14_sample_worst_heatmap.png')

# 15 illustrative formula surface: cell stress as beta/I example, use 2m worst
bgrid=np.linspace(0.7,1.6,10)
igrid=np.linspace(0.0,1.0,10)
r2=sc[(sc.horizon=='2m')&(sc.scenario=='worst')].iloc[0]
Z=np.zeros((len(igrid),len(bgrid)))
for ii,I in enumerate(igrid):
    for jj,B in enumerate(bgrid):
        Z[ii,jj]=100*(math.exp(B*r2['S_WORLD_log']+I*r2['S_AI_EXCESS_log'])-1)
fig, ax=plt.subplots(figsize=(7.7,5.1))
im=ax.imshow(Z, origin='lower', aspect='auto', extent=[bgrid.min(), bgrid.max(), igrid.min(), igrid.max()])
ax.set_xlabel('Broad-market beta')
ax.set_ylabel('AI/TMT-excess intensity')
ax.set_title('How calibration flows through to position shocks (2m worst)')
fig.colorbar(im, ax=ax, label='Stress (%)')
figs['surface']=savefig('fig_15_beta_intensity_surface.png')

# 16 distribution of model shocks (country-industry, revised kappa long if available)
mc_long_path=BASE/'ai_unwind_v5_country_industry_revised_kappa_all_scenarios_long.csv'
if mc_long_path.exists():
    long=pd.read_csv(mc_long_path)
    # columns short_horizon etc? inspect; use long without marketcap?
else:
    long=None
# use country-industry files per horizon revised kappa
all_rows=[]
for h in horizons:
    f=BASE/f'ai_unwind_v5_{h}_country_industry_revised_kappa_all_scenarios.csv'
    if f.exists():
        df=pd.read_csv(f)
        df['horizon']=h
        all_rows.append(df)
rev=pd.concat(all_rows, ignore_index=True)
# get stress pct columns? inspect later dynamically
# likely wide columns base_stress_pct etc
fig, ax=plt.subplots(figsize=(8.5,5.0))
for scen in ['base','severe','extreme','worst']:
    col=f'{scen}_stress_pct'
    if col in rev.columns:
        vals=rev[rev.horizon=='2m'][col].dropna()
        ax.hist(vals, bins=40, alpha=0.45, label=scen)
ax.set_title('Distribution of country-industry shocks generated by 2m calibration')
ax.set_xlabel('Stress (%)')
ax.set_ylabel('Number of country-industry cells')
ax.legend()
figs['dist']=savefig('fig_16_stress_distribution.png')

# 17 bar top severe/worst country-industry samples maybe top worst 2m
fig, ax=plt.subplots(figsize=(9.5,5.5))
col='worst_stress_pct'
if col in rev.columns:
    top=rev[rev.horizon=='2m'].sort_values(col).head(12)
    labels=[f"{r['country_bucket']} / {str(r['client_industry_label'])[:18]}" for _,r in top.iterrows()]
    ax.barh(np.arange(len(top)), top[col])
    ax.set_yticks(np.arange(len(top))); ax.set_yticklabels(labels, fontsize=8)
    ax.invert_yaxis()
    ax.set_xlabel('2m worst stress (%)')
    ax.set_title('Most severe country-industry shocks under 2m worst')
else:
    ax.axis('off'); ax.text(0.5,0.5,'No revised country-industry file found',ha='center')
figs['top_cells']=savefig('fig_17_top_country_industry.png')

# 18 sample path illustration table-like as chart: raw anchors in dates
fig, ax=plt.subplots(figsize=(8.5,4.8))
ax.axis('off')
ax.set_title('Calibration dates and raw shocks', pad=15)
cols=['Horizon','Days','Anchor date','Market','AI/TMT excess','Epicenter']
cell_text=[]
for _,r in raw.iterrows():
    cell_text.append([r['horizon'], int(r['days']), r['anchor_date'], f"{r['S_WORLD_raw_pct']:.1f}%", f"{r['S_AI_EXCESS_raw_pct']:.1f}%", f"{r['S_EPICENTER_raw_pct']:.1f}%"])
tab=ax.table(cellText=cell_text, colLabels=cols, loc='center', cellLoc='center')
tab.auto_set_font_size(False); tab.set_fontsize(9); tab.scale(1,1.5)
figs['anchor_table']=savefig('fig_18_anchor_table.png')

# Output scenario table csv
calib_table = sc.copy()
calib_csv = BASE/'ai_unwind_dotcom_calibration_presentation_scenario_table.csv'
calib_table.to_csv(calib_csv,index=False)

# ---------- LaTeX report ----------
tex_path = BASE/'ai_unwind_dotcom_calibration_presentation.tex'
pdf_path = BASE/'ai_unwind_dotcom_calibration_presentation.pdf'

raw_table_rows=[]
for _,r in raw.iterrows():
    raw_table_rows.append(f"{r['horizon']} & {int(r['days'])} & {r['anchor_date']} & {r['S_WORLD_raw_pct']:.2f} & {r['S_AI_EXCESS_raw_pct']:.2f} & {r['S_EPICENTER_raw_pct']:.2f} " + "\\\\")
scenario_rows=[]
for h in horizons:
    srow=sc[sc.horizon==h].set_index('scenario').loc[scen_order]
    scenario_rows.append(f"{h} & {int(srow.iloc[0]['horizon_trading_days'])} & " + " & ".join([f"{srow.loc[s,'S_AI_EPICENTER_pct']:.2f}" for s in scen_order]) + " " + "\\\\")

sample_rows=[]
for sp in sample_order:
    sub=sample[(sample.sample_proxy==sp)&(sample.short_horizon=='2m')].set_index('scenario').loc[scen_order]
    sample_rows.append(f"{esc(short_label[sp])} & " + " & ".join([f"{sub.loc[s,'stress_pct']:.2f}" for s in scen_order]) + " " + "\\\\")

fig_rel = lambda name: f"figures/{Path(figs[name]).name}"

latex = rf'''
\documentclass[11pt]{{article}}
\usepackage[margin=0.72in]{{geometry}}
\usepackage{{graphicx}}
\usepackage{{amsmath}}
\usepackage{{array}}
\usepackage{{booktabs}}
\usepackage{{hyperref}}
\setlength{{\parindent}}{{0pt}}
\setlength{{\parskip}}{{0.55em}}
\begin{{document}}
\title{{Dot-Com Calibration for the AI Unwind Stress Framework}}
\author{{Presentation Preparation Note}}
\date{{July 2026}}
\maketitle

\section*{{Executive summary}}
The dot-com calibration turns a historical technology-bubble unwind into production-ready stress factors. The core idea is simple: do not copy the dot-com episode blindly. Instead, split the historical move into two interpretable pieces: a broad-market selloff and an AI/TMT-excess selloff. The broad-market leg captures ordinary equity de-risking. The excess leg captures the additional downside of the technology epicenter after removing broad-market movement.

For each horizon $h$, the model measures:
\[
S_W^h=\log\left(\frac{{P_W(t_0+h)}}{{P_W(t_0)}}\right),\qquad
S_E^h=\log\left(\frac{{P_E(t_0+h)}}{{P_E(t_0)}}\right),\qquad
S_X^h=S_E^h-S_W^h.
\]
Here $P_W$ is the broad-market proxy, $P_E$ is the TMT epicenter proxy, $S_W$ is the market shock, $S_E$ is the total epicenter shock, and $S_X$ is the excess AI/TMT shock. Scenario severity then scales $S_X$ by $\kappa$ while the broad-market leg is kept explicit.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.95\textwidth]{{{fig_rel('workflow')}}}
\caption{{The calibration workflow. The key control is separating the historical technology crash into a broad-market leg and an excess technology leg.}}
\end{{figure}}

\section{{Why the calibration uses the dot-com TMT peak}}
The dot-com episode is useful because it was a broad equity event caused by a concentrated technology epicenter. That is structurally close to the risk being modeled in an AI unwind: the broad market can sell off, but the technology/AI complex should sell off more.

The calibration therefore uses two time series. The broad-market leg is the S\&P 500. The epicenter leg is an equal-weight daily proxy from Fama--French 49 industries: Hardware, Software, Chips, and Telecommunications. This epicenter proxy is not meant to be a perfect NASDAQ clone. It is used because it gives a direct industry-level TMT basket that matches the logic of the current AI/TMT stress vector.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.92\textwidth]{{{fig_rel('full_path')}}}
\caption{{Dot-com window. The TMT epicenter rose and then fell much more sharply than the S\&P 500. This is the empirical reason the model needs a separate excess AI/TMT leg rather than a single market shock.}}
\end{{figure}}

The TMT epicenter peak is identified on 2000-03-27. The short-horizon calibration uses fixed trading-day windows after that peak: 5 trading days, 10 trading days, 21 trading days, and 42 trading days.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.90\textwidth]{{{fig_rel('peak_zoom')}}}
\caption{{The first two months after the peak are the exact horizon anchor for the production stress vectors.}}
\end{{figure}}

\section{{From a historical crash path to factor shocks}}
The key step is to convert the historical path into two shocks. First, measure the broad-market log return. Second, measure the TMT epicenter log return. Third, subtract the market leg from the epicenter leg to get the excess leg.

This is why log returns are used. In simple-return space, decomposition is approximate. In log-return space, it is exact:
\[
S_E^h = S_W^h + S_X^h.
\]
That means the final stress can be written as a transparent linear combination:
\[
R_i^{{s,h}}=\beta_i^W S_W^{{s,h}}+I_i^{{AI}}S_X^{{s,h}}.
\]
A position or bucket with high market beta is more exposed to $S_W$. A position or bucket with high AI intensity is more exposed to $S_X$.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.90\textwidth]{{{fig_rel('drawdown')}}}
\caption{{Post-peak drawdown path. The gap between the TMT line and the S\&P 500 line is the intuition behind the excess AI/TMT leg.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.84\textwidth]{{{fig_rel('raw_decomp')}}}
\caption{{Raw dot-com shocks before scenario scaling. The epicenter shock is always more severe than the broad-market shock because of the excess TMT leg.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.84\textwidth]{{{fig_rel('log_stack')}}}
\caption{{In log space, the epicenter shock is exactly the sum of the market leg and the excess leg. This makes the calibration clean and auditable.}}
\end{{figure}}

\begin{{center}}
\small
\begin{{tabular}}{{lrrrrr}}
\toprule
Horizon & Days & Anchor date & Market raw & Excess raw & Epicenter raw \\
\midrule
{chr(10).join(raw_table_rows)}
\bottomrule
\end{{tabular}}
\end{{center}}

\section{{How scenarios scale the dot-com excess shock}}
The model does not assume that the present AI bubble must equal the full dot-com episode. It uses the dot-com excess leg as the reference shock and then applies scenario-specific multipliers.

The current ladder is:
\[
\kappa_{{mild}}=0.335,\qquad
\kappa_{{base}}=0.671,\qquad
\kappa_{{severe}}=1.000,\qquad
\kappa_{{extreme}}=1.500,\qquad
\kappa_{{worst}}=2.000.
\]
The base multiplier, $\kappa=0.671$, comes from the valuation-severity calibration: the current blended AI/TMT valuation premium divided by the dot-com reference premium. Severe applies the full dot-com excess move. Extreme and worst intentionally go beyond the dot-com excess leg to represent stress cases.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.78\textwidth]{{{fig_rel('valuation_kappa')}}}
\caption{{Base kappa is anchored in relative valuation severity. It scales the excess AI/TMT leg rather than the broad-market leg.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.78\textwidth]{{{fig_rel('kappa_ladder')}}}
\caption{{Scenario ladder. Kappa is the severity knob for the AI/TMT-excess component.}}
\end{{figure}}

\section{{The scenario output: horizon times severity}}
After applying scenario multipliers, each horizon has five scenario shocks. The table below shows the implied AI epicenter stress in percent terms. This is not the stress for every client position; it is the calibrated epicenter shock before mapping through each bucket's beta and AI intensity.

\begin{{center}}
\small
\begin{{tabular}}{{lrrrrrr}}
\toprule
Horizon & Days & Mild & Base & Severe & Extreme & Worst \\
\midrule
{chr(10).join(scenario_rows)}
\bottomrule
\end{{tabular}}
\end{{center}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.75\textwidth]{{{fig_rel('heat_epicenter')}}}
\caption{{Epicenter shock matrix. Severity increases moving down the rows; horizon increases moving right across columns.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.82\textwidth]{{{fig_rel('epicenter_lines')}}}
\caption{{The same calibration viewed as curves. Longer horizons and larger kappa values produce more severe epicenter shocks.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.82\textwidth]{{{fig_rel('decomp_2m')}}}
\caption{{Two-month decomposition. The broad-market component is held fixed across base/severe/extreme/worst; the excess AI/TMT component drives the scenario ladder.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.82\textwidth]{{{fig_rel('kappa_sens')}}}
\caption{{Kappa sensitivity curves. This chart is useful in presentation because it shows exactly what changes when management asks for a harsher or milder AI-specific stress.}}
\end{{figure}}

\section{{How the calibration maps into actual portfolio shocks}}
The dot-com calibration produces factor shocks, not final portfolio losses. The model then maps those factor shocks through exposure estimates:
\[
R_{{b,g}}^{{s,h}}=\beta_{{b,g}}^W S_W^{{s,h}}+I_{{b,g}}^{{AI}}S_X^{{s,h}}.
\]
That means two names can share the same broad market shock but receive different final shocks because their AI intensity is different. Conversely, a broad index or country ETF can receive a meaningful market shock without being treated as an AI epicenter.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.78\textwidth]{{{fig_rel('surface')}}}
\caption{{Stress surface for the 2-month worst case. Higher beta increases market loss; higher AI intensity increases excess AI/TMT loss.}}
\end{{figure}}

\section{{Sample index and ETF shocks}}
The charts below show what the calibration produces for sample broad-market, technology, and international index/ETF proxies. These are useful for senior-management presentation because they translate the abstract factor decomposition into familiar names.

\begin{{center}}
\small
\begin{{tabular}}{{lrrrrr}}
\toprule
2m sample proxy & Mild & Base & Severe & Extreme & Worst \\
\midrule
{chr(10).join(sample_rows)}
\bottomrule
\end{{tabular}}
\end{{center}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.94\textwidth]{{{fig_rel('sample_2m')}}}
\caption{{Sample two-month shocks under the revised scenario ladder. The NASDAQ/AI proxy is most sensitive because it carries the largest AI-excess loading.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.82\textwidth]{{{fig_rel('sample_worst_heat')}}}
\caption{{Worst-case sample shocks by horizon. This chart makes the horizon dimension easy to explain.}}
\end{{figure}}

\section{{Distributional view of the generated stress vector}}
The calibration is also easy to sanity-check in cross-section. As scenario severity increases, the distribution of country-industry shocks shifts left. The most severe cells are high-beta and high-AI-intensity buckets.

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.84\textwidth]{{{fig_rel('dist')}}}
\caption{{Distribution of 2-month country-industry shocks generated by the dot-com calibration.}}
\end{{figure}}

\begin{{figure}}[h!]
\centering
\includegraphics[width=0.92\textwidth]{{{fig_rel('top_cells')}}}
\caption{{Most severe 2-month worst-case country-industry shocks. These are the buckets where high market sensitivity and high AI intensity compound.}}
\end{{figure}}

\section{{Presentation takeaways}}
\begin{{itemize}}
\item The calibration is not a vague dot-com comparison. It is a mechanical conversion from an observed historical path into market and excess AI/TMT factor shocks.
\item The TMT peak date, horizon anchors, and shock calculations are explicit and auditable.
\item Log returns make the decomposition exact: epicenter shock equals market shock plus excess shock.
\item Kappa is the clean severity control. It scales the AI/TMT-excess leg while preserving the broad-market leg.
\item The calibrated factors become final client shocks only after being mapped through each bucket's market beta and AI intensity.
\end{{itemize}}

\section*{{Included source files}}
This bundle includes the PDF, LaTeX source, scenario calibration table, all chart PNGs, and the Python build script. The chart calculations use the uploaded FF49 daily industry portfolios, S\&P 500 daily close data, valuation severity table, revised short-horizon scenario parameters, and sample index/ETF shock file.

\end{{document}}
'''
tex_path.write_text(latex)

# copy fig directory and data/script to OUT before compile with relative paths
shutil.copy2(tex_path, OUT/tex_path.name)
shutil.copy2(calib_csv, OUT/calib_csv.name)
# script copied later after this script exists

# compile in OUT
cwd=os.getcwd()
os.chdir(OUT)
os.system(f'pdflatex -interaction=nonstopmode {tex_path.name} > /tmp/dotcom_calibration_presentation.log 2>&1')
os.system(f'pdflatex -interaction=nonstopmode {tex_path.name} >> /tmp/dotcom_calibration_presentation.log 2>&1')
os.chdir(cwd)
# copy pdf and tex top level
if (OUT/pdf_path.name).exists():
    shutil.copy2(OUT/pdf_path.name, pdf_path)
# Copy build script
script=BASE/'build_dotcom_calibration_presentation.py'
if script.exists():
    shutil.copy2(script, OUT/script.name)
# zip
zip_path=BASE/'ai_unwind_dotcom_calibration_presentation_bundle.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for fp in OUT.rglob('*'):
        z.write(fp, arcname=fp.relative_to(OUT).as_posix())
print('pdf', pdf_path.exists(), pdf_path)
print('zip', zip_path, zip_path.stat().st_size/1024/1024, 'MiB')
print('peak', peak_date.date(), 'base kappa', kappa_base)
