from pathlib import Path
import zipfile
import warnings
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path('/mnt/data')
OUT = ROOT / 'ai_bubble_stress_research'
FIG = OUT / 'figures'
DAT = OUT / 'data'
for d in [OUT, FIG, DAT]:
    d.mkdir(parents=True, exist_ok=True)

# -------------------------------
# Helpers
# -------------------------------
def ols(y, X, add_const=True):
    """Small OLS helper returning coefficients, fitted, residuals, stderr, t-stat, r2."""
    y = np.asarray(y, dtype=float)
    X = np.asarray(X, dtype=float)
    if X.ndim == 1:
        X = X[:, None]
    if add_const:
        X = np.column_stack([np.ones(len(X)), X])
    mask = np.isfinite(y) & np.all(np.isfinite(X), axis=1)
    y2, X2 = y[mask], X[mask]
    n, k = X2.shape
    if n <= k:
        beta = np.full(k, np.nan)
        return dict(beta=beta, fitted=np.full(len(y), np.nan), resid=np.full(len(y), np.nan), se=np.full(k,np.nan), t=np.full(k,np.nan), r2=np.nan, n=n)
    beta = np.linalg.lstsq(X2, y2, rcond=None)[0]
    fitted2 = X2 @ beta
    resid2 = y2 - fitted2
    s2 = (resid2 @ resid2) / max(n-k, 1)
    cov = s2 * np.linalg.pinv(X2.T @ X2)
    se = np.sqrt(np.diag(cov))
    t = beta / se
    tss = np.sum((y2 - y2.mean())**2)
    rss = np.sum(resid2**2)
    r2 = 1 - rss/tss if tss > 0 else np.nan
    fitted = np.full(len(y), np.nan)
    resid = np.full(len(y), np.nan)
    fitted[mask] = fitted2
    resid[mask] = resid2
    return dict(beta=beta, fitted=fitted, resid=resid, se=se, t=t, r2=r2, n=n)

def future_min_cum(arr, H):
    """For each t, min_{1<=h<=H} sum_{u=1}^h arr[t+u]."""
    n = len(arr)
    out = np.full(n, np.nan)
    for t in range(n):
        end = min(n, t+H+1)
        vals = arr[t+1:end]
        if len(vals) >= H and np.all(np.isfinite(vals)):
            c = np.cumsum(vals)
            out[t] = np.min(c)
    return out

def ewma_past(arr, theta=0.85, K=24):
    arr = np.asarray(arr, dtype=float)
    n = len(arr)
    out = np.full(n, np.nan)
    weights = np.array([(1-theta)*(theta**k) for k in range(K)])
    # k=0 corresponds to t-1, k=K-1 to t-K
    for t in range(K, n):
        vals = arr[t-K:t][::-1]
        if np.all(np.isfinite(vals)):
            out[t] = np.sum(weights * vals)
    return out

def trailing_sum(arr, K):
    arr = np.asarray(arr, dtype=float)
    out = np.full(len(arr), np.nan)
    for t in range(K, len(arr)):
        vals = arr[t-K:t]
        if np.all(np.isfinite(vals)):
            out[t] = vals.sum()
    return out

def read_stooq_daily(path):
    df = pd.read_csv(path)
    df.columns = [c.strip('<>').upper() for c in df.columns]
    df['DATE'] = pd.to_datetime(df['DATE'].astype(str), format='%Y%m%d')
    df = df.sort_values('DATE').set_index('DATE')
    return df

def monthly_log_returns_from_daily(path):
    df = read_stooq_daily(path)
    close = df['CLOSE'].astype(float)
    monthly_close = close.resample('M').last().dropna()
    lr = np.log(monthly_close / monthly_close.shift(1)).dropna()
    return lr

# -------------------------------
# Fama-French files
# -------------------------------
def parse_ff3_zip(zip_path):
    with zipfile.ZipFile(zip_path) as z:
        name = z.namelist()[0]
        text = z.read(name).decode('latin1')
    lines = text.splitlines()
    # find header line starting with comma and containing Mkt-RF
    header_idx = None
    for i, l in enumerate(lines):
        if l.startswith(',') and 'Mkt-RF' in l:
            header_idx = i
            break
    rows = []
    header = lines[header_idx].split(',')
    header[0] = 'Date'
    for l in lines[header_idx+1:]:
        if not l.strip():
            break
        parts = [p.strip() for p in l.split(',')]
        if len(parts) >= 5 and parts[0].isdigit() and len(parts[0]) == 6:
            rows.append(parts[:5])
        else:
            break
    df = pd.DataFrame(rows, columns=header[:5])
    df['Date'] = pd.to_datetime(df['Date'], format='%Y%m') + pd.offsets.MonthEnd(0)
    for c in ['Mkt-RF','SMB','HML','RF']:
        df[c] = pd.to_numeric(df[c], errors='coerce') / 100.0
    df['MKT'] = df['Mkt-RF'] + df['RF']
    df['MKT_log'] = np.log1p(df['MKT'])
    return df.set_index('Date')

def parse_ff49(path):
    lines = Path(path).read_text(errors='ignore').splitlines()
    header_idx = None
    for i, l in enumerate(lines):
        if l.startswith(',Agric'):
            header_idx = i
            break
    header = [h.strip() for h in lines[header_idx].split(',')]
    header[0] = 'Date'
    rows = []
    for l in lines[header_idx+1:]:
        if not l.strip():
            break
        parts = [p.strip() for p in l.split(',')]
        if len(parts) >= 50 and parts[0].isdigit() and len(parts[0]) == 6:
            rows.append(parts[:50])
        else:
            break
    df = pd.DataFrame(rows, columns=header[:50])
    df['Date'] = pd.to_datetime(df['Date'], format='%Y%m') + pd.offsets.MonthEnd(0)
    for c in df.columns[1:]:
        df[c] = pd.to_numeric(df[c], errors='coerce') / 100.0
        df.loc[df[c] <= -0.99, c] = np.nan
    # log returns, retain names
    logdf = np.log1p(df.set_index('Date'))
    return df.set_index('Date'), logdf

ff3 = parse_ff3_zip(ROOT / 'F-F_Research_Data_Factors_CSV (1).zip')
ff49_simple, ff49_log = parse_ff49(ROOT / '49_Industry_Portfolios.csv')

ff3.to_csv(DAT / 'ff3_monthly_factors_decimal.csv')
ff49_simple.to_csv(DAT / 'ff49_value_weighted_monthly_returns_decimal.csv')

# -------------------------------
# Historical TMT factor and drawdowns
# -------------------------------
columns = list(ff49_log.columns)
# Baseline TMT industries using FF49 names. Include robust basket separately.
tmt_base = [c for c in ['Softw','Hardw','Chips','Telcm'] if c in columns]
tmt_broad = [c for c in ['Softw','Hardw','Chips','Telcm','LabEq','BusSv','ElcEq'] if c in columns]

hist = ff49_log.join(ff3[['MKT_log']], how='inner')
for basket_name, basket in [('base', tmt_base), ('broad', tmt_broad)]:
    hist[f'TMT_{basket_name}_log'] = hist[basket].mean(axis=1)
    hist[f'TMT_{basket_name}_rel_log'] = hist[f'TMT_{basket_name}_log'] - hist['MKT_log']
    hist[f'TMT_{basket_name}_cum_rel'] = hist[f'TMT_{basket_name}_rel_log'].cumsum()

# dot-com peak in 1995-2000 window and future H drawdowns
dot_window = hist.loc['1995-01-31':'2004-12-31'].copy()
peak_window = hist.loc['1995-01-31':'2000-12-31'].copy()
rows = []
for basket_name in ['base','broad']:
    cum = hist[f'TMT_{basket_name}_cum_rel']
    peak_date = cum.loc['1995-01-31':'2000-12-31'].idxmax()
    peak_level = cum.loc[peak_date]
    for H in [6,12,24,36]:
        future = cum.loc[peak_date:].iloc[:H+1]
        dd = (future - peak_level).min()
        trough_date = (future - peak_level).idxmin()
        rows.append({
            'basket': basket_name,
            'industries': ','.join(tmt_base if basket_name=='base' else tmt_broad),
            'peak_date': peak_date.strftime('%Y-%m-%d'),
            'horizon_months': H,
            'log_relative_drawdown': dd,
            'simple_relative_drawdown': np.exp(dd)-1,
            'trough_date': trough_date.strftime('%Y-%m-%d')
        })
dotcom_drawdowns = pd.DataFrame(rows)
dotcom_drawdowns.to_csv(DAT / 'dotcom_tmt_relative_drawdowns.csv', index=False)

# -------------------------------
# Historical calibration: signals vs future drawdowns for all FF49 industries
# -------------------------------
theta = 0.85
K = 24
ma_L = 60
H = 24
cal_rows = []
for industry in ff49_log.columns:
    if industry == 'MKT_log':
        continue
    series = hist[industry] - hist['MKT_log']
    z = series.cumsum()
    X = ewma_past(series.values, theta=theta, K=K)
    # Stretch relative wealth minus 60m rolling mean of relative wealth, lagged at t
    z_ser = pd.Series(z.values, index=z.index)
    V = (z_ser - z_ser.rolling(ma_L, min_periods=ma_L).mean()).values
    D6 = future_min_cum(series.values, 6)
    D12 = future_min_cum(series.values, 12)
    D24 = future_min_cum(series.values, 24)
    for idx, date in enumerate(series.index):
        cal_rows.append({
            'date': date,
            'industry': industry,
            'rel_log_return': series.iloc[idx],
            'X_growth_signal': X[idx],
            'V_stretch_signal': V[idx],
            'future_min_cum_rel_log_6m': D6[idx],
            'future_min_cum_rel_log_12m': D12[idx],
            'future_min_cum_rel_log_24m': D24[idx],
        })
cal = pd.DataFrame(cal_rows).dropna()
# Start after 1963 to avoid old missing composition and align with modern factor era; keep full sample in separate summary
cal_modern = cal[cal['date'] >= pd.Timestamp('1963-07-31')].copy()
# zscores based on modern full sample
for c in ['X_growth_signal','V_stretch_signal']:
    mu = cal_modern[c].mean(); sig = cal_modern[c].std(ddof=0)
    cal_modern[c+'_z'] = (cal_modern[c]-mu)/sig
cal_modern['B_score'] = cal_modern['X_growth_signal_z'] + cal_modern['V_stretch_signal_z']
cal_modern.to_csv(DAT / 'historical_industry_signal_drawdown_sample.csv', index=False)

# Regression of future drawdowns on signals
reg_rows = []
for dep in ['future_min_cum_rel_log_6m','future_min_cum_rel_log_12m','future_min_cum_rel_log_24m']:
    res = ols(cal_modern[dep].values, cal_modern[['X_growth_signal','V_stretch_signal']].values, add_const=True)
    reg_rows.append({
        'dependent_variable': dep,
        'n': res['n'],
        'alpha': res['beta'][0],
        'beta_X_growth': res['beta'][1],
        'beta_V_stretch': res['beta'][2],
        't_alpha': res['t'][0],
        't_beta_X': res['t'][1],
        't_beta_V': res['t'][2],
        'r2': res['r2']
    })
reg_df = pd.DataFrame(reg_rows)
reg_df.to_csv(DAT / 'historical_signal_drawdown_regression.csv', index=False)

# Unconditional and high-signal drawdown distributions
quant_rows = []
for sample_name, df in [('all_modern', cal_modern), ('top_decile_B', cal_modern[cal_modern['B_score'] >= cal_modern['B_score'].quantile(0.90)]), ('top_quintile_B', cal_modern[cal_modern['B_score'] >= cal_modern['B_score'].quantile(0.80)])]:
    for dep in ['future_min_cum_rel_log_6m','future_min_cum_rel_log_12m','future_min_cum_rel_log_24m']:
        vals = df[dep].dropna().values
        quant_rows.append({
            'sample': sample_name,
            'drawdown_variable': dep,
            'n': len(vals),
            'mean': vals.mean(),
            'median': np.median(vals),
            'q25': np.quantile(vals, 0.25),
            'q10': np.quantile(vals, 0.10),
            'q05': np.quantile(vals, 0.05),
            'min': vals.min(),
            'mean_simple_equivalent': np.exp(vals.mean())-1,
            'q10_simple_equivalent': np.exp(np.quantile(vals, 0.10))-1,
        })
quant_df = pd.DataFrame(quant_rows)
quant_df.to_csv(DAT / 'historical_drawdown_quantiles.csv', index=False)

# -------------------------------
# Current AI factor
# -------------------------------
ai_tickers = ['nvda','amd','avgo','msft','googl','amzn','meta','smci','pltr']
ai_series = {}
for t in ai_tickers:
    p = ROOT / f'{t}.us.txt'
    if not p.exists():
        p = ROOT / f'{t}.us(1).txt'
    if p.exists():
        ai_series[t.upper()] = monthly_log_returns_from_daily(p)

ai_monthly = pd.DataFrame(ai_series).sort_index()
# Use complete-case equal-weighted AI basket.
ai_monthly_complete = ai_monthly.dropna(how='any')
ai_monthly_complete['AI_raw_log'] = ai_monthly_complete.mean(axis=1)
# Align with FF3 market data and use Dec 2022 onward for AI boom regime.
ai = ai_monthly_complete.join(ff3[['MKT_log']], how='inner')
ai = ai.loc['2022-12-31':].copy()
# Orthogonalize AI factor against market
res_ai = ols(ai['AI_raw_log'].values, ai['MKT_log'].values, add_const=True)
ai['AI_factor_log'] = res_ai['resid']
ai['AI_factor_cum'] = ai['AI_factor_log'].cumsum()
ai['AI_raw_cum'] = ai['AI_raw_log'].cumsum()
ai['MKT_cum'] = ai['MKT_log'].cumsum()
# Signals for current AI
ai_rel = ai['AI_factor_log']
ai['X_growth_signal'] = ewma_past(ai_rel.values, theta=theta, K=min(K, max(3, len(ai_rel)//2))) # because current history short
# For V, use raw cumulative factor above 12m MA due to short sample
L_current = min(12, max(3, len(ai)//2))
ai['V_stretch_signal'] = ai['AI_factor_cum'] - ai['AI_factor_cum'].rolling(L_current, min_periods=L_current).mean()
# Current signals: last available non-null
current_signal = ai[['X_growth_signal','V_stretch_signal']].dropna().iloc[-1]
current_date = ai[['X_growth_signal','V_stretch_signal']].dropna().index[-1]
# Standardize against historical distribution
hist_mu_X = cal_modern['X_growth_signal'].mean(); hist_sd_X = cal_modern['X_growth_signal'].std(ddof=0)
hist_mu_V = cal_modern['V_stretch_signal'].mean(); hist_sd_V = cal_modern['V_stretch_signal'].std(ddof=0)
current_X_z = (current_signal['X_growth_signal']-hist_mu_X)/hist_sd_X
current_V_z = (current_signal['V_stretch_signal']-hist_mu_V)/hist_sd_V
current_B = current_X_z + current_V_z
current_percentile = (cal_modern['B_score'] <= current_B).mean()

ai.to_csv(DAT / 'current_ai_monthly_factor.csv')
current_signal_df = pd.DataFrame([{
    'current_date': current_date.strftime('%Y-%m-%d'),
    'X_growth_signal': current_signal['X_growth_signal'],
    'V_stretch_signal': current_signal['V_stretch_signal'],
    'X_z_vs_history': current_X_z,
    'V_z_vs_history': current_V_z,
    'B_score': current_B,
    'B_percentile_vs_historical_industries': current_percentile,
    'AI_factor_alpha_vs_market': res_ai['beta'][0],
    'AI_raw_market_beta': res_ai['beta'][1],
    'AI_factor_regression_r2': res_ai['r2'],
    'AI_factor_regression_n_months': res_ai['n']
}])
current_signal_df.to_csv(DAT / 'current_ai_signal_summary.csv', index=False)

# Conditional historical drawdown set: states at or above current B, with minimum top decile fallback
threshold = max(current_B, cal_modern['B_score'].quantile(0.80))
cond = cal_modern[cal_modern['B_score'] >= threshold]
if len(cond) < 100:
    threshold = cal_modern['B_score'].quantile(0.90)
    cond = cal_modern[cal_modern['B_score'] >= threshold]
cond_stats = {}
for dep in ['future_min_cum_rel_log_6m','future_min_cum_rel_log_12m','future_min_cum_rel_log_24m']:
    vals = cond[dep].dropna().values
    cond_stats[dep] = {
        'n': len(vals),
        'median': np.median(vals),
        'q25': np.quantile(vals,0.25),
        'q10': np.quantile(vals,0.10),
        'q05': np.quantile(vals,0.05),
    }
cond_summary = pd.DataFrame([{**{'calibration_sample':'conditional_high_B','B_threshold':threshold}, **{f'{k}_{m}':v[m] for k,v in cond_stats.items() for m in v}}])
cond_summary.to_csv(DAT / 'current_conditional_historical_drawdown_calibration.csv', index=False)

# -------------------------------
# Scenario definitions
# -------------------------------
# Use 24m horizon as main stress horizon.
dot_base = dotcom_drawdowns[(dotcom_drawdowns['basket']=='base') & (dotcom_drawdowns['horizon_months']==24)]['log_relative_drawdown'].iloc[0]
dot_broad = dotcom_drawdowns[(dotcom_drawdowns['basket']=='broad') & (dotcom_drawdowns['horizon_months']==24)]['log_relative_drawdown'].iloc[0]
hist_q25 = cond_stats['future_min_cum_rel_log_24m']['q25']
hist_q10 = cond_stats['future_min_cum_rel_log_24m']['q10']
hist_q05 = cond_stats['future_min_cum_rel_log_24m']['q05']
# Scenarios: mild = conditional q25; base = dot-com base 24m relative drawdown; severe = min of conditional q05 and 1.25*dotcom (more negative)
S_mild = hist_q25
S_base = dot_base
S_severe = min(hist_q05, 1.25*dot_base)
scenarios = pd.DataFrame([
    {'scenario':'mild','AI_factor_log_shock':S_mild,'AI_factor_simple_equiv':np.exp(S_mild)-1,'calibration':'25th percentile of future 24m relative drawdowns in high-signal historical FF49 states'},
    {'scenario':'base','AI_factor_log_shock':S_base,'AI_factor_simple_equiv':np.exp(S_base)-1,'calibration':'dot-com base TMT 24m relative drawdown'},
    {'scenario':'severe','AI_factor_log_shock':S_severe,'AI_factor_simple_equiv':np.exp(S_severe)-1,'calibration':'min(5th percentile high-signal historical drawdown, 1.25 x dot-com base drawdown)'},
])
scenarios.to_csv(DAT / 'scenario_definitions.csv', index=False)

# -------------------------------
# Stock-level AI vector
# -------------------------------
# Estimate lambda_i and market beta using current monthly returns.
stock_rows = []
for ticker in ai_series.keys():
    df = ai[[ticker, 'AI_factor_log', 'MKT_log']].dropna() if ticker in ai.columns else None
    if df is None or len(df) < 12:
        continue
    res = ols(df[ticker].values, df[['AI_factor_log','MKT_log']].values, add_const=True)
    row = {
        'ticker': ticker,
        'n_months': res['n'],
        'alpha': res['beta'][0],
        'lambda_AI_factor': res['beta'][1],
        'beta_market': res['beta'][2],
        't_lambda_AI': res['t'][1],
        't_beta_market': res['t'][2],
        'r2': res['r2']
    }
    for _, srow in scenarios.iterrows():
        log_ret = res['beta'][1] * srow['AI_factor_log_shock']
        row[f'{srow.scenario}_log_return'] = log_ret
        row[f'{srow.scenario}_simple_return'] = np.exp(log_ret)-1
    stock_rows.append(row)
stock_vec = pd.DataFrame(stock_rows).sort_values('base_simple_return')
stock_vec.to_csv(DAT / 'stress_vector_ai_stocks.csv', index=False)

# -------------------------------
# Industry spillover vector from recent data
# -------------------------------
# Align FF49 monthly industry log returns, AI factor and market over current period.
recent = ff49_log.join(ai[['AI_factor_log','MKT_log']], how='inner')
industry_rows = []
for industry in columns:
    df = recent[[industry,'AI_factor_log','MKT_log']].dropna()
    if len(df) < 18:
        continue
    res = ols(df[industry].values, df[['AI_factor_log','MKT_log']].values, add_const=True)
    row = {
        'industry': industry,
        'n_months': res['n'],
        'beta_AI_spillover': res['beta'][1],
        'beta_market': res['beta'][2],
        't_beta_AI': res['t'][1],
        't_beta_market': res['t'][2],
        'r2': res['r2']
    }
    for _, srow in scenarios.iterrows():
        log_ret = res['beta'][1] * srow['AI_factor_log_shock']
        row[f'{srow.scenario}_log_return'] = log_ret
        row[f'{srow.scenario}_simple_return'] = np.exp(log_ret)-1
    industry_rows.append(row)
industry_vec = pd.DataFrame(industry_rows).sort_values('base_simple_return')
industry_vec.to_csv(DAT / 'stress_vector_ff49_industries.csv', index=False)

# -------------------------------
# SPY direct AI concentration impact
# -------------------------------
try:
    holdings = pd.read_excel(ROOT / 'holdings-daily-us-en-spy.xlsx', sheet_name='holdings', header=4)
    holdings = holdings.dropna(subset=['Ticker','Weight']).copy()
    holdings['Ticker'] = holdings['Ticker'].astype(str).str.strip().str.upper()
    holdings['Weight_decimal'] = pd.to_numeric(holdings['Weight'], errors='coerce')/100.0
    # Direct AI universe in holdings: AI tickers plus GOOG proxy to GOOGL, plus MU optional? Keep only modelled names.
    stock_shock_lookup = stock_vec.set_index('ticker').to_dict('index')
    map_proxy = {'GOOG':'GOOGL'}
    hrows = []
    for _, r in holdings.iterrows():
        tk = r['Ticker']
        model_tk = map_proxy.get(tk, tk)
        if model_tk in stock_shock_lookup:
            rec = {'ticker': tk, 'model_ticker': model_tk, 'name': r['Name'], 'weight_decimal': r['Weight_decimal']}
            for sc in scenarios['scenario']:
                ret = stock_shock_lookup[model_tk][f'{sc}_simple_return']
                rec[f'{sc}_simple_return'] = ret
                rec[f'{sc}_direct_index_impact'] = r['Weight_decimal'] * ret
            hrows.append(rec)
    spy_ai = pd.DataFrame(hrows).sort_values('weight_decimal', ascending=False)
    spy_ai.to_csv(DAT / 'spy_ai_holdings_direct_impacts.csv', index=False)
    idx_rows = []
    for sc in scenarios['scenario']:
        idx_rows.append({
            'scenario': sc,
            'ai_weight_in_spy_modelled': spy_ai['weight_decimal'].sum(),
            'direct_index_impact_simple': spy_ai[f'{sc}_direct_index_impact'].sum(),
            'direct_index_impact_pct': 100*spy_ai[f'{sc}_direct_index_impact'].sum(),
            'note': 'Direct impact only, based on modelled AI names in SPY; sector spillover vector reported separately because current SPY holdings file lacks usable sector/industry mapping.'
        })
    index_summary = pd.DataFrame(idx_rows)
    index_summary.to_csv(DAT / 'spy_direct_index_impact_summary.csv', index=False)
except Exception as e:
    spy_ai = pd.DataFrame()
    index_summary = pd.DataFrame([{'error':str(e)}])
    index_summary.to_csv(DAT / 'spy_direct_index_impact_summary.csv', index=False)

# -------------------------------
# Output combined vector
# -------------------------------
combined_rows = []
for _, r in stock_vec.iterrows():
    rec = {'type':'AI_STOCK','name':r['ticker'],'loading':r['lambda_AI_factor']}
    for sc in scenarios['scenario']:
        rec[f'{sc}_log_return'] = r[f'{sc}_log_return']
        rec[f'{sc}_simple_return'] = r[f'{sc}_simple_return']
    combined_rows.append(rec)
for _, r in industry_vec.iterrows():
    rec = {'type':'FF49_INDUSTRY','name':r['industry'],'loading':r['beta_AI_spillover']}
    for sc in scenarios['scenario']:
        rec[f'{sc}_log_return'] = r[f'{sc}_log_return']
        rec[f'{sc}_simple_return'] = r[f'{sc}_simple_return']
    combined_rows.append(rec)
combined = pd.DataFrame(combined_rows)
combined.to_csv(DAT / 'stress_vector_combined.csv', index=False)

# -------------------------------
# Visualizations
# -------------------------------
plt.rcParams.update({'font.size': 10})

# 1. Dot-com TMT cumulative relative wealth
fig, ax = plt.subplots(figsize=(8,4.5))
for basket_name in ['base','broad']:
    series = hist[f'TMT_{basket_name}_cum_rel'].loc['1995-01-31':'2004-12-31']
    ax.plot(series.index, np.exp(series)-1, label=f'TMT {basket_name}')
ax.axhline(0, linewidth=0.8)
ax.set_title('Dot-com TMT relative performance vs market')
ax.set_ylabel('Cumulative relative return')
ax.legend()
fig.autofmt_xdate()
fig.tight_layout()
fig.savefig(FIG / '01_dotcom_tmt_relative_performance.png', dpi=180)
plt.close(fig)

# 2. Historical signal vs future drawdown scatter
plot_sample = cal_modern.sample(min(5000, len(cal_modern)), random_state=0)
fig, ax = plt.subplots(figsize=(7,4.5))
ax.scatter(plot_sample['B_score'], plot_sample['future_min_cum_rel_log_24m'], s=6, alpha=0.25)
ax.axvline(current_B, linestyle='--', linewidth=1.0, label='Current AI signal score')
ax.set_title('Historical FF49 states: signal score vs future 24m drawdown')
ax.set_xlabel('B score = z(growth signal) + z(stretch signal)')
ax.set_ylabel('Future 24m min cumulative relative log return')
ax.legend()
fig.tight_layout()
fig.savefig(FIG / '02_historical_signal_vs_drawdown.png', dpi=180)
plt.close(fig)

# 3. Current AI factor cumulative performance
fig, ax = plt.subplots(figsize=(8,4.5))
ax.plot(ai.index, np.exp(ai['AI_raw_cum'])-1, label='AI raw equal-weight')
ax.plot(ai.index, np.exp(ai['MKT_cum'])-1, label='Market')
ax.plot(ai.index, np.exp(ai['AI_factor_cum'])-1, label='AI factor residual')
ax.axhline(0, linewidth=0.8)
ax.set_title('Current AI basket and pure AI factor')
ax.set_ylabel('Cumulative return')
ax.legend()
fig.autofmt_xdate()
fig.tight_layout()
fig.savefig(FIG / '03_current_ai_factor.png', dpi=180)
plt.close(fig)

# 4. Scenario definitions
fig, ax = plt.subplots(figsize=(7,4.5))
ax.bar(scenarios['scenario'], 100*scenarios['AI_factor_simple_equiv'])
ax.axhline(0, linewidth=0.8)
ax.set_title('AI factor shock scenarios')
ax.set_ylabel('Simple return equivalent (%)')
fig.tight_layout()
fig.savefig(FIG / '04_ai_shock_scenarios.png', dpi=180)
plt.close(fig)

# 5. AI stock vector base returns
fig, ax = plt.subplots(figsize=(8,4.5))
plot_stock = stock_vec.sort_values('base_simple_return')
ax.bar(plot_stock['ticker'], 100*plot_stock['base_simple_return'])
ax.axhline(0, linewidth=0.8)
ax.set_title('Base scenario: AI stock stress vector')
ax.set_ylabel('Simple return (%)')
fig.autofmt_xdate(rotation=45)
fig.tight_layout()
fig.savefig(FIG / '05_base_ai_stock_vector.png', dpi=180)
plt.close(fig)

# 6. Industry spillover vector base returns (most negative 15)
fig, ax = plt.subplots(figsize=(8,5.0))
plot_ind = industry_vec.sort_values('base_simple_return').head(15).iloc[::-1]
ax.barh(plot_ind['industry'], 100*plot_ind['base_simple_return'])
ax.axvline(0, linewidth=0.8)
ax.set_title('Base scenario: most negative FF49 industry spillovers')
ax.set_xlabel('Simple return (%)')
fig.tight_layout()
fig.savefig(FIG / '06_base_industry_spillover_vector.png', dpi=180)
plt.close(fig)

# 7. SPY direct impact decomposition by name
if not spy_ai.empty:
    fig, ax = plt.subplots(figsize=(8,4.5))
    plot_spy = spy_ai.sort_values('base_direct_index_impact').copy()
    ax.bar(plot_spy['ticker'], 100*plot_spy['base_direct_index_impact'])
    ax.axhline(0, linewidth=0.8)
    ax.set_title('Base scenario: direct S&P 500 impact by AI constituent')
    ax.set_ylabel('Index impact (percentage points)')
    fig.autofmt_xdate(rotation=45)
    fig.tight_layout()
    fig.savefig(FIG / '07_base_spy_direct_impact_by_name.png', dpi=180)
    plt.close(fig)

# -------------------------------
# Text summaries for LaTeX
# -------------------------------
# Prepare selected tables rounded for report.
def pct(x): return 100*x
scenario_report = scenarios.copy()
scenario_report['AI_factor_simple_equiv_pct'] = 100*scenario_report['AI_factor_simple_equiv']
scenario_report.to_csv(DAT / 'report_scenario_table.csv', index=False)
stock_report = stock_vec[['ticker','lambda_AI_factor','beta_market','base_simple_return','mild_simple_return','severe_simple_return','r2','n_months']].copy()
for c in ['base_simple_return','mild_simple_return','severe_simple_return']:
    stock_report[c+'_pct'] = 100*stock_report[c]
stock_report.to_csv(DAT / 'report_ai_stock_vector_table.csv', index=False)
industry_report = industry_vec[['industry','beta_AI_spillover','base_simple_return','mild_simple_return','severe_simple_return','r2','n_months']].copy()
for c in ['base_simple_return','mild_simple_return','severe_simple_return']:
    industry_report[c+'_pct'] = 100*industry_report[c]
industry_report.to_csv(DAT / 'report_industry_vector_table.csv', index=False)

# Analysis metadata
metadata = {
    'ff3_start': ff3.index.min().strftime('%Y-%m-%d'),
    'ff3_end': ff3.index.max().strftime('%Y-%m-%d'),
    'ff49_start': ff49_log.index.min().strftime('%Y-%m-%d'),
    'ff49_end': ff49_log.index.max().strftime('%Y-%m-%d'),
    'ai_start': ai.index.min().strftime('%Y-%m-%d'),
    'ai_end': ai.index.max().strftime('%Y-%m-%d'),
    'n_ai_months': len(ai),
    'ai_tickers': ','.join(ai_series.keys()),
    'tmt_base': ','.join(tmt_base),
    'tmt_broad': ','.join(tmt_broad),
    'historical_calibration_n': len(cal_modern),
    'current_ai_signal_date': current_date.strftime('%Y-%m-%d'),
    'current_B_score': current_B,
    'current_B_percentile': current_percentile,
    'conditional_B_threshold': threshold,
    'conditional_sample_n': len(cond),
}
pd.DataFrame([metadata]).to_csv(DAT / 'analysis_metadata.csv', index=False)

print('Analysis complete.')
print('Key outputs:')
print('Scenarios:')
print(scenarios.to_string(index=False))
print('\nCurrent signal:')
print(current_signal_df.to_string(index=False))
print('\nSPY direct impact:')
print(index_summary.to_string(index=False))
print('\nTop AI stock shocks:')
print(stock_vec[['ticker','lambda_AI_factor','base_simple_return']].to_string(index=False))
print('\nTop industry spillovers:')
print(industry_vec[['industry','beta_AI_spillover','base_simple_return']].head(10).to_string(index=False))
