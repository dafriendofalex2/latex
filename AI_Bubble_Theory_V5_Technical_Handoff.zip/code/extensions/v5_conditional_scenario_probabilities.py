"""Burst-conditional five-case severity probability layer."""
import numpy as np
import pandas as pd
from scipy import stats, optimize

BURST_THRESHOLD = 0.40
ORDER = ['mild','base','severe','extreme','worst']


def build_scenario_cells(scenario_parameters_v5):
    scen3 = scenario_parameters_v5.copy()
    base_kappa = float(scen3.loc[scen3.scenario.eq('base'), 'valuation_severity_scalar'].iloc[0])
    world_log = float(scen3.loc[scen3.scenario.eq('severe'), 'S_WORLD_log'].iloc[0])
    severe_excess_log = float(scen3.loc[scen3.scenario.eq('severe'), 'S_AI_EXCESS_log'].iloc[0])
    rows = []
    for s in ['mild','base','severe']:
        r = scen3[scen3.scenario.eq(s)].iloc[0]
        rows.append(dict(scenario=s, kappa=float(r['valuation_severity_scalar']),
                         world_scale=float(r['world_scale']),
                         epicenter_log=float(r['S_AI_EPICENTER_log']),
                         epicenter_drawdown=float(-r['S_AI_EPICENTER_simple'])))
    for s,k in [('extreme',1.5),('worst',2.0)]:
        L = -(world_log + k*severe_excess_log)
        rows.append(dict(scenario=s,kappa=k,world_scale=1.0,
                         epicenter_log=-L,epicenter_drawdown=1-np.exp(-L)))
    scenario = pd.DataFrame(rows).set_index('scenario').loc[ORDER].reset_index()
    scenario['loss_log'] = -scenario['epicenter_log']
    L = scenario['loss_log'].to_numpy()
    bound_L = (L[:-1] + L[1:]) / 2.0
    bound_D = 1.0 - np.exp(-bound_L)
    scenario['cell_lower_drawdown'] = np.array([BURST_THRESHOLD, *bound_D])
    scenario['cell_upper_drawdown'] = np.array([*bound_D, 1.0])
    return scenario


def aicc(loglik, k, n):
    return -2*loglik + 2*k + 2*k*(k+1)/(n-k-1)


def _cell_probs_from_cdf(cdf, scenario):
    lo = scenario['cell_lower_drawdown'].to_numpy()
    hi = scenario['cell_upper_drawdown'].to_numpy()
    return np.maximum(0.0, np.array([cdf(h)-cdf(l) for l,h in zip(lo,hi)]))


def fit_beta_normalized(drawdowns, scenario):
    u = BURST_THRESHOLD
    y = (np.asarray(drawdowns)-u)/(1-u)
    y = np.clip(y, 1e-9, 1-1e-9)
    a,b,_,_ = stats.beta.fit(y, floc=0, fscale=1)
    ll = float(np.sum(stats.beta.logpdf(y,a,b))) - len(y)*np.log(1-u)
    def cdf_d(d):
        if d <= u: return 0.0
        if d >= 1: return 1.0
        return float(stats.beta.cdf((d-u)/(1-u),a,b))
    return {'name':'beta_normalized','params':(a,b),'loglik':ll,'k':2,
            'probs':_cell_probs_from_cdf(cdf_d,scenario)}


def _fit_excess_logloss(drawdowns, scenario, dist_name):
    uL = -np.log(1-BURST_THRESHOLD)
    loss = -np.log(1-np.asarray(drawdowns))
    x = np.maximum(loss-uL, 1e-9)
    if dist_name == 'gamma':
        shape,loc,scale = stats.gamma.fit(x, floc=0); dist=stats.gamma; params=(shape,0,scale)
    elif dist_name == 'weibull':
        shape,loc,scale = stats.weibull_min.fit(x, floc=0); dist=stats.weibull_min; params=(shape,0,scale)
    elif dist_name == 'lognormal':
        shape,loc,scale = stats.lognorm.fit(x, floc=0); dist=stats.lognorm; params=(shape,0,scale)
    else:
        raise ValueError(dist_name)
    ll = float(np.sum(dist.logpdf(x,*params))) + float(np.sum(-np.log(1-np.asarray(drawdowns))))
    def cdf_d(d):
        if d <= BURST_THRESHOLD: return 0.0
        if d >= 1: return 1.0
        ld = -np.log(1-d)
        return float(dist.cdf(max(ld-uL,0),*params))
    return {'name':dist_name,'params':params,'loglik':ll,'k':2,
            'probs':_cell_probs_from_cdf(cdf_d,scenario)}


def fit_model_average(drawdowns, scenario):
    d = np.asarray(drawdowns, dtype=float)
    d = d[(d >= BURST_THRESHOLD) & (d < 1.0)]
    fits = [fit_beta_normalized(d,scenario)] + [
        _fit_excess_logloss(d,scenario,n) for n in ['gamma','weibull','lognormal']]
    for x in fits:
        x['aicc'] = aicc(x['loglik'],x['k'],len(d))
    amin = min(x['aicc'] for x in fits)
    wr = np.array([np.exp(-0.5*(x['aicc']-amin)) for x in fits])
    w = wr/wr.sum()
    p = sum(ww*x['probs'] for ww,x in zip(w,fits))
    p = p/p.sum()
    return p, fits, w


def bootstrap_probabilities(drawdowns, scenario, n_boot=5000, seed=42):
    rng = np.random.default_rng(seed)
    d = np.asarray(drawdowns, dtype=float)
    d = d[(d >= BURST_THRESHOLD) & (d < 1.0)]
    out=[]
    for _ in range(n_boot):
        sample = rng.choice(d, size=len(d), replace=True)
        try:
            p,_,_ = fit_model_average(sample,scenario)
            out.append(p)
        except Exception:
            continue
    return np.asarray(out)


def jeffreys_dirichlet_crosscheck(drawdowns, scenario):
    d=np.asarray(drawdowns,float)
    counts=[]
    for lo,hi in zip(scenario.cell_lower_drawdown,scenario.cell_upper_drawdown):
        counts.append(int(((d>=lo)&(d<hi if hi<1 else d<=hi)).sum()))
    alpha=np.asarray(counts,float)+0.5
    return alpha/alpha.sum(), np.asarray(counts)
