Revised theory slides. Slide 3 has a cleaned-up orthogonalization derivation with consistent symbols, variable labels, and plain-English explanation.
