# AI Bubble / AI Unwind Theory V5 - Final Technical Handoff

This bundle is designed for leadership review, technical replication, and model-governance handoff.

Primary files:
- `AI_Bubble_Theory_V5_Technical_Handoff.tex` - portable LaTeX source.
- `AI_Bubble_Theory_V5_Technical_Handoff.pdf` - compiled review copy.
- `code/original_v5/` - original V5 model core and exact position-application template.
- `code/research_reference/` - executable reference for the upstream factor-estimation theory consumed by V5.
- `code/extensions/` - explicitly labelled post-V5 extensions.
- `documentation/SOURCE_LINEAGE.md` - exact-vs-recovered source-fidelity notes.

Compile from the bundle root with:

```bash
pdflatex -interaction=nonstopmode AI_Bubble_Theory_V5_Technical_Handoff.tex
pdflatex -interaction=nonstopmode AI_Bubble_Theory_V5_Technical_Handoff.tex
```

The LaTeX uses standard packages only and embeds code through `listings` / `\lstinputlisting`.
