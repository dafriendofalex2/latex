# AI country-industry stress research v5

This package contains the coherent valuation-calibrated AI unwind stress model.

Main outputs:
- `main.pdf`: presentation-ready report.
- `data/country_industry_stress_vector_v5.csv`: merge-ready country x industry vector.
- `data/single_stock_override_vector_v5.csv`: single-stock override vector for AI epicenter names.
- `data/scenario_parameters_v5.csv`: mild, base, and severe scenario settings.
- `data/coherence_diagnostics_v5.csv`: index-versus-technology hardware checks by country.
- `code/apply_stress_to_client_template_v5.py`: merge template for position-level data.
- `code/build_ai_country_industry_stress_v5.py`: replication code.

Key base outputs:
- Base valuation severity scalar: 0.671
- S&P 500 proxy base stress: -37.0%
- Korea broad ETF base stress: -46.2%
- Korea technology hardware base stress: -53.5%
- NVDA base stress: -63.3%
