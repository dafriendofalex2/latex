AI Dot-Com Comparison - 310 Trading Day Narrative Window

This bundle remakes the four-slide NASDAQ comparison deck using a 310-trading-day window chosen to provide a visually closer match while still being comfortably longer than 200 trading days.

Key outputs
- Window length: 310 trading days
- Current window: 2025-05-20 to 2026-08-13
- Dot-com peak: 2000-03-27
- Best-fit lead: 300 trading days
- Final-window path correlation: 0.8999
- Final-window RMSE: 0.2001
- Best-fit RMSE: 0.0880
- Best-fit correlation: 0.8429
- Remaining historical move from matched point: 131.3373%

Note
This deck is intended as a narrative similarity illustration rather than a core model input.
