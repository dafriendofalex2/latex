Revised theory slides. Slide 3 has been rebuilt with consistent variables, projection-style math, and clean formatting.
